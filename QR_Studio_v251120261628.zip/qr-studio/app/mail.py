"""Servidor SMTP del sitio y envío de correos (recuperar la contraseña, correo de prueba).

La configuración la pone el administrador en Ajustes → Correo y vive en la tabla app_settings. La contraseña
del SMTP se guarda en la base de datos (igual que el resto de ajustes) y NUNCA se devuelve a la página: solo
se informa de si hay una guardada. Por defecto el formulario propone los valores de Gmail.
"""

from __future__ import annotations

import logging
import re
import smtplib
import socket
import sqlite3
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid
from urllib.parse import urlparse

log = logging.getLogger("qr_studio.mail")

TIMEOUT = 15
SECURITIES = ("starttls", "ssl", "none")

# Valores que se proponen mientras no se haya guardado nada: una cuenta de Gmail.
GMAIL = {"host": "smtp.gmail.com", "port": 587, "security": "starttls"}

_HOST = re.compile(r"^[A-Za-z0-9.\-]{1,255}$")
_EMAIL = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,63}$")
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")


class MailError(Exception):
    """Error con un mensaje que se le puede enseñar tal cual al administrador."""

    def __init__(self, message: str, status: int = 502):
        super().__init__(message)
        self.message = message
        self.status = status


@dataclass(frozen=True)
class SmtpConfig:
    host: str
    port: int
    security: str
    user: str
    password: str
    sender: str
    sender_name: str


# ----- Guardar y leer la configuración -------------------------------------------------------------

def _get(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
    return default if row is None else row["value"]


def _set(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def is_gmail(host: str) -> bool:
    return host.lower().endswith(("gmail.com", "googlemail.com"))


def load(conn: sqlite3.Connection) -> SmtpConfig | None:
    """La configuración lista para usar, o None si falta el servidor o el remitente."""
    host = _get(conn, "smtp_host")
    sender = _get(conn, "smtp_from")
    if not host or not sender:
        return None
    try:
        port = int(_get(conn, "smtp_port", str(GMAIL["port"])))
    except ValueError:
        return None
    security = _get(conn, "smtp_security", GMAIL["security"])
    if security not in SECURITIES:
        return None
    return SmtpConfig(
        host=host,
        port=port,
        security=security,
        user=_get(conn, "smtp_user"),
        password=_get(conn, "smtp_password"),
        sender=sender,
        sender_name=_get(conn, "smtp_from_name"),
    )


def site_url(conn: sqlite3.Connection, env_value: str = "") -> str:
    """Dirección pública del sitio para los enlaces de los correos. APP_PUBLIC_URL manda sobre lo guardado.

    No se deduce de la petición: una cabecera Host falsa permitiría mandar enlaces a otro sitio."""
    return (env_value or _get(conn, "site_url")).rstrip("/")


def public_view(conn: sqlite3.Connection, env_site_url: str = "") -> dict:
    """Lo que ve el administrador. Sin contraseña: solo si hay una guardada."""
    host = _get(conn, "smtp_host")
    configured = load(conn) is not None
    try:
        port = int(_get(conn, "smtp_port", str(GMAIL["port"])))
    except ValueError:
        port = GMAIL["port"]
    return {
        "configured": configured,
        "host": host or GMAIL["host"],
        "port": port,
        "security": _get(conn, "smtp_security", GMAIL["security"]),
        "user": _get(conn, "smtp_user"),
        "passwordSet": bool(_get(conn, "smtp_password")),
        "sender": _get(conn, "smtp_from"),
        "senderName": _get(conn, "smtp_from_name"),
        "siteUrl": _get(conn, "site_url"),
        "siteUrlFromEnv": env_site_url,
        "recoveryEnabled": configured and bool(site_url(conn, env_site_url)),
        "defaults": {"gmail": GMAIL},
    }


def _line(value: str, label: str, maximum: int) -> str:
    value = value.strip()
    if _CONTROL.search(value):
        raise MailError(f"«{label}» tiene caracteres no válidos.", 422)
    if len(value) > maximum:
        raise MailError(f"«{label}» es demasiado largo (máximo {maximum} caracteres).", 422)
    return value


def save(
    conn: sqlite3.Connection,
    *,
    host: str,
    port: int,
    security: str,
    user: str,
    password: str | None,
    clear_password: bool,
    sender: str,
    sender_name: str,
    site: str,
) -> None:
    host = _line(host, "Servidor", 255)
    if not _HOST.match(host):
        raise MailError("Escribe el servidor SMTP, por ejemplo smtp.gmail.com.", 422)
    if isinstance(port, bool) or not 1 <= port <= 65535:
        raise MailError("El puerto debe estar entre 1 y 65535.", 422)
    if security not in SECURITIES:
        raise MailError("La seguridad debe ser STARTTLS, SSL/TLS o ninguna.", 422)
    user = _line(user, "Usuario", 254)
    sender = _line(sender, "Remitente", 254)
    if not _EMAIL.match(sender):
        raise MailError("Escribe un correo válido como remitente (el campo «De»).", 422)
    sender_name = _line(sender_name, "Nombre del remitente", 80)
    site = _line(site, "Dirección del sitio", 200).rstrip("/")
    if site:
        parts = urlparse(site)
        if parts.scheme not in ("http", "https") or not parts.netloc or parts.query or parts.fragment or " " in site:
            raise MailError("La dirección del sitio debe ser como https://qr.midominio.com", 422)

    _set(conn, "smtp_host", host)
    _set(conn, "smtp_port", str(port))
    _set(conn, "smtp_security", security)
    _set(conn, "smtp_user", user)
    _set(conn, "smtp_from", sender)
    _set(conn, "smtp_from_name", sender_name)
    _set(conn, "site_url", site)
    if clear_password:
        _set(conn, "smtp_password", "")
    elif password:
        if "\r" in password or "\n" in password or len(password) > 256:
            raise MailError("La contraseña del correo no es válida.", 422)
        # Google muestra las contraseñas de aplicación en grupos con espacios; sin ellos también valen.
        _set(conn, "smtp_password", password.replace(" ", "") if is_gmail(host) else password)


# ----- Enviar ----------------------------------------------------------------------------------------

def send(cfg: SmtpConfig, to: str, subject: str, body: str) -> None:
    """Envía un correo de texto. Lanza MailError con un mensaje claro si algo falla."""
    msg = EmailMessage()
    msg["From"] = formataddr((cfg.sender_name, cfg.sender)) if cfg.sender_name else cfg.sender
    msg["To"] = to
    msg["Subject"] = subject
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=cfg.sender.rsplit("@", 1)[-1])
    msg.set_content(body)

    context = ssl.create_default_context()
    try:
        # local_hostname fijo: si no, smtplib consulta el DNS (getfqdn) en cada envío y puede tardar segundos.
        if cfg.security == "ssl":
            server = smtplib.SMTP_SSL(cfg.host, cfg.port, local_hostname="localhost", timeout=TIMEOUT, context=context)
        else:
            server = smtplib.SMTP(cfg.host, cfg.port, local_hostname="localhost", timeout=TIMEOUT)
        with server:
            server.ehlo()
            if cfg.security == "starttls":
                server.starttls(context=context)
                server.ehlo()
            if cfg.user:
                server.login(cfg.user, cfg.password)
            server.send_message(msg)
    except smtplib.SMTPAuthenticationError:
        if is_gmail(cfg.host):
            raise MailError(
                "Gmail rechazó el usuario o la contraseña. Usa tu dirección completa como usuario y una "
                "«contraseña de aplicación» (hace falta la verificación en 2 pasos), no la contraseña normal."
            ) from None
        raise MailError("El servidor rechazó el usuario o la contraseña.") from None
    except smtplib.SMTPRecipientsRefused:
        raise MailError("El servidor no aceptó el destinatario.") from None
    except smtplib.SMTPSenderRefused:
        raise MailError("El servidor no aceptó el remitente: el campo «De» debe ser una dirección permitida.") from None
    except smtplib.SMTPNotSupportedError:
        raise MailError("El servidor no admite esa seguridad o ese inicio de sesión. Revisa el tipo de seguridad.") from None
    except smtplib.SMTPServerDisconnected:
        raise MailError(
            f"El servidor cerró la conexión. Revisa el puerto ({cfg.port}) y el tipo de seguridad."
        ) from None
    except smtplib.SMTPException:
        raise MailError("El servidor SMTP respondió con un error.") from None
    except ssl.SSLError:
        raise MailError("Falló la conexión segura (TLS). Revisa el puerto y el tipo de seguridad.") from None
    except UnicodeEncodeError:
        raise MailError("El usuario o la contraseña tienen caracteres que el servidor no admite.") from None
    except socket.gaierror:
        raise MailError(f"No se encuentra el servidor «{cfg.host}». Revisa el nombre.") from None
    except TimeoutError:
        raise MailError("El servidor tardó demasiado en responder.") from None
    except OSError:
        raise MailError(f"No se pudo conectar a {cfg.host}:{cfg.port}.") from None


def send_quietly(cfg: SmtpConfig, to: str, subject: str, body: str) -> None:
    """Para tareas en segundo plano: un fallo se anota en el registro (sin datos privados) y no se propaga."""
    try:
        send(cfg, to, subject, body)
    except MailError as exc:
        log.warning("No se pudo enviar un correo: %s", exc.message)
    except Exception:  # noqa: BLE001 - nada de lo que pase aquí debe tumbar la petición
        log.exception("Error inesperado al enviar un correo")


def reset_message(name: str, link: str, minutes: int) -> tuple[str, str]:
    subject = "Restablece tu contraseña de QR Studio"
    body = (
        f"Hola {name},\n\n"
        "Pediste restablecer la contraseña de tu cuenta de QR Studio. Abre este enlace para elegir una nueva:\n\n"
        f"{link}\n\n"
        f"El enlace funciona una sola vez y caduca en {minutes} minutos.\n\n"
        "Si no lo pediste tú, ignora este correo: tu contraseña no cambia.\n"
    )
    return subject, body


def probe_message() -> tuple[str, str]:
    return (
        "Correo de prueba de QR Studio",
        "Si lees esto, el servidor SMTP de QR Studio funciona.\n\n"
        "Ya se pueden enviar los enlaces para recuperar la contraseña.\n",
    )
