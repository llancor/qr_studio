// Ajustes, separados por secciones en un menú lateral:
//   · Personalización (la ve cualquier usuario; la maneja js/personalizacion.js).
//   · Solo administrador: Usuarios (crear, editar nombre y correo, restablecer contraseña, activar o desactivar,
//     cambiar el rol), Crear cuentas (abrir o cerrar el registro) y Correo (servidor SMTP para recuperar contraseñas).
// El servidor comprueba el rol en cada petición; esta página solo es la interfaz. Todo texto que llega del
// servidor se escribe con textContent.

const $ = (id) => document.getElementById(id);

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  return data;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

/** Contraseña al azar sin caracteres que se confundan (0/O, 1/l/I). */
export function randomPassword(length = 14) {
  const alphabet = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const limit = 256 - (256 % alphabet.length); // evita sesgo al repartir los bytes
  let out = '';
  while (out.length < length) {
    for (const byte of crypto.getRandomValues(new Uint8Array(length * 2))) {
      if (byte < limit && out.length < length) out += alphabet[byte % alphabet.length];
    }
  }
  return out;
}

let me = null;
let users = [];
let statusTimer = 0;

/** Aviso arriba de la página. `sticky`: no se quita solo (para algo que hay que copiar, como una contraseña). */
function say(message, isError = false, sticky = false) {
  const box = $('ad-status');
  box.textContent = message;
  box.hidden = !message;
  box.classList.toggle('is-error', isError);
  clearTimeout(statusTimer);
  if (message && !sticky) statusTimer = setTimeout(() => (box.hidden = true), 8000);
}

function setFieldError(id, message) {
  $(id).textContent = message || '';
  $(id).hidden = !message;
}

// ----- Crear cuentas: abrir o cerrar -------------------------------------------

function showRegistration(open) {
  $('ad-registration').checked = open;
  $('ad-registration-hint').textContent = open
    ? 'Ahora cualquiera puede crear una cuenta desde la página de entrada.'
    : 'Ahora nadie puede crear una cuenta por su cuenta: solo tú, desde esta página. Quien ya tiene cuenta sigue entrando.';
}

$('ad-registration').addEventListener('change', async (event) => {
  const wanted = event.target.checked;
  event.target.disabled = true;
  try {
    const data = await api('/api/admin/settings', { method: 'PUT', body: { registrationOpen: wanted } });
    showRegistration(data.registrationOpen);
    say(data.registrationOpen ? 'Se permite crear cuentas.' : 'Se desactivó la creación de cuentas.');
  } catch (err) {
    showRegistration(!wanted);
    say(err.message, true);
  } finally {
    event.target.disabled = false;
  }
});

// ----- Lista de usuarios ---------------------------------------------------------

function formatDate(iso) {
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleDateString('es', { year: 'numeric', month: 'short', day: 'numeric' });
}

function badge(text, kind) {
  return el('span', `admin-badge admin-badge-${kind}`, text);
}

function renderUsers() {
  const list = $('ad-users');
  list.replaceChildren();
  for (const user of users) {
    const row = el('div', 'admin-user' + (user.active ? '' : ' is-off'));

    const who = el('div', 'admin-who');
    const title = el('strong', 'admin-name', user.name);
    who.append(title);
    if (user.id === me.id) who.append(el('span', 'admin-you', ' (tú)'));
    who.append(el('span', 'admin-email', user.email));
    const tags = el('span', 'admin-tags');
    tags.append(badge(user.role === 'admin' ? 'Administrador' : 'Usuario', user.role === 'admin' ? 'admin' : 'user'));
    if (!user.active) tags.append(badge('Desactivada', 'off'));
    const created = formatDate(user.createdAt);
    if (created) tags.append(el('span', 'admin-date', `Desde ${created}`));
    who.append(tags);
    row.append(who);

    const actions = el('div', 'admin-actions');
    const edit = el('button', 'btn btn-small', 'Editar');
    edit.type = 'button';
    edit.addEventListener('click', () => openEdit(user));
    actions.append(edit);

    const reset = el('button', 'btn btn-small', 'Restablecer contraseña');
    reset.type = 'button';
    reset.addEventListener('click', () => openReset(user));
    actions.append(reset);

    const toggle = el('button', 'btn btn-small', user.active ? 'Desactivar' : 'Activar');
    toggle.type = 'button';
    toggle.disabled = user.id === me.id; // el servidor también lo impide
    if (user.id === me.id) toggle.title = 'No puedes desactivar tu propia cuenta.';
    toggle.addEventListener('click', () => change(user, { active: !user.active }, user.active ? 'desactivada' : 'activada'));
    actions.append(toggle);

    const role = el('button', 'btn btn-small', user.role === 'admin' ? 'Quitar administrador' : 'Hacer administrador');
    role.type = 'button';
    role.addEventListener('click', () => change(user, { role: user.role === 'admin' ? 'user' : 'admin' }, 'actualizada'));
    actions.append(role);

    row.append(actions);
    list.append(row);
  }
}

async function loadUsers() {
  users = (await api('/api/admin/users')).users;
  renderUsers();
}

async function change(user, patch, doneWord) {
  if (patch.active === false && !window.confirm(`¿Desactivar la cuenta de ${user.name}? Perderá el acceso de inmediato.`)) return;
  try {
    await api(`/api/admin/users/${user.id}`, { method: 'PATCH', body: patch });
    await loadUsers();
    say(`Cuenta de ${user.name} ${doneWord}.`);
  } catch (err) {
    say(err.message, true);
  }
}

// ----- Crear un usuario ----------------------------------------------------------

$('ad-generate').addEventListener('click', () => {
  $('ad-password').value = randomPassword();
});

$('ad-create').addEventListener('submit', async (event) => {
  event.preventDefault();
  setFieldError('ad-create-error', '');
  const name = $('ad-name').value.trim();
  const email = $('ad-email').value.trim();
  const password = $('ad-password').value;
  if (!name || !email || !password) {
    setFieldError('ad-create-error', 'Completa el nombre, el correo y la contraseña.');
    return;
  }
  $('ad-create-submit').disabled = true;
  try {
    await api('/api/admin/users', { method: 'POST', body: { name, email, password, role: $('ad-role').value } });
    say(`Usuario creado: ${email}. Comparte con esa persona su contraseña inicial: ${password}`, false, true);
    $('ad-create').reset();
    await loadUsers();
  } catch (err) {
    setFieldError('ad-create-error', err.message);
  } finally {
    $('ad-create-submit').disabled = false;
  }
});

// ----- Restablecer contraseña --------------------------------------------------------

let resetting = null;
const dialog = $('ad-dialog');

function openReset(user) {
  resetting = user;
  $('ad-dialog-who').textContent = `${user.name} · ${user.email}`;
  $('ad-new-password').value = randomPassword();
  setFieldError('ad-reset-error', '');
  $('ad-reset-done').hidden = true;
  $('ad-reset-submit').disabled = false;
  dialog.showModal();
  $('ad-new-password').select();
}

$('ad-new-generate').addEventListener('click', () => {
  $('ad-new-password').value = randomPassword();
});
$('ad-dialog-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => {
  if (event.target === dialog) dialog.close();
});

$('ad-copy').addEventListener('click', async () => {
  const button = $('ad-copy');
  try {
    await navigator.clipboard.writeText($('ad-new-password').value);
    button.textContent = 'Copiada';
  } catch {
    $('ad-new-password').select(); // sin permiso de portapapeles: queda seleccionada para copiarla a mano
    button.textContent = 'Cópiala con Ctrl+C';
  }
  setTimeout(() => (button.textContent = 'Copiar contraseña'), 2500);
});

$('ad-reset').addEventListener('submit', async (event) => {
  event.preventDefault();
  setFieldError('ad-reset-error', '');
  const password = $('ad-new-password').value;
  if (!password) {
    setFieldError('ad-reset-error', 'Escribe o genera una contraseña.');
    return;
  }
  $('ad-reset-submit').disabled = true;
  try {
    await api(`/api/admin/users/${resetting.id}/password`, { method: 'POST', body: { password } });
    $('ad-reset-done').textContent = `Listo. Dale esta contraseña a ${resetting.name}; sus sesiones abiertas se cerraron.`;
    $('ad-reset-done').hidden = false;
    say(`Contraseña de ${resetting.name} restablecida.`);
  } catch (err) {
    setFieldError('ad-reset-error', err.message);
    $('ad-reset-submit').disabled = false;
  }
});

// ----- Editar usuario (nombre y correo) --------------------------------------------------------

const editDialog = $('ad-edit-dialog');
let editing = null;

function openEdit(user) {
  editing = user;
  $('ad-edit-name').value = user.name;
  $('ad-edit-email').value = user.email;
  setFieldError('ad-edit-error', '');
  $('ad-edit-submit').disabled = false;
  editDialog.showModal();
  $('ad-edit-name').select();
}

$('ad-edit-close').addEventListener('click', () => editDialog.close());
editDialog.addEventListener('click', (event) => {
  if (event.target === editDialog) editDialog.close();
});
$('ad-edit-reset').addEventListener('click', () => {
  const user = editing;
  editDialog.close();
  if (user) openReset(user);
});

$('ad-edit').addEventListener('submit', async (event) => {
  event.preventDefault();
  setFieldError('ad-edit-error', '');
  const name = $('ad-edit-name').value.trim();
  const email = $('ad-edit-email').value.trim();
  if (!name || !email) {
    setFieldError('ad-edit-error', 'Completa el nombre y el correo.');
    return;
  }
  if (name === editing.name && email.toLowerCase() === editing.email) {
    editDialog.close(); // no cambió nada
    return;
  }
  $('ad-edit-submit').disabled = true;
  try {
    await api(`/api/admin/users/${editing.id}`, { method: 'PATCH', body: { name, email } });
    editDialog.close();
    await loadUsers();
    say(`Datos de ${name} guardados.`);
  } catch (err) {
    setFieldError('ad-edit-error', err.message);
    $('ad-edit-submit').disabled = false;
  }
});

// ----- Correo (servidor SMTP) --------------------------------------------------------------------

// Lo que se propone mientras no haya nada guardado: una cuenta de Gmail.
const GMAIL = { host: 'smtp.gmail.com', port: 587, security: 'starttls' };
const PUERTOS = { starttls: 587, ssl: 465, none: 25 };
let smtpInfo = null;
let lastUser = '';

const isGmailHost = (host) => /(^|\.)(gmail|googlemail)\.com$/i.test(host.trim());

function updateSiteHint() {
  const hint = $('sm-site-hint');
  let local = false;
  try {
    const host = new URL($('sm-site').value).hostname;
    local = host === 'localhost' || host === '127.0.0.1' || host === '[::1]' || host.endsWith('.localhost');
  } catch {
    /* todavía no es una dirección */
  }
  hint.classList.toggle('warn', local);
  hint.textContent = smtpInfo?.siteUrlFromEnv
    ? 'La fija la variable APP_PUBLIC_URL del servidor; aquí no se puede cambiar.'
    : local
      ? 'Ahora es una dirección local: los enlaces solo abrirían en este equipo. Cámbiala por la dirección pública de QR Studio.'
      : 'Va dentro del enlace del correo, así que debe abrirse desde donde estén tus usuarios (no «localhost»).';
}

function updateProviderUi() {
  $('sm-gmail-help').hidden = $('sm-provider').value !== 'gmail';
}

function showSmtp(info) {
  smtpInfo = info;
  $('sm-host').value = info.host;
  $('sm-port').value = info.port;
  $('sm-security').value = info.security;
  $('sm-user').value = info.user;
  lastUser = info.user;
  $('sm-password').value = '';
  $('sm-password').placeholder = info.passwordSet ? 'Guardada. Déjala vacía para conservarla.' : '';
  $('sm-clear-row').hidden = !info.passwordSet;
  $('sm-clear').checked = false;
  $('sm-sender').value = info.sender;
  $('sm-sender-name').value = info.senderName;
  // Sin dirección guardada se propone la que se está usando para entrar a esta página.
  $('sm-site').value = info.siteUrlFromEnv || info.siteUrl || window.location.origin;
  $('sm-site').disabled = Boolean(info.siteUrlFromEnv);
  $('sm-provider').value = isGmailHost(info.host) ? 'gmail' : 'otro';
  updateProviderUi();
  updateSiteHint();

  const state = $('sm-state');
  state.classList.toggle('is-on', info.recoveryEnabled);
  if (info.recoveryEnabled) {
    state.textContent = 'Recuperación de contraseña por correo: activada. En la página de acceso aparece «¿Olvidaste tu contraseña?».';
  } else if (!info.configured) {
    state.textContent = 'Recuperación de contraseña por correo: desactivada. Guarda el servidor y el remitente para activarla.';
  } else {
    state.textContent = 'Recuperación de contraseña por correo: desactivada. Falta la dirección del sitio.';
  }
}

function smtpBody() {
  return {
    host: $('sm-host').value.trim(),
    port: Number($('sm-port').value),
    security: $('sm-security').value,
    user: $('sm-user').value.trim(),
    password: $('sm-password').value || null,
    clearPassword: $('sm-clear').checked,
    sender: $('sm-sender').value.trim(),
    senderName: $('sm-sender-name').value.trim(),
    siteUrl: $('sm-site').value.trim(),
  };
}

async function saveSmtp() {
  const info = await api('/api/admin/smtp', { method: 'PUT', body: smtpBody() });
  showSmtp(info);
  return info;
}

$('sm-provider').addEventListener('change', () => {
  if ($('sm-provider').value === 'gmail') {
    $('sm-host').value = GMAIL.host;
    $('sm-port').value = GMAIL.port;
    $('sm-security').value = GMAIL.security;
  }
  updateProviderUi();
});
$('sm-host').addEventListener('input', () => {
  $('sm-provider').value = isGmailHost($('sm-host').value) ? 'gmail' : 'otro';
  updateProviderUi();
});
$('sm-security').addEventListener('change', () => {
  // Si el puerto es el habitual de otra seguridad, se cambia al de la elegida.
  if (Object.values(PUERTOS).includes(Number($('sm-port').value))) $('sm-port').value = PUERTOS[$('sm-security').value];
});
$('sm-user').addEventListener('input', () => {
  const user = $('sm-user').value.trim();
  const sender = $('sm-sender').value.trim();
  if (!sender || sender === lastUser) $('sm-sender').value = user; // el remitente suele ser el mismo usuario
  lastUser = user;
});
$('sm-site').addEventListener('input', updateSiteHint);

$('sm-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  setFieldError('sm-error', '');
  $('sm-save').disabled = true;
  try {
    await saveSmtp();
    say('Servidor de correo guardado.');
  } catch (err) {
    setFieldError('sm-error', err.message);
  } finally {
    $('sm-save').disabled = false;
  }
});

$('sm-test').addEventListener('click', async () => {
  setFieldError('sm-test-error', '');
  $('sm-test-ok').hidden = true;
  const to = $('sm-test-to').value.trim();
  if (!to) {
    setFieldError('sm-test-error', 'Escribe el correo que recibirá la prueba.');
    return;
  }
  $('sm-test').disabled = true;
  try {
    await saveSmtp(); // la prueba usa lo guardado, así que primero se guarda lo que hay escrito
    const result = await api('/api/admin/smtp/test', { method: 'POST', body: { to } });
    $('sm-test-ok').textContent = `Listo: se envió un correo de prueba a ${result.to}. Revisa la bandeja de entrada y el correo no deseado.`;
    $('sm-test-ok').hidden = false;
  } catch (err) {
    setFieldError('sm-test-error', err.message);
  } finally {
    $('sm-test').disabled = false;
  }
});

// ----- Secciones del menú lateral ------------------------------------------------------------------

const SECTIONS = ['personalizacion', 'usuarios', 'cuentas', 'correo'];

function showSection(wanted) {
  // Un usuario que no es administrador solo ve Personalización, aunque escriba otra dirección a mano.
  const id = SECTIONS.includes(wanted) && (wanted === 'personalizacion' || me?.role === 'admin') ? wanted : 'personalizacion';
  for (const section of SECTIONS) $(`sec-${section}`).hidden = section !== id;
  for (const link of document.querySelectorAll('#aj-nav a')) {
    if (link.dataset.sec === id) link.setAttribute('aria-current', 'true');
    else link.removeAttribute('aria-current');
  }
}

window.addEventListener('hashchange', () => showSection(window.location.hash.slice(1)));

// ----- Arranque ----------------------------------------------------------------------

$('year').textContent = new Date().getFullYear();

(async () => {
  try {
    me = (await api('/api/auth/me')).user;
  } catch {
    me = null;
  }
  if (!me) {
    window.location.replace('/entrar/?next=%2Fajustes%2F');
    return;
  }
  const isAdmin = me.role === 'admin';
  if (isAdmin) {
    for (const link of document.querySelectorAll('#aj-nav [data-admin]')) link.hidden = false;
    $('aj-lead').textContent = 'Cambia el aspecto de tu cuenta y administra los usuarios, la creación de cuentas y el correo.';
    $('sm-test-to').value = me.email;
  }
  showSection(window.location.hash.slice(1));
  if (!isAdmin) return;
  try {
    showRegistration((await api('/api/admin/settings')).registrationOpen);
    await loadUsers();
    showSmtp(await api('/api/admin/smtp'));
  } catch (err) {
    say(err.message, true);
  }
})();
