// Lector de QR: decodifica una imagen o la cámara con jsQR (vendor/jsQR.js). Todo en el navegador.
// Todo texto leído de un QR se muestra con textContent: nunca se interpreta como HTML.

const $ = (id) => document.getElementById(id);
const MAX_SIDE = 1600;
const ACCEPTED = new Set(['image/png', 'image/jpeg', 'image/webp']);

let stream = null;
let scanning = false;

function setError(message) {
  $('rd-error').textContent = message || '';
  $('rd-error').hidden = !message;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

/** Tipo de contenido (para mostrarlo en español) y datos útiles del texto leído. */
export function describe(text) {
  const t = text.trim();
  if (/^https?:\/\//i.test(t)) return { kind: 'Enlace web', link: t };
  if (/^WIFI:/i.test(t)) {
    const field = (key) => {
      const m = new RegExp(`(?:^|;)${key}:((?:\\\\.|[^;])*)`, 'i').exec(t.replace(/^WIFI:/i, ''));
      return m ? m[1].replace(/\\(.)/g, '$1') : '';
    };
    return { kind: 'Red WiFi', rows: [['Red', field('S')], ['Seguridad', field('T') || 'sin contraseña'], ['Contraseña', field('P')]] };
  }
  if (/^mailto:/i.test(t)) return { kind: 'Correo electrónico', rows: [['Para', t.slice(7).split('?')[0]]] };
  if (/^tel:/i.test(t)) return { kind: 'Teléfono', rows: [['Número', t.slice(4)]] };
  if (/^smsto?:/i.test(t)) return { kind: 'SMS', rows: [['Contenido', t.replace(/^smsto?:/i, '')]] };
  if (/^geo:/i.test(t)) return { kind: 'Ubicación', rows: [['Coordenadas', t.slice(4)]] };
  if (/^BEGIN:VCARD/i.test(t)) return { kind: 'Contacto (vCard)', rows: [] };
  if (/^BEGIN:VCALENDAR/i.test(t)) return { kind: 'Evento de calendario', rows: [] };
  return { kind: 'Texto', rows: [] };
}

function showResult(text) {
  const info = describe(text);
  const box = $('rd-result');
  box.replaceChildren();
  box.append(el('p', 'reader-kind', info.kind));
  for (const [label, value] of info.rows ?? []) if (value) box.append(el('p', 'reader-row', `${label}: ${value}`));
  const raw = el('pre', 'reader-raw', text);
  box.append(raw);
  const actions = el('div', 'bulk-actions');
  const copy = el('button', 'btn btn-small', 'Copiar el contenido');
  copy.type = 'button';
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(text);
      copy.textContent = 'Copiado';
    } catch {
      copy.textContent = 'No se pudo copiar';
    }
  });
  actions.append(copy);
  if (info.link) {
    const open = el('a', 'btn btn-small btn-primary', 'Abrir el enlace');
    open.href = info.link;
    open.target = '_blank';
    open.rel = 'noopener noreferrer';
    actions.append(open);
    box.append(el('p', 'hint', 'Revisa la dirección antes de abrirla: solo abre enlaces en los que confíes.'));
  }
  box.append(actions);
}

/**
 * jsQR devuelve el texto y también los bytes originales. Su texto sale vacío o mal con tildes y «ñ»
 * (UTF-8), así que primero se leen los bytes como UTF-8; si no lo son (QR antiguos en Latin-1), se usa
 * el texto de jsQR.
 */
function textOf(found) {
  if (found.binaryData?.length) {
    const bytes = Uint8Array.from(found.binaryData);
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    } catch {
      // No es UTF-8: un QR antiguo en Latin-1 (como los que hacía este generador antes). En los
      // navegadores «iso-8859-1» es Windows-1252, que además lee bien el «€».
      return new TextDecoder('iso-8859-1').decode(bytes);
    }
  }
  return found.data;
}

function decode(imageData) {
  const found = window.jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: 'attemptBoth' });
  return found ? textOf(found) : null;
}

/** Prueba la imagen entera y, si no se lee, a menor tamaño (a veces un QR muy grande o ruidoso así sí sale). */
function decodeBitmap(bitmap) {
  const scales = [1, 0.5, 0.25];
  for (const factor of scales) {
    let w = Math.round(bitmap.width * factor);
    let h = Math.round(bitmap.height * factor);
    const big = Math.max(w, h);
    if (big > MAX_SIDE) {
      w = Math.round((w * MAX_SIDE) / big);
      h = Math.round((h * MAX_SIDE) / big);
    }
    if (w < 40 || h < 40) break;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#ffffff'; // los PNG transparentes se leen sobre blanco
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(bitmap, 0, 0, w, h);
    const text = decode(ctx.getImageData(0, 0, w, h));
    if (text) return text;
  }
  return null;
}

async function readFile(file) {
  setError('');
  if (!file) return;
  if (!ACCEPTED.has(file.type)) {
    setError('Formato no admitido. Usa un PNG, JPG o WebP.');
    return;
  }
  try {
    const bitmap = await createImageBitmap(file);
    const text = decodeBitmap(bitmap);
    bitmap.close?.();
    $('rd-title').textContent = file.name || 'Imagen pegada';
    if (text) showResult(text);
    else {
      $('rd-result').replaceChildren(el('p', 'hint center', 'No se encontró ningún código QR en la imagen. Prueba con una imagen más nítida y que muestre el QR completo.'));
    }
  } catch {
    setError('No se pudo abrir la imagen: el archivo está dañado o no es una imagen válida.');
  }
}

// ----- Cámara -----

function stopCamera() {
  scanning = false;
  stream?.getTracks().forEach((track) => track.stop());
  stream = null;
  $('rd-video').hidden = true;
  $('rd-video').srcObject = null;
  $('rd-stop').hidden = true;
  $('rd-camera').hidden = false;
}

async function startCamera() {
  setError('');
  if (!navigator.mediaDevices?.getUserMedia) {
    setError('La cámara no está disponible aquí: necesita una página segura (https) o abrirla desde este mismo equipo (localhost). Sube una imagen en su lugar.');
    return;
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
  } catch {
    setError('No se pudo usar la cámara. Revisa el permiso del navegador o sube una imagen.');
    return;
  }
  const video = $('rd-video');
  video.srcObject = stream;
  video.hidden = false;
  await video.play();
  $('rd-camera').hidden = true;
  $('rd-stop').hidden = false;
  scanning = true;
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const tick = () => {
    if (!scanning) return;
    if (video.readyState >= 2 && video.videoWidth) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);
      const text = decode(ctx.getImageData(0, 0, canvas.width, canvas.height));
      if (text) {
        stopCamera();
        showResult(text);
        return;
      }
    }
    setTimeout(() => requestAnimationFrame(tick), 150);
  };
  tick();
}

$('rd-file').addEventListener('change', (event) => readFile(event.target.files?.[0]));
$('rd-camera').addEventListener('click', startCamera);
$('rd-stop').addEventListener('click', stopCamera);

const drop = $('rd-drop');
for (const type of ['dragenter', 'dragover']) {
  drop.addEventListener(type, (event) => {
    event.preventDefault();
    drop.classList.add('is-over');
  });
}
for (const type of ['dragleave', 'drop']) {
  drop.addEventListener(type, (event) => {
    event.preventDefault();
    drop.classList.remove('is-over');
  });
}
drop.addEventListener('drop', (event) => readFile(event.dataTransfer?.files?.[0]));

// Ctrl+V con una imagen copiada (por ejemplo, una captura de pantalla).
document.addEventListener('paste', (event) => {
  const file = [...(event.clipboardData?.files ?? [])].find((f) => ACCEPTED.has(f.type));
  if (file) readFile(file);
});

window.addEventListener('pagehide', stopCamera);
$('year').textContent = new Date().getFullYear();
