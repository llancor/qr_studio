// Apariencia de QR Studio: tema (claro, oscuro o el del sistema), color de acento, estilo (esquinas, tamaño y
// tipo de letra) e imagen de portada a toda la página.
//
// Cada usuario tiene la suya: se guarda en el servidor, en su cuenta (/api/me/prefs y /api/me/cover), así que
// le acompaña a cualquier navegador. Este script solo conserva una COPIA en localStorage para pintar bien desde
// el primer cuadro, sin esperar a la red, y luego se pone al día con el servidor.
//
// Se carga como script normal en el <head> de cada página (sin defer). La pantalla Ajustes → Personalización
// lo maneja con window.QRTema. La política de seguridad del sitio no admite estilos incrustados, así que aquí
// solo se usan atributos data-* en <html> y propiedades CSS escritas con style.setProperty (eso sí vale).
(function () {
  'use strict';

  var KEY = 'qrstudio.apariencia'; // copia: { uid, p: preferencias, cv: versión de la portada (0 = sin portada) }
  var KEY_IMG_ANTIGUA = 'qrstudio.portada'; // versión anterior: la imagen se guardaba aquí, solo en el navegador

  var ACENTOS = [
    { nombre: 'Azul', hex: '#2f5bff' },
    { nombre: 'Índigo', hex: '#4f46e5' },
    { nombre: 'Morado', hex: '#7c3aed' },
    { nombre: 'Rosa', hex: '#db2777' },
    { nombre: 'Rojo', hex: '#dc2626' },
    { nombre: 'Naranja', hex: '#ea580c' },
    { nombre: 'Verde', hex: '#16a34a' },
    { nombre: 'Turquesa', hex: '#0d9488' },
    { nombre: 'Grafito', hex: '#475569' },
  ];

  var DEFAULTS = {
    tema: 'auto',
    acento: '#2f5bff',
    esquinas: 'suaves',
    texto: 'normal',
    fuente: 'sistema',
    velo: 60,
    desenfoque: 0,
    ajuste: 'cubrir',
    posicion: 'centro',
  };

  var OPCIONES = {
    tema: ['auto', 'claro', 'oscuro'],
    esquinas: ['rectas', 'suaves', 'redondas'],
    texto: ['pequeno', 'normal', 'grande', 'enorme'],
    fuente: ['sistema', 'serif', 'mono'],
    ajuste: ['cubrir', 'ajustar', 'mosaico'],
    posicion: ['centro', 'arriba', 'abajo', 'izquierda', 'derecha'],
  };

  var AJUSTE_CSS = { cubrir: 'cover', ajustar: 'contain', mosaico: 'auto' };
  var POSICION_CSS = {
    centro: 'center',
    arriba: 'center top',
    abajo: 'center bottom',
    izquierda: 'left center',
    derecha: 'right center',
  };

  // Superficie de cada tema (para calcular qué tan legible es el acento sobre ella).
  var SUPERFICIE = { claro: [255, 255, 255], oscuro: [29, 28, 44] };

  // ----- Color -------------------------------------------------------------------------------------

  function hexToRgb(hex) {
    var n = parseInt(hex.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function luminance(rgb) {
    var c = rgb.map(function (v) {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }

  function contrast(a, b) {
    var la = luminance(a);
    var lb = luminance(b);
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }

  function mix(a, b, t) {
    return a.map(function (v, i) {
      return v + (b[i] - v) * t;
    });
  }

  function css(rgb) {
    return 'rgb(' + rgb.map(Math.round).join(',') + ')';
  }

  /** Acerca el color hacia `toward` solo lo necesario para que alcance el contraste pedido sobre `bg`. */
  function legible(rgb, bg, min, toward) {
    for (var t = 0; t <= 1.0001; t += 0.05) {
      var candidate = mix(rgb, toward, t);
      if (contrast(candidate, bg) >= min) return candidate;
    }
    return toward;
  }

  // ----- Preferencias y copia local --------------------------------------------------------------

  function limpiar(raw) {
    var p = {};
    var o = raw && typeof raw === 'object' ? raw : {};
    Object.keys(DEFAULTS).forEach(function (k) {
      p[k] = DEFAULTS[k];
    });
    Object.keys(OPCIONES).forEach(function (k) {
      if (OPCIONES[k].indexOf(o[k]) !== -1) p[k] = o[k];
    });
    if (typeof o.acento === 'string' && /^#[0-9a-f]{6}$/i.test(o.acento)) p.acento = o.acento.toLowerCase();
    var velo = Number(o.velo);
    if (isFinite(velo)) p.velo = Math.max(0, Math.min(90, Math.round(velo)));
    var blur = Number(o.desenfoque);
    if (isFinite(blur)) p.desenfoque = Math.max(0, Math.min(20, Math.round(blur)));
    return p;
  }

  /** La copia local. `antigua`: está en el formato de la versión anterior (preferencias sueltas, sin cuenta). */
  function leerCopia() {
    var o = null;
    try {
      o = JSON.parse(localStorage.getItem(KEY) || 'null');
    } catch (e) {
      o = null;
    }
    if (!o || typeof o !== 'object') return { uid: null, p: limpiar({}), cv: 0, antigua: false };
    if (o.p && typeof o.p === 'object') {
      var cv = Number(o.cv);
      return { uid: typeof o.uid === 'number' ? o.uid : null, p: limpiar(o.p), cv: cv > 0 ? Math.floor(cv) : 0, antigua: false };
    }
    return { uid: null, p: limpiar(o), cv: 0, antigua: true };
  }

  function escribirCopia(copia) {
    try {
      localStorage.setItem(KEY, JSON.stringify({ uid: copia.uid, p: copia.p, cv: copia.cv }));
    } catch (e) {
      /* sin almacenamiento (ventana privada): vale solo mientras la página siga abierta */
    }
  }

  function cargar() {
    return leerCopia().p;
  }

  function temaEfectivo(p) {
    if (p.tema === 'claro' || p.tema === 'oscuro') return p.tema;
    var oscuro = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    return oscuro ? 'oscuro' : 'claro';
  }

  function urlPortada(cv) {
    return cv > 0 ? '/api/me/cover?v=' + cv : '';
  }

  // ----- Aplicar --------------------------------------------------------------------------------------

  function aplicar(copia) {
    copia = copia || leerCopia();
    var p = copia.p;
    var root = document.documentElement;
    var ef = temaEfectivo(p);
    var st = root.style;

    root.dataset.tema = ef;
    root.dataset.esquinas = p.esquinas;
    root.dataset.texto = p.texto;
    root.dataset.fuente = p.fuente;

    // Acento: un relleno visible sobre la superficie (≥3:1), un texto legible (≥4.5:1) y la tinta de los botones.
    var base = hexToRgb(p.acento);
    var superficie = SUPERFICIE[ef];
    var hacia = ef === 'oscuro' ? [255, 255, 255] : [0, 0, 0];
    var relleno = legible(base, superficie, 3, hacia);
    var texto = legible(base, superficie, 4.5, hacia);
    var tinta = contrast(relleno, [255, 255, 255]) >= contrast(relleno, [17, 17, 27]) ? '#ffffff' : '#11111b';
    st.setProperty('--primary', css(relleno));
    st.setProperty('--primary-text', css(texto));
    st.setProperty('--primary-ink', tinta);

    // Aviso para quien dependa del acento (el color del marco del QR empieza siendo este).
    document.dispatchEvent(new CustomEvent('qrtema:aplicado', { detail: { acento: p.acento, tema: ef } }));

    var url = urlPortada(copia.cv);
    if (url) {
      root.dataset.portada = 'si';
      st.setProperty('--portada-img', 'url("' + url + '")');
      st.setProperty('--portada-ajuste', AJUSTE_CSS[p.ajuste]);
      st.setProperty('--portada-repite', p.ajuste === 'mosaico' ? 'repeat' : 'no-repeat');
      st.setProperty('--portada-pos', POSICION_CSS[p.posicion]);
      st.setProperty('--portada-desenfoque', p.desenfoque + 'px');
      st.setProperty('--velo', p.velo + '%');
    } else {
      delete root.dataset.portada;
      ['--portada-img', '--portada-ajuste', '--portada-repite', '--portada-pos', '--portada-desenfoque', '--velo'].forEach(
        function (name) {
          st.removeProperty(name);
        }
      );
    }
  }

  // ----- Servidor ------------------------------------------------------------------------------------

  function pedir(metodo, ruta, cuerpo, tipo) {
    var opciones = { method: metodo, credentials: 'same-origin', headers: {} };
    if (cuerpo !== undefined) {
      if (tipo) {
        opciones.headers['Content-Type'] = tipo;
        opciones.body = cuerpo;
      } else {
        opciones.headers['Content-Type'] = 'application/json';
        opciones.body = JSON.stringify(cuerpo);
      }
    }
    return fetch(ruta, opciones).then(function (res) {
      return res.json().then(
        function (data) {
          return { ok: res.ok, status: res.status, data: data };
        },
        function () {
          return { ok: res.ok, status: res.status, data: null };
        }
      );
    });
  }

  function mensajeDe(res) {
    return res.data && typeof res.data.detail === 'string' ? res.data.detail : 'No se pudo guardar. Inténtalo de nuevo.';
  }

  var pendiente = false; // hay cambios locales aún sin subir: la puesta al día no debe pisarlos
  var temporizador = 0;

  function subir() {
    var copia = leerCopia();
    return pedir('PUT', '/api/me/prefs', copia.p).then(
      function (res) {
        if (res.ok) pendiente = false;
        return res;
      },
      function () {
        return { ok: false };
      }
    );
  }

  /** Aplica y guarda cambios de aspecto: al instante en la página y, un instante después, en la cuenta. */
  function guardar(cambios) {
    var copia = leerCopia();
    copia.p = limpiar(Object.assign({}, copia.p, cambios));
    escribirCopia(copia);
    aplicar(copia);
    pendiente = true;
    clearTimeout(temporizador);
    temporizador = setTimeout(subir, 500); // los deslizadores disparan muchos cambios seguidos
    return copia.p;
  }

  function dataUrlABlob(data) {
    var coma = data.indexOf(',');
    var tipo = data.slice(5, data.indexOf(';'));
    if (coma < 0 || tipo.indexOf('image/') !== 0) return null;
    var bin = atob(data.slice(coma + 1));
    var bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new Blob([bytes], { type: tipo });
  }

  /** Sube lo que había guardado la versión anterior (solo en el navegador) si la cuenta aún no tiene nada. */
  function migrarAntigua(antigua, uid) {
    var imagen = '';
    try {
      imagen = localStorage.getItem(KEY_IMG_ANTIGUA) || '';
    } catch (e) {
      imagen = '';
    }
    var copia = { uid: uid, p: antigua.p, cv: 0 };
    return pedir('PUT', '/api/me/prefs', copia.p)
      .then(function () {
        var blob = null;
        try {
          blob = imagen ? dataUrlABlob(imagen) : null;
        } catch (e) {
          blob = null;
        }
        return blob ? pedir('PUT', '/api/me/cover', blob, blob.type) : null;
      })
      .then(function (res) {
        if (res && res.ok && res.data) copia.cv = res.data.coverVersion || 0;
        try {
          localStorage.removeItem(KEY_IMG_ANTIGUA);
        } catch (e) {
          /* nada que quitar */
        }
        return copia;
      });
  }

  /** Se pone al día con la cuenta. El servidor manda; la copia local solo evita el parpadeo. */
  function sincronizar() {
    return pedir('GET', '/api/me/prefs')
      .then(function (res) {
        if (!res.ok || !res.data) return; // sin sesión (o sin red): se queda como está
        var uid = res.data.userId;
        var local = leerCopia();
        var vacia = res.data.prefs === null && !res.data.coverVersion;
        var siguiente;
        if (local.antigua && vacia) {
          return migrarAntigua(local, uid).then(function (copia) {
            escribirCopia(copia);
            aplicar(copia);
          });
        }
        if (local.antigua) {
          try {
            localStorage.removeItem(KEY_IMG_ANTIGUA); // la cuenta ya tiene lo suyo: lo anterior sobra
          } catch (e) {
            /* nada que quitar */
          }
        }
        if (pendiente) {
          // Hay cambios sin subir: se conservan las preferencias locales y solo se toma la portada del servidor.
          siguiente = { uid: uid, p: local.p, cv: res.data.coverVersion || 0 };
        } else {
          siguiente = { uid: uid, p: limpiar(res.data.prefs || {}), cv: res.data.coverVersion || 0 };
        }
        escribirCopia(siguiente);
        aplicar(siguiente);
      })
      .catch(function () {
        /* sin red: se queda la copia local */
      });
  }

  /** Cambia la portada. `blob`: imagen JPG, PNG o WebP ya reducida. Devuelve una promesa; falla con un Error legible. */
  function ponerPortada(blob) {
    return pedir('PUT', '/api/me/cover', blob, blob.type || 'image/jpeg').then(function (res) {
      if (!res.ok) throw new Error(mensajeDe(res));
      var copia = leerCopia();
      copia.cv = res.data.coverVersion || 0;
      escribirCopia(copia);
      aplicar(copia);
    });
  }

  function quitarPortada() {
    return pedir('DELETE', '/api/me/cover').then(function (res) {
      if (!res.ok) throw new Error(mensajeDe(res));
      var copia = leerCopia();
      copia.cv = 0;
      escribirCopia(copia);
      aplicar(copia);
    });
  }

  /** Vuelve al aspecto original (quita también la portada) en la cuenta y en este navegador. */
  function restablecer() {
    return pedir('DELETE', '/api/me/prefs').then(function (res) {
      if (!res.ok) throw new Error(mensajeDe(res));
      pendiente = false;
      clearTimeout(temporizador);
      var copia = { uid: leerCopia().uid, p: limpiar({}), cv: 0 };
      escribirCopia(copia);
      aplicar(copia);
    });
  }

  /** Al cerrar sesión o entrar con otra cuenta: se borra la copia local para no enseñar lo de la cuenta anterior. */
  function olvidar() {
    try {
      localStorage.removeItem(KEY);
      localStorage.removeItem(KEY_IMG_ANTIGUA);
    } catch (e) {
      /* nada que quitar */
    }
    pendiente = false;
    clearTimeout(temporizador);
    aplicar();
  }

  // Cambios hechos en otra pestaña, o en el tema del sistema mientras está en «Automático».
  window.addEventListener('storage', function (event) {
    if (event.key === KEY || event.key === null) aplicar();
  });
  if (window.matchMedia) {
    var consulta = window.matchMedia('(prefers-color-scheme: dark)');
    var alCambiar = function () {
      if (cargar().tema === 'auto') aplicar();
    };
    if (consulta.addEventListener) consulta.addEventListener('change', alCambiar);
    else if (consulta.addListener) consulta.addListener(alCambiar);
  }

  window.QRTema = {
    ACENTOS: ACENTOS,
    DEFAULTS: DEFAULTS,
    cargar: cargar,
    guardar: guardar,
    aplicar: aplicar,
    restablecer: restablecer,
    ponerPortada: ponerPortada,
    quitarPortada: quitarPortada,
    olvidar: olvidar,
    sincronizar: sincronizar,
    hayPortada: function () {
      return leerCopia().cv > 0;
    },
    urlPortada: function () {
      return urlPortada(leerCopia().cv);
    },
  };

  aplicar();

  // Sin sesión (acceso y restablecer) no hay nada que pedir al servidor.
  var ruta = window.location.pathname;
  var sinSesion = ruta.indexOf('/entrar') === 0 || ruta.indexOf('/restablecer') === 0;
  window.QRTema.listo = sinSesion ? Promise.resolve() : sincronizar(); // promesa: ya llegó lo guardado en la cuenta
})();
