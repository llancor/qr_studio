"""Aplicación FastAPI: API de cuentas (SQLite) y servidor del frontend estático.

Arranque:  uvicorn --factory app.main:create_app
"""

from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urlparse

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from html import escape

from . import admin, auth, db, dynamic, files, mail, pages, prefs
from .config import Settings, load_settings

STATIC_DIR = Path(__file__).resolve().parent / "static"
# Versión del paquete (p. ej. v191120261705, igual que el nombre del .zip). La escribe Crear_Paquete_GitHub.ps1.
VERSION_FILE = Path(__file__).resolve().parent / "version.txt"
VERSION_RE = re.compile(r"^[A-Za-z0-9._-]{1,40}$")
COOKIE_NAME = "session"
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,63}$")

# Sin sesión solo se puede ver la página de acceso (y lo que ella necesita) y la comprobación de salud
# que usan el monitor, Docker y los instaladores. Todo lo demás exige iniciar sesión.
LOGIN_PATH = "/entrar/"
PUBLIC_PATHS = {
    "/healthz",
    "/entrar",
    LOGIN_PATH,
    "/entrar/index.html",
    "/css/styles.css",
    "/js/tema.js",
    "/js/entrar.js",
    # Recuperar la contraseña: quien lo necesita no puede tener sesión.
    "/restablecer",
    "/restablecer/",
    "/restablecer/index.html",
    "/js/restablecer.js",
    "/js/version.js",
    # Lo que necesita ver quien abre una página dinámica (/p/<código>) sin tener sesión.
    "/css/publica.css",
    "/js/publica.js",
    "/js/visor-pdf.js",
    "/vendor/page-flip.browser.js",
    "/vendor/pdf.min.js",
    "/vendor/pdf.worker.min.js",
}

CSP = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self'; "
    "img-src 'self' data: blob:; "
    "connect-src 'self'; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'"
)


def read_version_file() -> str:
    """Versión del software; «desarrollo» si se ejecuta desde el código fuente sin paquete."""
    try:
        text = VERSION_FILE.read_text(encoding="utf-8-sig").strip()
    except OSError:
        return "desarrollo"
    return text if VERSION_RE.match(text) else "desarrollo"


class RegisterIn(BaseModel):
    email: str
    name: str
    password: str


class LoginIn(BaseModel):
    email: str
    password: str


class FolderIn(BaseModel):
    name: str


class DynamicIn(BaseModel):
    name: str = ""
    target: str


class DynamicPatch(BaseModel):
    name: str | None = None
    target: str | None = None
    active: bool | None = None


class PageIn(BaseModel):
    template: str
    name: str = ""


class PagePatch(BaseModel):
    name: str | None = None
    content: dict | None = None
    active: bool | None = None
    expiresAt: str | None = None  # «» o null (si viene en la petición) quita la caducidad


class AdminUserIn(BaseModel):
    email: str
    name: str
    password: str
    role: str = "user"


class AdminUserPatch(BaseModel):
    role: str | None = None
    active: bool | None = None
    name: str | None = None
    email: str | None = None


class PasswordIn(BaseModel):
    password: str


class AdminSettingsIn(BaseModel):
    registrationOpen: bool


class SmtpIn(BaseModel):
    host: str
    port: int
    security: str
    user: str = ""
    password: str | None = None  # None o vacío: se conserva la guardada
    clearPassword: bool = False
    sender: str
    senderName: str = ""
    siteUrl: str = ""


class SmtpTestIn(BaseModel):
    to: str


class ForgotIn(BaseModel):
    email: str


class ResetIn(BaseModel):
    token: str
    password: str


# Cuánto dura el enlace para recuperar la contraseña.
RESET_MINUTES = 60


def _public_user(row: sqlite3.Row) -> dict:
    return {"id": row["id"], "email": row["email"], "name": row["name"], "role": row["role"]}


def _normalize_email(raw: str) -> str:
    email = raw.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(422, "Escribe un correo electrónico válido.")
    return email


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    db.init_db(settings.db_path)

    app = FastAPI(title="QR Studio", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.settings = settings
    login_limiter = auth.LoginLimiter(settings.login_max_attempts, settings.login_window_seconds)
    register_limiter = auth.LoginLimiter(10, settings.login_window_seconds)
    forgot_limiter = auth.LoginLimiter(5, settings.login_window_seconds)  # solicitudes por IP
    forgot_mail_limiter = auth.LoginLimiter(3, 900)  # correos por cuenta: evita inundar el buzón de alguien
    reset_limiter = auth.LoginLimiter(10, settings.login_window_seconds)

    # ----- Middleware -------------------------------------------------------

    def access_gate(request: Request) -> Response | None:
        """Todo el contenido exige sesión. Devuelve la respuesta de rechazo, o None si puede pasar."""
        path = request.url.path
        # /q/<código> y /p/<código> son públicos a propósito: quien escanea un QR no tiene sesión.
        if path in PUBLIC_PATHS or path.startswith(("/api/auth/", "/q/", "/p/")):
            return None
        with db.connect(settings.db_path) as conn:
            if auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME)):
                return None
        if path.startswith("/api/"):
            return JSONResponse({"detail": "Inicia sesión para continuar."}, status_code=401)
        wants_page = "text/html" in request.headers.get("accept", "") or path.endswith(("/", ".html"))
        if wants_page and request.method in {"GET", "HEAD"}:
            target = path + (f"?{request.url.query}" if request.url.query else "")
            return RedirectResponse(f"{LOGIN_PATH}?next={quote(target, safe='')}", status_code=303)
        return Response(status_code=401)  # un archivo suelto (script, imagen...) pedido sin sesión

    @app.middleware("http")
    async def security(request: Request, call_next):
        # Defensa CSRF: una petición que cambia datos debe venir de este mismo origen.
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            origin = request.headers.get("origin")
            if origin and urlparse(origin).netloc != request.headers.get("host", ""):
                return JSONResponse({"detail": "Origen no permitido."}, status_code=403)
        response = access_gate(request) or await call_next(request)
        response.headers["Content-Security-Policy"] = CSP
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["X-Frame-Options"] = "DENY"
        # La API nunca se guarda en caché; páginas y archivos se revalidan siempre (así un cambio de
        # versión llega enseguida y, al salir, el botón «atrás» no muestra contenido privado).
        # (/q/ también: una redirección guardada en caché haría que el destino nuevo no se viera ni se contara).
        # (/p/ también; solo sus archivos —imágenes y PDF, con nombre aleatorio— fijan su propia caché.)
        if "cache-control" not in response.headers:
            no_store = request.url.path.startswith(("/api/", "/q/", "/p/"))
            response.headers["Cache-Control"] = "no-store" if no_store else "no-cache"
        return response

    @app.exception_handler(RequestValidationError)
    async def validation_error(_: Request, __: RequestValidationError):
        return JSONResponse({"detail": "Solicitud no válida."}, status_code=422)

    # ----- Utilidades -------------------------------------------------------

    def set_session_cookie(response: Response, token: str) -> None:
        response.set_cookie(
            COOKIE_NAME,
            token,
            max_age=settings.session_days * 86400,
            httponly=True,
            secure=settings.cookie_secure,
            samesite="lax",
            path="/",
        )

    def client_ip(request: Request) -> str:
        return request.client.host if request.client else "unknown"

    def clean_name(raw: str) -> str:
        name = raw.strip()
        if not 1 <= len(name) <= 80:
            raise HTTPException(422, "Escribe el nombre (máximo 80 caracteres).")
        return name

    def check_password(password: str) -> None:
        if not settings.min_password_length <= len(password) <= 128:
            raise HTTPException(
                422,
                f"La contraseña debe tener entre {settings.min_password_length} y 128 caracteres.",
            )

    # ----- API --------------------------------------------------------------

    version = read_version_file()

    @app.get("/healthz")
    def healthz():
        return {"status": "ok", "version": version, "time": datetime.now(timezone.utc).isoformat()}

    @app.get("/api/auth/options")
    def auth_options():
        """Lo que necesita la página de acceso (pública): ¿se ofrece «Crear cuenta»?"""
        with db.connect(settings.db_path) as conn:
            # Sin ningún usuario siempre se puede registrar el primero: será el administrador.
            first = admin.count_users(conn) == 0
            return {
                "registrationOpen": first or admin.registration_open(conn, settings.registration_open),
                "firstUser": first,
                # ¿Hay servidor SMTP y dirección del sitio? Si sí, la página de acceso ofrece recuperar la contraseña.
                "recoveryEnabled": mail.load(conn) is not None and bool(mail.site_url(conn, settings.public_url)),
            }

    @app.post("/api/auth/register", status_code=201)
    def register(payload: RegisterIn, request: Request, response: Response):
        ip = client_ip(request)
        if register_limiter.blocked(ip):
            raise HTTPException(429, "Demasiados registros. Inténtalo más tarde.")
        register_limiter.record_failure(ip)  # cuenta cada intento de registro

        email = _normalize_email(payload.email)
        name = clean_name(payload.name)
        check_password(payload.password)

        with db.connect(settings.db_path) as conn:
            first = admin.count_users(conn) == 0
            if not first and not admin.registration_open(conn, settings.registration_open):
                raise HTTPException(
                    403, "La creación de cuentas está desactivada. Pídele una cuenta al administrador."
                )
            password_hash = auth.hash_password(payload.password)
            now = datetime.now(timezone.utc).isoformat()
            role = "admin" if first else "user"  # la primera cuenta del sitio es la del administrador
            try:
                cur = conn.execute(
                    "INSERT INTO users (email, name, password_hash, created_at, role) VALUES (?, ?, ?, ?, ?)",
                    (email, name, password_hash, now, role),
                )
            except sqlite3.IntegrityError:
                raise HTTPException(409, "Ya existe una cuenta con ese correo.") from None
            user_id = cur.lastrowid
            token = auth.create_session(conn, user_id, settings.session_days)
        set_session_cookie(response, token)
        return {"user": {"id": user_id, "email": email, "name": name, "role": role}}

    @app.post("/api/auth/login")
    def login(payload: LoginIn, request: Request, response: Response):
        email = payload.email.strip().lower()
        key = f"{client_ip(request)}|{email}"
        if login_limiter.blocked(key):
            raise HTTPException(429, "Demasiados intentos. Espera unos minutos.")

        with db.connect(settings.db_path) as conn:
            row = conn.execute(
                "SELECT id, email, name, role, active, password_hash FROM users WHERE email = ?", (email,)
            ).fetchone()
            stored = row["password_hash"] if row else auth.DUMMY_HASH
            valid = auth.verify_password(payload.password, stored) and row is not None
            if not valid:
                login_limiter.record_failure(key)
                raise HTTPException(401, "Correo o contraseña incorrectos.")
            if not row["active"]:
                # Solo se dice tras acertar la contraseña, para no revelar qué correos existen.
                raise HTTPException(403, "Tu cuenta está desactivada. Habla con el administrador.")
            login_limiter.reset(key)
            token = auth.create_session(conn, row["id"], settings.session_days)
        set_session_cookie(response, token)
        return {"user": _public_user(row)}

    @app.post("/api/auth/logout")
    def logout(request: Request, response: Response):
        with db.connect(settings.db_path) as conn:
            auth.delete_session(conn, request.cookies.get(COOKIE_NAME))
        response.delete_cookie(COOKIE_NAME, path="/")
        return {"ok": True}

    @app.get("/api/auth/me")
    def me(request: Request):
        with db.connect(settings.db_path) as conn:
            row = auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME))
        return {"user": _public_user(row) if row else None}

    # ----- Recuperar la contraseña por correo (público: quien la olvidó no tiene sesión) -----

    @app.post("/api/auth/forgot")
    def forgot_password(payload: ForgotIn, request: Request, background: BackgroundTasks):
        """Manda un enlace para elegir una contraseña nueva. Responde igual exista o no la cuenta."""
        ip = client_ip(request)
        if forgot_limiter.blocked(ip):
            raise HTTPException(429, "Demasiadas solicitudes. Inténtalo más tarde.")
        forgot_limiter.record_failure(ip)
        email = _normalize_email(payload.email)

        with db.connect(settings.db_path) as conn:
            cfg = mail.load(conn)
            base = mail.site_url(conn, settings.public_url)
            if cfg is None or not base:
                raise HTTPException(
                    503,
                    "La recuperación por correo no está activada. Pídele al administrador que te restablezca la contraseña.",
                )
            row = conn.execute("SELECT id, email, name, active FROM users WHERE email = ?", (email,)).fetchone()
            if row and row["active"] and not forgot_mail_limiter.blocked(email):
                forgot_mail_limiter.record_failure(email)
                token = auth.create_reset_token(conn, int(row["id"]), RESET_MINUTES)
                subject, body = mail.reset_message(row["name"], f"{base}/restablecer/?token={token}", RESET_MINUTES)
                # Se envía después de responder: así no se nota por el tiempo si la cuenta existe.
                background.add_task(mail.send_quietly, cfg, row["email"], subject, body)
        return {"ok": True}

    @app.post("/api/auth/reset")
    def reset_password(payload: ResetIn, request: Request):
        ip = client_ip(request)
        if reset_limiter.blocked(ip):
            raise HTTPException(429, "Demasiados intentos. Inténtalo más tarde.")
        reset_limiter.record_failure(ip)
        check_password(payload.password)  # antes de gastar el enlace: una contraseña corta no lo quema
        with db.connect(settings.db_path) as conn:
            user_id = auth.consume_reset_token(conn, payload.token)
            if user_id is None:
                raise HTTPException(
                    400, "El enlace no es válido o ya caducó. Pide uno nuevo desde «¿Olvidaste tu contraseña?»."
                )
            conn.execute(
                "UPDATE users SET password_hash = ? WHERE id = ?", (auth.hash_password(payload.password), user_id)
            )
            auth.delete_sessions_of(conn, user_id)  # se cierran todas las sesiones abiertas
        return {"ok": True}

    # ----- Carpetas de QR por usuario (requieren sesión) --------------------

    store = files.QrStore(
        settings.files_path or settings.db_path.parent / "qr",
        files.Limits(quota_bytes=settings.files_quota_mb * 1024 * 1024),
    )
    app.state.qr_store = store  # los tests ajustan los límites desde aquí

    def require_user(request: Request) -> int:
        with db.connect(settings.db_path) as conn:
            row = auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME))
        if not row:
            raise HTTPException(401, "Inicia sesión para usar esta función.")
        return int(row["id"])

    @app.exception_handler(files.StoreError)
    async def store_error(_: Request, exc: files.StoreError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    async def read_limited(request: Request, limit: int) -> bytes:
        declared = request.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > limit:
            raise files.StoreError(413, "La imagen es demasiado grande.")
        chunks, size = [], 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > limit:
                raise files.StoreError(413, "La imagen es demasiado grande.")
            chunks.append(chunk)
        return b"".join(chunks)

    @app.get("/api/qr/folders")
    def list_folders(request: Request):
        return store.list_folders(require_user(request))

    @app.post("/api/qr/folders", status_code=201)
    def create_folder(payload: FolderIn, request: Request):
        name, created = store.create_folder(require_user(request), payload.name)
        return {"name": name, "created": created}

    @app.get("/api/qr/folders/{folder}")
    def list_files(folder: str, request: Request):
        return store.list_files(require_user(request), folder)

    @app.delete("/api/qr/folders/{folder}")
    def delete_folder(folder: str, request: Request):
        store.delete_folder(require_user(request), folder)
        return {"ok": True}

    @app.post("/api/qr/folders/{folder}/files", status_code=201)
    async def upload_file(folder: str, name: str, request: Request):
        user_id = require_user(request)
        data = await read_limited(request, store.limits.max_file_bytes)
        saved = store.save_file(user_id, folder, name, data)
        return {"name": saved, "bytes": len(data)}

    @app.get("/api/qr/folders/{folder}/files/{filename}")
    def get_file(folder: str, filename: str, request: Request, download: bool = False):
        path = store.file_path(require_user(request), folder, filename)
        return FileResponse(path, media_type="image/png", filename=path.name if download else None)

    @app.delete("/api/qr/folders/{folder}/files/{filename}")
    def delete_file(folder: str, filename: str, request: Request):
        store.delete_file(require_user(request), folder, filename)
        return {"ok": True}

    @app.get("/api/qr/folders/{folder}/zip")
    def download_zip(folder: str, request: Request):
        name, archive = store.zip_folder(require_user(request), folder)

        def chunks():
            try:
                while block := archive.read(1024 * 1024):
                    yield block
            finally:
                archive.close()

        disposition = f"attachment; filename=\"qr.zip\"; filename*=UTF-8''{quote(name)}.zip"
        return StreamingResponse(chunks(), media_type="application/zip", headers={"Content-Disposition": disposition})

    # ----- Personalización de cada usuario (tema, color, estilo y portada) -----------

    @app.exception_handler(prefs.PrefsError)
    async def prefs_error(_: Request, exc: prefs.PrefsError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    @app.get("/api/me/prefs")
    def get_my_prefs(request: Request):
        user_id = require_user(request)
        with db.connect(settings.db_path) as conn:
            # userId: el navegador guarda una copia y así sabe si es de esta cuenta o de otra anterior.
            return {**prefs.get(conn, user_id), "userId": user_id}

    @app.put("/api/me/prefs")
    def put_my_prefs(payload: dict, request: Request):
        user_id = require_user(request)
        with db.connect(settings.db_path) as conn:
            return prefs.save(conn, user_id, payload)

    @app.delete("/api/me/prefs")
    def reset_my_prefs(request: Request):
        """Vuelve al aspecto original: quita las preferencias y la portada."""
        user_id = require_user(request)
        with db.connect(settings.db_path) as conn:
            return prefs.reset(conn, user_id)

    @app.put("/api/me/cover")
    async def put_my_cover(request: Request):
        user_id = require_user(request)
        data = await read_limited(request, prefs.MAX_COVER_BYTES)
        with db.connect(settings.db_path) as conn:
            return prefs.set_cover(conn, user_id, data)

    @app.get("/api/me/cover")
    def get_my_cover(request: Request):
        user_id = require_user(request)
        with db.connect(settings.db_path) as conn:
            cover = prefs.get_cover(conn, user_id)
        if cover is None:
            raise HTTPException(404, "No hay imagen de portada.")
        data, mime = cover
        # La URL lleva ?v=<versión>: cada cambio de portada es una URL nueva, así que se puede guardar para siempre.
        return Response(content=data, media_type=mime, headers={"Cache-Control": "private, max-age=31536000, immutable"})

    @app.delete("/api/me/cover")
    def delete_my_cover(request: Request):
        user_id = require_user(request)
        with db.connect(settings.db_path) as conn:
            return prefs.delete_cover(conn, user_id)

    # ----- Administración (solo administradores) -------------------------------

    @app.exception_handler(admin.AdminError)
    async def admin_error(_: Request, exc: admin.AdminError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    def require_admin(request: Request) -> sqlite3.Row:
        with db.connect(settings.db_path) as conn:
            row = auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME))
        if not row:
            raise HTTPException(401, "Inicia sesión para continuar.")
        if row["role"] != "admin":
            raise HTTPException(403, "Solo el administrador puede hacer esto.")
        return row

    @app.get("/api/admin/users")
    def admin_list_users(request: Request):
        require_admin(request)
        with db.connect(settings.db_path) as conn:
            return {"users": admin.list_users(conn)}

    @app.post("/api/admin/users", status_code=201)
    def admin_create_user(payload: AdminUserIn, request: Request):
        require_admin(request)
        email = _normalize_email(payload.email)
        name = clean_name(payload.name)
        check_password(payload.password)
        password_hash = auth.hash_password(payload.password)
        with db.connect(settings.db_path) as conn:
            return {"user": admin.create_user(conn, email, name, password_hash, payload.role)}

    @app.patch("/api/admin/users/{user_id}")
    def admin_update_user(user_id: int, payload: AdminUserPatch, request: Request):
        actor = require_admin(request)
        name = clean_name(payload.name) if payload.name is not None else None
        email = _normalize_email(payload.email) if payload.email is not None else None
        with db.connect(settings.db_path) as conn:
            return {
                "user": admin.update_user(
                    conn,
                    int(actor["id"]),
                    user_id,
                    role=payload.role,
                    active=payload.active,
                    name=name,
                    email=email,
                )
            }

    @app.post("/api/admin/users/{user_id}/password")
    def admin_reset_password(user_id: int, payload: PasswordIn, request: Request):
        actor = require_admin(request)
        check_password(payload.password)
        password_hash = auth.hash_password(payload.password)
        # Si el administrador cambia la suya, se conserva la sesión que está usando.
        keep = request.cookies.get(COOKIE_NAME) if user_id == int(actor["id"]) else None
        with db.connect(settings.db_path) as conn:
            admin.set_password(conn, user_id, password_hash, keep)
        return {"ok": True}

    @app.get("/api/admin/settings")
    def admin_get_settings(request: Request):
        require_admin(request)
        with db.connect(settings.db_path) as conn:
            return {"registrationOpen": admin.registration_open(conn, settings.registration_open)}

    @app.put("/api/admin/settings")
    def admin_put_settings(payload: AdminSettingsIn, request: Request):
        require_admin(request)
        with db.connect(settings.db_path) as conn:
            admin.set_registration_open(conn, payload.registrationOpen)
        return {"registrationOpen": payload.registrationOpen}

    # ----- Servidor SMTP (para recuperar contraseñas) ----------------------------

    @app.exception_handler(mail.MailError)
    async def mail_error(_: Request, exc: mail.MailError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    @app.get("/api/admin/smtp")
    def admin_get_smtp(request: Request):
        require_admin(request)
        with db.connect(settings.db_path) as conn:
            return mail.public_view(conn, settings.public_url)

    @app.put("/api/admin/smtp")
    def admin_put_smtp(payload: SmtpIn, request: Request):
        require_admin(request)
        sender = payload.sender.strip().lower()
        with db.connect(settings.db_path) as conn:
            mail.save(
                conn,
                host=payload.host,
                port=payload.port,
                security=payload.security,
                user=payload.user,
                password=payload.password,
                clear_password=payload.clearPassword,
                sender=sender,
                sender_name=payload.senderName,
                site=payload.siteUrl,
            )
            return mail.public_view(conn, settings.public_url)

    @app.post("/api/admin/smtp/test")
    def admin_test_smtp(payload: SmtpTestIn, request: Request):
        """Manda un correo de prueba con lo que está guardado (no con lo que hay escrito sin guardar)."""
        require_admin(request)
        to = _normalize_email(payload.to)
        with db.connect(settings.db_path) as conn:
            cfg = mail.load(conn)
        if cfg is None:
            raise HTTPException(409, "Guarda primero el servidor SMTP y el remitente.")
        subject, body = mail.probe_message()
        mail.send(cfg, to, subject, body)
        return {"ok": True, "to": to}

    # ----- QR dinámicos (opcionales) ------------------------------------------

    @app.exception_handler(dynamic.DynamicError)
    async def dynamic_error(_: Request, exc: dynamic.DynamicError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    def require_dynamic(request: Request) -> int:
        user_id = require_user(request)
        if not settings.dynamic_qr:
            raise HTTPException(404, "Los QR dinámicos no están activados en este servidor.")
        return user_id

    @app.get("/api/features")
    def features(request: Request):
        require_user(request)
        return {"dynamicQr": settings.dynamic_qr, "publicUrl": settings.public_url, "pages": settings.pages_enabled}

    @app.get("/api/dynamic")
    def dynamic_list(request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.list_items(conn, user_id)

    @app.post("/api/dynamic", status_code=201)
    def dynamic_create(payload: DynamicIn, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.create(conn, user_id, payload.name, payload.target)

    @app.patch("/api/dynamic/{qr_id}")
    def dynamic_update(qr_id: int, payload: DynamicPatch, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.update(
                conn, user_id, qr_id, name=payload.name, target=payload.target, active=payload.active
            )

    @app.delete("/api/dynamic/{qr_id}")
    def dynamic_delete(qr_id: int, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            dynamic.delete(conn, user_id, qr_id)
        return {"ok": True}

    @app.get("/api/dynamic/{qr_id}/stats")
    def dynamic_stats(qr_id: int, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.stats(conn, user_id, qr_id)

    def notice_page(status: int, title: str, text: str) -> HTMLResponse:
        body = (
            '<!doctype html><html lang="es"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f"<title>{escape(title)}</title>"
            '<meta name="robots" content="noindex"><link rel="stylesheet" href="/css/styles.css"></head>'
            '<body><main><section class="login container"><div class="login-card">'
            f"<h1>{escape(title)}</h1><p class=\"login-lead\">{escape(text)}</p>"
            "</div></section></main></body></html>"
        )
        return HTMLResponse(body, status_code=status, headers={"Cache-Control": "no-store"})

    @app.get("/q/{code}")
    def follow(code: str):
        """Destino de un QR dinámico (público). Cuenta la visita y redirige; nunca se guarda en caché."""
        if not settings.dynamic_qr:
            return notice_page(404, "No disponible", "Este servidor no tiene activados los QR dinámicos.")
        with db.connect(settings.db_path) as conn:
            result, target = dynamic.record_scan(conn, code)
        if result == "ok" and target:
            return RedirectResponse(target, status_code=302, headers={"Cache-Control": "no-store"})
        if result == "paused":
            return notice_page(410, "Código pausado", "Su dueño lo ha desactivado por ahora. Vuelve a intentarlo más tarde.")
        return notice_page(404, "Código no encontrado", "Este código QR no existe o fue eliminado.")

    # ----- Páginas dinámicas (opcionales): evento, empresa y carta ----------------------------

    pages_root = settings.pages_path or settings.db_path.parent / "paginas"
    app.state.pages_limits = pages.Limits(quota_bytes=settings.pages_quota_mb * 1024 * 1024)  # los tests lo ajustan

    @app.exception_handler(pages.PageError)
    async def page_error(_: Request, exc: pages.PageError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    def require_pages(request: Request) -> int:
        user_id = require_user(request)
        if not settings.pages_enabled:
            raise HTTPException(404, "Las páginas dinámicas no están activadas en este servidor.")
        return user_id

    async def read_body(request: Request, limit: int) -> bytes:
        declared = request.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > limit:
            raise pages.PageError(413, "El archivo es demasiado grande.")
        chunks, size = [], 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > limit:
                raise pages.PageError(413, "El archivo es demasiado grande.")
            chunks.append(chunk)
        return b"".join(chunks)

    @app.get("/api/paginas")
    def pages_list(request: Request):
        user_id = require_pages(request)
        with db.connect(settings.db_path) as conn:
            return pages.list_items(conn, user_id, app.state.pages_limits)

    @app.post("/api/paginas", status_code=201)
    def pages_create(payload: PageIn, request: Request):
        user_id = require_pages(request)
        with db.connect(settings.db_path) as conn:
            return pages.create(conn, user_id, payload.template, payload.name)

    @app.get("/api/paginas/{page_id}")
    def pages_get(page_id: int, request: Request):
        user_id = require_pages(request)
        with db.connect(settings.db_path) as conn:
            return pages.get(conn, user_id, page_id)

    @app.put("/api/paginas/{page_id}")
    def pages_update(page_id: int, payload: PagePatch, request: Request):
        user_id = require_pages(request)
        clear = "expiresAt" in payload.model_fields_set and not payload.expiresAt
        with db.connect(settings.db_path) as conn:
            return pages.update(
                conn,
                user_id,
                page_id,
                name=payload.name,
                content=payload.content,
                active=payload.active,
                expires_at=payload.expiresAt,
                clear_expiry=clear,
            )

    @app.delete("/api/paginas/{page_id}")
    def pages_delete(page_id: int, request: Request):
        user_id = require_pages(request)
        with db.connect(settings.db_path) as conn:
            pages.delete(conn, pages_root, user_id, page_id)
        return {"ok": True}

    @app.post("/api/paginas/{page_id}/archivos", status_code=201)
    async def pages_upload(page_id: int, request: Request, name: str = ""):
        user_id = require_pages(request)
        limits = app.state.pages_limits
        data = await read_body(request, max(limits.max_pdf_bytes, limits.max_image_bytes))
        with db.connect(settings.db_path) as conn:
            return pages.add_asset(conn, pages_root, user_id, page_id, name, data, limits)

    @app.delete("/api/paginas/{page_id}/archivos/{token}")
    def pages_remove_file(page_id: int, token: str, request: Request):
        user_id = require_pages(request)
        with db.connect(settings.db_path) as conn:
            return pages.remove_asset(conn, pages_root, user_id, page_id, token)

    @app.get("/api/paginas/{page_id}/archivos/{token}")
    def pages_owner_file(page_id: int, token: str, request: Request):
        """Archivo de una página para quien la edita (también si está pausada o caducada)."""
        user_id = require_pages(request)
        with db.connect(settings.db_path) as conn:
            pages.owned_row(conn, user_id, page_id)
            path, mime, _ = pages.read_asset(conn, pages_root, page_id, token)
        return FileResponse(path, media_type=mime, headers={"Cache-Control": "private, max-age=300"})

    @app.get("/api/paginas/{page_id}/stats")
    def pages_stats(page_id: int, request: Request):
        user_id = require_pages(request)
        with db.connect(settings.db_path) as conn:
            return pages.stats(conn, user_id, page_id)

    @app.get("/api/paginas/{page_id}/vista")
    def pages_preview(page_id: int, request: Request):
        """Vista previa para quien edita: igual que la pública, pero no cuenta la visita."""
        user_id = require_pages(request)
        with db.connect(settings.db_path) as conn:
            row = pages.owned_row(conn, user_id, page_id)
        html = pages.render_public(row, lambda token: f"/api/paginas/{page_id}/archivos/{token}", preview=True)
        return HTMLResponse(html)

    def public_page(code: str):
        """(fila, None) si la página se puede ver; (None, respuesta de aviso) si no."""
        if not settings.pages_enabled:
            return None, notice_page(404, "No disponible", "Este servidor no tiene activadas las páginas dinámicas.")
        with db.connect(settings.db_path) as conn:
            state, row = pages.public_lookup(conn, code)
            if state == "ok":
                return row, None
        if state == "paused":
            return None, notice_page(410, "Página pausada", "Su dueño la ha desactivado por ahora. Vuelve a intentarlo más tarde.")
        if state == "expired":
            return None, notice_page(410, "Página caducada", "Esta página ya no está disponible.")
        return None, notice_page(404, "Página no encontrada", "Este código QR no existe o fue eliminado.")

    @app.get("/p/{code}")
    def page_public(code: str):
        """Página dinámica pública: cuenta la visita y muestra el contenido (nunca se guarda en caché)."""
        row, notice = public_page(code)
        if notice:
            return notice
        with db.connect(settings.db_path) as conn:
            pages.record_view(conn, row["id"])
        html = pages.render_public(row, lambda token: f"/p/{code}/a/{token}")
        return HTMLResponse(html, headers={"Cache-Control": "no-store"})

    @app.get("/p/{code}/a/{token}")
    def page_public_file(code: str, token: str, descargar: int = 0):
        row, notice = public_page(code)
        if notice:
            raise HTTPException(404, "El archivo no está disponible.")
        with db.connect(settings.db_path) as conn:
            path, mime, name = pages.read_asset(conn, pages_root, row["id"], token)
        headers = {"Cache-Control": "public, max-age=3600"}
        if descargar:
            ext = path.suffix
            filename = name if name.lower().endswith(ext) else f"{name}{ext}"
            return FileResponse(path, media_type=mime, filename=filename, content_disposition_type="attachment", headers=headers)
        return FileResponse(path, media_type=mime, headers=headers)

    @app.get("/p/{code}/evento.ics")
    def page_calendar(code: str):
        row, notice = public_page(code)
        if notice:
            return notice
        text = pages.build_ics(row)
        if text is None:
            raise HTTPException(404, "Este evento no tiene fecha.")
        return Response(
            text,
            media_type="text/calendar; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="evento.ics"', "Cache-Control": "no-store"},
        )

    @app.post("/p/{code}/clic/{key}", status_code=204)
    def page_click(code: str, key: str):
        row, notice = public_page(code)
        if row:
            with db.connect(settings.db_path) as conn:
                pages.record_click(conn, row["id"], key)
        return Response(status_code=204)

    # ----- Frontend ---------------------------------------------------------

    app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
    return app
