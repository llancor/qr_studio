"""Personalización de cada usuario: tema, color de acento, estilo e imagen de portada.

Se guarda en la base de datos (tabla user_prefs), así que acompaña a la cuenta en cualquier navegador.
Las preferencias son un JSON pequeño que se valida aquí; la portada es una imagen (JPG, PNG o WebP)
que se guarda tal cual la envía el navegador, que ya la reduce antes de subirla.
"""

from __future__ import annotations

import json
import re
import sqlite3
from datetime import datetime, timezone

MAX_COVER_BYTES = 4 * 1024 * 1024

DEFAULTS = {
    "tema": "auto",
    "acento": "#2f5bff",
    "esquinas": "suaves",
    "texto": "normal",
    "fuente": "sistema",
    "velo": 60,
    "desenfoque": 0,
    "ajuste": "cubrir",
    "posicion": "centro",
}

OPTIONS = {
    "tema": ("auto", "claro", "oscuro"),
    "esquinas": ("rectas", "suaves", "redondas"),
    "texto": ("pequeno", "normal", "grande", "enorme"),
    "fuente": ("sistema", "serif", "mono"),
    "ajuste": ("cubrir", "ajustar", "mosaico"),
    "posicion": ("centro", "arriba", "abajo", "izquierda", "derecha"),
}

RANGES = {"velo": (0, 90), "desenfoque": (0, 20)}

_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")


class PrefsError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def clean(raw: object) -> dict:
    """Valida unas preferencias. Lo que falta toma el valor por defecto; un valor no válido es un error."""
    if not isinstance(raw, dict):
        raise PrefsError(422, "Preferencias no válidas.")
    out = dict(DEFAULTS)
    for key, allowed in OPTIONS.items():
        if key in raw:
            value = raw[key]
            if not isinstance(value, str) or value not in allowed:
                raise PrefsError(422, f"Valor no válido para «{key}».")
            out[key] = value
    if "acento" in raw:
        accent = raw["acento"]
        if not isinstance(accent, str) or not _HEX.match(accent):
            raise PrefsError(422, "El color de acento debe ser como #2f5bff.")
        out["acento"] = accent.lower()
    for key, (low, high) in RANGES.items():
        if key in raw:
            value = raw[key]
            if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
                raise PrefsError(422, f"«{key}» debe estar entre {low} y {high}.")
            out[key] = value
    return out


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def get(conn: sqlite3.Connection, user_id: int) -> dict:
    """Lo guardado por el usuario. `prefs` es None si nunca guardó nada; `coverVersion` es 0 sin portada."""
    row = conn.execute(
        "SELECT prefs, cover_v, cover IS NOT NULL AS has_cover FROM user_prefs WHERE user_id = ?", (user_id,)
    ).fetchone()
    if row is None:
        return {"prefs": None, "coverVersion": 0}
    prefs = None
    if row["prefs"]:
        try:
            prefs = clean(json.loads(row["prefs"]))
        except (ValueError, PrefsError):
            prefs = None
    return {"prefs": prefs, "coverVersion": int(row["cover_v"]) if row["has_cover"] else 0}


def save(conn: sqlite3.Connection, user_id: int, raw: object) -> dict:
    prefs = clean(raw)
    conn.execute(
        "INSERT INTO user_prefs (user_id, prefs, updated_at) VALUES (?, ?, ?) "
        "ON CONFLICT(user_id) DO UPDATE SET prefs = excluded.prefs, updated_at = excluded.updated_at",
        (user_id, json.dumps(prefs, separators=(",", ":")), _now()),
    )
    return get(conn, user_id)


def reset(conn: sqlite3.Connection, user_id: int) -> dict:
    """Vuelve al aspecto original: quita preferencias y portada. cover_v sigue subiendo para no repetir URL."""
    conn.execute(
        "UPDATE user_prefs SET prefs = NULL, cover = NULL, cover_mime = NULL, cover_v = cover_v + 1, "
        "updated_at = ? WHERE user_id = ?",
        (_now(), user_id),
    )
    return get(conn, user_id)


def detect_image(data: bytes) -> str | None:
    """Tipo de imagen según los primeros bytes (no se confía en lo que diga el navegador)."""
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def set_cover(conn: sqlite3.Connection, user_id: int, data: bytes) -> dict:
    if not data:
        raise PrefsError(422, "Falta la imagen.")
    if len(data) > MAX_COVER_BYTES:
        raise PrefsError(413, "La imagen es demasiado grande (máximo 4 MB).")
    mime = detect_image(data)
    if mime is None:
        raise PrefsError(415, "Usa una imagen JPG, PNG o WebP.")
    conn.execute(
        "INSERT INTO user_prefs (user_id, cover, cover_mime, cover_v, updated_at) VALUES (?, ?, ?, 1, ?) "
        "ON CONFLICT(user_id) DO UPDATE SET cover = excluded.cover, cover_mime = excluded.cover_mime, "
        "cover_v = user_prefs.cover_v + 1, updated_at = excluded.updated_at",
        (user_id, data, mime, _now()),
    )
    return get(conn, user_id)


def get_cover(conn: sqlite3.Connection, user_id: int) -> tuple[bytes, str] | None:
    row = conn.execute(
        "SELECT cover, cover_mime FROM user_prefs WHERE user_id = ? AND cover IS NOT NULL", (user_id,)
    ).fetchone()
    return None if row is None else (bytes(row["cover"]), row["cover_mime"])


def delete_cover(conn: sqlite3.Connection, user_id: int) -> dict:
    conn.execute(
        "UPDATE user_prefs SET cover = NULL, cover_mime = NULL, cover_v = cover_v + 1, updated_at = ? "
        "WHERE user_id = ?",
        (_now(), user_id),
    )
    return get(conn, user_id)
