"""Configuración leída de variables de entorno (ver .env.example)."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    db_path: Path
    session_days: int
    cookie_secure: bool
    min_password_length: int
    login_max_attempts: int
    login_window_seconds: int
    # Carpetas de QR de los usuarios (por defecto, junto a la base de datos) y espacio máximo por usuario.
    files_path: Path | None = None
    files_quota_mb: int = 200
    # QR dinámicos (opcionales): se pueden apagar con APP_DYNAMIC_QR=false. public_url es la dirección
    # pública del sitio que llevará el enlace corto (si está vacía, la web usa la que el usuario ve).
    dynamic_qr: bool = True
    public_url: str = ""
    # ¿Puede cualquiera crear una cuenta? Es el valor inicial: el administrador lo cambia desde Ajustes
    # y esa elección (guardada en la base de datos) manda sobre esta variable.
    registration_open: bool = True
    # Páginas dinámicas (evento, empresa, carta): se pueden apagar con APP_PAGES=false. Sus archivos
    # (imágenes y PDF) van junto a la base de datos, con un espacio máximo por usuario.
    pages_enabled: bool = True
    pages_path: Path | None = None
    pages_quota_mb: int = 200


def load_settings() -> Settings:
    db_path = Path(os.environ.get("APP_DB_PATH", BASE_DIR / "data" / "app.db"))
    return Settings(
        registration_open=_env_bool("APP_REGISTRATION_OPEN", True),
        files_path=Path(os.environ.get("APP_FILES_PATH", db_path.parent / "qr")),
        files_quota_mb=int(os.environ.get("APP_QR_QUOTA_MB", "200")),
        dynamic_qr=_env_bool("APP_DYNAMIC_QR", True),
        pages_enabled=_env_bool("APP_PAGES", True),
        pages_path=Path(os.environ.get("APP_PAGES_PATH", db_path.parent / "paginas")),
        pages_quota_mb=int(os.environ.get("APP_PAGES_QUOTA_MB", "200")),
        public_url=os.environ.get("APP_PUBLIC_URL", "").strip().rstrip("/"),
        db_path=db_path,
        session_days=int(os.environ.get("APP_SESSION_DAYS", "14")),
        # Poner a true cuando el sitio se sirva por HTTPS.
        cookie_secure=_env_bool("APP_COOKIE_SECURE", False),
        min_password_length=int(os.environ.get("APP_MIN_PASSWORD_LENGTH", "8")),
        login_max_attempts=int(os.environ.get("APP_LOGIN_MAX_ATTEMPTS", "5")),
        login_window_seconds=int(os.environ.get("APP_LOGIN_WINDOW_SECONDS", "300")),
    )
