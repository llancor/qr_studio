"""Carpetas de códigos QR por usuario (sistema de archivos, sin tocar SQLite).

Estructura:  <raíz>/<id de usuario>/<carpeta>/<archivo>.png

Todo nombre que llega del cliente se limpia aquí (nunca se usa tal cual como ruta) y toda ruta
resultante se comprueba contra la carpeta del usuario, así que un usuario no puede leer ni escribir
fuera de su espacio.
"""

from __future__ import annotations

import os
import re
import shutil
import struct
import tempfile
import unicodedata
import zipfile
from dataclasses import dataclass
from pathlib import Path

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
MAX_PIXELS_SIDE = 4096

_BAD_CHARS = re.compile(r"[^\w .\-()]", re.UNICODE)
_SPACES = re.compile(r"\s+")
_RESERVED = {"con", "prn", "aux", "nul", *{f"com{i}" for i in range(1, 10)}, *{f"lpt{i}" for i in range(1, 10)}}


class StoreError(Exception):
    """Error pensado para el usuario: lleva el código HTTP y el mensaje en español."""

    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def safe_name(raw: str, max_len: int = 60) -> str:
    """Nombre de carpeta o archivo seguro: sin separadores, sin puntos al final, no reservado."""
    text = unicodedata.normalize("NFC", raw or "").strip()
    text = _BAD_CHARS.sub("-", text)
    text = _SPACES.sub(" ", text).strip(" .-")
    text = text[:max_len].rstrip(" .-")
    if not text:
        raise StoreError(422, "Escribe un nombre válido (letras, números, espacios, guiones o puntos).")
    if text.split(".")[0].lower() in _RESERVED:
        text = f"_{text}"
    return text


def validate_png(data: bytes, max_bytes: int) -> None:
    """Comprueba que son los bytes de un PNG real y de tamaño razonable (cabecera IHDR)."""
    if len(data) > max_bytes:
        raise StoreError(413, "La imagen es demasiado grande.")
    if len(data) < 33 or not data.startswith(PNG_SIGNATURE) or data[12:16] != b"IHDR":
        raise StoreError(415, "El archivo no es un PNG válido.")
    width, height = struct.unpack(">II", data[16:24])
    if not (0 < width <= MAX_PIXELS_SIDE and 0 < height <= MAX_PIXELS_SIDE):
        raise StoreError(415, "Las dimensiones del PNG no son válidas.")


@dataclass(frozen=True)
class Limits:
    quota_bytes: int = 200 * 1024 * 1024
    max_file_bytes: int = 4 * 1024 * 1024
    max_files_per_folder: int = 500
    max_folders: int = 100


class QrStore:
    def __init__(self, root: Path, limits: Limits | None = None):
        self.root = Path(root)
        self.limits = limits or Limits()

    # ----- Rutas ------------------------------------------------------------

    def _user_dir(self, user_id: int) -> Path:
        return self.root / str(int(user_id))

    def _folder_dir(self, user_id: int, folder: str) -> Path:
        base = self._user_dir(user_id).resolve()
        path = (base / safe_name(folder)).resolve()
        if path.parent != base:  # defensa en profundidad
            raise StoreError(400, "Carpeta no válida.")
        return path

    def _existing_folder(self, user_id: int, folder: str) -> Path:
        path = self._folder_dir(user_id, folder)
        if not path.is_dir():
            raise StoreError(404, "La carpeta no existe.")
        return path

    def file_path(self, user_id: int, folder: str, filename: str) -> Path:
        directory = self._existing_folder(user_id, folder)
        path = (directory / f"{safe_name(_strip_png(filename), 80)}.png").resolve()
        if path.parent != directory or not path.is_file():
            raise StoreError(404, "El archivo no existe.")
        return path

    # ----- Consultas --------------------------------------------------------

    def used_bytes(self, user_id: int) -> int:
        base = self._user_dir(user_id)
        if not base.is_dir():
            return 0
        return sum(p.stat().st_size for p in base.rglob("*.png") if p.is_file())

    def list_folders(self, user_id: int) -> dict:
        base = self._user_dir(user_id)
        folders = []
        if base.is_dir():
            for entry in sorted(base.iterdir(), key=lambda p: p.name.lower()):
                if not entry.is_dir():
                    continue
                files = [f for f in entry.glob("*.png") if f.is_file()]
                folders.append(
                    {
                        "name": entry.name,
                        "count": len(files),
                        "bytes": sum(f.stat().st_size for f in files),
                        "modified": int(max((f.stat().st_mtime for f in files), default=entry.stat().st_mtime)),
                    }
                )
        return {
            "folders": folders,
            "quota": {"used": self.used_bytes(user_id), "limit": self.limits.quota_bytes},
            "limits": {"maxFilesPerFolder": self.limits.max_files_per_folder, "maxFolders": self.limits.max_folders},
        }

    def list_files(self, user_id: int, folder: str) -> dict:
        directory = self._existing_folder(user_id, folder)
        files = sorted((f for f in directory.glob("*.png") if f.is_file()), key=lambda p: p.name.lower())
        return {
            "name": directory.name,
            "files": [
                {"name": f.name, "bytes": f.stat().st_size, "modified": int(f.stat().st_mtime)} for f in files
            ],
        }

    # ----- Cambios ----------------------------------------------------------

    def create_folder(self, user_id: int, name: str) -> tuple[str, bool]:
        path = self._folder_dir(user_id, name)
        if path.is_dir():
            return path.name, False
        base = self._user_dir(user_id)
        existing = sum(1 for p in base.iterdir() if p.is_dir()) if base.is_dir() else 0
        if existing >= self.limits.max_folders:
            raise StoreError(409, f"Has llegado al máximo de {self.limits.max_folders} carpetas.")
        path.mkdir(parents=True, exist_ok=True)
        return path.name, True

    def save_file(self, user_id: int, folder: str, filename: str, data: bytes) -> str:
        validate_png(data, self.limits.max_file_bytes)
        directory = self._existing_folder(user_id, folder)
        if sum(1 for _ in directory.glob("*.png")) >= self.limits.max_files_per_folder:
            raise StoreError(409, f"La carpeta ya tiene el máximo de {self.limits.max_files_per_folder} archivos.")
        if self.used_bytes(user_id) + len(data) > self.limits.quota_bytes:
            raise StoreError(413, "Has superado tu espacio disponible. Borra algo para seguir guardando.")
        stem = safe_name(_strip_png(filename), 80)
        for i in range(1, 1000):
            candidate = directory / (f"{stem}.png" if i == 1 else f"{stem} ({i}).png")
            try:
                with open(candidate, "xb") as handle:  # «x»: no pisa un archivo existente
                    handle.write(data)
            except FileExistsError:
                continue
            except OSError:
                candidate.unlink(missing_ok=True)
                raise
            return candidate.name
        raise StoreError(409, "No se pudo elegir un nombre libre para el archivo.")

    def delete_file(self, user_id: int, folder: str, filename: str) -> None:
        self.file_path(user_id, folder, filename).unlink()

    def delete_folder(self, user_id: int, folder: str) -> None:
        shutil.rmtree(self._existing_folder(user_id, folder))

    def zip_folder(self, user_id: int, folder: str):
        """Devuelve (nombre, archivo temporal abierto con el .zip). Quien lo llama debe cerrarlo."""
        directory = self._existing_folder(user_id, folder)
        tmp = tempfile.SpooledTemporaryFile(max_size=32 * 1024 * 1024)  # noqa: SIM115 (lo cierra el llamador)
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as archive:  # los PNG ya van comprimidos
            for f in sorted(directory.glob("*.png"), key=lambda p: p.name.lower()):
                if f.is_file():
                    archive.write(f, arcname=f.name)
        tmp.seek(0)
        return directory.name, tmp


def _strip_png(filename: str) -> str:
    name = os.path.basename((filename or "").replace("\\", "/"))
    return name[:-4] if name.lower().endswith(".png") else name
