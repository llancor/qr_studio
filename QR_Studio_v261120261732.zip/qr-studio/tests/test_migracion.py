"""Migración de la configuración: exportar (cifrada con contraseña) e importar. Ejecutar desde web/:  python -m pytest"""

import base64
import copy
import json

import pytest
from fastapi.testclient import TestClient

from app import auth, db, migracion
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}
PW = "frase-larga-de-prueba-1"  # la contraseña de la migración (mínimo 10 caracteres)

PNG = b"\x89PNG\r\n\x1a\n" + b"x" * 2000
JPEG = b"\xff\xd8\xff\xe0" + b"y" * 3000
SMTP = {
    "host": "smtp.example.com",
    "port": 587,
    "security": "starttls",
    "user": "avisos@example.com",
    "password": "app-password",
    "sender": "avisos@example.com",
    "senderName": "QR Studio",
    "siteUrl": "https://qr.example.com",
}

IMPORT = "/api/admin/migration/import"
FIRST_RUN = "/api/auth/migration/import"


def make_app(tmp_path, name="a", **extra):
    return create_app(
        Settings(
            db_path=tmp_path / f"{name}.db",
            session_days=14,
            cookie_secure=False,
            min_password_length=8,
            login_max_attempts=5,
            login_window_seconds=300,
            files_path=tmp_path / f"qr-{name}",
            **extra,
        )
    )


def client(app):
    return TestClient(app, follow_redirects=False)


def sign_up(app, who):
    c = client(app)
    assert c.post("/api/auth/register", json=who).status_code == 201
    return c


@pytest.fixture()
def origin(tmp_path):
    """Un servidor ya configurado: la fuente de la migración."""
    app = make_app(tmp_path, "origen")
    boss = sign_up(app, ANA)
    assert boss.post("/api/admin/users", json={**LUIS, "role": "user"}).status_code == 201
    assert boss.put("/api/admin/settings", json={"registrationOpen": False}).status_code == 200
    assert boss.put("/api/admin/smtp", json=SMTP).status_code == 200
    assert boss.put("/api/admin/branding", json={"name": "Mi Tienda", "card": "#112233", "text": "#f1f5f9", "accent": "#16a34a"}).status_code == 200
    assert boss.put(
        "/api/admin/branding",
        json={"topBg": "#0f172a", "bottomText": "#e2e8f0", "footerText": "Con cariño.", "privacyLabel": "Privacidad", "footerHidden": True},
    ).status_code == 200
    assert boss.put("/api/admin/branding/logo", content=PNG).status_code == 200
    assert boss.put("/api/admin/login-image", content=JPEG).status_code == 200
    assert boss.put("/api/admin/login-image/settings", json={"velo": 70, "desenfoque": 4, "ajuste": "ajustar", "posicion": "arriba"}).status_code == 200
    luis = client(app)
    luis.post("/api/auth/login", json={"email": LUIS["email"], "password": LUIS["password"]})
    assert luis.put("/api/me/prefs", json={"tema": "oscuro", "acento": "#db2777"}).status_code == 200
    return boss


def export_file(boss, password=PW, **flags):
    """El archivo tal como se descarga (cifrado)."""
    res = boss.post("/api/admin/migration/export", json={"password": password, **flags})
    assert res.status_code == 200, res.text
    return res.json()


def export(boss, password=PW, **flags):
    """El contenido ya descifrado, para comprobar qué lleva."""
    return migracion.unseal(export_file(boss, password, **flags), password)


def body(file, password=PW):
    return json.dumps({"password": password, "file": file})


def seal_body(data, password=PW):
    """Un contenido (posiblemente manipulado) cifrado y listo para enviar."""
    return body(migracion.seal(data, password), password)


# ----- Exportar: siempre con contraseña, siempre cifrado --------------------------------------------------

def test_export_is_an_encrypted_download_that_shows_nothing(origin):
    res = origin.post("/api/admin/migration/export", json={"password": PW, "users": True, "smtpPassword": True})
    assert "attachment" in res.headers["content-disposition"] and "qr-studio-migracion-" in res.headers["content-disposition"]
    assert res.headers["cache-control"] == "no-store"
    file = res.json()
    assert file["format"] == "qr-studio-migration-encrypted" and file["version"] == 1
    assert file["kdf"]["name"] == "scrypt" and file["cipher"]["name"] == "AES-256-GCM" and file["data"]
    # nada legible: ni ajustes, ni correo, ni nombres, ni la contraseña del correo, ni los usuarios
    for secreto in ("smtp.example.com", "Mi Tienda", "app-password", "avisos@example.com", "ana@example.com", "scrypt$", "#112233"):
        assert secreto not in res.text
    assert PW not in res.text


def test_export_needs_a_password_of_at_least_10_characters(origin):
    assert origin.post("/api/admin/migration/export", json={}).status_code == 422
    for bad in ("", "corta", "123456789", "x" * 129):
        res = origin.post("/api/admin/migration/export", json={"password": bad})
        assert res.status_code == 422, bad
    res = origin.post("/api/admin/migration/export", json={"password": "corta"})
    assert "entre 10 y 128" in res.json()["detail"]
    assert origin.get("/api/admin/migration/export").status_code in (404, 405)  # ya no existe sin contraseña


def test_two_exports_with_the_same_password_are_different_files(origin):
    first, second = export_file(origin), export_file(origin)
    assert first["data"] != second["data"] and first["kdf"]["salt"] != second["kdf"]["salt"]


def test_decrypted_export_has_everything_but_no_secrets_by_default(origin):
    data = export(origin)
    assert data["format"] == "qr-studio-migration"
    assert data["settings"] == {"registrationOpen": False}
    assert data["smtp"]["host"] == "smtp.example.com" and "password" not in data["smtp"]
    assert data["brand"]["name"] == "Mi Tienda" and data["brand"]["accent"] == "#16a34a"
    assert base64.b64decode(data["brand"]["logo"]["data"]) == PNG
    assert data["login"]["velo"] == 70 and base64.b64decode(data["login"]["image"]["data"]) == JPEG
    assert "users" not in data


def test_export_can_include_the_smtp_password_and_users(origin):
    data = export(origin, smtpPassword=True, users=True)
    assert data["smtp"]["password"] == "app-password"
    assert [u["email"] for u in data["users"]] == [ANA["email"], LUIS["email"]]
    luis = data["users"][1]
    assert luis["role"] == "user" and luis["active"] is True and luis["hash"].startswith("scrypt$")
    assert luis["prefs"]["tema"] == "oscuro"
    assert LUIS["password"] not in json.dumps(data)  # nunca la contraseña, solo su hash


def test_export_of_a_fresh_server_is_valid_and_has_no_smtp(tmp_path):
    boss = sign_up(make_app(tmp_path, "vacio"), ANA)
    data = export(boss)
    assert data["smtp"] is None and data["brand"]["logo"] is None and data["login"]["image"] is None
    assert data["brand"]["name"] == "QR Studio" and data["settings"]["registrationOpen"] is True


def test_only_the_admin_can_export_or_import(tmp_path, origin):
    app = make_app(tmp_path, "dos")
    boss = sign_up(app, ANA)
    boss.post("/api/admin/users", json={**LUIS, "role": "user"})
    luis = client(app)
    luis.post("/api/auth/login", json={"email": LUIS["email"], "password": LUIS["password"]})
    for who, expected in ((client(app), 401), (luis, 403)):
        assert who.post("/api/admin/migration/export", json={"password": PW}).status_code == expected
        assert who.post(IMPORT, content=b"{}").status_code == expected


# ----- Abrir el archivo: la contraseña, el cifrado y la manipulación --------------------------------------

def test_the_same_password_opens_it_and_a_wrong_one_does_not(tmp_path, origin):
    file = export_file(origin)
    app = make_app(tmp_path, "destino")
    boss = sign_up(app, ANA)
    bad = boss.post(IMPORT, content=body(file, "otra-frase-distinta-9"))
    assert bad.status_code == 422 and "contraseña no es correcta" in bad.json()["detail"]
    assert boss.post(IMPORT, content=body(file, PW)).status_code == 200


def test_missing_or_empty_password_on_import(tmp_path, origin):
    file = export_file(origin)
    boss = sign_up(make_app(tmp_path, "destino"), ANA)
    for content in (json.dumps({"file": file}), body(file, ""), json.dumps({"file": file, "password": 7})):
        res = boss.post(IMPORT, content=content)
        assert res.status_code == 422 and "contraseña" in res.json()["detail"]


def test_a_tampered_file_is_detected(tmp_path, origin):
    file = export_file(origin)
    boss = sign_up(make_app(tmp_path, "destino"), ANA)

    changed_header = copy.deepcopy(file)
    changed_header["created"] = "2000-01-01T00:00:00+00:00"  # la cabecera también está autenticada
    changed_data = copy.deepcopy(file)
    raw = bytearray(base64.b64decode(changed_data["data"]))
    raw[len(raw) // 2] ^= 0x01
    changed_data["data"] = base64.b64encode(bytes(raw)).decode()
    changed_salt = copy.deepcopy(file)
    changed_salt["kdf"]["salt"] = base64.b64encode(b"otra-sal-distinta").decode()

    for tampered in (changed_header, changed_data, changed_salt):
        res = boss.post(IMPORT, content=body(tampered))
        assert res.status_code == 422 and "contraseña no es correcta, o el archivo está dañado" in res.json()["detail"]
    assert boss.get("/api/admin/branding").json()["name"] == "QR Studio"  # no se aplicó nada


def test_a_plain_unencrypted_file_is_refused(tmp_path, origin):
    plain = export(origin)  # el contenido en claro, sin cifrar
    boss = sign_up(make_app(tmp_path, "destino"), ANA)
    res = boss.post(IMPORT, content=body(plain))
    assert res.status_code == 422 and "no está cifrado" in res.json()["detail"]
    fresh = make_app(tmp_path, "nuevo")
    assert client(fresh).post(FIRST_RUN, content=body(plain)).status_code == 422


@pytest.mark.parametrize(
    "mutate,fragment",
    [
        (lambda f: f["kdf"].update(n=2**30), "parámetros de cifrado"),
        (lambda f: f["kdf"].update(n=3), "parámetros de cifrado"),
        (lambda f: f["kdf"].update(r=100), "parámetros de cifrado"),
        (lambda f: f["kdf"].update(p=64), "parámetros de cifrado"),
        (lambda f: f["kdf"].update(n="16384"), "parámetros de cifrado"),
        (lambda f: f["kdf"].update(salt="@@@"), "sal"),
        (lambda f: f["cipher"].update(nonce=base64.b64encode(b"corto").decode()), "nonce"),
        (lambda f: f.update(data="@@@"), "datos"),
        (lambda f: f.update(data=base64.b64encode(b"x").decode()), "datos"),
        (lambda f: f["kdf"].update(name="pbkdf2"), "no conoce"),
        (lambda f: f["cipher"].update(name="ROT13"), "no conoce"),
        (lambda f: f.update(version=99), "más nueva"),
        (lambda f: f.update(version="1"), "versión"),
        (lambda f: f.update(format="otra-cosa"), "no es una migración"),
    ],
)
def test_dangerous_or_broken_envelopes_are_refused(tmp_path, origin, mutate, fragment):
    file = export_file(origin)
    mutate(file)
    boss = sign_up(make_app(tmp_path, "destino"), ANA)
    res = boss.post(IMPORT, content=body(file))
    assert res.status_code == 422 and fragment in res.json()["detail"]


def test_wrong_passwords_are_rate_limited(tmp_path, origin):
    file = export_file(origin)
    boss = sign_up(make_app(tmp_path, "destino"), ANA)
    codes = [boss.post(IMPORT, content=body(file, f"incorrecta-numero-{i}")).status_code for i in range(11)]
    assert codes[:10] == [422] * 10 and codes[10] == 429


# ----- Importar en un servidor nuevo (primer arranque) -------------------------------------------------

def test_first_run_import_sets_up_everything_and_the_imported_admin_can_log_in(tmp_path, origin):
    file = export_file(origin, smtpPassword=True, users=True)
    fresh = make_app(tmp_path, "nuevo")
    guest = client(fresh)
    assert guest.get("/api/auth/options").json()["firstUser"] is True

    res = guest.post(FIRST_RUN, content=body(file))
    assert res.status_code == 200, res.text
    report = res.json()
    assert report["dryRun"] is False and report["usersAdded"] == 2 and report["smtp"] and report["smtpPassword"]
    assert report["logo"] and report["loginImageFile"] and report["registrationOpen"] is False

    options = client(fresh).get("/api/auth/options").json()
    assert options["firstUser"] is False and options["registrationOpen"] is False
    assert options["site"]["name"] == "Mi Tienda" and options["site"]["logoVersion"] == 1
    # Colores de las barras y textos del pie viajan con la marca; lo que no se cambió sigue vacío.
    site = options["site"]
    assert site["topBg"] == "#0f172a" and site["bottomText"] == "#e2e8f0" and site["topText"] == "" and site["bottomBg"] == ""
    assert site["footerText"] == "Con cariño." and site["privacyLabel"] == "Privacidad" and site["termsLabel"] == ""
    assert site["footerHidden"] is True
    assert options["loginImage"]["velo"] == 70 and options["recoveryEnabled"] is True

    boss = client(fresh)
    assert boss.post("/api/auth/login", json={"email": ANA["email"], "password": ANA["password"]}).status_code == 200
    assert boss.get("/api/auth/me").json()["user"]["role"] == "admin"
    assert boss.get("/api/admin/smtp").json()["passwordSet"] is True
    luis = client(fresh)
    assert luis.post("/api/auth/login", json={"email": LUIS["email"], "password": LUIS["password"]}).status_code == 200
    assert luis.get("/api/me/prefs").json()["prefs"]["acento"] == "#db2777"
    assert client(fresh).get("/api/auth/site-logo").content == PNG


def test_first_run_wrong_password_imports_nothing(tmp_path, origin):
    fresh = make_app(tmp_path, "nuevo")
    guest = client(fresh)
    res = guest.post(FIRST_RUN, content=body(export_file(origin, users=True), "no-es-la-frase-1"))
    assert res.status_code == 422
    assert guest.get("/api/auth/options").json()["firstUser"] is True


def test_first_run_import_without_users_leaves_the_first_account_to_the_installer(tmp_path, origin):
    fresh = make_app(tmp_path, "nuevo")
    guest = client(fresh)
    res = guest.post(FIRST_RUN, content=body(export_file(origin)))
    assert res.status_code == 200 and res.json()["usersAdded"] == 0
    # sigue sin haber cuentas: quien llega primero crea la del administrador, como siempre
    assert guest.get("/api/auth/options").json()["firstUser"] is True
    assert client(fresh).post("/api/auth/register", json=ANA).status_code == 201


def test_first_run_import_is_refused_once_there_is_an_account(tmp_path, origin):
    fresh = make_app(tmp_path, "nuevo")
    sign_up(fresh, ANA)
    assert client(fresh).post(FIRST_RUN, content=body(export_file(origin))).status_code == 403


def test_first_run_import_needs_an_active_admin_when_it_brings_users(tmp_path, origin):
    data = export(origin, users=True)
    for user in data["users"]:
        user["role"] = "user"
    fresh = make_app(tmp_path, "nuevo")
    res = client(fresh).post(FIRST_RUN, content=seal_body(data))
    assert res.status_code == 422 and "administrador" in res.json()["detail"]
    assert client(fresh).get("/api/auth/options").json()["firstUser"] is True  # no quedó nada a medias


def test_first_run_import_is_rate_limited(tmp_path):
    fresh = make_app(tmp_path, "nuevo")
    guest = client(fresh)
    codes = [guest.post(FIRST_RUN, content=b"{}").status_code for _ in range(11)]
    assert codes[:10] == [422] * 10 and codes[10] == 429


# ----- Importar como administrador -------------------------------------------------------------------------

def test_dry_run_reports_but_writes_nothing(tmp_path, origin):
    file = export_file(origin, smtpPassword=True, users=True)
    app = make_app(tmp_path, "destino")
    boss = sign_up(app, {"email": "otra@example.com", "name": "Otra", "password": "correct-horse-9"})
    res = boss.post(IMPORT, params={"dry_run": True}, content=body(file))
    assert res.status_code == 200 and res.json()["dryRun"] is True and res.json()["usersAdded"] == 2
    assert boss.get("/api/admin/branding").json()["name"] == "QR Studio"
    assert boss.get("/api/admin/smtp").json()["configured"] is False
    assert len(boss.get("/api/admin/users").json()["users"]) == 1


def test_admin_import_merges_without_deleting_and_skips_existing_users(tmp_path, origin):
    file = export_file(origin, users=True)
    app = make_app(tmp_path, "destino")
    boss = sign_up(app, ANA)  # ya existe Ana
    boss.put("/api/admin/smtp", json={**SMTP, "host": "otro.example.com", "password": "clave-local"})
    res = boss.post(IMPORT, content=body(file))
    assert res.status_code == 200
    report = res.json()
    assert report["usersAdded"] == 1 and report["usersSkipped"] == 1 and report["smtpPassword"] is False
    emails = [u["email"] for u in boss.get("/api/admin/users").json()["users"]]
    assert emails == [ANA["email"], LUIS["email"]]
    assert boss.get("/api/admin/smtp").json()["host"] == "smtp.example.com"  # el archivo manda en los ajustes
    assert boss.get("/api/admin/smtp").json()["passwordSet"] is True  # sin contraseña en el archivo se conserva la local
    with db.connect(app.state.settings.db_path) as conn:
        exported_hash = migracion.unseal(file, PW)["users"][0]["hash"]
        assert conn.execute("SELECT password_hash FROM users WHERE email = ?", (ANA["email"],)).fetchone()[0] != exported_hash


def test_a_missing_logo_or_image_in_the_file_does_not_remove_the_current_ones(tmp_path, origin):
    app = make_app(tmp_path, "destino")
    boss = sign_up(app, ANA)
    boss.put("/api/admin/branding/logo", content=PNG)
    data = export(boss)  # esta instalación no tiene imagen de acceso
    data["brand"]["logo"] = None
    assert boss.post(IMPORT, content=seal_body(data)).status_code == 200
    assert boss.get("/api/admin/branding").json()["logoVersion"] >= 1


@pytest.mark.parametrize(
    "mutate,fragment",
    [
        (lambda f: f.update(format="otra-cosa"), "no es una migración"),
        (lambda f: f.update(version=99), "más nueva"),
        (lambda f: f.update(version="1"), "versión"),
        (lambda f: f["settings"].update(registrationOpen="si"), "verdadero o falso"),
        (lambda f: f["smtp"].update(host="mal host"), "servidor SMTP"),
        (lambda f: f["smtp"].update(port="587"), "puerto"),
        (lambda f: f["brand"].update(accent="rojo"), "colores"),
        (lambda f: f["brand"].update(name="x" * 80), "demasiado largo"),
        (lambda f: f["brand"]["logo"].update(data="@@@no-es-base64@@@"), "dañada"),
        (lambda f: f["login"].update(velo=500), "velo"),
        (lambda f: f.update(users="no es una lista"), "users"),
        (lambda f: f["users"][1].update(email="no-es-correo"), "correo no válido"),
        (lambda f: f["users"][1].update(hash="scrypt$1$1$1$AAAA$AAAA"), "no es válida"),
        (lambda f: f["users"][1].update(role="superjefe"), "rol"),
        (lambda f: f["users"][1].update(active="si"), "activo"),
    ],
)
def test_invalid_contents_are_rejected_and_apply_nothing(tmp_path, origin, mutate, fragment):
    data = export(origin, users=True)
    mutate(data)
    app = make_app(tmp_path, "destino")
    boss = sign_up(app, ANA)
    res = boss.post(IMPORT, content=seal_body(data))  # bien cifrado, pero con contenido que no vale
    assert res.status_code in (413, 422) and fragment in res.json()["detail"]
    assert boss.get("/api/admin/branding").json()["name"] == "QR Studio"  # nada a medias
    assert len(boss.get("/api/admin/users").json()["users"]) == 1


def test_garbage_and_oversized_requests(tmp_path, origin):
    boss = sign_up(make_app(tmp_path, "destino"), ANA)
    assert boss.post(IMPORT, content=b"esto no es json").status_code == 422
    assert boss.post(IMPORT, content=b"[]").status_code == 422
    res = boss.post(IMPORT, content=b'{"file": 5, "password": "frase-larga-1"}')
    assert res.status_code == 422 and "no es una migración" in res.json()["detail"]
    assert boss.post(IMPORT, content=b"x" * (12 * 1024 * 1024 + 100_000)).status_code == 413


def test_hash_validation_rejects_dangerous_parameters():
    ok = auth.hash_password("correct-horse-1")
    assert auth.is_valid_hash(ok)
    parts = ok.split("$")
    for n in ("1000000", "3", "2048", "1073741824"):
        assert not auth.is_valid_hash("$".join([parts[0], n, *parts[2:]]))
    for bad in ("", "x", "bcrypt$1$2$3$4$5", None, 5, ok + "$extra", "scrypt$16384$8$1$!!$!!"):
        assert not auth.is_valid_hash(bad)
