"""Marca del sitio: nombre, logo y colores de la página de acceso. Ejecutar desde web/:  python -m pytest"""

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}

PNG = b"\x89PNG\r\n\x1a\n" + b"x" * 3000
DEFAULT = {
    "name": "QR Studio",
    "logoVersion": 0,
    "card": "",
    "text": "",
    "accent": "",
    "topBg": "",
    "topText": "",
    "bottomBg": "",
    "bottomText": "",
    "footerText": "",
    "privacyLabel": "",
    "termsLabel": "",
    "footerHidden": False,
}


@pytest.fixture()
def app(tmp_path):
    return create_app(
        Settings(
            db_path=tmp_path / "test.db",
            session_days=14,
            cookie_secure=False,
            min_password_length=8,
            login_max_attempts=5,
            login_window_seconds=300,
            files_path=tmp_path / "qr",
        )
    )


def sign_up(app, who):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=who).status_code == 201
    return client


@pytest.fixture()
def ana(app):
    return sign_up(app, ANA)


@pytest.fixture()
def luis(app, ana):
    return sign_up(app, LUIS)


def test_defaults_are_the_original_look(app, ana):
    assert ana.get("/api/admin/branding").json() == DEFAULT
    assert TestClient(app).get("/api/auth/options").json()["site"] == DEFAULT


def test_site_is_public_without_session_and_with_it(app, ana):
    ana.put("/api/admin/branding", json={"name": "Mi Tienda", "card": "#112233", "text": "#FFFFFF", "accent": "#DB2777"})
    expected = {**DEFAULT, "name": "Mi Tienda", "card": "#112233", "text": "#ffffff", "accent": "#db2777"}
    assert TestClient(app).get("/api/auth/options").json()["site"] == expected  # sin sesión, para la página de acceso
    assert ana.get("/api/me/prefs").json()["site"] == expected  # con sesión, para el resto de páginas


def test_only_the_admin_can_change_the_brand(app, ana, luis):
    guest = TestClient(app, follow_redirects=False)
    for client, expected in ((guest, 401), (luis, 403)):
        assert client.get("/api/admin/branding").status_code == expected
        assert client.put("/api/admin/branding", json={"name": "X"}).status_code == expected
        assert client.put("/api/admin/branding/logo", content=PNG).status_code == expected
        assert client.delete("/api/admin/branding/logo").status_code == expected


@pytest.mark.parametrize(
    "body",
    [
        {"name": "x" * 41},
        {"name": "a\nb"},
        {"name": 7},
        {"card": "rojo"},
        {"text": "#12345"},
        {"accent": "#gggggg"},
        {"card": 5},
        [],
    ],
)
def test_invalid_brand_values_are_rejected(ana, body):
    assert ana.put("/api/admin/branding", json=body).status_code == 422
    assert ana.get("/api/admin/branding").json() == DEFAULT  # un rechazo no deja nada a medias


def test_saving_only_some_fields_keeps_the_rest(ana):
    ana.put("/api/admin/branding", json={"name": "Mi Tienda", "card": "#112233"})
    info = ana.put("/api/admin/branding", json={"accent": "#16a34a"}).json()
    assert info["name"] == "Mi Tienda" and info["card"] == "#112233" and info["accent"] == "#16a34a"


def test_empty_color_goes_back_to_the_theme_default_and_empty_name_to_the_original(ana):
    ana.put("/api/admin/branding", json={"name": "Mi Tienda", "card": "#112233"})
    info = ana.put("/api/admin/branding", json={"name": "   ", "card": ""}).json()
    assert info["name"] == "QR Studio" and info["card"] == ""
    info = ana.put("/api/admin/branding", json={"name": "Mi Tienda"}).json()
    assert ana.put("/api/admin/branding", json={"name": "QR Studio"}).json()["name"] == "QR Studio"
    assert info["name"] == "Mi Tienda"


def test_logo_is_public_and_versioned(app, ana):
    guest = TestClient(app, follow_redirects=False)
    assert guest.get("/api/auth/site-logo").status_code == 404
    info = ana.put("/api/admin/branding/logo", content=PNG, headers={"Content-Type": "image/png"}).json()
    assert info["logoVersion"] == 1
    got = guest.get("/api/auth/site-logo")
    assert got.status_code == 200 and got.content == PNG and got.headers["content-type"] == "image/png"
    assert "immutable" in got.headers["cache-control"]
    assert guest.get("/api/auth/options").json()["site"]["logoVersion"] == 1


def test_logo_must_be_a_small_real_image(ana):
    assert ana.put("/api/admin/branding/logo", content=b"<svg onload=alert(1)></svg>" * 10).status_code == 415
    assert ana.put("/api/admin/branding/logo", content=b"").status_code == 422
    assert ana.put("/api/admin/branding/logo", content=b"\x89PNG\r\n\x1a\n" + b"0" * (1024 * 1024 + 10)).status_code == 413


def test_removing_the_logo_never_reuses_a_version(app, ana):
    guest = TestClient(app, follow_redirects=False)
    first = ana.put("/api/admin/branding/logo", content=PNG).json()["logoVersion"]
    assert ana.delete("/api/admin/branding/logo").json()["logoVersion"] == 0
    assert guest.get("/api/auth/site-logo").status_code == 404
    assert ana.put("/api/admin/branding/logo", content=PNG).json()["logoVersion"] > first


def test_bar_colors_and_footer_texts_are_saved_and_public(app, ana):
    body = {
        "topBg": "#112233",
        "topText": "#FFFFFF",
        "bottomBg": "#445566",
        "bottomText": "#F0F0F0",
        "footerText": "Hecho con cariño.",
        "privacyLabel": "Privacidad",
        "termsLabel": "Condiciones",
        "footerHidden": True,
    }
    info = ana.put("/api/admin/branding", json=body).json()
    assert info["topBg"] == "#112233" and info["topText"] == "#ffffff" and info["bottomText"] == "#f0f0f0"
    assert info["footerText"] == "Hecho con cariño." and info["privacyLabel"] == "Privacidad"
    assert info["termsLabel"] == "Condiciones" and info["footerHidden"] is True
    # Es del sitio: lo ve quien no ha iniciado sesión (página de acceso) y quien sí.
    assert TestClient(app).get("/api/auth/options").json()["site"] == info
    assert ana.get("/api/me/prefs").json()["site"] == info


def test_footer_texts_empty_or_equal_to_the_original_go_back_to_it(ana):
    ana.put("/api/admin/branding", json={"footerText": "Mío", "privacyLabel": "Privacidad", "termsLabel": "Reglas"})
    info = ana.put(
        "/api/admin/branding",
        json={"footerText": "  ", "privacyLabel": "Aviso de privacidad", "termsLabel": None},
    ).json()
    assert info["footerText"] == "" and info["privacyLabel"] == "" and info["termsLabel"] == ""


def test_bar_colors_can_be_reset_one_by_one(ana):
    ana.put("/api/admin/branding", json={"topBg": "#112233", "bottomBg": "#445566"})
    info = ana.put("/api/admin/branding", json={"topBg": ""}).json()
    assert info["topBg"] == "" and info["bottomBg"] == "#445566"


@pytest.mark.parametrize(
    "body",
    [
        {"topBg": "azul"},
        {"topText": "#12345"},
        {"bottomBg": 3},
        {"bottomText": "#gggggg"},
        {"footerText": "x" * 81},
        {"footerText": "a\nb"},
        {"privacyLabel": 7},
        {"termsLabel": "y" * 81},
        {"footerHidden": "si"},
        {"footerHidden": 1},
    ],
)
def test_invalid_bar_and_footer_values_are_rejected(ana, body):
    assert ana.put("/api/admin/branding", json=body).status_code == 422
    assert ana.get("/api/admin/branding").json() == DEFAULT  # un rechazo no deja nada a medias


def test_footer_text_is_stored_as_plain_text_and_never_as_html(app, ana):
    text = "<script>alert(1)</script>"
    assert ana.put("/api/admin/branding", json={"footerText": text}).json()["footerText"] == text
    # El navegador lo pone con textContent; aquí solo se comprueba que viaja tal cual dentro del JSON.
    assert TestClient(app).get("/api/auth/options").json()["site"]["footerText"] == text


def test_the_footer_text_hook_exists_in_every_page_that_shows_it():
    """Cada página con el pie «Hecho con Python y SQLite.» lo trae dentro de data-pie-texto (si no, tema.js no lo cambia)."""
    from pathlib import Path

    static = Path(__file__).resolve().parents[1] / "app" / "static"
    for page in static.rglob("*.html"):
        html = page.read_text(encoding="utf-8")
        if "Hecho con Python y SQLite." in html:
            assert "<span data-pie-texto>Hecho con Python y SQLite.</span>" in html, page


def test_the_brand_does_not_touch_the_login_image_or_the_account_look(ana):
    ana.put("/api/admin/branding", json={"name": "Mi Tienda", "accent": "#16a34a"})
    ana.put("/api/admin/branding/logo", content=PNG)
    assert ana.get("/api/admin/login-image").json()["version"] == 0
    assert ana.get("/api/me/prefs").json()["prefs"] is None
