"""Acceso sin iniciar sesión y datos legales (aviso de privacidad y términos). Ejecutar desde web/:  python -m pytest"""

import sqlite3

import pytest
from fastapi.testclient import TestClient

from app import db
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}
MARTA = {"email": "marta@example.com", "name": "Marta", "password": "correct-horse-3"}
LEGAL = {"name": "Mi Empresa SAS", "email": "privacidad@example.com", "country": "Colombia", "address": "Calle 1 # 2-3"}

# Páginas y archivos que cualquiera puede abrir con el acceso abierto, y los que siguen pidiendo cuenta.
OPEN_PAGES = ["/", "/lector/", "/png-a-ico/", "/codigo-de-barras/"]
OPEN_ASSETS = ["/js/app.js", "/js/lector.js", "/js/qr.js", "/vendor/qr-code-styling.js", "/vendor/jsQR.js"]
ACCOUNT_PAGES = ["/ajustes/", "/paginas/", "/ajustes/index.html"]


def make_settings(tmp_path, **extra):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
        files_path=tmp_path / "qr",
        **extra,
    )


@pytest.fixture()
def app(tmp_path):
    return create_app(make_settings(tmp_path))


def new_client(app):
    return TestClient(app, follow_redirects=False)


def sign_up(app, who, **extra):
    client = new_client(app)
    res = client.post("/api/auth/register", json={**who, **extra})
    assert res.status_code == 201, res.text
    return client


@pytest.fixture()
def boss(app):
    return sign_up(app, ANA)


# ----- Acceso sin iniciar sesión ---------------------------------------------------------------------


def test_public_access_is_off_by_default(app, boss):
    guest = new_client(app)
    assert guest.get("/api/auth/options").json()["publicAccess"] is False
    assert boss.get("/api/admin/public-access").json() == {"publicAccess": False}
    for path in OPEN_PAGES:
        res = guest.get(path, headers={"Accept": "text/html"})
        assert res.status_code == 303 and res.headers["location"].startswith("/entrar/?next=")


def test_admin_turns_public_access_on_and_off(app, boss):
    guest = new_client(app)
    assert boss.put("/api/admin/public-access", json={"publicAccess": True}).json() == {"publicAccess": True}
    assert guest.get("/api/auth/options").json()["publicAccess"] is True
    for path in OPEN_PAGES:
        assert guest.get(path, headers={"Accept": "text/html"}).status_code == 200, path
    assert boss.put("/api/admin/public-access", json={"publicAccess": False}).json() == {"publicAccess": False}
    for path in OPEN_PAGES:
        assert guest.get(path, headers={"Accept": "text/html"}).status_code == 303, path


@pytest.mark.parametrize("path", OPEN_ASSETS)
def test_open_access_serves_the_tool_files(app, boss, path):
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    assert new_client(app).get(path).status_code == 200


@pytest.mark.parametrize("path", ACCOUNT_PAGES)
def test_account_pages_still_need_a_session_when_open(app, boss, path):
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    res = new_client(app).get(path, headers={"Accept": "text/html"})
    assert res.status_code == 303 and res.headers["location"].startswith("/entrar/?next=")


@pytest.mark.parametrize(
    "method,path",
    [
        ("get", "/api/qr/folders"),
        ("get", "/api/dynamic"),
        ("get", "/api/paginas"),
        ("get", "/api/me/prefs"),
        ("get", "/api/admin/users"),
        ("get", "/api/admin/public-access"),
        ("get", "/api/admin/legal"),
        ("get", "/api/admin/smtp"),
        ("post", "/api/admin/migration/export"),
    ],
)
def test_open_access_never_opens_the_api(app, boss, method, path):
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    assert getattr(new_client(app), method)(path).status_code == 401


def test_open_access_is_read_only_for_guests(app, boss):
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    guest = new_client(app)
    # Un invitado solo lee páginas y archivos: cualquier otro método sigue rechazado.
    assert guest.post("/", content=b"x").status_code in {401, 405}
    assert guest.put("/js/app.js", content=b"x").status_code in {401, 405}


def test_only_the_admin_can_change_public_access(app, boss):
    sign_up(app, LUIS)
    luis = new_client(app)
    luis.post("/api/auth/login", json={"email": LUIS["email"], "password": LUIS["password"]})
    assert luis.put("/api/admin/public-access", json={"publicAccess": True}).status_code == 403
    assert new_client(app).put("/api/admin/public-access", json={"publicAccess": True}).status_code == 401
    assert boss.get("/api/admin/public-access").json() == {"publicAccess": False}


def test_public_access_choice_survives_a_restart_and_beats_the_environment(tmp_path):
    first = create_app(make_settings(tmp_path))
    boss = sign_up(first, ANA)
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    second = create_app(make_settings(tmp_path))  # mismo archivo de base de datos
    assert new_client(second).get("/api/auth/options").json()["publicAccess"] is True
    # La variable de entorno es solo el valor inicial: lo guardado manda.
    opened = create_app(make_settings(tmp_path / "otra", public_access=True))
    assert new_client(opened).get("/api/auth/options").json()["publicAccess"] is True
    sign_up(opened, ANA).put("/api/admin/public-access", json={"publicAccess": False})
    assert new_client(opened).get("/api/auth/options").json()["publicAccess"] is False


def test_logged_in_users_are_not_affected_by_the_switch(app, boss):
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    assert boss.get("/ajustes/", headers={"Accept": "text/html"}).status_code == 200
    assert boss.get("/api/qr/folders").status_code == 200


# ----- El aspecto de los invitados es el del administrador ---------------------------------------------

COVER = b"\x89PNG\r\n\x1a\n" + b"portada-del-admin" * 80


def set_look(client, **prefs):
    assert client.put("/api/me/prefs", json=prefs).status_code == 200


def test_public_appearance_does_not_exist_while_access_is_closed(app, boss):
    set_look(boss, tema="oscuro", acento="#db2777")
    assert boss.put("/api/me/cover", content=COVER).status_code == 200
    guest = new_client(app)
    assert guest.get("/api/auth/appearance").status_code == 404
    assert guest.get("/api/auth/public-cover").status_code == 404


def test_guests_get_the_admins_look_when_access_is_open(app, boss):
    set_look(boss, tema="oscuro", acento="#db2777", esquinas="redondas")
    boss.put("/api/admin/branding", json={"name": "Mi Tienda"})
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    data = new_client(app).get("/api/auth/appearance").json()
    assert data["prefs"]["tema"] == "oscuro" and data["prefs"]["acento"] == "#db2777" and data["prefs"]["esquinas"] == "redondas"
    assert data["site"]["name"] == "Mi Tienda" and data["coverVersion"] == 0


def test_guests_get_the_admins_cover_image(app, boss):
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    assert new_client(app).get("/api/auth/public-cover").status_code == 404  # aún sin portada
    version = boss.put("/api/me/cover", content=COVER).json()["coverVersion"]
    guest = new_client(app)
    assert guest.get("/api/auth/appearance").json()["coverVersion"] == version
    res = guest.get("/api/auth/public-cover")
    assert res.status_code == 200 and res.content == COVER and res.headers["content-type"] == "image/png"
    assert "max-age" in res.headers["cache-control"]


def test_closing_the_access_hides_the_look_again(app, boss):
    set_look(boss, tema="oscuro")
    boss.put("/api/me/cover", content=COVER)
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    assert new_client(app).get("/api/auth/appearance").status_code == 200
    boss.put("/api/admin/public-access", json={"publicAccess": False})
    guest = new_client(app)
    assert guest.get("/api/auth/appearance").status_code == 404
    assert guest.get("/api/auth/public-cover").status_code == 404


def test_other_users_looks_are_never_shown_to_guests(app, boss):
    set_look(boss, tema="oscuro", acento="#db2777")
    luis = sign_up(app, LUIS)
    set_look(luis, tema="claro", acento="#16a34a")
    luis.put("/api/me/cover", content=COVER + b"-de-luis")
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    guest = new_client(app)
    data = guest.get("/api/auth/appearance").json()
    assert data["prefs"]["tema"] == "oscuro" and data["prefs"]["acento"] == "#db2777"
    assert data["coverVersion"] == 0  # la portada de Luis no es la del administrador
    assert guest.get("/api/auth/public-cover").status_code == 404


def test_the_look_belongs_to_the_oldest_active_admin(app, boss):
    set_look(boss, tema="oscuro")
    luis = sign_up(app, LUIS)
    set_look(luis, tema="claro")
    assert boss.patch("/api/admin/users/2", json={"role": "admin"}).status_code == 200
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    assert new_client(app).get("/api/auth/appearance").json()["prefs"]["tema"] == "oscuro"  # manda la más antigua
    assert luis.patch("/api/admin/users/1", json={"active": False}).status_code == 200  # se desactiva a Ana
    assert new_client(app).get("/api/auth/appearance").json()["prefs"]["tema"] == "claro"  # pasa a la siguiente


def test_admin_without_saved_look_gives_the_original_one(app, boss):
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    data = new_client(app).get("/api/auth/appearance").json()
    assert data["prefs"] is None and data["coverVersion"] == 0  # el navegador usa los valores originales


def test_logged_in_users_keep_their_own_look(app, boss):
    set_look(boss, tema="oscuro")
    luis = sign_up(app, LUIS)
    set_look(luis, tema="claro")
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    assert luis.get("/api/me/prefs").json()["prefs"]["tema"] == "claro"


def test_the_client_uses_the_public_look_only_without_a_session(app, boss):
    script = new_client(app).get("/js/tema.js")  # el cliente decide por el 401 de /api/me/prefs
    assert script.status_code == 200 and "/api/auth/appearance" in script.text and "/api/auth/public-cover" in script.text


# ----- Datos legales ---------------------------------------------------------------------------------


def test_legal_starts_empty_and_public_pages_always_open(app, boss):
    guest = new_client(app)
    data = guest.get("/api/auth/legal").json()
    assert data["configured"] is False and data["name"] == "" and data["updatedAt"] == ""
    assert guest.get("/api/auth/options").json()["legalConfigured"] is False
    for path in ("/privacidad/", "/terminos/", "/js/legal.js"):
        assert guest.get(path, headers={"Accept": "text/html"}).status_code == 200, path


def test_legal_pages_are_public_even_with_public_access_off(app, boss):
    guest = new_client(app)
    assert guest.get("/", headers={"Accept": "text/html"}).status_code == 303
    html = guest.get("/privacidad/").text
    assert "Aviso de privacidad" in html and "composeFrame" not in html
    assert "Términos de uso" in guest.get("/terminos/").text


def test_admin_saves_legal_data_and_everyone_can_read_it(app, boss):
    saved = boss.put("/api/admin/legal", json=LEGAL).json()
    assert saved["configured"] is True and saved["name"] == LEGAL["name"] and saved["updatedAt"]
    public = new_client(app).get("/api/auth/legal").json()
    assert public["name"] == LEGAL["name"] and public["email"] == LEGAL["email"] and public["country"] == "Colombia"
    assert public["siteName"] == "QR Studio" and public["sessionDays"] == 14
    assert new_client(app).get("/api/auth/options").json()["legalConfigured"] is True
    assert boss.get("/api/admin/legal").json() == saved


def test_public_legal_reports_which_features_exist(app, boss):
    data = new_client(app).get("/api/auth/legal").json()
    assert data["publicAccess"] is False and data["registrationOpen"] is True
    assert data["recoveryEnabled"] is False and data["dynamicQr"] is True and data["pages"] is True
    boss.put("/api/admin/public-access", json={"publicAccess": True})
    boss.put("/api/admin/settings", json={"registrationOpen": False})
    data = new_client(app).get("/api/auth/legal").json()
    assert data["publicAccess"] is True and data["registrationOpen"] is False


def test_the_update_date_only_moves_when_something_changes(app, boss):
    first = boss.put("/api/admin/legal", json=LEGAL).json()
    again = boss.put("/api/admin/legal", json=LEGAL).json()
    assert again["updatedAt"] == first["updatedAt"]
    with sqlite3.connect(app.state.settings.db_path) as conn:
        conn.execute("UPDATE app_settings SET value = '2020-01-01' WHERE key = 'legal_updated'")
    unchanged = boss.put("/api/admin/legal", json=LEGAL).json()
    assert unchanged["updatedAt"] == "2020-01-01"  # mismos datos: la fecha no se toca
    changed = boss.put("/api/admin/legal", json={**LEGAL, "country": "México"}).json()
    assert changed["updatedAt"] != "2020-01-01" and changed["country"] == "México"


def test_legal_partial_updates_keep_the_rest(app, boss):
    boss.put("/api/admin/legal", json=LEGAL)
    kept = boss.put("/api/admin/legal", json={"address": ""}).json()
    assert kept["name"] == LEGAL["name"] and kept["email"] == LEGAL["email"] and kept["address"] == ""


@pytest.mark.parametrize(
    "body",
    [
        {"email": "no-es-correo"},
        {"name": "x" * 121},
        {"country": "y" * 81},
        {"address": "z" * 201},
        {"name": "con\x00control"},
        {"name": 5},
        {"email": ["a@b.co"]},
    ],
)
def test_legal_rejects_bad_values(app, boss, body):
    assert boss.put("/api/admin/legal", json=body).status_code == 422
    assert boss.get("/api/admin/legal").json()["configured"] is False


def test_legal_values_are_stored_as_plain_text(app, boss):
    boss.put("/api/admin/legal", json={**LEGAL, "name": "<script>alert(1)</script>"})
    # El servidor lo guarda tal cual; la página lo escribe con textContent, nunca como HTML.
    assert new_client(app).get("/api/auth/legal").json()["name"] == "<script>alert(1)</script>"
    script = new_client(app).get("/js/legal.js").text
    assert "textContent" in script and "innerHTML" not in script


# ----- Aceptar los términos al crear una cuenta ------------------------------------------------------


def test_without_legal_data_nothing_has_to_be_accepted(app, boss):
    assert new_client(app).post("/api/auth/register", json=LUIS).status_code == 201


def test_with_legal_data_creating_an_account_requires_acceptance(app, boss):
    boss.put("/api/admin/legal", json=LEGAL)
    guest = new_client(app)
    res = guest.post("/api/auth/register", json=LUIS)
    assert res.status_code == 422 and "aceptar" in res.json()["detail"]
    assert guest.post("/api/auth/register", json={**LUIS, "acceptTerms": False}).status_code == 422
    assert guest.post("/api/auth/register", json={**LUIS, "acceptTerms": True}).status_code == 201


def test_acceptance_is_recorded_with_date_and_version(app, boss):
    boss.put("/api/admin/legal", json=LEGAL)
    version = boss.get("/api/admin/legal").json()["updatedAt"]
    sign_up(app, LUIS, acceptTerms=True)
    with sqlite3.connect(app.state.settings.db_path) as conn:
        rows = {email: (at, ver) for email, at, ver in conn.execute("SELECT email, terms_accepted_at, terms_version FROM users")}
    assert rows[LUIS["email"]][0] and rows[LUIS["email"]][1] == version
    assert rows[ANA["email"]] == (None, None)  # quien se registró antes de existir los textos no aceptó nada


def test_acceptance_is_also_recorded_when_given_without_being_required(app, boss):
    sign_up(app, MARTA, acceptTerms=True)
    with sqlite3.connect(app.state.settings.db_path) as conn:
        (at,) = conn.execute("SELECT terms_accepted_at FROM users WHERE email = ?", (MARTA["email"],)).fetchone()
    assert at


def test_the_admin_can_still_create_accounts_without_acceptance(app, boss):
    boss.put("/api/admin/legal", json=LEGAL)
    assert boss.post("/api/admin/users", json={**LUIS, "role": "user"}).status_code == 201


def test_old_databases_get_the_acceptance_columns(tmp_path):
    path = tmp_path / "old.db"
    with sqlite3.connect(path) as conn:
        conn.executescript(
            """
            CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
            INSERT INTO users (email, name, password_hash, created_at) VALUES ('uno@example.com', 'Uno', 'x', '2026-01-01');
            """
        )
    db.init_db(path)
    db.init_db(path)
    with sqlite3.connect(path) as conn:
        columns = {row[1] for row in conn.execute("PRAGMA table_info(users)")}
    assert {"terms_accepted_at", "terms_version"} <= columns
