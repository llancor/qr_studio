// Pie de página: muestra la versión del software («Versión v191120261705», igual que el nombre del .zip) y un botón
// «Actualizar página» que descarga de nuevo la página y sus archivos sin usar la caché del navegador.
// Falla en silencio: si no se puede leer la versión, el pie queda con el botón solamente.

/** Vacía lo que el navegador guardó de este sitio, vuelve a bajar la página con sus archivos y la recarga.
 *  No toca la sesión ni las preferencias (localStorage): solo archivos en caché. */
async function actualizarPagina(boton) {
  const texto = boton.textContent;
  boton.disabled = true;
  boton.textContent = "Actualizando…";
  try {
    // 1) Caché de archivos del navegador (Cache Storage) y service workers, si algo los hubiera dejado.
    if ("caches" in window) {
      for (const nombre of await caches.keys()) await caches.delete(nombre);
    }
    if (navigator.serviceWorker?.getRegistrations) {
      for (const registro of await navigator.serviceWorker.getRegistrations()) await registro.unregister();
    }
    // 2) La página y todo lo que cargó (hojas de estilo, scripts y módulos importados) se piden otra vez sin caché;
    //    eso reemplaza la copia guardada. La API nunca se guarda en caché, así que no hace falta pedirla.
    const urls = new Set([window.location.href]);
    for (const recurso of performance.getEntriesByType("resource")) {
      const url = new URL(recurso.name, window.location.href);
      if (url.origin === window.location.origin && /\.(js|css|html|svg)$/.test(url.pathname)) urls.add(url.href);
    }
    await Promise.all([...urls].map((url) => fetch(url, { cache: "reload", credentials: "same-origin" }).catch(() => null)));
  } catch {
    /* si algo falla, igual se recarga */
  }
  // 3) Recarga. Con los archivos ya renovados, lo que se ve es lo último que hay en el servidor.
  window.location.reload();
  // Por si el navegador demora o cancela la recarga, el botón no queda trabado.
  setTimeout(() => {
    boton.disabled = false;
    boton.textContent = texto;
  }, 4000);
}

(async () => {
  const container = document.querySelector(".site-footer .container");
  if (!container) return;

  const fila = document.createElement("p");
  fila.className = "site-actualizar";
  const boton = document.createElement("button");
  boton.type = "button";
  boton.className = "btn-refrescar";
  boton.textContent = "Actualizar página";
  boton.title = "Borra la copia guardada por el navegador y vuelve a cargar la página con lo último del servidor";
  boton.addEventListener("click", () => actualizarPagina(boton));
  fila.append(boton);
  container.append(fila);

  try {
    const response = await fetch("/healthz", { cache: "no-store" });
    if (!response.ok) return;
    const { version } = await response.json();
    if (!version) return;
    const line = document.createElement("p");
    line.className = "site-version";
    line.textContent = `Versión ${version}`;
    fila.before(line); // la versión queda arriba del botón
  } catch {
    /* sin versión visible */
  }
})();
