// Ajustes → Página de acceso: la imagen de fondo de la página donde se escribe el usuario y la contraseña.
// Es del sitio (la elige el administrador) y es pública: se ve sin iniciar sesión. El servidor comprueba el rol en
// cada petición de /api/admin; si quien abre Ajustes no es administrador, la primera petición da 403 y aquí no
// se hace nada (la sección ni se muestra).

import { abrirImagen, prepararImagen } from './personalizacion.js';

const $ = (id) => document.getElementById(id);

async function api(path, { method = 'GET', body, blob } = {}) {
  const res = await fetch(path, {
    method,
    headers: blob ? { 'Content-Type': blob.type || 'image/jpeg' } : body ? { 'Content-Type': 'application/json' } : undefined,
    body: blob ?? (body ? JSON.stringify(body) : undefined),
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  return data;
}

function mensaje(id, text) {
  const box = $(id);
  box.textContent = text || '';
  box.hidden = !text;
}

let okTimer = 0;
function aviso(text) {
  mensaje('lg-ok', text);
  clearTimeout(okTimer);
  if (text) okTimer = setTimeout(() => mensaje('lg-ok', ''), 5000);
}

let shownVersion = null;

function mostrar(info) {
  const hay = info.version > 0;
  const img = $('lg-img');
  if (info.version !== shownVersion) {
    // La miniatura solo se vuelve a cargar si la imagen cambió.
    if (hay) img.src = `/api/auth/login-image?v=${info.version}`;
    else img.removeAttribute('src');
    shownVersion = info.version;
  }
  img.hidden = !hay;
  $('lg-vacio').hidden = hay;
  $('lg-quitar').disabled = !hay;
  $('lg-opciones').setAttribute('aria-disabled', String(!hay));
  for (const control of $('lg-opciones').querySelectorAll('input, select')) control.disabled = !hay;
  $('lg-velo').value = info.velo;
  $('lg-velo-out').textContent = `${info.velo} %`;
  $('lg-desenfoque').value = info.desenfoque;
  $('lg-desenfoque-out').textContent = `${info.desenfoque} px`;
  $('lg-ajuste').value = info.ajuste;
  $('lg-posicion').value = info.posicion;
}

// Los ajustes se guardan poco después del último cambio (los deslizadores disparan muchos seguidos).
let saveTimer = 0;
function saveSettings() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    try {
      mensaje('lg-error', '');
      await api('/api/admin/login-image/settings', {
        method: 'PUT',
        body: {
          velo: Number($('lg-velo').value),
          desenfoque: Number($('lg-desenfoque').value),
          ajuste: $('lg-ajuste').value,
          posicion: $('lg-posicion').value,
        },
      });
    } catch (err) {
      mensaje('lg-error', err.message);
    }
  }, 400);
}

$('lg-velo').addEventListener('input', () => {
  $('lg-velo-out').textContent = `${$('lg-velo').value} %`;
  saveSettings();
});
$('lg-desenfoque').addEventListener('input', () => {
  $('lg-desenfoque-out').textContent = `${$('lg-desenfoque').value} px`;
  saveSettings();
});
$('lg-ajuste').addEventListener('change', saveSettings);
$('lg-posicion').addEventListener('change', saveSettings);

$('lg-file').addEventListener('change', async (event) => {
  const input = event.target;
  const file = input.files?.[0];
  mensaje('lg-error', '');
  aviso('');
  if (!file) return;
  input.disabled = true;
  try {
    const blob = await prepararImagen(file);
    const info = await api('/api/admin/login-image', { method: 'PUT', blob });
    // Los ajustes elegidos antes de subir la imagen (o los que hay en pantalla) se conservan.
    mostrar(info);
    aviso('Listo: ya es el fondo de la página de acceso.');
  } catch (err) {
    mensaje('lg-error', err.message);
  } finally {
    input.value = '';
    input.disabled = false;
  }
});

$('lg-quitar').addEventListener('click', async () => {
  mensaje('lg-error', '');
  try {
    mostrar(await api('/api/admin/login-image', { method: 'DELETE' }));
    aviso('Se quitó la imagen: la página de acceso vuelve al fondo normal.');
  } catch (err) {
    mensaje('lg-error', err.message);
  }
});

// ----- Colores de la tarjeta de entrada --------------------------------------------------------------

// Un color vacío ('') es «el predeterminado del tema»; el valor de abajo solo es lo que enseña el selector.
const COLORES = {
  card: { input: 'co-card', reset: 'co-card-reset', state: 'co-card-state', ejemplo: '#ffffff' },
  text: { input: 'co-text', reset: 'co-text-reset', state: 'co-text-state', ejemplo: '#1a1630' },
  accent: { input: 'co-accent', reset: 'co-accent-reset', state: 'co-accent-state', ejemplo: '#2f5bff' },
};
let colores = { card: '', text: '', accent: '' };

function luminancia(hex) {
  const n = parseInt(hex.slice(1), 16);
  const [r, g, b] = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function contraste(a, b) {
  const [alto, bajo] = [luminancia(a), luminancia(b)].sort((x, y) => y - x);
  return (alto + 0.05) / (bajo + 0.05);
}

function pintarColores() {
  for (const [clave, c] of Object.entries(COLORES)) {
    $(c.input).value = colores[clave] || c.ejemplo;
    $(c.state).textContent = colores[clave] || 'Predeterminado del tema';
  }
  // Vista previa (se escriben propiedades CSS con el CSSOM: la política de seguridad no admite style="")
  const vista = $('co-preview');
  const poner = (nombre, valor) => (valor ? vista.style.setProperty(nombre, valor) : vista.style.removeProperty(nombre));
  poner('--p-card', colores.card);
  poner('--p-text', colores.text);
  poner('--p-accent', colores.accent);
  poner('--p-ink', colores.accent ? (luminancia(colores.accent) > 0.45 ? '#11111b' : '#ffffff') : '');
  // Aviso de poco contraste (si solo se elige uno, se compara con lo que suele haber por defecto).
  const fondo = colores.card || '#ffffff';
  const texto = colores.text || '#1a1630';
  $('co-contrast').hidden = !(colores.card || colores.text) || contraste(fondo, texto) >= 4.5;
}

for (const [clave, c] of Object.entries(COLORES)) {
  $(c.input).addEventListener('input', (event) => {
    colores[clave] = event.target.value;
    pintarColores();
  });
  $(c.reset).addEventListener('click', () => {
    colores[clave] = '';
    pintarColores();
  });
}

function textoOk(id, text) {
  mensaje(id, text);
  if (text) setTimeout(() => mensaje(id, ''), 5000);
}

$('co-save').addEventListener('click', async () => {
  mensaje('co-error', '');
  $('co-save').disabled = true;
  try {
    const info = await api('/api/admin/branding', { method: 'PUT', body: { card: colores.card, text: colores.text, accent: colores.accent } });
    window.QRTema?.ponerSitio(info);
    textoOk('co-ok', 'Colores guardados. Se ven al abrir la página de acceso.');
  } catch (err) {
    mensaje('co-error', err.message);
  } finally {
    $('co-save').disabled = false;
  }
});

// ----- Barras superior e inferior -----------------------------------------------------------------------

const PIE_BASE = 'Hecho con Python y SQLite.';
// Un color vacío es «el del tema»; el valor de abajo solo es lo que enseña el selector. `css` es la variable de la vista previa.
const BARRAS = {
  topBg: { input: 'ba-top-bg', reset: 'ba-top-bg-reset', state: 'ba-top-bg-state', ejemplo: '#ffffff', css: '--b-top-bg' },
  topText: { input: 'ba-top-text', reset: 'ba-top-text-reset', state: 'ba-top-text-state', ejemplo: '#1a1630', css: '--b-top-text' },
  bottomBg: { input: 'ba-bottom-bg', reset: 'ba-bottom-bg-reset', state: 'ba-bottom-bg-state', ejemplo: '#ffffff', css: '--b-bottom-bg' },
  bottomText: { input: 'ba-bottom-text', reset: 'ba-bottom-text-reset', state: 'ba-bottom-text-state', ejemplo: '#5b5675', css: '--b-bottom-text' },
};
let barras = { topBg: '', topText: '', bottomBg: '', bottomText: '' };
let nombreSitio = 'QR Studio';

function pintarBarras() {
  const vista = $('ba-preview');
  for (const [clave, c] of Object.entries(BARRAS)) {
    $(c.input).value = barras[clave] || c.ejemplo;
    $(c.state).textContent = barras[clave] || 'Predeterminado del tema';
    if (barras[clave]) vista.style.setProperty(c.css, barras[clave]);
    else vista.style.removeProperty(c.css);
  }
  // Vista previa de los textos (lo que se escribe, o el original si está vacío)
  const hide = $('ba-footer-hide').checked;
  $('ba-footer').disabled = hide;
  const frase = $('ba-footer').value.trim() || PIE_BASE;
  $('ba-prev-copy').textContent = `© ${new Date().getFullYear()} ${nombreSitio}.${hide ? '' : ` ${frase}`}`;
  $('ba-prev-priv').textContent = $('ba-privacy').value.trim() || 'Aviso de privacidad';
  $('ba-prev-terms').textContent = $('ba-terms').value.trim() || 'Términos de uso';
  $('ba-prev-name').textContent = nombreSitio;
  // Aviso de poco contraste en cada barra (si solo se elige un color, se compara con lo que suele haber por defecto)
  const flojo = (bg, txt) => (barras[bg] || barras[txt]) && contraste(barras[bg] || '#ffffff', barras[txt] || '#1a1630') < 4.5;
  $('ba-contrast').hidden = !(flojo('topBg', 'topText') || flojo('bottomBg', 'bottomText'));
}

for (const [clave, c] of Object.entries(BARRAS)) {
  $(c.input).addEventListener('input', (event) => {
    barras[clave] = event.target.value;
    pintarBarras();
  });
  $(c.reset).addEventListener('click', () => {
    barras[clave] = '';
    pintarBarras();
  });
}
for (const id of ['ba-footer', 'ba-privacy', 'ba-terms', 'ba-footer-hide']) $(id).addEventListener('input', pintarBarras);

function cargarBarras(info) {
  barras = { topBg: info.topBg || '', topText: info.topText || '', bottomBg: info.bottomBg || '', bottomText: info.bottomText || '' };
  $('ba-footer').value = info.footerText || '';
  $('ba-footer-hide').checked = Boolean(info.footerHidden);
  $('ba-privacy').value = info.privacyLabel || '';
  $('ba-terms').value = info.termsLabel || '';
  pintarBarras();
}

$('ba-save').addEventListener('click', async () => {
  mensaje('ba-error', '');
  $('ba-save').disabled = true;
  try {
    const info = await api('/api/admin/branding', {
      method: 'PUT',
      body: {
        ...barras,
        footerText: $('ba-footer').value.trim(),
        footerHidden: $('ba-footer-hide').checked,
        privacyLabel: $('ba-privacy').value.trim(),
        termsLabel: $('ba-terms').value.trim(),
      },
    });
    cargarBarras(info);
    window.QRTema?.ponerSitio(info);
    textoOk('ba-ok', 'Guardado. Los colores se ven al abrir la página de acceso; los textos, en todas las páginas.');
  } catch (err) {
    mensaje('ba-error', err.message);
  } finally {
    $('ba-save').disabled = false;
  }
});

// ----- Logo y nombre del sitio --------------------------------------------------------------------------

const NOMBRE_BASE = 'QR Studio';

function pintarMarca(info) {
  $('br-name').value = info.name === NOMBRE_BASE ? '' : info.name;
  $('co-prev-name').textContent = info.name;
  nombreSitio = info.name;
  pintarBarras();
  const hay = info.logoVersion > 0;
  const img = $('br-img');
  if (hay) img.src = `/api/auth/site-logo?v=${info.logoVersion}`;
  else img.removeAttribute('src');
  img.hidden = !hay;
  $('br-vacio').hidden = hay;
  $('br-quitar').disabled = !hay;
}

/** Reduce el logo a 256 px como máximo y lo deja en PNG para conservar la transparencia. */
async function prepararLogo(file) {
  if (!file.type.startsWith('image/')) throw new Error('Elige un archivo de imagen (PNG, JPG, WebP o SVG).');
  if (file.size > 10 * 1024 * 1024) throw new Error('El archivo pesa más de 10 MB. Elige un logo más pequeño.');
  const { source, ancho, alto, cerrar } = await abrirImagen(file);
  try {
    if (!ancho || !alto) throw new Error('No se pudo leer ese logo. Prueba con un PNG.');
    const escala = Math.min(1, 256 / Math.max(ancho, alto));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(ancho * escala));
    canvas.height = Math.max(1, Math.round(alto * escala));
    canvas.getContext('2d').drawImage(source, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!blob || blob.size > 900_000) throw new Error('El logo pesa demasiado. Prueba con uno más simple.');
    return blob;
  } finally {
    cerrar();
  }
}

$('br-file').addEventListener('change', async (event) => {
  const input = event.target;
  const file = input.files?.[0];
  mensaje('br-error', '');
  if (!file) return;
  input.disabled = true;
  try {
    const info = await api('/api/admin/branding/logo', { method: 'PUT', blob: await prepararLogo(file) });
    pintarMarca(info);
    window.QRTema?.ponerSitio(info);
    textoOk('br-ok', 'Logo guardado: ya sale en la cabecera y en la página de acceso.');
  } catch (err) {
    mensaje('br-error', err.message);
  } finally {
    input.value = '';
    input.disabled = false;
  }
});

$('br-quitar').addEventListener('click', async () => {
  mensaje('br-error', '');
  try {
    const info = await api('/api/admin/branding/logo', { method: 'DELETE' });
    pintarMarca(info);
    window.QRTema?.ponerSitio(info);
    textoOk('br-ok', 'Se quitó el logo.');
  } catch (err) {
    mensaje('br-error', err.message);
  }
});

$('br-save').addEventListener('click', async () => {
  mensaje('br-error', '');
  $('br-save').disabled = true;
  try {
    // Vacío = volver al nombre original (el servidor lo toma como «QR Studio»).
    const info = await api('/api/admin/branding', { method: 'PUT', body: { name: $('br-name').value.trim() || NOMBRE_BASE } });
    pintarMarca(info);
    window.QRTema?.ponerSitio(info);
    textoOk('br-ok', 'Nombre guardado.');
  } catch (err) {
    mensaje('br-error', err.message);
  } finally {
    $('br-save').disabled = false;
  }
});

// Arranque: solo el administrador puede leerlo; para los demás da 403 y no se hace nada.
api('/api/admin/login-image')
  .then(mostrar)
  .catch(() => {
    /* sin permiso o sin conexión: la sección no se muestra o queda vacía */
  });
api('/api/admin/branding')
  .then((info) => {
    colores = { card: info.card, text: info.text, accent: info.accent };
    pintarColores();
    cargarBarras(info);
    pintarMarca(info);
  })
  .catch(() => {
    /* sin permiso o sin conexión */
  });
