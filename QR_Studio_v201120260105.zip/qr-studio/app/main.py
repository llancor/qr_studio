"""Aplicación FastAPI: API de cuentas (SQLite) y servidor del frontend estático.

Arranque:  uvicorn --factory app.main:create_app
"""

from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urlparse

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from html import escape

from . import admin, auth, db, dynamic, files
from .config import Settings, load_settings

STATIC_DIR = Path(__file__).resolve().parent / "static"
# Versión del paquete (p. ej. v191120261705, igual que el nombre del .zip). La escribe Crear_Paquete_GitHub.ps1.
VERSION_FILE = Path(__file__).resolve().parent / "version.txt"
VERSION_RE = re.compile(r"^[A-Za-z0-9._-]{1,40}$")
COOKIE_NAME = "session"
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,63}$")

# Sin sesión solo se puede ver la página de acceso (y lo que ella necesita) y la comprobación de salud
# que usan el monitor, Docker y los instaladores. Todo lo demás exige iniciar sesión.
LOGIN_PATH = "/entrar/"
PUBLIC_PATHS = {
    "/healthz",
    "/entrar",
    LOGIN_PATH,
    "/entrar/index.html",
    "/css/styles.css",
    "/js/entrar.js",
    "/js/version.js",
}

CSP = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self'; "
    "img-src 'self' data: blob:; "
    "connect-src 'self'; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'"
)


def read_version_file() -> str:
    """Versión del software; «desarrollo» si se ejecuta desde el código fuente sin paquete."""
    try:
        text = VERSION_FILE.read_text(encoding="utf-8-sig").strip()
    except OSError:
        return "desarrollo"
    return text if VERSION_RE.match(text) else "desarrollo"


class RegisterIn(BaseModel):
    email: str
    name: str
    password: str


class LoginIn(BaseModel):
    email: str
    password: str


class FolderIn(BaseModel):
    name: str


class DynamicIn(BaseModel):
    name: str = ""
    target: str


class DynamicPatch(BaseModel):
    name: str | None = None
    target: str | None = None
    active: bool | None = None


class AdminUserIn(BaseModel):
    email: str
    name: str
    password: str
    role: str = "user"


class AdminUserPatch(BaseModel):
    role: str | None = None
    active: bool | None = None


class PasswordIn(BaseModel):
    password: str


class AdminSettingsIn(BaseModel):
    registrationOpen: bool


def _public_user(row: sqlite3.Row) -> dict:
    return {"id": row["id"], "email": row["email"], "name": row["name"], "role": row["role"]}


def _normalize_email(raw: str) -> str:
    email = raw.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(422, "Escribe un correo electrónico válido.")
    return email


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    db.init_db(settings.db_path)

    app = FastAPI(title="QR Studio", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.settings = settings
    login_limiter = auth.LoginLimiter(settings.login_max_attempts, settings.login_window_seconds)
    register_limiter = auth.LoginLimiter(10, settings.login_window_seconds)

    # ----- Middleware -------------------------------------------------------

    def access_gate(request: Request) -> Response | None:
        """Todo el contenido exige sesión. Devuelve la respuesta de rechazo, o None si puede pasar."""
        path = request.url.path
        # /q/<código> es público a propósito: quien escanea un QR dinámico no tiene sesión.
        if path in PUBLIC_PATHS or path.startswith(("/api/auth/", "/q/")):
            return None
        with db.connect(settings.db_path) as conn:
            if auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME)):
                return None
        if path.startswith("/api/"):
            return JSONResponse({"detail": "Inicia sesión para continuar."}, status_code=401)
        wants_page = "text/html" in request.headers.get("accept", "") or path.endswith(("/", ".html"))
        if wants_page and request.method in {"GET", "HEAD"}:
            target = path + (f"?{request.url.query}" if request.url.query else "")
            return RedirectResponse(f"{LOGIN_PATH}?next={quote(target, safe='')}", status_code=303)
        return Response(status_code=401)  # un archivo suelto (script, imagen...) pedido sin sesión

    @app.middleware("http")
    async def security(request: Request, call_next):
        # Defensa CSRF: una petición que cambia datos debe venir de este mismo origen.
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            origin = request.headers.get("origin")
            if origin and urlparse(origin).netloc != request.headers.get("host", ""):
                return JSONResponse({"detail": "Origen no permitido."}, status_code=403)
        response = access_gate(request) or await call_next(request)
        response.headers["Content-Security-Policy"] = CSP
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["X-Frame-Options"] = "DENY"
        # La API nunca se guarda en caché; páginas y archivos se revalidan siempre (así un cambio de
        # versión llega enseguida y, al salir, el botón «atrás» no muestra contenido privado).
        # (/q/ también: una redirección guardada en caché haría que el destino nuevo no se viera ni se contara).
        no_store = request.url.path.startswith(("/api/", "/q/"))
        response.headers["Cache-Control"] = "no-store" if no_store else "no-cache"
        return response

    @app.exception_handler(RequestValidationError)
    async def validation_error(_: Request, __: RequestValidationError):
        return JSONResponse({"detail": "Solicitud no válida."}, status_code=422)

    # ----- Utilidades -------------------------------------------------------

    def set_session_cookie(response: Response, token: str) -> None:
        response.set_cookie(
            COOKIE_NAME,
            token,
            max_age=settings.session_days * 86400,
            httponly=True,
            secure=settings.cookie_secure,
            samesite="lax",
            path="/",
        )

    def client_ip(request: Request) -> str:
        return request.client.host if request.client else "unknown"

    def clean_name(raw: str) -> str:
        name = raw.strip()
        if not 1 <= len(name) <= 80:
            raise HTTPException(422, "Escribe el nombre (máximo 80 caracteres).")
        return name

    def check_password(password: str) -> None:
        if not settings.min_password_length <= len(password) <= 128:
            raise HTTPException(
                422,
                f"La contraseña debe tener entre {settings.min_password_length} y 128 caracteres.",
            )

    # ----- API --------------------------------------------------------------

    version = read_version_file()

    @app.get("/healthz")
    def healthz():
        return {"status": "ok", "version": version, "time": datetime.now(timezone.utc).isoformat()}

    @app.get("/api/auth/options")
    def auth_options():
        """Lo que necesita la página de acceso (pública): ¿se ofrece «Crear cuenta»?"""
        with db.connect(settings.db_path) as conn:
            # Sin ningún usuario siempre se puede registrar el primero: será el administrador.
            first = admin.count_users(conn) == 0
            return {
                "registrationOpen": first or admin.registration_open(conn, settings.registration_open),
                "firstUser": first,
            }

    @app.post("/api/auth/register", status_code=201)
    def register(payload: RegisterIn, request: Request, response: Response):
        ip = client_ip(request)
        if register_limiter.blocked(ip):
            raise HTTPException(429, "Demasiados registros. Inténtalo más tarde.")
        register_limiter.record_failure(ip)  # cuenta cada intento de registro

        email = _normalize_email(payload.email)
        name = clean_name(payload.name)
        check_password(payload.password)

        with db.connect(settings.db_path) as conn:
            first = admin.count_users(conn) == 0
            if not first and not admin.registration_open(conn, settings.registration_open):
                raise HTTPException(
                    403, "La creación de cuentas está desactivada. Pídele una cuenta al administrador."
                )
            password_hash = auth.hash_password(payload.password)
            now = datetime.now(timezone.utc).isoformat()
            role = "admin" if first else "user"  # la primera cuenta del sitio es la del administrador
            try:
                cur = conn.execute(
                    "INSERT INTO users (email, name, password_hash, created_at, role) VALUES (?, ?, ?, ?, ?)",
                    (email, name, password_hash, now, role),
                )
            except sqlite3.IntegrityError:
                raise HTTPException(409, "Ya existe una cuenta con ese correo.") from None
            user_id = cur.lastrowid
            token = auth.create_session(conn, user_id, settings.session_days)
        set_session_cookie(response, token)
        return {"user": {"id": user_id, "email": email, "name": name, "role": role}}

    @app.post("/api/auth/login")
    def login(payload: LoginIn, request: Request, response: Response):
        email = payload.email.strip().lower()
        key = f"{client_ip(request)}|{email}"
        if login_limiter.blocked(key):
            raise HTTPException(429, "Demasiados intentos. Espera unos minutos.")

        with db.connect(settings.db_path) as conn:
            row = conn.execute(
                "SELECT id, email, name, role, active, password_hash FROM users WHERE email = ?", (email,)
            ).fetchone()
            stored = row["password_hash"] if row else auth.DUMMY_HASH
            valid = auth.verify_password(payload.password, stored) and row is not None
            if not valid:
                login_limiter.record_failure(key)
                raise HTTPException(401, "Correo o contraseña incorrectos.")
            if not row["active"]:
                # Solo se dice tras acertar la contraseña, para no revelar qué correos existen.
                raise HTTPException(403, "Tu cuenta está desactivada. Habla con el administrador.")
            login_limiter.reset(key)
            token = auth.create_session(conn, row["id"], settings.session_days)
        set_session_cookie(response, token)
        return {"user": _public_user(row)}

    @app.post("/api/auth/logout")
    def logout(request: Request, response: Response):
        with db.connect(settings.db_path) as conn:
            auth.delete_session(conn, request.cookies.get(COOKIE_NAME))
        response.delete_cookie(COOKIE_NAME, path="/")
        return {"ok": True}

    @app.get("/api/auth/me")
    def me(request: Request):
        with db.connect(settings.db_path) as conn:
            row = auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME))
        return {"user": _public_user(row) if row else None}

    # ----- Carpetas de QR por usuario (requieren sesión) --------------------

    store = files.QrStore(
        settings.files_path or settings.db_path.parent / "qr",
        files.Limits(quota_bytes=settings.files_quota_mb * 1024 * 1024),
    )
    app.state.qr_store = store  # los tests ajustan los límites desde aquí

    def require_user(request: Request) -> int:
        with db.connect(settings.db_path) as conn:
            row = auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME))
        if not row:
            raise HTTPException(401, "Inicia sesión para usar esta función.")
        return int(row["id"])

    @app.exception_handler(files.StoreError)
    async def store_error(_: Request, exc: files.StoreError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    async def read_limited(request: Request, limit: int) -> bytes:
        declared = request.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > limit:
            raise files.StoreError(413, "La imagen es demasiado grande.")
        chunks, size = [], 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > limit:
                raise files.StoreError(413, "La imagen es demasiado grande.")
            chunks.append(chunk)
        return b"".join(chunks)

    @app.get("/api/qr/folders")
    def list_folders(request: Request):
        return store.list_folders(require_user(request))

    @app.post("/api/qr/folders", status_code=201)
    def create_folder(payload: FolderIn, request: Request):
        name, created = store.create_folder(require_user(request), payload.name)
        return {"name": name, "created": created}

    @app.get("/api/qr/folders/{folder}")
    def list_files(folder: str, request: Request):
        return store.list_files(require_user(request), folder)

    @app.delete("/api/qr/folders/{folder}")
    def delete_folder(folder: str, request: Request):
        store.delete_folder(require_user(request), folder)
        return {"ok": True}

    @app.post("/api/qr/folders/{folder}/files", status_code=201)
    async def upload_file(folder: str, name: str, request: Request):
        user_id = require_user(request)
        data = await read_limited(request, store.limits.max_file_bytes)
        saved = store.save_file(user_id, folder, name, data)
        return {"name": saved, "bytes": len(data)}

    @app.get("/api/qr/folders/{folder}/files/{filename}")
    def get_file(folder: str, filename: str, request: Request, download: bool = False):
        path = store.file_path(require_user(request), folder, filename)
        return FileResponse(path, media_type="image/png", filename=path.name if download else None)

    @app.delete("/api/qr/folders/{folder}/files/{filename}")
    def delete_file(folder: str, filename: str, request: Request):
        store.delete_file(require_user(request), folder, filename)
        return {"ok": True}

    @app.get("/api/qr/folders/{folder}/zip")
    def download_zip(folder: str, request: Request):
        name, archive = store.zip_folder(require_user(request), folder)

        def chunks():
            try:
                while block := archive.read(1024 * 1024):
                    yield block
            finally:
                archive.close()

        disposition = f"attachment; filename=\"qr.zip\"; filename*=UTF-8''{quote(name)}.zip"
        return StreamingResponse(chunks(), media_type="application/zip", headers={"Content-Disposition": disposition})

    # ----- Administración (solo administradores) -------------------------------

    @app.exception_handler(admin.AdminError)
    async def admin_error(_: Request, exc: admin.AdminError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    def require_admin(request: Request) -> sqlite3.Row:
        with db.connect(settings.db_path) as conn:
            row = auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME))
        if not row:
            raise HTTPException(401, "Inicia sesión para continuar.")
        if row["role"] != "admin":
            raise HTTPException(403, "Solo el administrador puede hacer esto.")
        return row

    @app.get("/api/admin/users")
    def admin_list_users(request: Request):
        require_admin(request)
        with db.connect(settings.db_path) as conn:
            return {"users": admin.list_users(conn)}

    @app.post("/api/admin/users", status_code=201)
    def admin_create_user(payload: AdminUserIn, request: Request):
        require_admin(request)
        email = _normalize_email(payload.email)
        name = clean_name(payload.name)
        check_password(payload.password)
        password_hash = auth.hash_password(payload.password)
        with db.connect(settings.db_path) as conn:
            return {"user": admin.create_user(conn, email, name, password_hash, payload.role)}

    @app.patch("/api/admin/users/{user_id}")
    def admin_update_user(user_id: int, payload: AdminUserPatch, request: Request):
        actor = require_admin(request)
        with db.connect(settings.db_path) as conn:
            return {
                "user": admin.update_user(
                    conn, int(actor["id"]), user_id, role=payload.role, active=payload.active
                )
            }

    @app.post("/api/admin/users/{user_id}/password")
    def admin_reset_password(user_id: int, payload: PasswordIn, request: Request):
        actor = require_admin(request)
        check_password(payload.password)
        password_hash = auth.hash_password(payload.password)
        # Si el administrador cambia la suya, se conserva la sesión que está usando.
        keep = request.cookies.get(COOKIE_NAME) if user_id == int(actor["id"]) else None
        with db.connect(settings.db_path) as conn:
            admin.set_password(conn, user_id, password_hash, keep)
        return {"ok": True}

    @app.get("/api/admin/settings")
    def admin_get_settings(request: Request):
        require_admin(request)
        with db.connect(settings.db_path) as conn:
            return {"registrationOpen": admin.registration_open(conn, settings.registration_open)}

    @app.put("/api/admin/settings")
    def admin_put_settings(payload: AdminSettingsIn, request: Request):
        require_admin(request)
        with db.connect(settings.db_path) as conn:
            admin.set_registration_open(conn, payload.registrationOpen)
        return {"registrationOpen": payload.registrationOpen}

    # ----- QR dinámicos (opcionales) ------------------------------------------

    @app.exception_handler(dynamic.DynamicError)
    async def dynamic_error(_: Request, exc: dynamic.DynamicError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    def require_dynamic(request: Request) -> int:
        user_id = require_user(request)
        if not settings.dynamic_qr:
            raise HTTPException(404, "Los QR dinámicos no están activados en este servidor.")
        return user_id

    @app.get("/api/features")
    def features(request: Request):
        require_user(request)
        return {"dynamicQr": settings.dynamic_qr, "publicUrl": settings.public_url}

    @app.get("/api/dynamic")
    def dynamic_list(request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.list_items(conn, user_id)

    @app.post("/api/dynamic", status_code=201)
    def dynamic_create(payload: DynamicIn, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.create(conn, user_id, payload.name, payload.target)

    @app.patch("/api/dynamic/{qr_id}")
    def dynamic_update(qr_id: int, payload: DynamicPatch, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.update(
                conn, user_id, qr_id, name=payload.name, target=payload.target, active=payload.active
            )

    @app.delete("/api/dynamic/{qr_id}")
    def dynamic_delete(qr_id: int, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            dynamic.delete(conn, user_id, qr_id)
        return {"ok": True}

    @app.get("/api/dynamic/{qr_id}/stats")
    def dynamic_stats(qr_id: int, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.stats(conn, user_id, qr_id)

    def notice_page(status: int, title: str, text: str) -> HTMLResponse:
        body = (
            '<!doctype html><html lang="es"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f"<title>{escape(title)}</title>"
            '<meta name="robots" content="noindex"><link rel="stylesheet" href="/css/styles.css"></head>'
            '<body><main><section class="login container"><div class="login-card">'
            f"<h1>{escape(title)}</h1><p class=\"login-lead\">{escape(text)}</p>"
            "</div></section></main></body></html>"
        )
        return HTMLResponse(body, status_code=status, headers={"Cache-Control": "no-store"})

    @app.get("/q/{code}")
    def follow(code: str):
        """Destino de un QR dinámico (público). Cuenta la visita y redirige; nunca se guarda en caché."""
        if not settings.dynamic_qr:
            return notice_page(404, "No disponible", "Este servidor no tiene activados los QR dinámicos.")
        with db.connect(settings.db_path) as conn:
            result, target = dynamic.record_scan(conn, code)
        if result == "ok" and target:
            return RedirectResponse(target, status_code=302, headers={"Cache-Control": "no-store"})
        if result == "paused":
            return notice_page(410, "Código pausado", "Su dueño lo ha desactivado por ahora. Vuelve a intentarlo más tarde.")
        return notice_page(404, "Código no encontrado", "Este código QR no existe o fue eliminado.")

    # ----- Frontend ---------------------------------------------------------

    app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
    return app
