// Muestra los enlaces marcados con data-admin-only (p. ej. «Ajustes») solo si quien navega es administrador.
// El servidor vuelve a comprobarlo en cada petición de /api/admin: esto solo evita enseñar un enlace inútil.

fetch('/api/auth/me', { credentials: 'same-origin' })
  .then((res) => (res.ok ? res.json() : null))
  .then((data) => {
    if (data?.user?.role !== 'admin') return;
    document.querySelectorAll('[data-admin-only]').forEach((el) => {
      el.hidden = false;
    });
  })
  .catch(() => {
    /* sin conexión: los enlaces siguen ocultos */
  });
