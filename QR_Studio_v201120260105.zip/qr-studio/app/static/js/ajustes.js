// Ajustes del administrador: crear usuarios, restablecer contraseñas, activar o desactivar cuentas,
// cambiar el rol y decidir si cualquiera puede crear una cuenta. El servidor comprueba el rol en cada
// petición; esta página solo es la interfaz. Todo texto que llega del servidor se escribe con textContent.

const $ = (id) => document.getElementById(id);

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  return data;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

/** Contraseña al azar sin caracteres que se confundan (0/O, 1/l/I). */
export function randomPassword(length = 14) {
  const alphabet = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const limit = 256 - (256 % alphabet.length); // evita sesgo al repartir los bytes
  let out = '';
  while (out.length < length) {
    for (const byte of crypto.getRandomValues(new Uint8Array(length * 2))) {
      if (byte < limit && out.length < length) out += alphabet[byte % alphabet.length];
    }
  }
  return out;
}

let me = null;
let users = [];
let statusTimer = 0;

/** Aviso arriba de la página. `sticky`: no se quita solo (para algo que hay que copiar, como una contraseña). */
function say(message, isError = false, sticky = false) {
  const box = $('ad-status');
  box.textContent = message;
  box.hidden = !message;
  box.classList.toggle('is-error', isError);
  clearTimeout(statusTimer);
  if (message && !sticky) statusTimer = setTimeout(() => (box.hidden = true), 8000);
}

function setFieldError(id, message) {
  $(id).textContent = message || '';
  $(id).hidden = !message;
}

// ----- Crear cuentas: abrir o cerrar -------------------------------------------

function showRegistration(open) {
  $('ad-registration').checked = open;
  $('ad-registration-hint').textContent = open
    ? 'Ahora cualquiera puede crear una cuenta desde la página de entrada.'
    : 'Ahora nadie puede crear una cuenta por su cuenta: solo tú, desde esta página. Quien ya tiene cuenta sigue entrando.';
}

$('ad-registration').addEventListener('change', async (event) => {
  const wanted = event.target.checked;
  event.target.disabled = true;
  try {
    const data = await api('/api/admin/settings', { method: 'PUT', body: { registrationOpen: wanted } });
    showRegistration(data.registrationOpen);
    say(data.registrationOpen ? 'Se permite crear cuentas.' : 'Se desactivó la creación de cuentas.');
  } catch (err) {
    showRegistration(!wanted);
    say(err.message, true);
  } finally {
    event.target.disabled = false;
  }
});

// ----- Lista de usuarios ---------------------------------------------------------

function formatDate(iso) {
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleDateString('es', { year: 'numeric', month: 'short', day: 'numeric' });
}

function badge(text, kind) {
  return el('span', `admin-badge admin-badge-${kind}`, text);
}

function renderUsers() {
  const list = $('ad-users');
  list.replaceChildren();
  for (const user of users) {
    const row = el('div', 'admin-user' + (user.active ? '' : ' is-off'));

    const who = el('div', 'admin-who');
    const title = el('strong', 'admin-name', user.name);
    who.append(title);
    if (user.id === me.id) who.append(el('span', 'admin-you', ' (tú)'));
    who.append(el('span', 'admin-email', user.email));
    const tags = el('span', 'admin-tags');
    tags.append(badge(user.role === 'admin' ? 'Administrador' : 'Usuario', user.role === 'admin' ? 'admin' : 'user'));
    if (!user.active) tags.append(badge('Desactivada', 'off'));
    const created = formatDate(user.createdAt);
    if (created) tags.append(el('span', 'admin-date', `Desde ${created}`));
    who.append(tags);
    row.append(who);

    const actions = el('div', 'admin-actions');
    const reset = el('button', 'btn btn-small', 'Restablecer contraseña');
    reset.type = 'button';
    reset.addEventListener('click', () => openReset(user));
    actions.append(reset);

    const toggle = el('button', 'btn btn-small', user.active ? 'Desactivar' : 'Activar');
    toggle.type = 'button';
    toggle.disabled = user.id === me.id; // el servidor también lo impide
    if (user.id === me.id) toggle.title = 'No puedes desactivar tu propia cuenta.';
    toggle.addEventListener('click', () => change(user, { active: !user.active }, user.active ? 'desactivada' : 'activada'));
    actions.append(toggle);

    const role = el('button', 'btn btn-small', user.role === 'admin' ? 'Quitar administrador' : 'Hacer administrador');
    role.type = 'button';
    role.addEventListener('click', () => change(user, { role: user.role === 'admin' ? 'user' : 'admin' }, 'actualizada'));
    actions.append(role);

    row.append(actions);
    list.append(row);
  }
}

async function loadUsers() {
  users = (await api('/api/admin/users')).users;
  renderUsers();
}

async function change(user, patch, doneWord) {
  if (patch.active === false && !window.confirm(`¿Desactivar la cuenta de ${user.name}? Perderá el acceso de inmediato.`)) return;
  try {
    await api(`/api/admin/users/${user.id}`, { method: 'PATCH', body: patch });
    await loadUsers();
    say(`Cuenta de ${user.name} ${doneWord}.`);
  } catch (err) {
    say(err.message, true);
  }
}

// ----- Crear un usuario ----------------------------------------------------------

$('ad-generate').addEventListener('click', () => {
  $('ad-password').value = randomPassword();
});

$('ad-create').addEventListener('submit', async (event) => {
  event.preventDefault();
  setFieldError('ad-create-error', '');
  const name = $('ad-name').value.trim();
  const email = $('ad-email').value.trim();
  const password = $('ad-password').value;
  if (!name || !email || !password) {
    setFieldError('ad-create-error', 'Completa el nombre, el correo y la contraseña.');
    return;
  }
  $('ad-create-submit').disabled = true;
  try {
    await api('/api/admin/users', { method: 'POST', body: { name, email, password, role: $('ad-role').value } });
    say(`Usuario creado: ${email}. Comparte con esa persona su contraseña inicial: ${password}`, false, true);
    $('ad-create').reset();
    await loadUsers();
  } catch (err) {
    setFieldError('ad-create-error', err.message);
  } finally {
    $('ad-create-submit').disabled = false;
  }
});

// ----- Restablecer contraseña --------------------------------------------------------

let resetting = null;
const dialog = $('ad-dialog');

function openReset(user) {
  resetting = user;
  $('ad-dialog-who').textContent = `${user.name} · ${user.email}`;
  $('ad-new-password').value = randomPassword();
  setFieldError('ad-reset-error', '');
  $('ad-reset-done').hidden = true;
  $('ad-reset-submit').disabled = false;
  dialog.showModal();
  $('ad-new-password').select();
}

$('ad-new-generate').addEventListener('click', () => {
  $('ad-new-password').value = randomPassword();
});
$('ad-dialog-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', (event) => {
  if (event.target === dialog) dialog.close();
});

$('ad-copy').addEventListener('click', async () => {
  const button = $('ad-copy');
  try {
    await navigator.clipboard.writeText($('ad-new-password').value);
    button.textContent = 'Copiada';
  } catch {
    $('ad-new-password').select(); // sin permiso de portapapeles: queda seleccionada para copiarla a mano
    button.textContent = 'Cópiala con Ctrl+C';
  }
  setTimeout(() => (button.textContent = 'Copiar contraseña'), 2500);
});

$('ad-reset').addEventListener('submit', async (event) => {
  event.preventDefault();
  setFieldError('ad-reset-error', '');
  const password = $('ad-new-password').value;
  if (!password) {
    setFieldError('ad-reset-error', 'Escribe o genera una contraseña.');
    return;
  }
  $('ad-reset-submit').disabled = true;
  try {
    await api(`/api/admin/users/${resetting.id}/password`, { method: 'POST', body: { password } });
    $('ad-reset-done').textContent = `Listo. Dale esta contraseña a ${resetting.name}; sus sesiones abiertas se cerraron.`;
    $('ad-reset-done').hidden = false;
    say(`Contraseña de ${resetting.name} restablecida.`);
  } catch (err) {
    setFieldError('ad-reset-error', err.message);
    $('ad-reset-submit').disabled = false;
  }
});

// ----- Arranque ----------------------------------------------------------------------

$('year').textContent = new Date().getFullYear();

(async () => {
  try {
    me = (await api('/api/auth/me')).user;
  } catch {
    me = null;
  }
  if (!me) {
    window.location.replace('/entrar/?next=%2Fajustes%2F');
    return;
  }
  if (me.role !== 'admin') {
    $('ad-denied').hidden = false;
    return;
  }
  $('ad-panel').hidden = false;
  try {
    showRegistration((await api('/api/admin/settings')).registrationOpen);
    await loadUsers();
  } catch (err) {
    say(err.message, true);
  }
})();
