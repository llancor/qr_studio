import { FRAMES, TYPES, buildContent, composeFrame, contrastRatio, frameThumbnail } from './qr.js';
import { initAuth } from './auth.js';
import { createBulk } from './masivo.js';
import { createDynamic } from './dinamico.js';

const $ = (id) => document.getElementById(id);
const SVG_NS = 'http://www.w3.org/2000/svg';
const PREVIEW_SIZE = 560; // se muestra a ~280 px CSS (nítido en pantallas HiDPI)
const EXPORT_SIZE = 1024;
const MAX_LOGO_BYTES = 1024 * 1024;
const PLACEHOLDER_DATA = 'https://example.com';

const state = {
  typeId: TYPES[0].id,
  values: {},
  design: {
    frame: 'none',
    frameText: 'ESCANÉAME',
    frameColor: '#2f5bff',
    dotsType: 'square',
    cornersType: 'square',
    cornersDotType: 'square',
    fg: '#1a1630',
    bg: '#ffffff',
    level: 'M',
    logo: null,
    logoSize: 0.3,
  },
};

const currentType = () => TYPES.find((t) => t.id === state.typeId);

// ---------- Utilidades de pestañas ----------

function enableArrowKeys(tablist, tabSelector) {
  tablist.addEventListener('keydown', (event) => {
    const tabs = [...tablist.querySelectorAll(tabSelector)].filter((t) => t.offsetParent !== null);
    const index = tabs.indexOf(document.activeElement);
    if (index < 0) return;
    let next = null;
    if (event.key === 'ArrowRight') next = tabs[(index + 1) % tabs.length];
    else if (event.key === 'ArrowLeft') next = tabs[(index - 1 + tabs.length) % tabs.length];
    else if (event.key === 'Home') next = tabs[0];
    else if (event.key === 'End') next = tabs[tabs.length - 1];
    if (next) {
      event.preventDefault();
      next.focus();
      next.click();
    }
  });
}

function svgIcon(parts) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  // `parts` son fragmentos SVG fijos definidos en qr.js (no contienen datos del usuario).
  const doc = new DOMParser().parseFromString(`<svg xmlns="${SVG_NS}">${parts.join('')}</svg>`, 'image/svg+xml');
  for (const node of doc.documentElement.children) svg.appendChild(document.importNode(node, true));
  return svg;
}

// ---------- Pestañas de tipo de contenido ----------

const typeTabs = $('type-tabs');

// «Masivo»: crear muchos QR a la vez y guardarlos en carpetas de la cuenta (ver masivo.js).
const BULK_TAB = {
  id: 'bulk',
  label: 'Masivo',
  icon: [
    '<rect x="3" y="3" width="7" height="7" rx="1.5"/>',
    '<rect x="14" y="3" width="7" height="7" rx="1.5"/>',
    '<rect x="3" y="14" width="7" height="7" rx="1.5"/>',
    '<rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  ],
};
const isBulk = () => state.typeId === BULK_TAB.id;

function renderTypeTabs() {
  typeTabs.replaceChildren();
  for (const type of [...TYPES, BULK_TAB]) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'tab';
    btn.id = `tab-${type.id}`;
    btn.setAttribute('role', 'tab');
    btn.setAttribute('aria-controls', 'content-form');
    const icon = document.createElement('span');
    icon.className = 'tab-icon';
    icon.appendChild(svgIcon(type.icon));
    const label = document.createElement('span');
    label.className = 'tab-label';
    label.textContent = type.label;
    btn.append(icon, label);
    btn.addEventListener('click', () => selectType(type.id));
    typeTabs.appendChild(btn);
  }
}

function selectType(id) {
  state.typeId = id;
  for (const btn of typeTabs.children) {
    const selected = btn.id === `tab-${id}`;
    btn.setAttribute('aria-selected', String(selected));
    btn.tabIndex = selected ? 0 : -1;
    // En pantallas estrechas la fila se desplaza: se asegura que la pestaña elegida quede a la vista.
    if (selected && typeTabs.scrollWidth > typeTabs.clientWidth) btn.scrollIntoView({ inline: 'nearest', block: 'nearest' });
  }
  const bulkMode = isBulk();
  const form = $('content-form');
  const panel = bulkMode ? $('bulk-panel') : form;
  $('bulk-panel').hidden = !bulkMode;
  form.hidden = bulkMode;
  document.querySelector('.download').hidden = bulkMode;
  panel.setAttribute('role', 'tabpanel');
  panel.setAttribute('aria-labelledby', `tab-${id}`);
  if (!bulkMode) renderForm();
  else {
    $('content-error').hidden = true;
    $('svg-note').hidden = true;
  }
  if (!bulkMode) updateSvgNote();
  syncDynamicPanel();
  schedulePreview();
}

// El QR dinámico es opcional y solo existe en «Sitio web»: el panel aparece si la función está activa.
function syncDynamicPanel() {
  const visible = state.typeId === 'website' && dynamic.available();
  $('dynamic-panel').hidden = !visible;
  if (visible) dynamic.refresh(); // al volver a la pestaña, los escaneos se ven al día
}
const dynamicOn = () => state.typeId === 'website' && dynamic.active();

enableArrowKeys(typeTabs, '.tab');

// ---------- Formulario de contenido ----------

function renderForm() {
  const type = currentType();
  const values = (state.values[type.id] ??= {});
  const form = $('content-form');
  form.replaceChildren();

  for (const field of type.fields) {
    if (field.default !== undefined) values[field.id] ??= field.default;
    const id = `f-${type.id}-${field.id}`;
    const wrap = document.createElement('div');
    wrap.dataset.field = field.id;

    let control;
    if (field.type === 'checkbox') {
      wrap.className = 'field-check';
      control = document.createElement('input');
      control.type = 'checkbox';
      control.checked = Boolean(values[field.id]);
      const label = document.createElement('label');
      label.htmlFor = id;
      label.textContent = field.label;
      control.id = id;
      wrap.append(control, label);
    } else {
      wrap.className = 'field';
      const label = document.createElement('label');
      label.htmlFor = id;
      label.textContent = field.label;
      if (field.type === 'select') {
        control = document.createElement('select');
        for (const [value, text] of field.options) {
          const option = document.createElement('option');
          option.value = value;
          option.textContent = text;
          control.appendChild(option);
        }
      } else if (field.type === 'textarea') {
        control = document.createElement('textarea');
        control.rows = 3;
      } else {
        control = document.createElement('input');
        control.type = field.type;
        if (field.inputmode) control.inputMode = field.inputmode;
      }
      control.id = id;
      if (field.placeholder) control.placeholder = field.placeholder;
      if (field.maxlength) control.maxLength = field.maxlength;
      control.autocomplete = field.autocomplete || 'off';
      control.value = values[field.id] ?? '';
      wrap.append(label, control);
    }

    control.addEventListener('input', () => {
      values[field.id] = control.type === 'checkbox' ? control.checked : control.value;
      applyVisibility();
      schedulePreview();
    });
    control.addEventListener('change', () => {
      if (control.type === 'checkbox') values[field.id] = control.checked;
      applyVisibility();
      schedulePreview();
    });
    form.appendChild(wrap);
  }
  applyVisibility();
}

function applyVisibility() {
  const type = currentType();
  const values = state.values[type.id] ?? {};
  for (const field of type.fields) {
    if (!field.showIf) continue;
    const wrap = $('content-form').querySelector(`[data-field="${field.id}"]`);
    if (wrap) wrap.hidden = !field.showIf(values);
  }
}

$('content-form').addEventListener('submit', (event) => event.preventDefault());

// ---------- Pestañas y controles de diseño ----------

const designTablist = document.querySelector('.design-tabs');
function selectDesignTab(tab) {
  for (const t of designTablist.querySelectorAll('.design-tab')) {
    const selected = t === tab;
    t.setAttribute('aria-selected', String(selected));
    t.tabIndex = selected ? 0 : -1;
    $(t.getAttribute('aria-controls')).hidden = !selected;
  }
}
designTablist.addEventListener('click', (event) => {
  const tab = event.target.closest('.design-tab');
  if (tab) selectDesignTab(tab);
});
enableArrowKeys(designTablist, '.design-tab');

function bindControl(id, key, parse = (v) => v, after) {
  const el = $(id);
  const handler = () => {
    state.design[key] = parse(el.value);
    after?.();
    schedulePreview();
  };
  el.addEventListener('input', handler);
  el.addEventListener('change', handler);
}

function bindRadios(name, key) {
  for (const radio of document.querySelectorAll(`input[name="${name}"]`)) {
    radio.addEventListener('change', () => {
      if (!radio.checked) return;
      state.design[key] = radio.value;
      if (name === 'frame') updateSvgNote();
      schedulePreview();
    });
  }
}

// Selector de marcos: «Sin marco» viene en el HTML; el resto se dibuja con la misma función que
// usa la descarga, así la miniatura es exactamente el marco que se obtiene (y toma el color elegido).
function buildFrameChoices() {
  const row = $('frame-choices');
  for (const f of FRAMES) {
    if (f.id === 'none') continue;
    const label = document.createElement('label');
    label.className = 'choice';
    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'frame';
    input.value = f.id;
    const box = document.createElement('span');
    box.className = 'choice-box';
    box.dataset.frame = f.id;
    const text = document.createElement('span');
    text.className = 'choice-label';
    text.textContent = f.label;
    label.append(input, box, text);
    row.append(label);
  }
  refreshFrameThumbs();
}

function refreshFrameThumbs() {
  for (const box of document.querySelectorAll('#frame-choices .choice-box[data-frame]')) {
    const thumb = frameThumbnail(box.dataset.frame, state.design.frameColor);
    thumb.setAttribute('aria-hidden', 'true');
    box.replaceChildren(thumb);
  }
}

buildFrameChoices();
bindRadios('frame', 'frame');
bindRadios('level', 'level');
bindControl('frame-text', 'frameText');
bindControl('frame-color', 'frameColor', (v) => v, refreshFrameThumbs);
bindControl('dots-type', 'dotsType');
bindControl('corners-type', 'cornersType');
bindControl('corners-dot-type', 'cornersDotType');
bindControl('fg-color', 'fg', (v) => v, updateContrastNote);
bindControl('bg-color', 'bg', (v) => v, updateContrastNote);

function updateContrastNote() {
  $('contrast-note').hidden = contrastRatio(state.design.fg, state.design.bg) >= 3;
}

function updateSvgNote() {
  $('svg-note').hidden = state.design.frame === 'none' || isBulk();
}

// Logo
const logoNote = $('logo-note');
function setLogoNote(message) {
  logoNote.textContent = message || '';
  logoNote.hidden = !message;
}

$('logo-file').addEventListener('change', (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  if (!/^image\/(png|jpeg|webp|svg\+xml)$/.test(file.type)) {
    setLogoNote('Formato no admitido. Usa PNG, JPG, WebP o SVG.');
    event.target.value = '';
    return;
  }
  if (file.size > MAX_LOGO_BYTES) {
    setLogoNote('La imagen pesa más de 1 MB.');
    event.target.value = '';
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    // Se comprueba que la imagen carga de verdad antes de aceptarla (un archivo dañado dejaría
    // el QR sin poder generarse).
    const probe = new Image();
    probe.onload = () => {
      state.design.logo = reader.result;
      state.design.level = 'H';
      document.querySelector('input[name="level"][value="H"]').checked = true;
      $('logo-remove').hidden = false;
      setLogoNote('Logo añadido. Subimos el nivel de corrección a H para que el QR siga siendo legible.');
      schedulePreview();
    };
    probe.onerror = () => {
      setLogoNote('No se pudo abrir la imagen: el archivo está dañado o no es una imagen válida.');
      event.target.value = '';
    };
    probe.src = reader.result;
  };
  reader.onerror = () => setLogoNote('No se pudo leer la imagen.');
  reader.readAsDataURL(file);
});

$('logo-size').addEventListener('input', (event) => {
  state.design.logoSize = Number(event.target.value) / 100;
  schedulePreview();
});

$('logo-remove').addEventListener('click', () => {
  state.design.logo = null;
  $('logo-file').value = '';
  $('logo-remove').hidden = true;
  setLogoNote('');
  schedulePreview();
});

// ---------- Generación del QR ----------

// La librería de QR guarda cada carácter como UN byte (Latin-1): las tildes salen mal en muchos
// teléfonos y emoji, «€», «ł»... se corrompen. Se le pasa el texto ya convertido a bytes UTF-8 (un
// carácter por byte), que es lo que esperan los lectores. Para texto ASCII no cambia nada.
function utf8Bytes(text) {
  let out = '';
  for (const byte of new TextEncoder().encode(text)) out += String.fromCharCode(byte);
  return out;
}

function qrOptions({ data, size, type, placeholder }) {
  const d = state.design;
  const gray = '#9a97a6';
  return {
    width: size,
    height: size,
    type,
    data: utf8Bytes(data),
    margin: Math.round(size * 0.04),
    qrOptions: { errorCorrectionLevel: placeholder ? 'M' : d.level },
    dotsOptions: { type: placeholder ? 'square' : d.dotsType, color: placeholder ? gray : d.fg },
    cornersSquareOptions: { type: placeholder ? 'square' : d.cornersType, color: placeholder ? gray : d.fg },
    cornersDotOptions: { type: placeholder ? 'square' : d.cornersDotType, color: placeholder ? gray : d.fg },
    backgroundOptions: { color: placeholder ? '#ffffff' : d.bg },
    image: !placeholder && d.logo ? d.logo : undefined,
    // saveAsBlob:false es imprescindible: con el valor por defecto la librería lee el logo con un
    // fetch() que la política de seguridad (connect-src 'self') bloquea, y el QR con logo nunca termina.
    imageOptions: { hideBackgroundDots: true, imageSize: d.logoSize, margin: 4, crossOrigin: 'anonymous', saveAsBlob: false },
  };
}

// Si la imagen del logo no se puede cargar, la librería no falla: se queda esperando. Con este límite
// el usuario ve un aviso en vez de una vista previa congelada.
function withTimeout(promise, ms, message) {
  let timer = 0;
  const limit = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(message)), ms);
  });
  return Promise.race([promise, limit]).finally(() => clearTimeout(timer));
}

async function renderCanvas({ data, size, placeholder }) {
  const qr = new window.QRCodeStyling(qrOptions({ data, size, type: 'canvas', placeholder }));
  const blob = await withTimeout(qr.getRawData('png'), 8000, 'Se agotó el tiempo al generar el QR (¿el logo es válido?).');
  const bitmap = await createImageBitmap(blob);
  const d = state.design;
  return composeFrame(bitmap, {
    frame: placeholder ? 'none' : d.frame,
    text: d.frameText,
    color: d.frameColor,
  });
}

let previewTimer = 0;
let previewToken = 0;
let ready = false;

function schedulePreview() {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(updatePreview, 120);
}

async function updatePreview() {
  const token = ++previewToken;
  // En «Masivo» la vista previa muestra el primer QR de la lista; cada QR se guarda desde ese panel.
  let result;
  if (isBulk()) result = { data: bulk.previewData(), error: null };
  else if (dynamicOn()) result = { data: dynamic.previewData(), error: null }; // el QR lleva el enlace corto
  else result = buildContent(currentType(), state.values[state.typeId] ?? {});
  const error = $('content-error');
  error.textContent = result.error || '';
  error.hidden = !result.error;

  ready = Boolean(result.data);
  $('download-btn').disabled = !ready || isBulk();
  if (!ready || isBulk()) closeMenu();

  try {
    const canvas = await renderCanvas({
      data: result.data ?? PLACEHOLDER_DATA,
      size: PREVIEW_SIZE,
      placeholder: !ready,
    });
    if (token !== previewToken) return; // llegó una petición más reciente
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', ready ? 'Vista previa de tu código QR' : 'Código QR de ejemplo');
    $('preview').replaceChildren(canvas);
  } catch (err) {
    console.error(err);
    if (token === previewToken) {
      const p = document.createElement('p');
      p.className = 'field-error';
      p.textContent = 'No se pudo generar el QR.';
      $('preview').replaceChildren(p);
    }
  }
}

// ---------- Descarga ----------

const menu = $('download-menu');
const downloadBtn = $('download-btn');

function closeMenu() {
  menu.hidden = true;
  downloadBtn.setAttribute('aria-expanded', 'false');
}

downloadBtn.addEventListener('click', () => {
  const open = menu.hidden;
  menu.hidden = !open;
  downloadBtn.setAttribute('aria-expanded', String(open));
  if (open) menu.querySelector('button').focus();
});
document.addEventListener('click', (event) => {
  if (!menu.hidden && !event.target.closest('.download')) closeMenu();
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !menu.hidden) {
    closeMenu();
    downloadBtn.focus();
  }
});

function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function currentData() {
  const type = currentType();
  if (dynamicOn()) return { type, data: dynamic.previewData(), error: null };
  return { type, ...buildContent(type, state.values[type.id] ?? {}) };
}

$('dl-png').addEventListener('click', async () => {
  closeMenu();
  const { type, data } = currentData();
  if (!data) return;
  try {
    const canvas = await renderCanvas({ data, size: EXPORT_SIZE, placeholder: false });
    canvas.toBlob((blob) => blob && saveBlob(blob, `qr-${type.id}.png`), 'image/png');
  } catch (err) {
    console.error(err);
  }
});

$('dl-svg').addEventListener('click', async () => {
  closeMenu();
  const { type, data } = currentData();
  if (!data) return;
  try {
    const qr = new window.QRCodeStyling(qrOptions({ data, size: EXPORT_SIZE, type: 'svg', placeholder: false }));
    const blob = await qr.getRawData('svg');
    saveBlob(blob, `qr-${type.id}.svg`);
  } catch (err) {
    console.error(err);
  }
});

// ---------- Arranque ----------

$('year').textContent = new Date().getFullYear();
const bulk = createBulk({ renderCanvas, exportSize: EXPORT_SIZE, onPreview: schedulePreview });
const dynamic = createDynamic({ getTarget: () => (state.values.website?.url ?? '').trim(), onPreview: schedulePreview });
renderTypeTabs();
selectType(TYPES[0].id);
updateContrastNote();
updateSvgNote();
initAuth(async (user) => {
  bulk.setUser(user);
  await dynamic.setUser(user);
  syncDynamicPanel();
  schedulePreview();
});
