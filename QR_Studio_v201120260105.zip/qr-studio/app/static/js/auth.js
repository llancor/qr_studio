// Registro, inicio y cierre de sesión contra la API (/api/auth/*).

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) {
    throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  }
  return data;
}

// onUser(user | null) se llama cada vez que cambia la sesión (al cargar, al entrar y al salir).
export function initAuth(onUser) {
  const $ = (id) => document.getElementById(id);
  const dialog = $('auth-dialog');
  const form = $('auth-form');
  const guest = $('auth-guest');
  const userBox = $('auth-user');
  const errorEl = $('auth-error');
  const submit = $('auth-submit');
  let mode = 'login';
  let opener = null;

  function showUser(user) {
    guest.hidden = Boolean(user);
    userBox.hidden = !user;
    $('user-name').textContent = user ? user.name : '';
    onUser?.(user);
  }

  function setError(message) {
    errorEl.textContent = message || '';
    errorEl.hidden = !message;
  }

  function setMode(next) {
    mode = next;
    const register = next === 'register';
    $('auth-title').textContent = register ? 'Crear cuenta' : 'Iniciar sesión';
    $('auth-name-field').hidden = !register;
    $('auth-password-hint').hidden = !register;
    $('auth-password').autocomplete = register ? 'new-password' : 'current-password';
    submit.textContent = register ? 'Crear cuenta' : 'Entrar';
    $('auth-switch-text').textContent = register ? '¿Ya tienes cuenta?' : '¿No tienes cuenta?';
    $('auth-switch').textContent = register ? 'Inicia sesión' : 'Regístrate';
    setError('');
  }

  function open(nextMode, trigger) {
    opener = trigger || null;
    form.reset();
    setMode(nextMode);
    dialog.showModal();
    (nextMode === 'register' ? $('auth-name') : $('auth-email')).focus();
  }

  document.querySelectorAll('[data-auth-open]').forEach((btn) => {
    btn.addEventListener('click', () => open(btn.dataset.authOpen, btn));
  });
  $('auth-switch').addEventListener('click', () => setMode(mode === 'login' ? 'register' : 'login'));
  $('auth-close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('close', () => opener?.focus?.());
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close(); // clic en el fondo
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    setError('');
    const email = $('auth-email').value.trim();
    const password = $('auth-password').value;
    const name = $('auth-name').value.trim();

    if (!email || !password || (mode === 'register' && !name)) {
      setError('Completa todos los campos.');
      return;
    }

    submit.disabled = true;
    try {
      const payload = mode === 'register' ? { email, name, password } : { email, password };
      const data = await api(`/api/auth/${mode}`, { method: 'POST', body: payload });
      showUser(data.user);
      dialog.close();
    } catch (err) {
      setError(err.message);
    } finally {
      submit.disabled = false;
    }
  });

  $('logout-btn').addEventListener('click', async () => {
    try {
      await api('/api/auth/logout', { method: 'POST' });
    } finally {
      showUser(null);
      // Todo el sitio exige sesión: al salir se vuelve a la página de acceso.
      window.location.assign('/entrar/');
    }
  });

  // Restaura la sesión al cargar la página. Si ya no es válida (caducó), se vuelve a la página de acceso.
  api('/api/auth/me')
    .then((data) => {
      showUser(data.user);
      if (!data.user) window.location.replace(`/entrar/?next=${encodeURIComponent(window.location.pathname + window.location.search)}`);
    })
    .catch(() => showUser(null));
}
