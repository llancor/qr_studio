"""Aplicación FastAPI: API de cuentas (SQLite) y servidor del frontend estático.

Arranque:  uvicorn --factory app.main:create_app
"""

from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urlparse

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from html import escape

from . import auth, db, dynamic, files
from .config import Settings, load_settings

STATIC_DIR = Path(__file__).resolve().parent / "static"
COOKIE_NAME = "session"
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,63}$")

# Sin sesión solo se puede ver la página de acceso (y lo que ella necesita) y la comprobación de salud
# que usan el monitor, Docker y los instaladores. Todo lo demás exige iniciar sesión.
LOGIN_PATH = "/entrar/"
PUBLIC_PATHS = {
    "/healthz",
    "/entrar",
    LOGIN_PATH,
    "/entrar/index.html",
    "/css/styles.css",
    "/js/entrar.js",
}

CSP = (
    "default-src 'self'; "
    "script-src 'self'; "
    "style-src 'self'; "
    "img-src 'self' data: blob:; "
    "connect-src 'self'; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'"
)


class RegisterIn(BaseModel):
    email: str
    name: str
    password: str


class LoginIn(BaseModel):
    email: str
    password: str


class FolderIn(BaseModel):
    name: str


class DynamicIn(BaseModel):
    name: str = ""
    target: str


class DynamicPatch(BaseModel):
    name: str | None = None
    target: str | None = None
    active: bool | None = None


def _public_user(row: sqlite3.Row) -> dict:
    return {"id": row["id"], "email": row["email"], "name": row["name"]}


def _normalize_email(raw: str) -> str:
    email = raw.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(422, "Escribe un correo electrónico válido.")
    return email


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    db.init_db(settings.db_path)

    app = FastAPI(title="QR Studio", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.settings = settings
    login_limiter = auth.LoginLimiter(settings.login_max_attempts, settings.login_window_seconds)
    register_limiter = auth.LoginLimiter(10, settings.login_window_seconds)

    # ----- Middleware -------------------------------------------------------

    def access_gate(request: Request) -> Response | None:
        """Todo el contenido exige sesión. Devuelve la respuesta de rechazo, o None si puede pasar."""
        path = request.url.path
        # /q/<código> es público a propósito: quien escanea un QR dinámico no tiene sesión.
        if path in PUBLIC_PATHS or path.startswith(("/api/auth/", "/q/")):
            return None
        with db.connect(settings.db_path) as conn:
            if auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME)):
                return None
        if path.startswith("/api/"):
            return JSONResponse({"detail": "Inicia sesión para continuar."}, status_code=401)
        wants_page = "text/html" in request.headers.get("accept", "") or path.endswith(("/", ".html"))
        if wants_page and request.method in {"GET", "HEAD"}:
            target = path + (f"?{request.url.query}" if request.url.query else "")
            return RedirectResponse(f"{LOGIN_PATH}?next={quote(target, safe='')}", status_code=303)
        return Response(status_code=401)  # un archivo suelto (script, imagen...) pedido sin sesión

    @app.middleware("http")
    async def security(request: Request, call_next):
        # Defensa CSRF: una petición que cambia datos debe venir de este mismo origen.
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            origin = request.headers.get("origin")
            if origin and urlparse(origin).netloc != request.headers.get("host", ""):
                return JSONResponse({"detail": "Origen no permitido."}, status_code=403)
        response = access_gate(request) or await call_next(request)
        response.headers["Content-Security-Policy"] = CSP
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "same-origin"
        response.headers["X-Frame-Options"] = "DENY"
        # La API nunca se guarda en caché; páginas y archivos se revalidan siempre (así un cambio de
        # versión llega enseguida y, al salir, el botón «atrás» no muestra contenido privado).
        # (/q/ también: una redirección guardada en caché haría que el destino nuevo no se viera ni se contara).
        no_store = request.url.path.startswith(("/api/", "/q/"))
        response.headers["Cache-Control"] = "no-store" if no_store else "no-cache"
        return response

    @app.exception_handler(RequestValidationError)
    async def validation_error(_: Request, __: RequestValidationError):
        return JSONResponse({"detail": "Solicitud no válida."}, status_code=422)

    # ----- Utilidades -------------------------------------------------------

    def set_session_cookie(response: Response, token: str) -> None:
        response.set_cookie(
            COOKIE_NAME,
            token,
            max_age=settings.session_days * 86400,
            httponly=True,
            secure=settings.cookie_secure,
            samesite="lax",
            path="/",
        )

    def client_ip(request: Request) -> str:
        return request.client.host if request.client else "unknown"

    # ----- API --------------------------------------------------------------

    @app.get("/healthz")
    def healthz():
        return {"status": "ok", "time": datetime.now(timezone.utc).isoformat()}

    @app.post("/api/auth/register", status_code=201)
    def register(payload: RegisterIn, request: Request, response: Response):
        ip = client_ip(request)
        if register_limiter.blocked(ip):
            raise HTTPException(429, "Demasiados registros. Inténtalo más tarde.")
        register_limiter.record_failure(ip)  # cuenta cada intento de registro

        email = _normalize_email(payload.email)
        name = payload.name.strip()
        if not 1 <= len(name) <= 80:
            raise HTTPException(422, "Escribe tu nombre (máximo 80 caracteres).")
        if not settings.min_password_length <= len(payload.password) <= 128:
            raise HTTPException(
                422,
                f"La contraseña debe tener entre {settings.min_password_length} y 128 caracteres.",
            )

        password_hash = auth.hash_password(payload.password)
        now = datetime.now(timezone.utc).isoformat()
        with db.connect(settings.db_path) as conn:
            try:
                cur = conn.execute(
                    "INSERT INTO users (email, name, password_hash, created_at) VALUES (?, ?, ?, ?)",
                    (email, name, password_hash, now),
                )
            except sqlite3.IntegrityError:
                raise HTTPException(409, "Ya existe una cuenta con ese correo.") from None
            user_id = cur.lastrowid
            token = auth.create_session(conn, user_id, settings.session_days)
        set_session_cookie(response, token)
        return {"user": {"id": user_id, "email": email, "name": name}}

    @app.post("/api/auth/login")
    def login(payload: LoginIn, request: Request, response: Response):
        email = payload.email.strip().lower()
        key = f"{client_ip(request)}|{email}"
        if login_limiter.blocked(key):
            raise HTTPException(429, "Demasiados intentos. Espera unos minutos.")

        with db.connect(settings.db_path) as conn:
            row = conn.execute(
                "SELECT id, email, name, password_hash FROM users WHERE email = ?", (email,)
            ).fetchone()
            stored = row["password_hash"] if row else auth.DUMMY_HASH
            valid = auth.verify_password(payload.password, stored) and row is not None
            if not valid:
                login_limiter.record_failure(key)
                raise HTTPException(401, "Correo o contraseña incorrectos.")
            login_limiter.reset(key)
            token = auth.create_session(conn, row["id"], settings.session_days)
        set_session_cookie(response, token)
        return {"user": _public_user(row)}

    @app.post("/api/auth/logout")
    def logout(request: Request, response: Response):
        with db.connect(settings.db_path) as conn:
            auth.delete_session(conn, request.cookies.get(COOKIE_NAME))
        response.delete_cookie(COOKIE_NAME, path="/")
        return {"ok": True}

    @app.get("/api/auth/me")
    def me(request: Request):
        with db.connect(settings.db_path) as conn:
            row = auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME))
        return {"user": _public_user(row) if row else None}

    # ----- Carpetas de QR por usuario (requieren sesión) --------------------

    store = files.QrStore(
        settings.files_path or settings.db_path.parent / "qr",
        files.Limits(quota_bytes=settings.files_quota_mb * 1024 * 1024),
    )
    app.state.qr_store = store  # los tests ajustan los límites desde aquí

    def require_user(request: Request) -> int:
        with db.connect(settings.db_path) as conn:
            row = auth.get_user_by_token(conn, request.cookies.get(COOKIE_NAME))
        if not row:
            raise HTTPException(401, "Inicia sesión para usar esta función.")
        return int(row["id"])

    @app.exception_handler(files.StoreError)
    async def store_error(_: Request, exc: files.StoreError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    async def read_limited(request: Request, limit: int) -> bytes:
        declared = request.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > limit:
            raise files.StoreError(413, "La imagen es demasiado grande.")
        chunks, size = [], 0
        async for chunk in request.stream():
            size += len(chunk)
            if size > limit:
                raise files.StoreError(413, "La imagen es demasiado grande.")
            chunks.append(chunk)
        return b"".join(chunks)

    @app.get("/api/qr/folders")
    def list_folders(request: Request):
        return store.list_folders(require_user(request))

    @app.post("/api/qr/folders", status_code=201)
    def create_folder(payload: FolderIn, request: Request):
        name, created = store.create_folder(require_user(request), payload.name)
        return {"name": name, "created": created}

    @app.get("/api/qr/folders/{folder}")
    def list_files(folder: str, request: Request):
        return store.list_files(require_user(request), folder)

    @app.delete("/api/qr/folders/{folder}")
    def delete_folder(folder: str, request: Request):
        store.delete_folder(require_user(request), folder)
        return {"ok": True}

    @app.post("/api/qr/folders/{folder}/files", status_code=201)
    async def upload_file(folder: str, name: str, request: Request):
        user_id = require_user(request)
        data = await read_limited(request, store.limits.max_file_bytes)
        saved = store.save_file(user_id, folder, name, data)
        return {"name": saved, "bytes": len(data)}

    @app.get("/api/qr/folders/{folder}/files/{filename}")
    def get_file(folder: str, filename: str, request: Request, download: bool = False):
        path = store.file_path(require_user(request), folder, filename)
        return FileResponse(path, media_type="image/png", filename=path.name if download else None)

    @app.delete("/api/qr/folders/{folder}/files/{filename}")
    def delete_file(folder: str, filename: str, request: Request):
        store.delete_file(require_user(request), folder, filename)
        return {"ok": True}

    @app.get("/api/qr/folders/{folder}/zip")
    def download_zip(folder: str, request: Request):
        name, archive = store.zip_folder(require_user(request), folder)

        def chunks():
            try:
                while block := archive.read(1024 * 1024):
                    yield block
            finally:
                archive.close()

        disposition = f"attachment; filename=\"qr.zip\"; filename*=UTF-8''{quote(name)}.zip"
        return StreamingResponse(chunks(), media_type="application/zip", headers={"Content-Disposition": disposition})

    # ----- QR dinámicos (opcionales) ------------------------------------------

    @app.exception_handler(dynamic.DynamicError)
    async def dynamic_error(_: Request, exc: dynamic.DynamicError):
        return JSONResponse({"detail": exc.message}, status_code=exc.status)

    def require_dynamic(request: Request) -> int:
        user_id = require_user(request)
        if not settings.dynamic_qr:
            raise HTTPException(404, "Los QR dinámicos no están activados en este servidor.")
        return user_id

    @app.get("/api/features")
    def features(request: Request):
        require_user(request)
        return {"dynamicQr": settings.dynamic_qr, "publicUrl": settings.public_url}

    @app.get("/api/dynamic")
    def dynamic_list(request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.list_items(conn, user_id)

    @app.post("/api/dynamic", status_code=201)
    def dynamic_create(payload: DynamicIn, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.create(conn, user_id, payload.name, payload.target)

    @app.patch("/api/dynamic/{qr_id}")
    def dynamic_update(qr_id: int, payload: DynamicPatch, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.update(
                conn, user_id, qr_id, name=payload.name, target=payload.target, active=payload.active
            )

    @app.delete("/api/dynamic/{qr_id}")
    def dynamic_delete(qr_id: int, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            dynamic.delete(conn, user_id, qr_id)
        return {"ok": True}

    @app.get("/api/dynamic/{qr_id}/stats")
    def dynamic_stats(qr_id: int, request: Request):
        user_id = require_dynamic(request)
        with db.connect(settings.db_path) as conn:
            return dynamic.stats(conn, user_id, qr_id)

    def notice_page(status: int, title: str, text: str) -> HTMLResponse:
        body = (
            '<!doctype html><html lang="es"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f"<title>{escape(title)}</title>"
            '<meta name="robots" content="noindex"><link rel="stylesheet" href="/css/styles.css"></head>'
            '<body><main><section class="login container"><div class="login-card">'
            f"<h1>{escape(title)}</h1><p class=\"login-lead\">{escape(text)}</p>"
            "</div></section></main></body></html>"
        )
        return HTMLResponse(body, status_code=status, headers={"Cache-Control": "no-store"})

    @app.get("/q/{code}")
    def follow(code: str):
        """Destino de un QR dinámico (público). Cuenta la visita y redirige; nunca se guarda en caché."""
        if not settings.dynamic_qr:
            return notice_page(404, "No disponible", "Este servidor no tiene activados los QR dinámicos.")
        with db.connect(settings.db_path) as conn:
            result, target = dynamic.record_scan(conn, code)
        if result == "ok" and target:
            return RedirectResponse(target, status_code=302, headers={"Cache-Control": "no-store"})
        if result == "paused":
            return notice_page(410, "Código pausado", "Su dueño lo ha desactivado por ahora. Vuelve a intentarlo más tarde.")
        return notice_page(404, "Código no encontrado", "Este código QR no existe o fue eliminado.")

    # ----- Frontend ---------------------------------------------------------

    app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")
    return app
