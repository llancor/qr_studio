// Página de acceso: inicio de sesión y registro. Es lo único que se ve sin sesión.
// Al entrar, lleva a la página que se pidió (?next=) o a la principal.

const $ = (id) => document.getElementById(id);

/** Solo se admiten rutas de este mismo sitio (evita redirigir a otro dominio con ?next=). */
export function safeNext(raw) {
  if (typeof raw !== 'string' || !raw.startsWith('/') || raw.startsWith('//') || raw.startsWith('/\\')) return '/';
  if (raw === '/entrar' || raw.startsWith('/entrar/') || raw.startsWith('/entrar?')) return '/';
  try {
    const url = new URL(raw, window.location.origin);
    if (url.origin !== window.location.origin) return '/';
    return url.pathname + url.search + url.hash;
  } catch {
    return '/';
  }
}

const destination = () => safeNext(new URLSearchParams(window.location.search).get('next'));

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  return data;
}

const form = $('login-form');
const errorEl = $('login-error');
const submit = $('login-submit');
let mode = 'login';

function setError(message) {
  errorEl.textContent = message || '';
  errorEl.hidden = !message;
}

function setMode(next) {
  mode = next;
  const register = next === 'register';
  $('login-title').textContent = register ? 'Crear cuenta' : 'Iniciar sesión';
  document.title = `${register ? 'Crear cuenta' : 'Entrar'} – QR Studio`;
  $('login-name-field').hidden = !register;
  $('login-password-hint').hidden = !register;
  $('login-password').autocomplete = register ? 'new-password' : 'current-password';
  submit.textContent = register ? 'Crear cuenta' : 'Entrar';
  $('login-switch-text').textContent = register ? '¿Ya tienes cuenta?' : '¿No tienes cuenta?';
  $('login-switch').textContent = register ? 'Inicia sesión' : 'Regístrate';
  setError('');
  (register ? $('login-name') : $('login-email')).focus();
}

$('login-switch').addEventListener('click', () => setMode(mode === 'login' ? 'register' : 'login'));

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  setError('');
  const email = $('login-email').value.trim();
  const password = $('login-password').value;
  const name = $('login-name').value.trim();
  if (!email || !password || (mode === 'register' && !name)) {
    setError('Completa todos los campos.');
    return;
  }
  submit.disabled = true;
  try {
    const payload = mode === 'register' ? { email, name, password } : { email, password };
    await api(`/api/auth/${mode}`, { method: 'POST', body: payload });
    window.location.replace(destination());
  } catch (err) {
    setError(err.message);
    submit.disabled = false;
  }
});

$('year').textContent = new Date().getFullYear();
if (new URLSearchParams(window.location.search).get('modo') === 'registro') setMode('register');

// Si ya hay una sesión válida, no tiene sentido mostrar el formulario.
api('/api/auth/me')
  .then((data) => {
    if (data.user) window.location.replace(destination());
  })
  .catch(() => {
    /* sin conexión: se deja el formulario */
  });
