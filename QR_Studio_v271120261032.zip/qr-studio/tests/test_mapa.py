"""Mapa para elegir el punto del QR «Ubicación» (Leaflet + OpenStreetMap). Ejecutar desde web/:  python -m pytest"""

import re
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app

USER = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
STATIC = Path(__file__).resolve().parents[1] / "app" / "static"

MAP_FILES = [
    "/js/mapa.js",
    "/vendor/leaflet/leaflet.js",
    "/vendor/leaflet/leaflet.css",
    "/vendor/leaflet/images/marker-icon.png",
    "/vendor/leaflet/images/marker-icon-2x.png",
    "/vendor/leaflet/images/marker-shadow.png",
    "/vendor/leaflet.LICENSE",
]


@pytest.fixture()
def app(tmp_path):
    return create_app(
        Settings(
            db_path=tmp_path / "test.db",
            session_days=14,
            cookie_secure=False,
            min_password_length=8,
            login_max_attempts=5,
            login_window_seconds=300,
            files_path=tmp_path / "qr",
        )
    )


@pytest.fixture()
def member(app):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=USER).status_code == 201
    return client


@pytest.mark.parametrize("path", MAP_FILES)
def test_map_files_are_served_to_members_only(app, member, path):
    assert TestClient(app, follow_redirects=False).get(path).status_code == 401
    assert member.get(path).status_code == 200


def test_the_csp_allows_only_the_openstreetmap_tile_server_from_outside(member):
    csp = member.get("/").headers["Content-Security-Policy"]
    directives = dict(part.strip().split(" ", 1) for part in csp.split(";") if part.strip())
    assert "https://tile.openstreetmap.org" in directives["img-src"].split()
    # Nada más sale del sitio: todo lo externo de la política es ese único servidor de imágenes.
    assert set(re.findall(r"https?://[^\s;]+", csp)) == {"https://tile.openstreetmap.org"}
    assert directives["script-src"] == "'self'" and directives["connect-src"] == "'self'"


def test_the_site_keeps_a_strict_referrer_policy(member):
    # El mapa envía solo el dominio con `referrerPolicy: 'origin'` en su capa; la política global no se relaja.
    assert member.get("/").headers["Referrer-Policy"] == "same-origin"


def test_location_type_has_the_map_before_latitude_and_longitude():
    source = (STATIC / "js" / "qr.js").read_text(encoding="utf-8")
    block = source[source.index("id: 'location'"):source.index("id: 'whatsapp'")]
    assert block.index("id: 'map'") < block.index("id: 'lat'") < block.index("id: 'lng'")
    # El mapa no guarda valor propio: el QR sale solo de la latitud y la longitud.
    assert "geo:${lat},${lng}" in block


def test_map_asks_for_the_device_location_only_when_the_button_is_pressed():
    source = (STATIC / "js" / "mapa.js").read_text(encoding="utf-8")
    assert source.count("getCurrentPosition") == 1
    assert source.index("locateBtn.addEventListener('click'") < source.index("getCurrentPosition")
    for other in ("app.js", "qr.js"):
        assert "geolocation" not in (STATIC / "js" / other).read_text(encoding="utf-8")


def test_map_loads_tiles_with_origin_referrer_and_attribution():
    source = (STATIC / "js" / "mapa.js").read_text(encoding="utf-8")
    assert "https://tile.openstreetmap.org/{z}/{x}/{y}.png" in source
    assert "referrerPolicy: 'origin'" in source
    assert "OpenStreetMap" in source and "openstreetmap.org/copyright" in source


def test_map_opens_on_chile():
    source = (STATIC / "js" / "mapa.js").read_text(encoding="utf-8")
    lat, lng = map(float, re.search(r"CHILE_START = \{ center: \[(-?[\d.]+), (-?[\d.]+)\]", source).groups())
    assert -56 < lat < -17 and -76 < lng < -66  # Santiago, dentro de Chile continental
    assert "Ver todo Chile" in source


def test_leaflet_is_vendored_with_its_license():
    assert "Leaflet 1.9.4" in (STATIC / "vendor" / "leaflet" / "leaflet.js").read_text(encoding="utf-8")[:200]
    assert "BSD 2-Clause" in (STATIC / "vendor" / "leaflet.LICENSE").read_text(encoding="utf-8")
