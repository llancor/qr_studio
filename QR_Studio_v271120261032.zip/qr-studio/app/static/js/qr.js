// Tipos de contenido, validación y marcos del código QR. Sin dependencias del DOM
// salvo `composeFrame`, que dibuja en un <canvas>.

const WEB_PROTOCOLS = new Set(['http:', 'https:']);

const trim = (v) => (v ?? '').toString().trim();

// Escapa caracteres especiales del formato WIFI:...
const escapeWifi = (s) => s.replace(/([\\;,:"])/g, '\\$1');
// Escapa valores dentro de una vCard.
const escapeVcard = (s) => s.replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/([,;])/g, '\\$1');

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]{2,}$/;

export const TYPES = [
  {
    id: 'website',
    label: 'Sitio web',
    icon: ['<circle cx="12" cy="12" r="9"/>', '<path d="M3 12h18"/>', '<path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18"/>'],
    fields: [{ id: 'url', label: 'Escribe tu sitio web', type: 'text', inputmode: 'url', placeholder: 'Ej.: https://www.misitio.com/', required: true }],
    build(v) {
      let raw = trim(v.url);
      if (!/^[a-z][a-z0-9+.-]*:/i.test(raw)) raw = `https://${raw}`;
      let url;
      try {
        url = new URL(raw);
      } catch {
        return { error: 'Escribe una dirección web válida.' };
      }
      if (!WEB_PROTOCOLS.has(url.protocol)) return { error: 'Solo se permiten enlaces http o https.' };
      if (!url.hostname.includes('.') && url.hostname !== 'localhost') return { error: 'Escribe una dirección web válida.' };
      return { data: url.href };
    },
  },
  {
    id: 'text',
    label: 'Texto',
    icon: ['<path d="M4 6h16"/>', '<path d="M4 12h16"/>', '<path d="M4 18h10"/>'],
    fields: [{ id: 'text', label: 'Escribe tu texto', type: 'textarea', maxlength: 1000, placeholder: 'Cualquier texto…', required: true }],
    build: (v) => ({ data: trim(v.text) }),
  },
  {
    id: 'email',
    label: 'Correo',
    icon: ['<rect x="3" y="5" width="18" height="14" rx="2"/>', '<path d="M3 7l9 6 9-6"/>'],
    fields: [
      { id: 'to', label: 'Correo del destinatario', type: 'text', inputmode: 'email', placeholder: 'nombre@dominio.com', required: true },
      { id: 'subject', label: 'Asunto (opcional)', type: 'text', maxlength: 150 },
      { id: 'body', label: 'Mensaje (opcional)', type: 'textarea', maxlength: 500 },
    ],
    build(v) {
      const to = trim(v.to);
      if (!EMAIL_RE.test(to)) return { error: 'Escribe un correo válido.' };
      const params = [];
      if (trim(v.subject)) params.push(`subject=${encodeURIComponent(trim(v.subject))}`);
      if (trim(v.body)) params.push(`body=${encodeURIComponent(trim(v.body))}`);
      return { data: `mailto:${to}${params.length ? `?${params.join('&')}` : ''}` };
    },
  },
  {
    id: 'phone',
    label: 'Teléfono',
    icon: ['<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>'],
    fields: [{ id: 'phone', label: 'Número de teléfono', type: 'text', inputmode: 'tel', placeholder: '+34 600 000 000', required: true }],
    build(v) {
      const num = trim(v.phone).replace(/[^\d+]/g, '');
      if (num.replace(/\D/g, '').length < 5) return { error: 'Escribe un número de teléfono válido.' };
      return { data: `tel:${num}` };
    },
  },
  {
    id: 'sms',
    label: 'SMS',
    icon: ['<path d="M4 5h16v11H9l-5 4z"/>'],
    fields: [
      { id: 'phone', label: 'Número de teléfono', type: 'text', inputmode: 'tel', placeholder: '+34 600 000 000', required: true },
      { id: 'message', label: 'Mensaje (opcional)', type: 'textarea', maxlength: 160 },
    ],
    build(v) {
      const num = trim(v.phone).replace(/[^\d+]/g, '');
      if (num.replace(/\D/g, '').length < 5) return { error: 'Escribe un número de teléfono válido.' };
      return { data: `SMSTO:${num}:${trim(v.message)}` };
    },
  },
  {
    id: 'wifi',
    label: 'WiFi',
    icon: ['<path d="M2 9a15 15 0 0 1 20 0"/>', '<path d="M5 12.5a10 10 0 0 1 14 0"/>', '<path d="M8.5 16a5 5 0 0 1 7 0"/>', '<circle cx="12" cy="19.2" r="1"/>'],
    fields: [
      { id: 'ssid', label: 'Nombre de la red (SSID)', type: 'text', maxlength: 32, required: true },
      {
        id: 'security', label: 'Seguridad', type: 'select', default: 'WPA',
        options: [['WPA', 'WPA / WPA2 / WPA3'], ['WEP', 'WEP'], ['nopass', 'Sin contraseña']],
      },
      { id: 'password', label: 'Contraseña', type: 'text', maxlength: 63, autocomplete: 'off', showIf: (v) => (v.security ?? 'WPA') !== 'nopass' },
      { id: 'hidden', label: 'Red oculta', type: 'checkbox' },
    ],
    build(v) {
      const ssid = trim(v.ssid);
      if (!ssid) return { data: null };
      const security = v.security ?? 'WPA';
      if (security === 'nopass') return { data: `WIFI:T:nopass;S:${escapeWifi(ssid)};${v.hidden ? 'H:true;' : ''};` };
      const password = v.password ?? '';
      if (!password) return { data: null };
      return { data: `WIFI:T:${security};S:${escapeWifi(ssid)};P:${escapeWifi(password)};${v.hidden ? 'H:true;' : ''};` };
    },
  },
  {
    id: 'vcard',
    label: 'Contacto',
    icon: ['<rect x="4" y="3" width="16" height="18" rx="2"/>', '<circle cx="12" cy="10" r="3"/>', '<path d="M7 18a5 5 0 0 1 10 0"/>'],
    fields: [
      { id: 'first', label: 'Nombre', type: 'text', maxlength: 60, autocomplete: 'off' },
      { id: 'last', label: 'Apellidos', type: 'text', maxlength: 60, autocomplete: 'off' },
      { id: 'phone', label: 'Teléfono', type: 'text', inputmode: 'tel', maxlength: 30, autocomplete: 'off' },
      { id: 'email', label: 'Correo', type: 'text', inputmode: 'email', maxlength: 100, autocomplete: 'off' },
      { id: 'company', label: 'Empresa', type: 'text', maxlength: 80, autocomplete: 'off' },
      { id: 'website', label: 'Sitio web', type: 'text', inputmode: 'url', maxlength: 200, autocomplete: 'off' },
    ],
    build(v) {
      const first = trim(v.first);
      const last = trim(v.last);
      if (!first && !last) return { data: null };
      const email = trim(v.email);
      if (email && !EMAIL_RE.test(email)) return { error: 'El correo del contacto no es válido.' };
      const lines = ['BEGIN:VCARD', 'VERSION:3.0', `N:${escapeVcard(last)};${escapeVcard(first)};;;`, `FN:${escapeVcard(`${first} ${last}`.trim())}`];
      if (trim(v.company)) lines.push(`ORG:${escapeVcard(trim(v.company))}`);
      if (trim(v.phone)) lines.push(`TEL:${escapeVcard(trim(v.phone))}`);
      if (email) lines.push(`EMAIL:${escapeVcard(email)}`);
      if (trim(v.website)) lines.push(`URL:${escapeVcard(trim(v.website))}`);
      lines.push('END:VCARD');
      return { data: lines.join('\r\n') };
    },
  },
  {
    id: 'location',
    label: 'Ubicación',
    icon: ['<path d="M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z"/>', '<circle cx="12" cy="10" r="2.5"/>'],
    fields: [
      // El mapa (js/mapa.js) rellena la latitud y la longitud al tocar un punto; los campos siguen siendo editables.
      { id: 'map', type: 'map' },
      { id: 'lat', label: 'Latitud', type: 'text', inputmode: 'decimal', placeholder: 'Ej.: -33.4489', required: true },
      { id: 'lng', label: 'Longitud', type: 'text', inputmode: 'decimal', placeholder: 'Ej.: -70.6693', required: true },
    ],
    build(v) {
      const lat = Number(trim(v.lat).replace(',', '.'));
      const lng = Number(trim(v.lng).replace(',', '.'));
      if (!Number.isFinite(lat) || lat < -90 || lat > 90) return { error: 'La latitud debe estar entre -90 y 90.' };
      if (!Number.isFinite(lng) || lng < -180 || lng > 180) return { error: 'La longitud debe estar entre -180 y 180.' };
      return { data: `geo:${lat},${lng}` };
    },
  },
  {
    id: 'whatsapp',
    label: 'WhatsApp',
    icon: ['<path d="M4 20l1.3-4.2A8 8 0 1 1 8.4 19z"/>', '<path d="M9 9.5c.4 2.2 2.3 4.1 4.5 4.5l1.1-1.1-1.7-.9-.7.5c-.7-.3-1.5-1.1-1.8-1.8l.5-.7-.9-1.7z"/>'],
    fields: [
      { id: 'phone', label: 'Número con prefijo del país', type: 'text', inputmode: 'tel', placeholder: 'Ej.: 34600000000', required: true },
      { id: 'message', label: 'Mensaje inicial (opcional)', type: 'textarea', maxlength: 500, placeholder: 'Hola, quiero más información…' },
    ],
    build(v) {
      const digits = trim(v.phone).replace(/\D/g, '');
      if (digits.length < 7 || digits.length > 15) return { error: 'Escribe el número completo con el prefijo del país (de 7 a 15 dígitos).' };
      const message = trim(v.message);
      return { data: `https://wa.me/${digits}${message ? `?text=${encodeURIComponent(message)}` : ''}` };
    },
  },
  {
    id: 'event',
    label: 'Evento',
    icon: ['<rect x="3" y="5" width="18" height="16" rx="2"/>', '<path d="M3 10h18"/>', '<path d="M8 3v4"/>', '<path d="M16 3v4"/>'],
    fields: [
      { id: 'title', label: 'Título del evento', type: 'text', maxlength: 100, required: true },
      { id: 'start', label: 'Comienza', type: 'datetime-local', required: true },
      { id: 'end', label: 'Termina (opcional)', type: 'datetime-local' },
      { id: 'where', label: 'Lugar (opcional)', type: 'text', maxlength: 150 },
      { id: 'notes', label: 'Descripción (opcional)', type: 'textarea', maxlength: 500 },
    ],
    build(v) {
      // «2026-11-19T18:30» -> «20261119T183000» (hora local, sin zona, como la agenda del que escanea).
      const stamp = (value) => {
        const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(trim(value));
        return m ? `${m[1]}${m[2]}${m[3]}T${m[4]}${m[5]}00` : null;
      };
      const start = stamp(v.start);
      if (!start) return { error: 'Elige cuándo comienza el evento.' };
      const end = trim(v.end) ? stamp(v.end) : null;
      if (trim(v.end) && !end) return { error: 'La fecha de fin no es válida.' };
      if (end && end < start) return { error: 'El evento no puede terminar antes de empezar.' };
      const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'BEGIN:VEVENT', `SUMMARY:${escapeVcard(trim(v.title))}`, `DTSTART:${start}`];
      if (end) lines.push(`DTEND:${end}`);
      if (trim(v.where)) lines.push(`LOCATION:${escapeVcard(trim(v.where))}`);
      if (trim(v.notes)) lines.push(`DESCRIPTION:${escapeVcard(trim(v.notes))}`);
      lines.push('END:VEVENT', 'END:VCALENDAR');
      return { data: lines.join('\r\n') };
    },
  },
];

/**
 * Devuelve {data, error}. `data` es null si faltan campos obligatorios (sin error);
 * `error` solo aparece cuando hay algo escrito pero no es válido.
 */
export function buildContent(type, values) {
  const missing = type.fields.some((f) => {
    if (!f.required) return false;
    return !trim(values[f.id]);
  });
  if (missing) return { data: null, error: null };
  const result = type.build(values);
  if (result.error) return { data: null, error: result.error };
  if (!result.data) return { data: null, error: null };
  if (new TextEncoder().encode(result.data).length > 2000) {
    return { data: null, error: 'El contenido es demasiado largo para un código QR.' };
  }
  return { data: result.data, error: null };
}

// ---------- Color ----------

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex);
  if (!m) return [0, 0, 0];
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function luminance(hex) {
  const [r, g, b] = hexToRgb(hex).map((c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrastRatio(a, b) {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}

const readableOn = (hex) => (luminance(hex) > 0.45 ? '#1a1630' : '#ffffff');

// ---------- Marco ----------

/**
 * Dibuja el QR (ImageBitmap/Canvas cuadrado) dentro del marco elegido y devuelve un canvas.
 * frame: 'none' | 'outline' | 'solid' | un marco con forma de FRAMES (envelope, bag, cup...)
 */
export function composeFrame(qrImage, { frame, text, color }) {
  const S = qrImage.width;
  const canvas = document.createElement('canvas');

  const preset = PRESETS[frame];
  if (preset) {
    const label = text.trim();
    const g = preset.layout(S, Boolean(label));
    canvas.width = Math.ceil(g.w);
    canvas.height = Math.ceil(g.h);
    preset.paint(canvas.getContext('2d'), g, { S, color, label, qrImage });
    return canvas;
  }

  if (frame === 'none') {
    canvas.width = S;
    canvas.height = S;
    canvas.getContext('2d').drawImage(qrImage, 0, 0);
    return canvas;
  }

  const pad = Math.round(S * 0.07);
  const barH = Math.round(S * 0.17);
  const radius = Math.round(S * 0.07);
  const label = text.trim();

  if (frame === 'outline') {
    const border = Math.max(2, Math.round(S * 0.03));
    const W = S + 2 * (pad + border);
    const cardH = W;
    canvas.width = W;
    canvas.height = cardH + (label ? barH : 0);
    const ctx = canvas.getContext('2d');
    if (label) {
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.roundRect(0, cardH - radius, W, barH + radius, [0, 0, radius, radius]);
      ctx.fill();
    }
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = color;
    ctx.lineWidth = border;
    ctx.beginPath();
    ctx.roundRect(border / 2, border / 2, W - border, cardH - border, radius);
    ctx.fill();
    ctx.stroke();
    ctx.drawImage(qrImage, pad + border, pad + border);
    if (label) drawLabel(ctx, label, W / 2, cardH + barH / 2 - radius / 4, W - 2 * pad, barH * 0.5, readableOn(color));
    return canvas;
  }

  // solid
  const inner = Math.round(S * 0.04);
  const W = S + 2 * (pad + inner);
  const cardH = W;
  canvas.width = W;
  canvas.height = cardH + (label ? barH : pad);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.roundRect(0, 0, canvas.width, canvas.height, radius * 1.4);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.roundRect(pad, pad, S + 2 * inner, S + 2 * inner, radius);
  ctx.fill();
  ctx.drawImage(qrImage, pad + inner, pad + inner);
  if (label) drawLabel(ctx, label, W / 2, cardH + barH / 2, W - 2 * pad, barH * 0.5, readableOn(color));
  return canvas;
}

function drawLabel(ctx, text, cx, cy, maxWidth, fontSize, color) {
  let size = fontSize;
  ctx.font = `700 ${size}px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`;
  while (ctx.measureText(text).width > maxWidth && size > 8) {
    size -= 1;
    ctx.font = `700 ${size}px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`;
  }
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, cx, cy);
}

// ---------- Marcos con forma (sobre, bolsa, taza...) ----------
// Cada marco define layout(S, hayTexto) -> medidas del lienzo y de la tarjeta blanca donde va el
// QR, y paint(ctx, g, {S, color, label, qrImage}). El QR siempre queda entero y sobre una tarjeta
// blanca: ningún adorno lo tapa, así sigue siendo legible.

export const FRAMES = [
  { id: 'none', label: 'Sin marco' },
  { id: 'outline', label: 'Contorno' },
  { id: 'solid', label: 'Sólido' },
  { id: 'envelope', label: 'Sobre' },
  { id: 'bag', label: 'Bolsa' },
  { id: 'cup', label: 'Taza' },
  { id: 'gift', label: 'Regalo' },
  { id: 'bubble', label: 'Globo' },
  { id: 'tag', label: 'Etiqueta' },
  { id: 'ribbon', label: 'Cinta' },
  { id: 'scanner', label: 'Visor' },
  { id: 'phone', label: 'Móvil' },
  { id: 'polaroid', label: 'Foto' },
  { id: 'banner', label: 'Cartel' },
  { id: 'ticket', label: 'Boleto' },
  { id: 'screen', label: 'Pantalla' },
];

// Mezcla un color con blanco (cantidad > 0) o con negro (cantidad < 0).
function shade(hex, amount) {
  const [r, g, b] = hexToRgb(hex);
  const target = amount < 0 ? 0 : 255;
  const k = Math.abs(amount);
  const mix = (c) => Math.round(c + (target - c) * k);
  return `rgb(${mix(r)}, ${mix(g)}, ${mix(b)})`;
}

function polygon(ctx, points, fill) {
  ctx.beginPath();
  points.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
}

function line(ctx, points) {
  ctx.beginPath();
  points.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.stroke();
}

// Tarjeta blanca con el QR encima (el QR se dibuja en píxeles enteros para que no se difumine).
function drawQrCard(ctx, g, o, stroke) {
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.roundRect(g.cardX, g.cardY, g.cardW, g.cardW, g.pad * 1.1);
  ctx.fill();
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = Math.max(1, o.S * 0.01);
    ctx.stroke();
  }
  ctx.drawImage(o.qrImage, Math.round(g.cardX + g.pad), Math.round(g.cardY + g.pad));
}

const base = (S) => ({ pad: S * 0.05, cardW: S + 2 * S * 0.05 });

const PRESETS = {
  // Sobre abierto: la carta con el QR asoma y el frente del sobre queda debajo, con el texto.
  envelope: {
    layout(S) {
      const { pad, cardW } = base(S);
      const m = S * 0.12;
      const w = cardW + 2 * m;
      const bt = w * 0.3; // arriba del cuerpo del sobre (base de la solapa)
      const cardY = bt - S * 0.14;
      const cb = cardY + cardW;
      const apex = cb + w * 0.17;
      const by1 = apex + w * 0.21;
      return { w, h: by1, pad, cardW, cardX: m, cardY, bt, cb, apex, by1 };
    },
    paint(ctx, g, o) {
      const { w, bt, cb, apex, by1 } = g;
      const c = o.color;
      ctx.lineJoin = 'round';
      polygon(ctx, [[0, bt], [w / 2, 0], [w, bt]], shade(c, -0.18)); // solapa abierta
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(0, bt, w, by1 - bt, o.S * 0.05);
      ctx.clip();
      ctx.fillStyle = shade(c, 0.6); // interior del sobre
      ctx.fillRect(0, bt, w, by1 - bt);
      ctx.restore();
      drawQrCard(ctx, g, o, shade(c, 0.5));
      ctx.save();
      ctx.beginPath();
      ctx.roundRect(0, bt, w, by1 - bt, o.S * 0.05);
      ctx.clip();
      // Frente del sobre: una sola pieza con el borde en «V» (sin líneas que crucen el texto).
      polygon(ctx, [[0, cb], [w / 2, apex], [w, cb], [w, by1], [0, by1]], c);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.lineWidth = Math.max(1, o.S * 0.009);
      line(ctx, [[0, cb], [w / 2, apex], [w, cb]]);
      ctx.restore();
      if (o.label) drawLabel(ctx, o.label, w / 2, apex + (by1 - apex) * 0.55, w * 0.7, w * 0.085, readableOn(c));
    },
  },

  // Bolsa de compras con asa.
  bag: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.08;
      const hh = S * 0.3;
      const cb = hh + m + cardW;
      return { w: cardW + 2 * m, h: cb + (hasLabel ? S * 0.19 : m), pad, cardW, cardX: m, cardY: hh + m, hh, cb };
    },
    paint(ctx, g, o) {
      const { w, h, hh, cb } = g;
      const S = o.S;
      ctx.lineCap = 'round';
      ctx.strokeStyle = shade(o.color, -0.2);
      ctx.lineWidth = S * 0.04;
      ctx.beginPath();
      ctx.moveTo(w * 0.3, hh + S * 0.03);
      ctx.bezierCurveTo(w * 0.3, -S * 0.02, w * 0.7, -S * 0.02, w * 0.7, hh + S * 0.03);
      ctx.stroke();
      ctx.fillStyle = o.color;
      ctx.beginPath();
      ctx.roundRect(0, hh, w, h - hh, S * 0.06);
      ctx.fill();
      drawQrCard(ctx, g, o);
      if (o.label) drawLabel(ctx, o.label, w / 2, cb + (h - cb) / 2, g.cardW, S * 0.085, readableOn(o.color));
    },
  },

  // Taza de café con vapor, asa y plato.
  cup: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.07;
      const bodyW = cardW + 2 * m;
      const hw = S * 0.22;
      const steam = S * 0.2;
      const bodyH = cardW + 2 * m;
      const saucer = S * 0.06;
      const labelH = hasLabel ? S * 0.16 : S * 0.02;
      return { w: bodyW + 2 * hw, h: steam + bodyH + saucer + labelH, pad, cardW, cardX: hw + m, cardY: steam + m, bodyW, hw, steam, bodyH, saucer, labelH };
    },
    paint(ctx, g, o) {
      const { hw, steam, bodyW, bodyH, saucer } = g;
      const S = o.S;
      const c = o.color;
      ctx.lineCap = 'round';
      ctx.lineWidth = S * 0.022;
      ctx.strokeStyle = shade(c, 0.35);
      for (const f of [0.3, 0.5, 0.7]) {
        const x = hw + bodyW * f;
        ctx.beginPath();
        ctx.moveTo(x, steam - S * 0.02);
        ctx.bezierCurveTo(x - S * 0.045, steam * 0.72, x + S * 0.045, steam * 0.45, x, steam * 0.12);
        ctx.stroke();
      }
      ctx.strokeStyle = c;
      ctx.lineWidth = S * 0.05;
      ctx.beginPath();
      ctx.arc(hw + bodyW, steam + bodyH * 0.42, S * 0.13, -Math.PI / 2, Math.PI / 2);
      ctx.stroke();
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.roundRect(hw, steam, bodyW, bodyH, [S * 0.03, S * 0.03, S * 0.12, S * 0.12]);
      ctx.fill();
      drawQrCard(ctx, g, o);
      const sw = bodyW * 1.22;
      ctx.fillStyle = shade(c, -0.2);
      ctx.beginPath();
      ctx.roundRect((g.w - sw) / 2, steam + bodyH - S * 0.01, sw, saucer + S * 0.01, saucer / 2);
      ctx.fill();
      if (o.label) drawLabel(ctx, o.label, g.w / 2, steam + bodyH + saucer + g.labelH / 2, g.w - S * 0.1, S * 0.09, shade(c, -0.25));
    },
  },

  // Caja de regalo con lazo.
  gift: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.08;
      const bowH = S * 0.24;
      const lidH = S * 0.1;
      const cardY = bowH + lidH + S * 0.04;
      const cb = cardY + cardW;
      return { w: cardW + 2 * m, h: cb + (hasLabel ? S * 0.19 : m), pad, cardW, cardX: m, cardY, bowH, lidH, cb };
    },
    paint(ctx, g, o) {
      const { w, h, bowH, lidH, cb } = g;
      const S = o.S;
      const c = o.color;
      const band = shade(c, -0.2);
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.roundRect(0, bowH, w, h - bowH, S * 0.05);
      ctx.fill();
      ctx.fillStyle = band;
      ctx.beginPath();
      ctx.roundRect(0, bowH, w, lidH, S * 0.03);
      ctx.fill();
      const cx = w / 2;
      const cy = bowH - S * 0.02;
      ctx.fillStyle = band;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.lineWidth = Math.max(1, S * 0.008);
      for (const dir of [-1, 1]) {
        ctx.beginPath();
        ctx.ellipse(cx + dir * S * 0.14, cy - S * 0.075, S * 0.13, S * 0.07, dir * -0.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
      ctx.fillStyle = shade(c, -0.35);
      ctx.beginPath();
      ctx.arc(cx, cy - S * 0.01, S * 0.045, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      drawQrCard(ctx, g, o);
      if (o.label) drawLabel(ctx, o.label, w / 2, cb + (h - cb) / 2, g.cardW, S * 0.085, readableOn(c));
    },
  },

  // Globo de diálogo.
  bubble: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.08;
      const bodyH = m + cardW + (hasLabel ? S * 0.17 : m);
      const tail = S * 0.13;
      return { w: cardW + 2 * m, h: bodyH + tail, pad, cardW, cardX: m, cardY: m, bodyH, tail, cb: m + cardW };
    },
    paint(ctx, g, o) {
      const { w, bodyH, tail, cb } = g;
      const S = o.S;
      ctx.fillStyle = o.color;
      ctx.beginPath();
      ctx.roundRect(0, 0, w, bodyH, S * 0.08);
      ctx.fill();
      polygon(ctx, [[w * 0.16, bodyH - 1], [w * 0.16, bodyH + tail], [w * 0.38, bodyH - 1]], o.color);
      drawQrCard(ctx, g, o);
      if (o.label) drawLabel(ctx, o.label, w / 2, cb + (bodyH - cb) / 2, g.cardW, S * 0.085, readableOn(o.color));
    },
  },

  // Etiqueta colgante con cordón.
  tag: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.08;
      const top = S * 0.2;
      const hole = S * 0.15;
      const cardY = top + hole;
      const cb = cardY + cardW;
      return { w: cardW + 2 * m, h: cb + (hasLabel ? S * 0.19 : m), pad, cardW, cardX: m, cardY, top, cb };
    },
    paint(ctx, g, o) {
      const { w, h, top, cb } = g;
      const S = o.S;
      const c = o.color;
      const dark = shade(c, -0.3);
      ctx.strokeStyle = dark;
      ctx.lineWidth = Math.max(1, S * 0.016);
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.ellipse(w / 2, top * 0.5, S * 0.06, top * 0.46, 0, 0, Math.PI * 2);
      ctx.stroke();
      line(ctx, [[w / 2, top * 0.96], [w / 2, top + S * 0.07]]);
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.roundRect(0, top, w, h - top, [w * 0.12, w * 0.12, S * 0.05, S * 0.05]);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(w / 2, top + S * 0.07, S * 0.032, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      drawQrCard(ctx, g, o);
      if (o.label) drawLabel(ctx, o.label, w / 2, cb + (h - cb) / 2, g.cardW, S * 0.085, readableOn(c));
    },
  },

  // Tarjeta con una cinta doblada debajo.
  ribbon: {
    layout(S) {
      const { pad, cardW } = base(S);
      const b = S * 0.05;
      const over = S * 0.12;
      const band = S * 0.17;
      const boxW = cardW + 2 * b;
      const boxH = boxW + band * 0.45;
      return { w: boxW + 2 * over, h: boxH + band * 0.55 + S * 0.05, pad, cardW, cardX: over + b, cardY: b, b, over, band, boxW, boxH };
    },
    paint(ctx, g, o) {
      const { w, over, b, boxW, boxH, band } = g;
      const S = o.S;
      const c = o.color;
      ctx.fillStyle = '#ffffff';
      ctx.strokeStyle = c;
      ctx.lineWidth = b;
      ctx.beginPath();
      ctx.roundRect(over + b / 2, b / 2, boxW - b, boxH - b, S * 0.05);
      ctx.fill();
      ctx.stroke();
      drawQrCard(ctx, g, o);
      const y0 = boxH - band * 0.45;
      const dy = S * 0.05;
      const tail = shade(c, -0.25);
      const fold = shade(c, -0.45);
      const e = over + S * 0.06;
      polygon(ctx, [[0, y0 + dy], [e, y0 + dy], [e, y0 + band + dy], [0, y0 + band + dy], [S * 0.045, y0 + band / 2 + dy]], tail);
      polygon(ctx, [[w, y0 + dy], [w - e, y0 + dy], [w - e, y0 + band + dy], [w, y0 + band + dy], [w - S * 0.045, y0 + band / 2 + dy]], tail);
      polygon(ctx, [[over * 0.45, y0 + band], [over + S * 0.04, y0 + band], [over + S * 0.04, y0 + band + dy]], fold);
      polygon(ctx, [[w - over * 0.45, y0 + band], [w - over - S * 0.04, y0 + band], [w - over - S * 0.04, y0 + band + dy]], fold);
      ctx.fillStyle = c;
      ctx.fillRect(over * 0.45, y0, w - over * 0.9, band);
      if (o.label) drawLabel(ctx, o.label, w / 2, y0 + band / 2, w - over * 1.4, band * 0.5, readableOn(c));
    },
  },

  // Visor de escáner: cuatro esquinas alrededor del QR y una pastilla con el texto debajo.
  scanner: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.11;
      return { w: cardW + 2 * m, h: 2 * m + cardW + (hasLabel ? S * 0.19 : 0), pad, cardW, cardX: m, cardY: m, m };
    },
    paint(ctx, g, o) {
      const { w, h, m } = g;
      const S = o.S;
      const c = o.color;
      const x0 = S * 0.025;
      const y0 = S * 0.025;
      const x1 = w - S * 0.025;
      const y1 = 2 * m + g.cardW - S * 0.025;
      const len = S * 0.2;
      ctx.strokeStyle = c;
      ctx.lineWidth = S * 0.045;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      line(ctx, [[x0, y0 + len], [x0, y0], [x0 + len, y0]]);
      line(ctx, [[x1 - len, y0], [x1, y0], [x1, y0 + len]]);
      line(ctx, [[x0, y1 - len], [x0, y1], [x0 + len, y1]]);
      line(ctx, [[x1 - len, y1], [x1, y1], [x1, y1 - len]]);
      drawQrCard(ctx, g, o);
      if (o.label) {
        const top = 2 * m + g.cardW;
        const ph = S * 0.13;
        const pw = w * 0.78;
        const cy = top + (h - top) / 2;
        ctx.fillStyle = c;
        ctx.beginPath();
        ctx.roundRect((w - pw) / 2, cy - ph / 2, pw, ph, ph / 2);
        ctx.fill();
        drawLabel(ctx, o.label, w / 2, cy, pw - S * 0.07, ph * 0.5, readableOn(c));
      }
    },
  },

  // Móvil: cuerpo de teléfono con altavoz arriba; el texto va en el borde de abajo.
  phone: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.09;
      const top = S * 0.17;
      const bottom = hasLabel ? S * 0.2 : S * 0.1;
      return { w: cardW + 2 * m, h: top + cardW + bottom, pad, cardW, cardX: m, cardY: top, top, bottom };
    },
    paint(ctx, g, o) {
      const { w, h, top, bottom } = g;
      const S = o.S;
      const c = o.color;
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.roundRect(0, 0, w, h, S * 0.12);
      ctx.fill();
      ctx.fillStyle = shade(c, -0.4);
      ctx.beginPath();
      ctx.roundRect(w / 2 - S * 0.09, top / 2 - S * 0.018, S * 0.18, S * 0.036, S * 0.018);
      ctx.fill();
      drawQrCard(ctx, g, o);
      const cy = top + g.cardW + bottom / 2;
      if (o.label) {
        drawLabel(ctx, o.label, w / 2, cy, g.cardW, S * 0.085, readableOn(c));
      } else {
        ctx.fillStyle = shade(c, 0.45);
        ctx.beginPath();
        ctx.roundRect(w / 2 - S * 0.1, cy - S * 0.012, S * 0.2, S * 0.024, S * 0.012);
        ctx.fill();
      }
    },
  },

  // Foto instantánea: marco blanco con sombra, el QR sobre un paspartú de color y el texto en el borde ancho.
  polaroid: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const e = S * 0.05;
      const m = S * 0.07;
      const chin = hasLabel ? S * 0.2 : S * 0.07;
      const bodyW = cardW + 2 * m;
      return { w: bodyW + 2 * e, h: m + cardW + chin + 2 * e, pad, cardW, cardX: e + m, cardY: e + m, e, m, chin, bodyW };
    },
    paint(ctx, g, o) {
      const { e, m, chin, bodyW, cardW } = g;
      const S = o.S;
      const c = o.color;
      ctx.save();
      ctx.shadowColor = 'rgba(0, 0, 0, 0.28)';
      ctx.shadowBlur = S * 0.04;
      ctx.shadowOffsetY = S * 0.015;
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.roundRect(e, e, bodyW, m + cardW + chin, S * 0.03);
      ctx.fill();
      ctx.restore();
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.roundRect(e + m - S * 0.025, e + m - S * 0.025, cardW + S * 0.05, cardW + S * 0.05, S * 0.02);
      ctx.fill();
      drawQrCard(ctx, g, o);
      if (o.label) drawLabel(ctx, o.label, e + bodyW / 2, e + m + cardW + chin * 0.55, bodyW - 2 * m, S * 0.085, shade(c, -0.35));
    },
  },

  // Cartel: el texto arriba, con una flecha que señala el QR.
  banner: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.07;
      const head = hasLabel ? S * 0.2 : S * 0.05;
      const cardY = head + (hasLabel ? S * 0.05 : 0);
      return { w: cardW + 2 * m, h: cardY + cardW + m, pad, cardW, cardX: m, cardY, head };
    },
    paint(ctx, g, o) {
      const { w, h, head } = g;
      const S = o.S;
      const c = o.color;
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.roundRect(0, 0, w, h, S * 0.07);
      ctx.fill();
      if (o.label) {
        const ink = readableOn(c);
        drawLabel(ctx, o.label, w / 2, head * 0.5 - S * 0.01, w - S * 0.14, S * 0.09, ink);
        polygon(ctx, [[w / 2 - S * 0.045, head], [w / 2 + S * 0.045, head], [w / 2, head + S * 0.035]], ink);
      }
      drawQrCard(ctx, g, o);
    },
  },

  // Boleto: dos mitades separadas por una línea de puntos con muescas a los lados.
  ticket: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.08;
      const head = hasLabel ? S * 0.19 : S * 0.04;
      const cardY = head + S * 0.06;
      return { w: cardW + 2 * m, h: cardY + cardW + m, pad, cardW, cardX: m, cardY, head, sep: head + S * 0.03 };
    },
    paint(ctx, g, o) {
      const { w, h, head, sep } = g;
      const S = o.S;
      const c = o.color;
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.roundRect(0, 0, w, h, S * 0.05);
      ctx.fill();
      if (o.label) {
        // Sin texto no hay «talón» que separar: el boleto queda liso.
        ctx.save(); // las muescas son huecos: se borra el color, no se pinta de blanco
        ctx.globalCompositeOperation = 'destination-out';
        for (const x of [0, w]) {
          ctx.beginPath();
          ctx.arc(x, sep, S * 0.05, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
        ctx.save();
        ctx.strokeStyle = readableOn(c);
        ctx.globalAlpha = 0.55;
        ctx.lineWidth = Math.max(1, S * 0.01);
        ctx.setLineDash([S * 0.025, S * 0.02]);
        line(ctx, [[S * 0.07, sep], [w - S * 0.07, sep]]);
        ctx.restore();
      }
      drawQrCard(ctx, g, o);
      if (o.label) drawLabel(ctx, o.label, w / 2, head * 0.5 + S * 0.005, w - S * 0.2, S * 0.09, readableOn(c));
    },
  },

  // Pantalla: monitor con pie; el texto va debajo.
  screen: {
    layout(S, hasLabel) {
      const { pad, cardW } = base(S);
      const m = S * 0.07;
      const ox = S * 0.05;
      const neck = S * 0.07;
      const foot = S * 0.045;
      const bodyW = cardW + 2 * m;
      const bodyH = cardW + 2 * m;
      const labelH = hasLabel ? S * 0.15 : S * 0.02;
      return { w: bodyW + 2 * ox, h: bodyH + neck + foot + labelH, pad, cardW, cardX: ox + m, cardY: m, ox, bodyW, bodyH, neck, foot, labelH };
    },
    paint(ctx, g, o) {
      const { w, ox, bodyW, bodyH, neck, foot, labelH } = g;
      const S = o.S;
      const c = o.color;
      ctx.fillStyle = shade(c, -0.25);
      ctx.fillRect(w / 2 - S * 0.04, bodyH - 2, S * 0.08, neck + 2);
      ctx.beginPath();
      ctx.roundRect(w / 2 - S * 0.16, bodyH + neck, S * 0.32, foot, foot / 2);
      ctx.fill();
      ctx.fillStyle = c;
      ctx.beginPath();
      ctx.roundRect(ox, 0, bodyW, bodyH, S * 0.06);
      ctx.fill();
      drawQrCard(ctx, g, o);
      if (o.label) drawLabel(ctx, o.label, w / 2, bodyH + neck + foot + labelH / 2, w - S * 0.1, S * 0.085, shade(c, -0.3));
    },
  },
};

// QR de muestra (gris) para las miniaturas del selector de marcos.
function placeholderQr(S) {
  const canvas = document.createElement('canvas');
  canvas.width = S;
  canvas.height = S;
  const ctx = canvas.getContext('2d');
  const ink = '#8c8a9a';
  const n = 21;
  const u = S / n;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, S, S);
  ctx.fillStyle = ink;
  const finder = (i, j) => {
    ctx.fillStyle = ink;
    ctx.fillRect(i * u, j * u, 7 * u, 7 * u);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect((i + 1) * u, (j + 1) * u, 5 * u, 5 * u);
    ctx.fillStyle = ink;
    ctx.fillRect((i + 2) * u, (j + 2) * u, 3 * u, 3 * u);
  };
  finder(0, 0);
  finder(14, 0);
  finder(0, 14);
  let seed = 7;
  for (let j = 0; j < n; j += 1) {
    for (let i = 0; i < n; i += 1) {
      if ((i < 8 && j < 8) || (i > 12 && j < 8) || (i < 8 && j > 12)) continue;
      seed = (seed * 73 + 19) % 97;
      if (seed % 2) ctx.fillRect(i * u, j * u, u, u);
    }
  }
  return canvas;
}

/** Miniatura (canvas) de un marco, con el color elegido, para el selector. */
export function frameThumbnail(frame, color, size = 64) {
  return composeFrame(placeholderQr(size), { frame, text: 'ESCANÉAME', color });
}
