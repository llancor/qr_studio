// Menú de la barra superior en pantallas chicas. En el teléfono los enlaces de la cabecera (Generador, Páginas,
// PNG a ICO, Lector QR, Códigos de barras, Ajustes) no caben en la fila, así que se agrupan detrás de un botón
// «Menú» que abre un panel debajo de la cabecera. En pantallas anchas el botón no se ve y todo sigue como antes.
// El botón se crea aquí para no repetirlo en cada página.

const nav = document.querySelector('.site-header .main-nav');
const inner = document.querySelector('.site-header .header-inner');

if (nav && inner) {
  nav.id ||= 'menu-principal';

  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'menu-btn';
  button.setAttribute('aria-controls', nav.id);

  const ns = 'http://www.w3.org/2000/svg';
  const icon = document.createElementNS(ns, 'svg');
  icon.setAttribute('viewBox', '0 0 24 24');
  icon.setAttribute('aria-hidden', 'true');
  for (const y of [6, 12, 18]) {
    const line = document.createElementNS(ns, 'path');
    line.setAttribute('d', `M4 ${y}h16`);
    icon.append(line);
  }
  const label = document.createElement('span');
  label.textContent = 'Menú';
  button.append(icon, label);
  inner.append(button);

  const isOpen = () => nav.classList.contains('is-open');
  const setOpen = (open) => {
    nav.classList.toggle('is-open', open);
    button.setAttribute('aria-expanded', String(open));
    button.setAttribute('aria-label', open ? 'Cerrar el menú' : 'Abrir el menú');
  };
  setOpen(false);

  button.addEventListener('click', () => setOpen(!isOpen()));
  // Al elegir un enlace el panel se cierra (en la página principal «Generador» solo baja a la sección).
  nav.addEventListener('click', (event) => {
    if (event.target.closest('a')) setOpen(false);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && isOpen()) {
      setOpen(false);
      button.focus();
    }
  });
  // Tocar fuera de la cabecera también lo cierra.
  document.addEventListener('click', (event) => {
    if (isOpen() && !event.target.closest('.site-header')) setOpen(false);
  });
  // Si la pantalla se ensancha (por ejemplo al girar el teléfono), el menú vuelve a la barra de siempre.
  window.matchMedia('(min-width: 801px)').addEventListener('change', (event) => {
    if (event.matches) setOpen(false);
  });
}
