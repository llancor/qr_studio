"""Tests de la administración de usuarios. Ejecutar desde web/:  python -m pytest"""

import sqlite3

import pytest
from fastapi.testclient import TestClient

from app import db
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}
MARTA = {"email": "marta@example.com", "name": "Marta", "password": "correct-horse-3"}


def make_settings(tmp_path, **extra):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
        files_path=tmp_path / "qr",
        **extra,
    )


@pytest.fixture()
def app(tmp_path):
    return create_app(make_settings(tmp_path))


def new_client(app):
    return TestClient(app, follow_redirects=False)


def sign_up(app, who):
    client = new_client(app)
    res = client.post("/api/auth/register", json=who)
    assert res.status_code == 201, res.text
    return client


def sign_in(app, who, password=None):
    client = new_client(app)
    res = client.post(
        "/api/auth/login", json={"email": who["email"], "password": password or who["password"]}
    )
    return client, res


@pytest.fixture()
def boss(app):
    """El administrador: la primera cuenta que se crea."""
    return sign_up(app, ANA)


def add_user(boss, who, role="user"):
    res = boss.post("/api/admin/users", json={**who, "role": role})
    assert res.status_code == 201, res.text
    return res.json()["user"]


# ----- Quién es administrador -----------------------------------------------

def test_first_account_is_admin_and_next_ones_are_not(app):
    first = sign_up(app, ANA)
    second = sign_up(app, LUIS)
    assert first.get("/api/auth/me").json()["user"]["role"] == "admin"
    assert second.get("/api/auth/me").json()["user"]["role"] == "user"


def test_old_database_gets_roles_and_first_user_becomes_admin(tmp_path):
    path = tmp_path / "old.db"
    with sqlite3.connect(path) as conn:
        conn.executescript(
            """
            CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
            INSERT INTO users (email, name, password_hash, created_at) VALUES
                ('uno@example.com', 'Uno', 'x', '2026-01-01'), ('dos@example.com', 'Dos', 'x', '2026-01-02');
            """
        )
    db.init_db(path)
    db.init_db(path)  # repetir no cambia nada
    with sqlite3.connect(path) as conn:
        rows = conn.execute("SELECT email, role, active FROM users ORDER BY id").fetchall()
    assert rows == [("uno@example.com", "admin", 1), ("dos@example.com", "user", 1)]


# ----- Solo el administrador entra a /api/admin ------------------------------

ADMIN_CALLS = [
    ("get", "/api/admin/users", None),
    ("post", "/api/admin/users", {**LUIS, "role": "user"}),
    ("patch", "/api/admin/users/1", {"active": False}),
    ("post", "/api/admin/users/1/password", {"password": "nueva-clave-1"}),
    ("get", "/api/admin/settings", None),
    ("put", "/api/admin/settings", {"registrationOpen": False}),
    ("get", "/api/admin/public-access", None),
    ("put", "/api/admin/public-access", {"publicAccess": True}),
    ("delete", "/api/admin/users/1", None),
    ("get", "/api/admin/legal", None),
    ("put", "/api/admin/legal", {"name": "Ana", "email": "ana@example.com"}),
    ("patch", "/api/admin/users/1", {"name": "Otro nombre"}),
    ("get", "/api/admin/smtp", None),
    (
        "put",
        "/api/admin/smtp",
        {"host": "smtp.example.com", "port": 587, "security": "starttls", "sender": "a@example.com"},
    ),
    ("post", "/api/admin/smtp/test", {"to": "a@example.com"}),
]


@pytest.mark.parametrize("method,path,body", ADMIN_CALLS)
def test_admin_api_needs_a_session(app, boss, method, path, body):
    anonymous = new_client(app)
    assert getattr(anonymous, method)(path, **({"json": body} if body else {})).status_code == 401


@pytest.mark.parametrize("method,path,body", ADMIN_CALLS)
def test_admin_api_refuses_regular_users(app, boss, method, path, body):
    add_user(boss, LUIS)
    luis, _ = sign_in(app, LUIS)
    assert getattr(luis, method)(path, **({"json": body} if body else {})).status_code == 403


# ----- Crear usuarios ----------------------------------------------------------

def test_admin_creates_users_who_can_sign_in(app, boss):
    user = add_user(boss, LUIS)
    assert user["email"] == "luis@example.com" and user["role"] == "user" and user["active"] is True
    assert "password" not in str(user) and "hash" not in str(user)
    _, res = sign_in(app, LUIS)
    assert res.status_code == 200 and res.json()["user"]["role"] == "user"


def test_admin_can_create_another_admin(app, boss):
    add_user(boss, LUIS, role="admin")
    luis, _ = sign_in(app, LUIS)
    assert luis.get("/api/admin/users").status_code == 200


# ----- Editar nombre y correo ----------------------------------------------------

def test_admin_edits_name_and_email_and_the_new_email_is_the_login(app, boss):
    user = add_user(boss, LUIS)
    res = boss.patch(f"/api/admin/users/{user['id']}", json={"name": "  Luis Pérez ", "email": "Luis.Perez@Example.com"})
    assert res.status_code == 200
    assert res.json()["user"]["name"] == "Luis Pérez" and res.json()["user"]["email"] == "luis.perez@example.com"
    assert sign_in(app, LUIS)[1].status_code == 401  # el correo anterior ya no entra
    _, ok = sign_in(app, {**LUIS, "email": "luis.perez@example.com"})
    assert ok.status_code == 200


def test_editing_the_email_cannot_take_another_accounts_email(app, boss):
    user = add_user(boss, LUIS)
    res = boss.patch(f"/api/admin/users/{user['id']}", json={"email": ANA["email"]})
    assert res.status_code == 409


@pytest.mark.parametrize("body", [{"email": "no-es-un-correo"}, {"name": "   "}, {"name": "x" * 81}])
def test_editing_rejects_invalid_values(app, boss, body):
    user = add_user(boss, LUIS)
    assert boss.patch(f"/api/admin/users/{user['id']}", json=body).status_code == 422


def test_editing_only_the_role_keeps_name_and_email(app, boss):
    user = add_user(boss, LUIS)
    res = boss.patch(f"/api/admin/users/{user['id']}", json={"role": "admin"}).json()["user"]
    assert res["name"] == "Luis" and res["email"] == LUIS["email"] and res["role"] == "admin"


def test_create_user_validations(boss):
    assert boss.post("/api/admin/users", json={**LUIS, "role": "user"}).status_code == 201
    assert boss.post("/api/admin/users", json={**LUIS, "role": "user"}).status_code == 409
    assert boss.post("/api/admin/users", json={**MARTA, "password": "corta", "role": "user"}).status_code == 422
    assert boss.post("/api/admin/users", json={**MARTA, "email": "no-es-correo", "role": "user"}).status_code == 422
    assert boss.post("/api/admin/users", json={**MARTA, "name": "  ", "role": "user"}).status_code == 422
    assert boss.post("/api/admin/users", json={**MARTA, "role": "superdios"}).status_code == 422


def test_list_users_shows_everyone_without_secrets(boss):
    add_user(boss, LUIS)
    users = boss.get("/api/admin/users").json()["users"]
    assert [u["email"] for u in users] == ["ana@example.com", "luis@example.com"]
    assert users[0]["role"] == "admin" and users[1]["role"] == "user"
    assert all(set(u) == {"id", "email", "name", "role", "active", "createdAt"} for u in users)


# ----- Restablecer contraseña -------------------------------------------------

def test_reset_password_replaces_it_and_closes_that_users_sessions(app, boss):
    user = add_user(boss, LUIS)
    luis, _ = sign_in(app, LUIS)
    assert luis.get("/api/auth/me").json()["user"] is not None

    res = boss.post(f"/api/admin/users/{user['id']}/password", json={"password": "nueva-clave-99"})
    assert res.status_code == 200

    assert luis.get("/api/auth/me").json() == {"user": None}  # su sesión se cerró
    assert sign_in(app, LUIS)[1].status_code == 401  # la vieja ya no sirve
    assert sign_in(app, LUIS, "nueva-clave-99")[1].status_code == 200


def test_reset_password_checks_length_and_user(boss):
    user = add_user(boss, LUIS)
    assert boss.post(f"/api/admin/users/{user['id']}/password", json={"password": "corta"}).status_code == 422
    assert boss.post("/api/admin/users/999/password", json={"password": "nueva-clave-99"}).status_code == 404


def test_admin_changing_own_password_keeps_the_current_session(app, boss):
    me = boss.get("/api/auth/me").json()["user"]
    assert boss.post(f"/api/admin/users/{me['id']}/password", json={"password": "otra-clave-77"}).status_code == 200
    assert boss.get("/api/auth/me").json()["user"]["email"] == "ana@example.com"
    assert sign_in(app, ANA, "otra-clave-77")[1].status_code == 200


# ----- Desactivar cuentas ----------------------------------------------------------

def test_deactivated_user_loses_access_at_once_and_cannot_log_in(app, boss):
    user = add_user(boss, LUIS)
    luis, _ = sign_in(app, LUIS)
    assert luis.get("/api/features").status_code == 200

    res = boss.patch(f"/api/admin/users/{user['id']}", json={"active": False})
    assert res.status_code == 200 and res.json()["user"]["active"] is False

    assert luis.get("/api/features").status_code == 401  # la sesión abierta deja de servir
    _, ok_password = sign_in(app, LUIS)
    assert ok_password.status_code == 403 and "desactivada" in ok_password.json()["detail"]
    _, bad_password = sign_in(app, LUIS, "equivocada-123")
    assert bad_password.status_code == 401  # no revela si la cuenta existe


def test_reactivated_user_can_enter_again(app, boss):
    user = add_user(boss, LUIS)
    boss.patch(f"/api/admin/users/{user['id']}", json={"active": False})
    boss.patch(f"/api/admin/users/{user['id']}", json={"active": True})
    assert sign_in(app, LUIS)[1].status_code == 200


def test_admin_cannot_deactivate_themselves(boss):
    me = boss.get("/api/auth/me").json()["user"]
    res = boss.patch(f"/api/admin/users/{me['id']}", json={"active": False})
    assert res.status_code == 409


def test_there_is_always_one_active_admin(app, boss):
    me = boss.get("/api/auth/me").json()["user"]
    # Único administrador: no se puede quitar el rol.
    assert boss.patch(f"/api/admin/users/{me['id']}", json={"role": "user"}).status_code == 409
    # Con otro administrador activo sí; y ese otro ya no puede quedarse solo sin él.
    other = add_user(boss, LUIS, role="admin")
    assert boss.patch(f"/api/admin/users/{me['id']}", json={"role": "user"}).status_code == 200
    luis, _ = sign_in(app, LUIS)
    assert luis.patch(f"/api/admin/users/{other['id']}", json={"role": "user"}).status_code == 409
    assert luis.patch(f"/api/admin/users/{me['id']}", json={"active": False}).status_code == 200


def test_a_deactivated_admin_does_not_count_as_the_remaining_admin(app, boss):
    other = add_user(boss, LUIS, role="admin")
    me = boss.get("/api/auth/me").json()["user"]
    assert boss.patch(f"/api/admin/users/{other['id']}", json={"active": False}).status_code == 200
    assert boss.patch(f"/api/admin/users/{me['id']}", json={"role": "user"}).status_code == 409


def test_update_user_validations(boss):
    user = add_user(boss, LUIS)
    assert boss.patch(f"/api/admin/users/{user['id']}", json={"role": "otro"}).status_code == 422
    assert boss.patch("/api/admin/users/999", json={"active": False}).status_code == 404


# ----- Crear cuenta: abrir y cerrar el registro -----------------------------------

def test_registration_is_open_by_default(app, boss):
    anonymous = new_client(app)
    # recoveryEnabled: sin servidor SMTP configurado no se ofrece «¿Olvidaste tu contraseña?»
    assert anonymous.get("/api/auth/options").json() == {
        "registrationOpen": True,
        "firstUser": False,
        "recoveryEnabled": False,
        "loginImage": None,  # el administrador aún no puso imagen en la página de acceso
        "site": {"name": "QR Studio", "logoVersion": 0, "card": "", "text": "", "accent": ""},
        "publicAccess": False,  # por defecto todo exige iniciar sesión
        "legalConfigured": False,  # sin datos legales no se pide aceptar nada al crear una cuenta
    }
    assert boss.get("/api/admin/settings").json() == {"registrationOpen": True}
    assert anonymous.post("/api/auth/register", json=LUIS).status_code == 201


def test_closing_registration_blocks_new_accounts_but_not_the_admin(app, boss):
    assert boss.put("/api/admin/settings", json={"registrationOpen": False}).json() == {"registrationOpen": False}
    anonymous = new_client(app)
    assert anonymous.get("/api/auth/options").json()["registrationOpen"] is False
    res = anonymous.post("/api/auth/register", json=LUIS)
    assert res.status_code == 403 and "desactivada" in res.json()["detail"]
    assert add_user(boss, LUIS)["email"] == "luis@example.com"  # el administrador sí puede crear
    assert sign_in(app, LUIS)[1].status_code == 200  # y las cuentas existentes siguen entrando

    boss.put("/api/admin/settings", json={"registrationOpen": True})
    assert new_client(app).post("/api/auth/register", json=MARTA).status_code == 201


def test_the_choice_survives_a_restart(tmp_path):
    first = create_app(make_settings(tmp_path))
    boss = sign_up(first, ANA)
    boss.put("/api/admin/settings", json={"registrationOpen": False})
    second = create_app(make_settings(tmp_path))  # mismo archivo de base de datos
    assert new_client(second).get("/api/auth/options").json()["registrationOpen"] is False


def test_environment_value_is_only_the_starting_point(tmp_path):
    closed = create_app(make_settings(tmp_path, registration_open=False))
    options = new_client(closed).get("/api/auth/options").json()
    # sin cuentas, el primero siempre puede
    assert options == {
        "registrationOpen": True,
        "firstUser": True,
        "recoveryEnabled": False,
        "loginImage": None,
        "site": {"name": "QR Studio", "logoVersion": 0, "card": "", "text": "", "accent": ""},
        "publicAccess": False,
        "legalConfigured": False,
    }
    boss = sign_up(closed, ANA)
    assert boss.get("/api/auth/me").json()["user"]["role"] == "admin"
    assert new_client(closed).get("/api/auth/options").json()["registrationOpen"] is False
    assert new_client(closed).post("/api/auth/register", json=LUIS).status_code == 403
    boss.put("/api/admin/settings", json={"registrationOpen": True})  # lo guardado manda sobre la variable
    assert new_client(closed).post("/api/auth/register", json=LUIS).status_code == 201


def test_options_are_public(app):
    assert new_client(app).get("/api/auth/options").status_code == 200
