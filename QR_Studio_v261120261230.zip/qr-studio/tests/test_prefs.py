"""Personalización de cada usuario (tema, color, estilo y portada). Ejecutar desde web/:  python -m pytest"""

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}

GOOD = {
    "tema": "oscuro",
    "acento": "#16A34A",
    "esquinas": "rectas",
    "texto": "grande",
    "fuente": "serif",
    "velo": 40,
    "desenfoque": 5,
    "ajuste": "ajustar",
    "posicion": "arriba",
}
JPEG = b"\xff\xd8\xff\xe0" + b"x" * 5000


@pytest.fixture()
def app(tmp_path):
    return create_app(
        Settings(
            db_path=tmp_path / "test.db",
            session_days=14,
            cookie_secure=False,
            min_password_length=8,
            login_max_attempts=5,
            login_window_seconds=300,
            files_path=tmp_path / "qr",
        )
    )


def sign_up(app, who):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=who).status_code == 201
    return client


@pytest.fixture()
def ana(app):
    return sign_up(app, ANA)


@pytest.fixture()
def luis(app, ana):
    return sign_up(app, LUIS)


def test_nothing_saved_yet(ana):
    data = ana.get("/api/me/prefs").json()
    assert data["prefs"] is None and data["coverVersion"] == 0 and isinstance(data["userId"], int)


def test_save_and_read_back(ana):
    saved = ana.put("/api/me/prefs", json=GOOD).json()
    assert saved["prefs"]["acento"] == "#16a34a"  # se guarda en minúsculas
    assert ana.get("/api/me/prefs").json()["prefs"] == saved["prefs"]


def test_missing_keys_take_their_defaults(ana):
    prefs = ana.put("/api/me/prefs", json={"tema": "claro"}).json()["prefs"]
    assert prefs["tema"] == "claro" and prefs["esquinas"] == "suaves" and prefs["velo"] == 60


def test_each_user_has_their_own_look(ana, luis):
    ana.put("/api/me/prefs", json=GOOD)
    assert luis.get("/api/me/prefs").json()["prefs"] is None
    luis.put("/api/me/prefs", json={"tema": "claro"})
    assert ana.get("/api/me/prefs").json()["prefs"]["tema"] == "oscuro"


@pytest.mark.parametrize(
    "body",
    [{"tema": "rosa"}, {"acento": "rojo"}, {"acento": "#12345"}, {"velo": 91}, {"velo": -1}, {"velo": True}, {"desenfoque": "3"}, {"texto": 7}, []],
)
def test_invalid_preferences_are_rejected(ana, body):
    assert ana.put("/api/me/prefs", json=body).status_code == 422


def test_everything_needs_a_session(app):
    guest = TestClient(app, follow_redirects=False)
    assert guest.get("/api/me/prefs").status_code == 401
    assert guest.put("/api/me/prefs", json=GOOD).status_code == 401
    assert guest.get("/api/me/cover").status_code == 401


def test_cover_upload_read_and_private(ana, luis):
    res = ana.put("/api/me/cover", content=JPEG, headers={"Content-Type": "image/jpeg"})
    assert res.status_code == 200 and res.json()["coverVersion"] == 1
    got = ana.get("/api/me/cover")
    assert got.status_code == 200 and got.content == JPEG and got.headers["content-type"] == "image/jpeg"
    assert "immutable" in got.headers["cache-control"]
    assert luis.get("/api/me/cover").status_code == 404  # la portada de Ana no es de Luis


def test_cover_version_changes_with_every_change(ana):
    first = ana.put("/api/me/cover", content=JPEG).json()["coverVersion"]
    second = ana.put("/api/me/cover", content=JPEG).json()["coverVersion"]
    assert second > first
    assert ana.delete("/api/me/cover").json()["coverVersion"] == 0
    assert ana.get("/api/me/cover").status_code == 404
    assert ana.put("/api/me/cover", content=JPEG).json()["coverVersion"] > second  # nunca repite una URL


def test_cover_must_be_a_real_image(ana):
    assert ana.put("/api/me/cover", content=b"<svg onload=alert(1)></svg>" * 10).status_code == 415
    assert ana.put("/api/me/cover", content=b"").status_code == 422


def test_cover_too_big(ana):
    assert ana.put("/api/me/cover", content=b"\xff\xd8\xff" + b"0" * (4 * 1024 * 1024 + 10)).status_code == 413


def test_prefs_and_cover_are_independent(ana):
    ana.put("/api/me/prefs", json=GOOD)
    ana.put("/api/me/cover", content=JPEG)
    ana.put("/api/me/prefs", json={"tema": "claro"})
    data = ana.get("/api/me/prefs").json()
    assert data["prefs"]["tema"] == "claro" and data["coverVersion"] >= 1


def test_reset_everything(ana):
    ana.put("/api/me/prefs", json=GOOD)
    ana.put("/api/me/cover", content=JPEG)
    data = ana.delete("/api/me/prefs").json()
    assert data["prefs"] is None and data["coverVersion"] == 0
    assert ana.get("/api/me/cover").status_code == 404


# ----- Imagen de la página de acceso (del sitio, la elige el administrador, es pública) ---------------


def test_login_image_is_empty_until_the_admin_sets_one(app, ana):
    guest = TestClient(app, follow_redirects=False)
    assert guest.get("/api/auth/options").json()["loginImage"] is None
    assert guest.get("/api/auth/login-image").status_code == 404
    info = ana.get("/api/admin/login-image").json()
    assert info == {"version": 0, "velo": 35, "desenfoque": 0, "ajuste": "cubrir", "posicion": "centro"}


def test_admin_sets_the_login_image_and_anyone_can_see_it(app, ana):
    guest = TestClient(app, follow_redirects=False)
    res = ana.put("/api/admin/login-image", content=JPEG, headers={"Content-Type": "image/jpeg"})
    assert res.status_code == 200 and res.json()["version"] == 1
    got = guest.get("/api/auth/login-image")  # sin sesión: es pública a propósito
    assert got.status_code == 200 and got.content == JPEG and got.headers["content-type"] == "image/jpeg"
    assert "immutable" in got.headers["cache-control"]
    assert guest.get("/api/auth/options").json()["loginImage"]["version"] == 1


def test_only_the_admin_can_change_the_login_image(app, ana, luis):
    guest = TestClient(app, follow_redirects=False)
    for client, expected in ((guest, 401), (luis, 403)):
        assert client.get("/api/admin/login-image").status_code == expected
        assert client.put("/api/admin/login-image", content=JPEG).status_code == expected
        assert client.put("/api/admin/login-image/settings", json={"velo": 10}).status_code == expected
        assert client.delete("/api/admin/login-image").status_code == expected


def test_login_image_settings_are_validated_and_kept(ana):
    ana.put("/api/admin/login-image", content=JPEG)
    ok = {"velo": 70, "desenfoque": 4, "ajuste": "ajustar", "posicion": "arriba"}
    assert ana.put("/api/admin/login-image/settings", json=ok).json() == {"version": 1, **ok}
    for bad in ({"velo": 95}, {"ajuste": "x"}, {"posicion": "medio"}, {"desenfoque": -1}, []):
        assert ana.put("/api/admin/login-image/settings", json=bad).status_code == 422
    assert ana.put("/api/admin/login-image", content=JPEG).json()["velo"] == 70  # cambiar la imagen no toca los ajustes


def test_login_image_must_be_a_real_image_and_small(ana):
    assert ana.put("/api/admin/login-image", content=b"<svg onload=alert(1)></svg>" * 10).status_code == 415
    assert ana.put("/api/admin/login-image", content=b"").status_code == 422
    assert ana.put("/api/admin/login-image", content=b"\xff\xd8\xff" + b"0" * (4 * 1024 * 1024 + 10)).status_code == 413


def test_removing_the_login_image(app, ana):
    guest = TestClient(app, follow_redirects=False)
    first = ana.put("/api/admin/login-image", content=JPEG).json()["version"]
    assert ana.delete("/api/admin/login-image").json()["version"] == 0
    assert guest.get("/api/auth/login-image").status_code == 404
    assert guest.get("/api/auth/options").json()["loginImage"] is None
    assert ana.put("/api/admin/login-image", content=JPEG).json()["version"] > first  # nunca repite una URL


def test_the_account_cover_and_the_login_image_are_independent(ana):
    ana.put("/api/me/cover", content=JPEG)
    assert ana.get("/api/admin/login-image").json()["version"] == 0
    ana.put("/api/admin/login-image", content=JPEG)
    ana.delete("/api/me/cover")
    assert ana.get("/api/admin/login-image").json()["version"] == 1


def test_deleting_an_account_removes_its_prefs(app, ana):
    ana.put("/api/me/prefs", json=GOOD)
    from app import db

    with db.connect(app.state.settings.db_path) as conn:
        conn.execute("DELETE FROM users WHERE email = ?", (ANA["email"],))
        assert conn.execute("SELECT COUNT(*) FROM user_prefs").fetchone()[0] == 0
