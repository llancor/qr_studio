"""Tests de la API de cuentas. Ejecutar desde la raíz:  python -m pytest"""

import sqlite3
from datetime import datetime, timedelta, timezone

import pytest
from fastapi.testclient import TestClient

from app import auth, main
from app.config import Settings
from app.main import create_app

USER = {"email": "Ana@Example.com", "name": "Ana", "password": "correct-horse-1"}


@pytest.fixture()
def settings(tmp_path):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
    )


@pytest.fixture()
def client(settings):
    return TestClient(create_app(settings))


def register(client, **overrides):
    return client.post("/api/auth/register", json={**USER, **overrides})


# ----- Contraseñas ---------------------------------------------------------

def test_password_hash_roundtrip():
    stored = auth.hash_password("secreto-123")
    assert stored.startswith("scrypt$")
    assert "secreto-123" not in stored
    assert auth.verify_password("secreto-123", stored)
    assert not auth.verify_password("otra-cosa", stored)
    assert not auth.verify_password("x", "formato-invalido")


# ----- Registro ------------------------------------------------------------

def test_register_creates_user_and_session(client, settings):
    res = register(client)
    assert res.status_code == 201
    assert res.json()["user"]["email"] == "ana@example.com"  # normalizado
    assert "session" in res.cookies

    me = client.get("/api/auth/me").json()
    assert me["user"]["name"] == "Ana"

    with sqlite3.connect(settings.db_path) as conn:
        (stored,) = conn.execute("SELECT password_hash FROM users").fetchone()
    assert stored != USER["password"] and stored.startswith("scrypt$")


def test_register_session_cookie_flags(client):
    res = register(client)
    header = res.headers["set-cookie"].lower()
    assert "httponly" in header and "samesite=lax" in header


def test_register_duplicate_email_is_case_insensitive(client):
    assert register(client).status_code == 201
    assert register(client, email="ANA@example.com").status_code == 409


@pytest.mark.parametrize(
    "overrides",
    [
        {"password": "corta"},
        {"password": "x" * 129},
        {"email": "no-es-un-correo"},
        {"name": "   "},
        {"name": "n" * 81},
    ],
)
def test_register_validation(client, overrides):
    assert register(client, **overrides).status_code == 422


def test_register_rejects_malformed_body(client):
    assert client.post("/api/auth/register", json={"email": "a@b.co"}).status_code == 422


# ----- Login / logout ------------------------------------------------------

def test_login_success_and_wrong_password(client):
    register(client)
    client.post("/api/auth/logout")

    bad = client.post("/api/auth/login", json={"email": USER["email"], "password": "mala-contraseña"})
    assert bad.status_code == 401

    ok = client.post("/api/auth/login", json={"email": "ana@EXAMPLE.com", "password": USER["password"]})
    assert ok.status_code == 200
    assert client.get("/api/auth/me").json()["user"]["email"] == "ana@example.com"


def test_login_unknown_user_gives_same_error_as_wrong_password(client):
    register(client)
    unknown = client.post("/api/auth/login", json={"email": "nadie@example.com", "password": "loquesea123"})
    wrong = client.post("/api/auth/login", json={"email": USER["email"], "password": "loquesea123"})
    assert unknown.status_code == wrong.status_code == 401
    assert unknown.json() == wrong.json()


def test_logout_invalidates_session(client):
    register(client)
    assert client.get("/api/auth/me").json()["user"] is not None
    assert client.post("/api/auth/logout").status_code == 200
    assert client.get("/api/auth/me").json()["user"] is None


def test_me_without_session_is_null(client):
    assert client.get("/api/auth/me").json() == {"user": None}


def test_expired_session_is_rejected(client, settings):
    register(client)
    past = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
    with sqlite3.connect(settings.db_path) as conn:
        conn.execute("UPDATE sessions SET expires_at = ?", (past,))
    assert client.get("/api/auth/me").json()["user"] is None


def test_login_is_rate_limited_after_repeated_failures(client):
    register(client)
    payload = {"email": USER["email"], "password": "incorrecta-1"}
    for _ in range(5):
        assert client.post("/api/auth/login", json=payload).status_code == 401
    assert client.post("/api/auth/login", json=payload).status_code == 429
    # Ni siquiera la contraseña correcta entra mientras dure el bloqueo.
    good = {"email": USER["email"], "password": USER["password"]}
    assert client.post("/api/auth/login", json=good).status_code == 429


# ----- Seguridad general ---------------------------------------------------

def test_cross_origin_post_is_blocked(client):
    res = client.post(
        "/api/auth/login",
        json={"email": USER["email"], "password": "x"},
        headers={"Origin": "https://evil.example"},
    )
    assert res.status_code == 403


def test_same_origin_post_is_allowed(client):
    res = client.post(
        "/api/auth/register",
        json=USER,
        headers={"Origin": "http://testserver"},
    )
    assert res.status_code == 201


def test_security_headers_and_static_index(client):
    register(client)  # todo el sitio exige sesión (ver test_access.py)
    res = client.get("/")
    assert res.status_code == 200
    assert "Generador de códigos QR" in res.text
    assert "default-src 'self'" in res.headers["content-security-policy"]
    assert res.headers["x-content-type-options"] == "nosniff"
    assert client.get("/api/auth/me").headers["cache-control"] == "no-store"


def test_healthz(client):
    assert client.get("/healthz").json()["status"] == "ok"


def test_healthz_muestra_la_version(client):
    # Sin paquete (código fuente) no hay version.txt: «desarrollo». Con paquete: p. ej. v191120261705.
    assert client.get("/healthz").json()["version"] == main.read_version_file()


def test_version_se_lee_del_archivo(tmp_path, monkeypatch):
    archivo = tmp_path / "version.txt"
    monkeypatch.setattr(main, "VERSION_FILE", archivo)
    assert main.read_version_file() == "desarrollo"          # no existe
    archivo.write_text("v191120261705", encoding="utf-8")
    assert main.read_version_file() == "v191120261705"
    archivo.write_text("﻿v191120261705\r\n", encoding="utf-8")  # con BOM y salto de línea
    assert main.read_version_file() == "v191120261705"
    archivo.write_text("<script>alert(1)</script>", encoding="utf-8")
    assert main.read_version_file() == "desarrollo"          # formato inválido: no se muestra

