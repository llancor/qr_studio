"""Tests de los QR dinámicos (opcionales). Ejecutar desde web/:  python -m pytest"""

import sqlite3

import pytest
from fastapi.testclient import TestClient

from app import dynamic
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}


def make_settings(tmp_path, **extra):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
        files_path=tmp_path / "qr",
        **extra,
    )


@pytest.fixture()
def settings(tmp_path):
    return make_settings(tmp_path)


@pytest.fixture()
def app(settings):
    return create_app(settings)


def member(app, who):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=who).status_code == 201
    return client


@pytest.fixture()
def ana(app):
    return member(app, ANA)


@pytest.fixture()
def luis(app):
    return member(app, LUIS)


@pytest.fixture()
def visitor(app):
    return TestClient(app, follow_redirects=False)


def new_qr(client, target="https://www.ejemplo.com/uno", name="Mi QR"):
    res = client.post("/api/dynamic", json={"name": name, "target": target})
    assert res.status_code == 201, res.text
    return res.json()


# ----- Validación ------------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw, expected",
    [
        ("https://www.ejemplo.com/a?x=1#y", "https://www.ejemplo.com/a?x=1#y"),
        ("  www.ejemplo.com/sin-esquema ", "https://www.ejemplo.com/sin-esquema"),
        ("http://localhost:8000/x", "http://localhost:8000/x"),
    ],
)
def test_clean_target_accepts_web_links(raw, expected):
    assert dynamic.clean_target(raw) == expected


@pytest.mark.parametrize(
    "raw",
    ["", "   ", "javascript:alert(1)", "data:text/html,hola", "file:///etc/passwd", "ftp://x.com/a", "https://", "https://a.com/con espacio", "mailto:a@b.cc"],
)
def test_clean_target_rejects_everything_else(raw):
    with pytest.raises(dynamic.DynamicError):
        dynamic.clean_target(raw)


def test_clean_target_limits_length():
    with pytest.raises(dynamic.DynamicError):
        dynamic.clean_target("https://a.com/" + "x" * dynamic.MAX_TARGET)


# ----- Crear y listar -----------------------------------------------------------------------


def test_create_and_list(ana):
    item = new_qr(ana)
    assert len(item["code"]) == dynamic.CODE_LEN
    assert set(item["code"]) <= set(dynamic.ALPHABET)
    assert item["name"] == "Mi QR"
    assert item["active"] is True and item["scans"] == 0 and item["lastScanAt"] is None

    listing = ana.get("/api/dynamic").json()
    assert [i["id"] for i in listing["items"]] == [item["id"]]
    assert listing["limit"] == dynamic.MAX_PER_USER


def test_name_defaults_to_the_host(ana):
    item = ana.post("/api/dynamic", json={"target": "https://tienda.ejemplo.com/oferta"}).json()
    assert item["name"] == "tienda.ejemplo.com"


def test_codes_are_unique(ana):
    codes = {new_qr(ana, name=f"n{i}")["code"] for i in range(30)}
    assert len(codes) == 30


def test_invalid_target_is_rejected(ana):
    assert ana.post("/api/dynamic", json={"target": "javascript:alert(1)"}).status_code == 422
    assert ana.post("/api/dynamic", json={"target": ""}).status_code == 422
    assert ana.get("/api/dynamic").json()["items"] == []


def test_per_user_limit(ana, monkeypatch):
    monkeypatch.setattr(dynamic, "MAX_PER_USER", 2)
    new_qr(ana)
    new_qr(ana)
    assert ana.post("/api/dynamic", json={"target": "https://a.com/x"}).status_code == 409


# ----- Escanear (público) ------------------------------------------------------------------------


def test_scan_redirects_counts_and_is_public(ana, visitor):
    item = new_qr(ana, "https://www.ejemplo.com/destino")
    for _ in range(3):
        res = visitor.get(f"/q/{item['code']}")  # sin sesión
        assert res.status_code == 302
        assert res.headers["location"] == "https://www.ejemplo.com/destino"
        assert res.headers["cache-control"] == "no-store"

    shown = ana.get("/api/dynamic").json()["items"][0]
    assert shown["scans"] == 3
    assert shown["lastScanAt"] is not None
    stats = ana.get(f"/api/dynamic/{item['id']}/stats").json()
    assert stats["total"] == 3
    assert len(stats["days"]) == 30
    assert stats["days"][-1]["count"] == 3  # todo ocurrió hoy
    assert sum(d["count"] for d in stats["days"]) == 3


def test_changing_the_target_takes_effect_immediately(ana, visitor):
    item = new_qr(ana, "https://www.ejemplo.com/viejo")
    assert visitor.get(f"/q/{item['code']}").headers["location"] == "https://www.ejemplo.com/viejo"
    res = ana.patch(f"/api/dynamic/{item['id']}", json={"target": "nuevo.ejemplo.com/ya"})
    assert res.status_code == 200 and res.json()["target"] == "https://nuevo.ejemplo.com/ya"
    assert visitor.get(f"/q/{item['code']}").headers["location"] == "https://nuevo.ejemplo.com/ya"
    assert res.json()["code"] == item["code"]  # el código (el QR impreso) no cambia


def test_paused_unknown_and_deleted_codes(ana, visitor):
    item = new_qr(ana)
    assert ana.patch(f"/api/dynamic/{item['id']}", json={"active": False}).json()["active"] is False
    paused = visitor.get(f"/q/{item['code']}")
    assert paused.status_code == 410 and "pausado" in paused.text
    assert ana.get("/api/dynamic").json()["items"][0]["scans"] == 0  # pausado: no cuenta

    assert ana.patch(f"/api/dynamic/{item['id']}", json={"active": True}).json()["active"] is True
    assert visitor.get(f"/q/{item['code']}").status_code == 302

    assert visitor.get("/q/zzzzzzz").status_code == 404
    assert visitor.get("/q/..%2f..%2fapp").status_code == 404
    assert visitor.get("/q/ABC").status_code == 404

    assert ana.delete(f"/api/dynamic/{item['id']}").status_code == 200
    assert visitor.get(f"/q/{item['code']}").status_code == 404
    assert ana.get("/api/dynamic").json()["items"] == []


def test_notice_pages_escape_and_are_not_cached(visitor):
    res = visitor.get("/q/noexiste")
    assert res.status_code == 404
    assert res.headers["cache-control"] == "no-store"
    assert "<script" not in res.text


def test_redirect_cannot_be_hijacked_through_the_short_url(visitor):
    # El destino solo se guarda al crearlo: nada de lo que venga en la dirección corta se usa.
    res = visitor.get("/q/abcdefg?url=https://malo.example&next=https://malo.example")
    assert res.status_code == 404
    assert "location" not in res.headers


# ----- Propiedad y acceso --------------------------------------------------------------------------


def test_users_cannot_touch_each_others_qrs(ana, luis):
    item = new_qr(ana)
    assert luis.get("/api/dynamic").json()["items"] == []
    assert luis.patch(f"/api/dynamic/{item['id']}", json={"target": "https://malo.example"}).status_code == 404
    assert luis.delete(f"/api/dynamic/{item['id']}").status_code == 404
    assert luis.get(f"/api/dynamic/{item['id']}/stats").status_code == 404
    assert ana.get("/api/dynamic").json()["items"][0]["target"] == "https://www.ejemplo.com/uno"


def test_management_requires_login(visitor):
    assert visitor.get("/api/dynamic").status_code == 401
    assert visitor.post("/api/dynamic", json={"target": "https://a.com"}).status_code == 401
    assert visitor.patch("/api/dynamic/1", json={"active": False}).status_code == 401
    assert visitor.delete("/api/dynamic/1").status_code == 401
    assert visitor.get("/api/features").status_code == 401


def test_cross_origin_write_is_rejected(ana):
    res = ana.post("/api/dynamic", json={"target": "https://a.com"}, headers={"Origin": "https://malo.example"})
    assert res.status_code == 403


def test_deleting_the_user_cascades(ana, settings):
    item = new_qr(ana)
    with sqlite3.connect(settings.db_path) as conn:
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("DELETE FROM users")
        assert conn.execute("SELECT COUNT(*) FROM dynamic_qr").fetchone()[0] == 0
    assert item["id"]


# ----- Función opcional -------------------------------------------------------------------------------


def test_features_endpoint_reports_the_switch(tmp_path):
    on = member(create_app(make_settings(tmp_path / "a", public_url="https://qr.ejemplo.com")), ANA)
    assert on.get("/api/features").json() == {"dynamicQr": True, "publicUrl": "https://qr.ejemplo.com", "pages": True}

    off = member(create_app(make_settings(tmp_path / "b", dynamic_qr=False)), ANA)
    assert off.get("/api/features").json() == {"dynamicQr": False, "publicUrl": "", "pages": True}


def test_everything_is_off_when_disabled(tmp_path):
    app = create_app(make_settings(tmp_path, dynamic_qr=False))
    client = member(app, ANA)
    assert client.get("/api/dynamic").status_code == 404
    assert client.post("/api/dynamic", json={"target": "https://a.com"}).status_code == 404
    res = TestClient(app, follow_redirects=False).get("/q/abcdefg")
    assert res.status_code == 404 and "activados" in res.text
