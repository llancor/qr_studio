"""Mi cuenta: descargar los datos y eliminarla (por la persona o por el administrador). Ejecutar desde web/:  python -m pytest"""

import io
import json
import sqlite3
import struct
import zipfile
import zlib

import pytest
from fastapi.testclient import TestClient

from app import files
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}
MARTA = {"email": "marta@example.com", "name": "Marta", "password": "correct-horse-3"}

PAGE_PNG = b"\x89PNG\r\n\x1a\n" + struct.pack(">I", 13) + b"IHDR" + struct.pack(">II", 10, 10) + b"\x08\x02\x00\x00\x00" + b"\x00" * 16


def png_bytes(width: int = 8, height: int = 8) -> bytes:
    def chunk(kind: bytes, data: bytes) -> bytes:
        body = kind + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    raw = b"".join(b"\x00" + b"\x80" * width for _ in range(height))
    return (
        files.PNG_SIGNATURE
        + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw))
        + chunk(b"IEND", b"")
    )


@pytest.fixture()
def settings(tmp_path):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
        files_path=tmp_path / "qr",
        pages_path=tmp_path / "paginas",
    )


@pytest.fixture()
def app(settings):
    return create_app(settings)


def new_client(app):
    return TestClient(app, follow_redirects=False)


def sign_up(app, who):
    client = new_client(app)
    assert client.post("/api/auth/register", json=who).status_code == 201
    return client


@pytest.fixture()
def boss(app):
    return sign_up(app, ANA)  # la primera cuenta es la del administrador


@pytest.fixture()
def luis(app, boss):
    return sign_up(app, LUIS)


def fill_account(client, tag="x"):
    """Le pone de todo: carpeta con un QR, QR dinámico, página con un archivo y aspecto propio. Devuelve ids útiles."""
    assert client.post("/api/qr/folders", json={"name": f"Lote {tag}"}).status_code in {200, 201}
    up = client.post(
        f"/api/qr/folders/Lote {tag}/files", params={"name": f"qr-{tag}"}, content=png_bytes(), headers={"Content-Type": "image/png"}
    )
    assert up.status_code in {200, 201}, up.text
    dyn = client.post("/api/dynamic", json={"name": f"Dinámico {tag}", "target": "https://example.com/destino"})
    assert dyn.status_code == 201, dyn.text
    page = client.post("/api/paginas", json={"template": "evento", "name": f"Fiesta {tag}"})
    assert page.status_code == 201, page.text
    page = page.json()
    asset = client.post(f"/api/paginas/{page['id']}/archivos", params={"name": "foto.png"}, content=PAGE_PNG)
    assert asset.status_code in {200, 201}, asset.text
    assert client.put("/api/me/prefs", json={"tema": "oscuro"}).status_code == 200
    return {"code": dyn.json()["code"], "page_code": page["code"], "token": asset.json()["token"]}


def open_zip(res):
    assert res.status_code == 200, res.text
    return zipfile.ZipFile(io.BytesIO(res.content))


def rows_of(settings, user_id):
    counts = {}
    with sqlite3.connect(settings.db_path) as conn:
        for table in ("users", "sessions", "dynamic_qr", "pages", "page_assets", "user_prefs", "password_resets"):
            column = "id" if table == "users" else "user_id"
            counts[table] = conn.execute(f"SELECT COUNT(*) FROM {table} WHERE {column} = ?", (user_id,)).fetchone()[0]
    return counts


# ----- Descargar mis datos ---------------------------------------------------------------------------


def test_export_needs_a_session(app):
    assert new_client(app).get("/api/me/export").status_code == 401


def test_export_zip_has_everything_of_the_account(app, boss, luis):
    ids = fill_account(luis, "luis")
    res = luis.get("/api/me/export")
    assert res.headers["content-type"] == "application/zip"
    assert "mis-datos-" in res.headers["content-disposition"] and res.headers["cache-control"] == "no-store"
    archive = open_zip(res)
    names = set(archive.namelist())
    assert {"LEEME.txt", "datos.json"} <= names
    assert any(n.startswith("qr/Lote luis/") and n.endswith(".png") for n in names)
    assert f"paginas/{ids['token']}.png" in names
    data = json.loads(archive.read("datos.json"))
    assert data["account"]["email"] == LUIS["email"] and data["account"]["role"] == "user"
    assert data["dynamicQr"][0]["code"] == ids["code"] and data["dynamicQr"][0]["target"] == "https://example.com/destino"
    assert data["pages"][0]["name"] == "Fiesta luis" and data["pages"][0]["files"][0]["token"] == ids["token"]
    assert data["qrFolders"] == [{"name": "Lote luis", "files": ["qr-luis.png"]}]
    assert data["appearance"]["preferences"]["tema"] == "oscuro"
    assert data["exportedAt"] and "appVersion" in data


def test_export_never_includes_the_password_or_session_tokens(app, boss, luis):
    fill_account(luis, "luis")
    archive = open_zip(luis.get("/api/me/export"))
    everything = b"".join(archive.read(n) for n in archive.namelist() if n.endswith((".json", ".txt"))).decode()
    assert "password_hash" not in everything and "scrypt$" not in everything and LUIS["password"] not in everything
    assert "token_hash" not in everything


def test_export_has_only_my_own_data(app, boss, luis):
    fill_account(boss, "ana")
    fill_account(luis, "luis")
    archive = open_zip(luis.get("/api/me/export"))
    text = archive.read("datos.json").decode()
    assert "Fiesta ana" not in text and "Lote ana" not in text and ANA["email"] not in text
    assert not any("ana" in n.lower() for n in archive.namelist() if n.startswith("qr/"))


def test_export_of_an_empty_account_works(app, luis):
    data = json.loads(open_zip(luis.get("/api/me/export")).read("datos.json"))
    assert data["dynamicQr"] == [] and data["pages"] == [] and data["qrFolders"] == []


def test_export_is_rate_limited(app, luis):
    for _ in range(5):
        assert luis.get("/api/me/export").status_code == 200
    assert luis.get("/api/me/export").status_code == 429


# ----- Eliminar mi cuenta ----------------------------------------------------------------------------


def test_delete_needs_a_session_and_a_password(app, luis):
    assert new_client(app).post("/api/me/account/delete", json={"password": LUIS["password"]}).status_code == 401
    assert luis.post("/api/me/account/delete", json={}).status_code == 422
    assert luis.get("/api/auth/me").json()["user"]["email"] == LUIS["email"]


def test_wrong_password_deletes_nothing(app, settings, luis):
    fill_account(luis, "luis")
    res = luis.post("/api/me/account/delete", json={"password": "otra-clave-9"})
    assert res.status_code == 403 and "contraseña" in res.json()["detail"]
    assert luis.get("/api/auth/me").json()["user"] is not None
    assert rows_of(settings, 2)["users"] == 1 and rows_of(settings, 2)["pages"] == 1


def test_wrong_passwords_are_rate_limited(app, luis):
    for _ in range(5):
        assert luis.post("/api/me/account/delete", json={"password": "otra-clave-9"}).status_code == 403
    assert luis.post("/api/me/account/delete", json={"password": LUIS["password"]}).status_code == 429
    assert luis.get("/api/auth/me").json()["user"] is not None


def test_delete_removes_the_account_and_everything_in_it(app, settings, tmp_path, boss, luis):
    ids = fill_account(luis, "luis")
    fill_account(boss, "ana")
    assert (tmp_path / "qr" / "2").is_dir() and (tmp_path / "paginas" / "2").is_dir()
    assert new_client(app).get(f"/q/{ids['code']}").status_code == 302  # el QR dinámico funcionaba

    res = luis.post("/api/me/account/delete", json={"password": LUIS["password"]})
    assert res.status_code == 200 and res.json() == {"ok": True}
    cookie = res.headers.get("set-cookie", "").lower()
    assert "session=" in cookie and ("max-age=0" in cookie or "expires" in cookie)  # se quitó la cookie

    # Ni filas ni archivos: nada de la cuenta queda.
    assert all(count == 0 for count in rows_of(settings, 2).values())
    assert not (tmp_path / "qr" / "2").exists() and not (tmp_path / "paginas" / "2").exists()
    # Ya no entra, y lo que era público dejó de existir.
    assert new_client(app).post("/api/auth/login", json={"email": LUIS["email"], "password": LUIS["password"]}).status_code == 401
    assert new_client(app).get(f"/q/{ids['code']}").status_code == 404
    assert new_client(app).get(f"/p/{ids['page_code']}").status_code == 404
    # Y lo de las demás cuentas sigue intacto.
    assert rows_of(settings, 1)["pages"] == 1 and rows_of(settings, 1)["dynamic_qr"] == 1
    assert (tmp_path / "qr" / "1").is_dir() and (tmp_path / "paginas" / "1").is_dir()


def test_the_only_admin_cannot_delete_themselves(app, settings, boss):
    fill_account(boss, "ana")
    res = boss.post("/api/me/account/delete", json={"password": ANA["password"]})
    assert res.status_code == 409 and "administrador" in res.json()["detail"]
    assert boss.get("/api/auth/me").json()["user"]["role"] == "admin"
    assert rows_of(settings, 1)["pages"] == 1


def test_an_admin_can_delete_themselves_when_another_admin_exists(app, settings, boss, luis):
    assert boss.patch("/api/admin/users/2", json={"role": "admin"}).status_code == 200
    assert boss.post("/api/me/account/delete", json={"password": ANA["password"]}).status_code == 200
    assert rows_of(settings, 1)["users"] == 0
    assert luis.get("/api/admin/users").status_code == 200  # el otro administrador sigue mandando


def test_email_can_be_used_again_after_deleting(app, luis):
    assert luis.post("/api/me/account/delete", json={"password": LUIS["password"]}).status_code == 200
    assert new_client(app).post("/api/auth/register", json=LUIS).status_code == 201


# ----- El administrador elimina otra cuenta -----------------------------------------------------------


def test_admin_deletes_another_account_with_all_its_files(app, settings, tmp_path, boss, luis):
    ids = fill_account(luis, "luis")
    assert boss.delete("/api/admin/users/2").json() == {"ok": True}
    assert all(count == 0 for count in rows_of(settings, 2).values())
    assert not (tmp_path / "qr" / "2").exists() and not (tmp_path / "paginas" / "2").exists()
    assert new_client(app).get(f"/q/{ids['code']}").status_code == 404
    assert luis.get("/api/auth/me").json() == {"user": None}  # su sesión se cerró
    assert [u["email"] for u in boss.get("/api/admin/users").json()["users"]] == [ANA["email"]]


def test_admin_cannot_delete_themselves_from_the_user_list(app, boss):
    res = boss.delete("/api/admin/users/1")
    assert res.status_code == 409 and "Mi cuenta" in res.json()["detail"]
    assert boss.get("/api/auth/me").json()["user"] is not None


def test_admin_delete_of_an_unknown_user_is_404(app, boss):
    assert boss.delete("/api/admin/users/999").status_code == 404


def test_regular_users_cannot_delete_other_accounts(app, boss, luis):
    marta = sign_up(app, MARTA)
    assert marta.delete("/api/admin/users/2").status_code == 403
    assert new_client(app).delete("/api/admin/users/2").status_code == 401
    assert luis.get("/api/auth/me").json()["user"] is not None


def test_deleting_an_account_with_no_files_works(app, boss, luis):
    assert boss.delete("/api/admin/users/2").status_code == 200
