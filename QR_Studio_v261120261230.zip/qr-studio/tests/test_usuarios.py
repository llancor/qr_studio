"""Tests de la herramienta de usuarios por línea de comandos. Ejecutar desde web/:  python -m pytest"""

import os
import re
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app import usuarios
from app.config import Settings
from app.main import create_app

WEB = Path(__file__).resolve().parent.parent
ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}


def make_settings(tmp_path, **extra):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
        files_path=tmp_path / "qr",
        **extra,
    )


@pytest.fixture()
def settings(tmp_path):
    return make_settings(tmp_path)


def run(settings, *argv, secretos=(), respuestas=()):
    """Ejecuta la herramienta con entradas simuladas. Devuelve (código, texto mostrado)."""
    salida = []
    pendientes_secretos = list(secretos)
    pendientes_respuestas = list(respuestas)

    def entrada(_texto):
        if not pendientes_respuestas:
            raise EOFError
        return pendientes_respuestas.pop(0)

    def secreto(_texto):
        return pendientes_secretos.pop(0)

    codigo = usuarios.main(list(argv), settings=settings, salida=salida.append, entrada=entrada, secreto=secreto)
    return codigo, "\n".join(salida)


def web_client(settings):
    return TestClient(create_app(settings), follow_redirects=False)


def login(settings, who, password=None):
    res = web_client(settings).post(
        "/api/auth/login", json={"email": who["email"], "password": password or who["password"]}
    )
    return res.status_code


def seed(settings, *people):
    """Crea cuentas a través de la propia página (la primera queda como administradora)."""
    app = create_app(settings)
    for who in people:
        assert TestClient(app).post("/api/auth/register", json=who).status_code == 201


# ----- Crear -------------------------------------------------------------------

def test_create_first_admin_on_a_new_database(settings):
    assert not settings.db_path.exists()
    code, out = run(settings, "crear", "Ana@Example.com", "--nombre", "Ana", "--rol", "admin", "--clave", "correct-horse-1")
    assert code == 0 and "administrador" in out
    assert login(settings, ANA) == 200
    assert web_client(settings).get("/api/auth/options").json()["firstUser"] is False


def test_create_with_generated_password_shows_it_once(settings):
    code, out = run(settings, "crear", "luis@example.com", "--generar")
    assert code == 0
    password = re.search(r"Contraseña: (\S+)", out).group(1)
    assert len(password) == 14
    assert login(settings, {"email": "luis@example.com"}, password) == 200


def test_create_asks_for_the_password_twice_and_rejects_mismatch(settings):
    code, _ = run(settings, "crear", "luis@example.com", secretos=["una-clave-larga", "otra-distinta-1"])
    assert code == 1
    assert not settings.db_path.exists() or login(settings, LUIS, "una-clave-larga") == 401
    code, _ = run(settings, "crear", "luis@example.com", secretos=["una-clave-larga", "una-clave-larga"])
    assert code == 0
    assert login(settings, {"email": "luis@example.com"}, "una-clave-larga") == 200


def test_create_validations(settings, capsys):
    assert run(settings, "crear", "no-es-correo", "--clave", "correct-horse-1")[0] == 1
    assert run(settings, "crear", "luis@example.com", "--clave", "corta")[0] == 1
    assert run(settings, "crear", "luis@example.com", "--clave", "correct-horse-1", "--nombre", " ")[0] == 1
    assert run(settings, "crear", "luis@example.com", "--clave", "correct-horse-1")[0] == 0
    assert run(settings, "crear", "LUIS@example.com", "--clave", "correct-horse-1")[0] == 1  # ya existe
    errors = capsys.readouterr().err
    assert "correo" in errors and "8 y 128" in errors and "Ya existe" in errors


# ----- Restablecer (la recuperación del administrador) ---------------------------

def test_rescue_admin_who_forgot_the_password(settings):
    seed(settings, ANA)  # Ana es la única administradora y olvidó su contraseña
    code, out = run(settings, "restablecer", "ana@example.com", secretos=["clave-de-rescate-9", "clave-de-rescate-9"])
    assert code == 0 and "restablecida" in out
    assert login(settings, ANA) == 401
    assert login(settings, ANA, "clave-de-rescate-9") == 200
    admin_client = web_client(settings)
    admin_client.post("/api/auth/login", json={"email": ANA["email"], "password": "clave-de-rescate-9"})
    assert admin_client.get("/api/admin/users").status_code == 200  # sigue siendo administradora


def test_reset_closes_open_sessions(settings):
    seed(settings, ANA)
    client = web_client(settings)
    client.post("/api/auth/login", json={"email": ANA["email"], "password": ANA["password"]})
    assert client.get("/api/auth/me").json()["user"] is not None
    assert run(settings, "restablecer", "ana@example.com", "--clave", "otra-clave-larga")[0] == 0
    assert client.get("/api/auth/me").json() == {"user": None}


def test_reset_with_generated_password(settings):
    seed(settings, ANA)
    code, out = run(settings, "restablecer", "ana@example.com", "--generar")
    password = re.search(r"Contraseña nueva: (\S+)", out).group(1)
    assert code == 0 and login(settings, ANA, password) == 200


def test_reset_mismatch_or_short_changes_nothing(settings):
    seed(settings, ANA)
    assert run(settings, "restablecer", "ana@example.com", secretos=["una-clave-larga", "no-coincide-1"])[0] == 1
    assert run(settings, "restablecer", "ana@example.com", "--clave", "corta")[0] == 1
    assert login(settings, ANA) == 200


def test_reset_unknown_account_and_missing_database(settings, capsys):
    assert run(settings, "restablecer", "nadie@example.com", "--generar")[0] == 1  # base sin crear
    assert "No se encontró la base de datos" in capsys.readouterr().err
    seed(settings, ANA)
    assert run(settings, "restablecer", "nadie@example.com", "--generar")[0] == 1
    assert "No existe ninguna cuenta" in capsys.readouterr().err


def test_reset_warns_when_the_account_is_deactivated(settings):
    seed(settings, ANA, LUIS)
    run(settings, "desactivar", "luis@example.com")
    code, out = run(settings, "restablecer", "luis@example.com", "--clave", "otra-clave-larga")
    assert code == 0 and "DESACTIVADA" in out


# ----- Activar, desactivar y rol ------------------------------------------------------

def test_deactivate_and_activate(settings):
    seed(settings, ANA, LUIS)
    assert run(settings, "desactivar", "luis@example.com")[0] == 0
    assert login(settings, LUIS) == 403
    assert run(settings, "activar", "luis@example.com")[0] == 0
    assert login(settings, LUIS) == 200


def test_the_last_active_admin_is_protected(settings, capsys):
    seed(settings, ANA, LUIS)
    assert run(settings, "desactivar", "ana@example.com")[0] == 1
    assert run(settings, "rol", "ana@example.com", "user")[0] == 1
    assert "al menos un administrador" in capsys.readouterr().err
    assert run(settings, "rol", "luis@example.com", "admin")[0] == 0  # con otro, ya se puede
    assert run(settings, "rol", "ana@example.com", "user")[0] == 0
    assert login(settings, ANA) == 200


# ----- Crear cuentas desde la página ---------------------------------------------------

def test_registration_switch(settings):
    seed(settings, ANA)
    assert "permitido" in run(settings, "registro", "estado")[1]
    assert "desactivado" in run(settings, "registro", "cerrar")[1]
    assert web_client(settings).get("/api/auth/options").json()["registrationOpen"] is False
    assert "permitido" in run(settings, "registro", "abrir")[1]
    assert web_client(settings).get("/api/auth/options").json()["registrationOpen"] is True


# ----- Listar y bases antiguas ------------------------------------------------------------

def test_list_shows_roles_and_states(settings):
    seed(settings, ANA, LUIS)
    run(settings, "desactivar", "luis@example.com")
    code, out = run(settings, "listar")
    assert code == 0
    assert re.search(r"ana@example.com\s+Ana\s+administrador\s+activa", out)
    assert re.search(r"luis@example.com\s+Luis\s+usuario\s+DESACTIVADA", out)
    assert "Crear cuentas desde la página: permitido" in out


def test_works_on_a_database_from_an_older_version(settings):
    with sqlite3.connect(settings.db_path) as conn:
        conn.executescript(
            """
            CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
            INSERT INTO users (email, name, password_hash, created_at) VALUES ('uno@example.com', 'Uno', 'x', '2026-01-01');
            """
        )
    code, out = run(settings, "listar")
    assert code == 0 and re.search(r"uno@example.com\s+Uno\s+administrador", out)  # el más antiguo pasa a ser admin
    assert run(settings, "restablecer", "uno@example.com", "--clave", "clave-nueva-123")[0] == 0
    assert login(settings, {"email": "uno@example.com"}, "clave-nueva-123") == 200


# ----- Menú interactivo ---------------------------------------------------------------------

def test_interactive_menu_creates_and_resets(settings):
    seed(settings, ANA)
    respuestas = [
        "2", "luis@example.com", "Luis", "n", "s",            # crear: no admin, contraseña inventada
        "3", "ana@example.com", "s",                          # restablecer: inventada
        "4", "luis@example.com", "d",                         # desactivar
        "9",                                                  # opción inexistente: se ignora
        "0",
    ]
    code, out = run(settings, respuestas=respuestas)
    assert code == 0
    assert "Cuenta creada: luis@example.com" in out and "restablecida" in out and "desactivada" in out
    with sqlite3.connect(settings.db_path) as conn:
        assert conn.execute("SELECT active FROM users WHERE email = 'luis@example.com'").fetchone() == (0,)
    assert login(settings, ANA) == 401  # su contraseña vieja ya no sirve


def test_interactive_menu_reports_errors_and_keeps_going(settings):
    seed(settings, ANA)
    code, out = run(settings, respuestas=["3", "nadie@example.com", "s", "0"])
    assert code == 0 and "ERROR: No existe ninguna cuenta" in out


# ----- Como se ejecuta de verdad ----------------------------------------------------------------

def test_module_entry_point_uses_app_db_path(tmp_path):
    base = tmp_path / "datos" / "app.db"
    # PYTHONIOENCODING=utf-8: igual que hace Usuarios_QR.bat, para no depender de la página de códigos de la consola.
    env = {**os.environ, "APP_DB_PATH": str(base), "PYTHONIOENCODING": "utf-8"}

    def ejecutar(*args):
        return subprocess.run(
            [sys.executable, "-m", "app.usuarios", *args],
            cwd=WEB, env=env, capture_output=True, text=True, encoding="utf-8",
        )

    creado = ejecutar("crear", "ana@example.com", "--rol", "admin", "--clave", "correct-horse-1")
    assert creado.returncode == 0, creado.stderr
    listado = ejecutar("listar")
    assert listado.returncode == 0 and "ana@example.com" in listado.stdout
    assert ejecutar("restablecer", "nadie@example.com", "--generar").returncode == 1
