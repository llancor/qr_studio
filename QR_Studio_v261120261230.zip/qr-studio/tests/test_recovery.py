"""Servidor SMTP (Ajustes → Correo) y recuperar la contraseña por correo. Ejecutar desde web/:  python -m pytest

El envío real se sustituye por una lista en memoria: ningún test manda correos ni abre conexiones."""

import re
import smtplib

import pytest
from fastapi.testclient import TestClient

from app import db, mail
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}

SMTP = {
    "host": "smtp.example.com",
    "port": 587,
    "security": "starttls",
    "user": "avisos@example.com",
    "password": "app-password",
    "sender": "Avisos@Example.com",
    "senderName": "QR Studio",
    "siteUrl": "https://qr.example.com/",
}


def make_app(tmp_path, **extra):
    return create_app(
        Settings(
            db_path=tmp_path / "test.db",
            session_days=14,
            cookie_secure=False,
            min_password_length=8,
            login_max_attempts=5,
            login_window_seconds=300,
            files_path=tmp_path / "qr",
            **extra,
        )
    )


@pytest.fixture()
def app(tmp_path):
    return make_app(tmp_path)


def new_client(app):
    return TestClient(app, follow_redirects=False)


@pytest.fixture()
def boss(app):
    client = new_client(app)
    assert client.post("/api/auth/register", json=ANA).status_code == 201
    return client


@pytest.fixture()
def outbox(monkeypatch):
    sent = []
    monkeypatch.setattr(mail, "send", lambda cfg, to, subject, body: sent.append({"cfg": cfg, "to": to, "subject": subject, "body": body}))
    return sent


def configure(boss, **changes):
    res = boss.put("/api/admin/smtp", json={**SMTP, **changes})
    assert res.status_code == 200, res.text
    return res.json()


def add_luis(boss):
    res = boss.post("/api/admin/users", json={**LUIS, "role": "user"})
    assert res.status_code == 201
    return res.json()["user"]


def token_from(body):
    return re.search(r"token=([A-Za-z0-9_\-]+)", body).group(1)


# ----- Ajustes del servidor SMTP ------------------------------------------------------------------

def test_defaults_are_gmail_until_something_is_saved(boss):
    info = boss.get("/api/admin/smtp").json()
    assert (info["host"], info["port"], info["security"]) == ("smtp.gmail.com", 587, "starttls")
    assert info["configured"] is False and info["recoveryEnabled"] is False and info["passwordSet"] is False


def test_saving_normalizes_and_never_returns_the_password(boss):
    info = configure(boss)
    assert info["configured"] and info["passwordSet"]
    assert info["sender"] == "avisos@example.com" and info["siteUrl"] == "https://qr.example.com"
    assert "app-password" not in str(info) and "app-password" not in str(boss.get("/api/admin/smtp").json())


def test_an_empty_password_keeps_the_saved_one_and_clear_removes_it(boss):
    configure(boss)
    assert configure(boss, password=None)["passwordSet"] is True
    assert configure(boss, password="")["passwordSet"] is True
    assert configure(boss, password=None, clearPassword=True)["passwordSet"] is False


def test_gmail_app_passwords_are_saved_without_spaces(app, boss):
    configure(boss, host="smtp.gmail.com", password="abcd efgh ijkl mnop")
    with db.connect(app.state.settings.db_path) as conn:
        assert mail.load(conn).password == "abcdefghijklmnop"


@pytest.mark.parametrize(
    "changes",
    [
        {"host": "mal host"},
        {"host": ""},
        {"port": 0},
        {"port": 70000},
        {"security": "x"},
        {"sender": "no-es-correo"},
        {"siteUrl": "ftp://x"},
        {"siteUrl": "https://x.com/?a=1"},
        {"senderName": "a\r\nBcc: otro@example.com"},
        {"user": "a\nb"},
    ],
)
def test_invalid_smtp_values_are_rejected(boss, changes):
    assert boss.put("/api/admin/smtp", json={**SMTP, **changes}).status_code == 422


def test_test_email_needs_saved_settings_and_uses_them(boss, outbox):
    assert boss.post("/api/admin/smtp/test", json={"to": ANA["email"]}).status_code == 409
    configure(boss)
    res = boss.post("/api/admin/smtp/test", json={"to": ANA["email"]})
    assert res.status_code == 200 and res.json()["to"] == ANA["email"]
    assert len(outbox) == 1 and outbox[0]["to"] == ANA["email"] and outbox[0]["cfg"].host == "smtp.example.com"


def test_test_email_shows_the_servers_problem(boss, monkeypatch):
    configure(boss)

    def boom(cfg, to, subject, body):
        raise mail.MailError("No se pudo conectar a smtp.example.com:587.")

    monkeypatch.setattr(mail, "send", boom)
    res = boss.post("/api/admin/smtp/test", json={"to": ANA["email"]})
    assert res.status_code == 502 and "No se pudo conectar" in res.json()["detail"]


def test_send_maps_errors_to_clear_messages(monkeypatch):
    class Refuses:
        def __init__(self, *a, **k):
            raise smtplib.SMTPServerDisconnected("x")

    monkeypatch.setattr(smtplib, "SMTP", Refuses)
    cfg = mail.SmtpConfig("smtp.example.com", 587, "starttls", "u", "p", "u@example.com", "")
    with pytest.raises(mail.MailError, match="cerró la conexión"):
        mail.send(cfg, "a@example.com", "s", "b")


def test_gmail_auth_failure_explains_app_passwords(monkeypatch):
    class Server:
        def __init__(self, *a, **k):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def ehlo(self):
            pass

        def starttls(self, **k):
            pass

        def login(self, *a):
            raise smtplib.SMTPAuthenticationError(535, b"bad")

    monkeypatch.setattr(smtplib, "SMTP", Server)
    cfg = mail.SmtpConfig("smtp.gmail.com", 587, "starttls", "u@gmail.com", "x", "u@gmail.com", "")
    with pytest.raises(mail.MailError, match="contraseña de aplicación"):
        mail.send(cfg, "a@example.com", "s", "b")


# ----- Recuperar la contraseña -----------------------------------------------------------------------

def test_recovery_is_offered_only_when_smtp_and_site_url_are_set(app, boss):
    guest = new_client(app)
    assert guest.get("/api/auth/options").json()["recoveryEnabled"] is False
    configure(boss, siteUrl="")
    assert guest.get("/api/auth/options").json()["recoveryEnabled"] is False  # falta la dirección del sitio
    configure(boss)
    assert guest.get("/api/auth/options").json()["recoveryEnabled"] is True


def test_the_site_url_can_come_from_the_environment(tmp_path):
    app = make_app(tmp_path, public_url="https://desde-env.example.com")
    boss = new_client(app)
    boss.post("/api/auth/register", json=ANA)
    configure(boss, siteUrl="")
    assert new_client(app).get("/api/auth/options").json()["recoveryEnabled"] is True


def test_forgot_without_smtp_says_so(app, boss):
    res = new_client(app).post("/api/auth/forgot", json={"email": ANA["email"]})
    assert res.status_code == 503 and "administrador" in res.json()["detail"]


def test_full_recovery_flow(app, boss, outbox):
    add_luis(boss)
    configure(boss)
    guest = new_client(app)
    luis, _ = new_client(app), None
    assert luis.post("/api/auth/login", json={"email": LUIS["email"], "password": LUIS["password"]}).status_code == 200

    assert guest.post("/api/auth/forgot", json={"email": "Luis@Example.com"}).json() == {"ok": True}
    assert len(outbox) == 1 and outbox[0]["to"] == LUIS["email"]
    body = outbox[0]["body"]
    assert "https://qr.example.com/restablecer/?token=" in body and "Hola Luis" in body and "60 minutos" in body
    token = token_from(body)

    # una contraseña corta no gasta el enlace
    assert guest.post("/api/auth/reset", json={"token": token, "password": "corta"}).status_code == 422
    assert guest.post("/api/auth/reset", json={"token": token, "password": "nueva-clave-99"}).status_code == 200

    assert luis.get("/api/auth/me").json()["user"] is None  # sus sesiones abiertas se cerraron
    assert new_client(app).post("/api/auth/login", json={"email": LUIS["email"], "password": LUIS["password"]}).status_code == 401
    assert new_client(app).post("/api/auth/login", json={"email": LUIS["email"], "password": "nueva-clave-99"}).status_code == 200
    # el enlace sirve una sola vez
    assert guest.post("/api/auth/reset", json={"token": token, "password": "otra-clave-100"}).status_code == 400


def test_forgot_answers_the_same_for_unknown_accounts_and_sends_nothing(app, boss, outbox):
    configure(boss)
    res = new_client(app).post("/api/auth/forgot", json={"email": "nadie@example.com"})
    assert res.status_code == 200 and res.json() == {"ok": True} and outbox == []


def test_deactivated_accounts_get_no_email(app, boss, outbox):
    user = add_luis(boss)
    configure(boss)
    boss.patch(f"/api/admin/users/{user['id']}", json={"active": False})
    assert new_client(app).post("/api/auth/forgot", json={"email": LUIS["email"]}).status_code == 200
    assert outbox == []


def test_a_fake_token_does_nothing(app, boss):
    add_luis(boss)
    res = new_client(app).post("/api/auth/reset", json={"token": "inventado", "password": "nueva-clave-99"})
    assert res.status_code == 400


def test_a_new_request_cancels_the_previous_link(app, boss, outbox):
    add_luis(boss)
    configure(boss)
    guest = new_client(app)
    guest.post("/api/auth/forgot", json={"email": LUIS["email"]})
    guest.post("/api/auth/forgot", json={"email": LUIS["email"]})
    first, second = (token_from(m["body"]) for m in outbox)
    assert guest.post("/api/auth/reset", json={"token": first, "password": "nueva-clave-99"}).status_code == 400
    assert guest.post("/api/auth/reset", json={"token": second, "password": "nueva-clave-99"}).status_code == 200


def test_changing_the_email_cancels_pending_links(app, boss, outbox):
    user = add_luis(boss)
    configure(boss)
    guest = new_client(app)
    guest.post("/api/auth/forgot", json={"email": LUIS["email"]})
    token = token_from(outbox[0]["body"])
    boss.patch(f"/api/admin/users/{user['id']}", json={"email": "luis.nuevo@example.com"})
    assert guest.post("/api/auth/reset", json={"token": token, "password": "nueva-clave-99"}).status_code == 400


def test_expired_links_do_not_work(app, boss, outbox):
    add_luis(boss)
    configure(boss)
    guest = new_client(app)
    guest.post("/api/auth/forgot", json={"email": LUIS["email"]})
    token = token_from(outbox[0]["body"])
    with db.connect(app.state.settings.db_path) as conn:
        conn.execute("UPDATE password_resets SET expires_at = '2000-01-01T00:00:00+00:00'")
    assert guest.post("/api/auth/reset", json={"token": token, "password": "nueva-clave-99"}).status_code == 400


def test_a_single_account_cannot_be_flooded_with_emails(app, boss, outbox):
    add_luis(boss)
    configure(boss)
    guest = new_client(app)
    for _ in range(5):
        guest.post("/api/auth/forgot", json={"email": LUIS["email"]})
    assert len(outbox) == 3  # máximo 3 correos por cuenta en la ventana


def test_requests_per_ip_are_limited(app, boss, outbox):
    configure(boss)
    guest = new_client(app)
    codes = [guest.post("/api/auth/forgot", json={"email": f"x{i}@example.com"}).status_code for i in range(6)]
    assert codes == [200, 200, 200, 200, 200, 429]


def test_the_reset_page_and_its_script_are_public(app):
    guest = new_client(app)
    assert guest.get("/restablecer/").status_code == 200
    assert guest.get("/js/restablecer.js").status_code == 200
