// Ajustes → Migración: exportar la configuración a un archivo CIFRADO e importarlo de vuelta (aquí o en otro
// servidor). Al exportar se elige una contraseña (el archivo sale cifrado con ella); al importar hay que escribir la
// misma. Solo el administrador (el servidor lo comprueba en cada petición de /api/admin). Importar primero enseña
// qué se va a importar (vista previa, sin cambiar nada) y solo aplica cuando se confirma. La contraseña no se guarda.

import { leerArchivo, enviar, pintarLista, MIN_PASSWORD } from './migracion.js';

const $ = (id) => document.getElementById(id);

function mensaje(id, text) {
  const box = $(id);
  box.textContent = text || '';
  box.hidden = !text;
}

// ----- Exportar ------------------------------------------------------------------------------------------

$('mg-export').addEventListener('click', async () => {
  mensaje('mg-exp-error', '');
  const password = $('mg-pass').value;
  if (password.length < MIN_PASSWORD) {
    mensaje('mg-exp-error', `La contraseña debe tener al menos ${MIN_PASSWORD} caracteres.`);
    $('mg-pass').focus();
    return;
  }
  if (password !== $('mg-pass2').value) {
    mensaje('mg-exp-error', 'Las dos contraseñas no coinciden.');
    $('mg-pass2').focus();
    return;
  }
  $('mg-export').disabled = true;
  try {
    // La contraseña viaja en el cuerpo de la petición, nunca en la dirección.
    const res = await fetch('/api/admin/migration/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ password, users: $('mg-users').checked, smtpPassword: $('mg-smtp').checked }),
    });
    if (!res.ok) {
      let detail = '';
      try {
        detail = (await res.json()).detail;
      } catch {
        /* sin JSON */
      }
      throw new Error(typeof detail === 'string' && detail ? detail : 'No se pudo crear la migración.');
    }
    const blob = await res.blob();
    const name = /filename="([^"]+)"/.exec(res.headers.get('Content-Disposition') || '')?.[1] || 'qr-studio-migracion.json';
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = name;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    $('mg-pass').value = '';
    $('mg-pass2').value = '';
    mensaje('mg-exp-ok', `Descargado: ${name}. Está cifrado: para importarlo hace falta la contraseña que acabas de elegir.`);
    setTimeout(() => mensaje('mg-exp-ok', ''), 10000);
  } catch (err) {
    mensaje('mg-exp-error', err.message);
  } finally {
    $('mg-export').disabled = false;
  }
});

// ----- Importar -------------------------------------------------------------------------------------------

let archivo = null; // el archivo elegido (ya leído), a la espera de la contraseña y de confirmar
let contrasena = ''; // la contraseña que abrió la vista previa; se usa para aplicar y no se guarda en ningún sitio

function reiniciar() {
  archivo = null;
  contrasena = '';
  $('mg-file').value = '';
  $('mg-import-pass').value = '';
  $('mg-pass-row').hidden = true;
  $('mg-preview').hidden = true;
}

$('mg-file').addEventListener('change', async (event) => {
  const file = event.target.files?.[0];
  mensaje('mg-error', '');
  mensaje('mg-ok', '');
  $('mg-preview').hidden = true;
  $('mg-pass-row').hidden = true;
  if (!file) return;
  try {
    archivo = await leerArchivo(file);
    $('mg-pass-row').hidden = false;
    $('mg-import-pass').focus();
  } catch (err) {
    reiniciar();
    mensaje('mg-error', err.message);
  }
});

async function verQueTrae() {
  mensaje('mg-error', '');
  $('mg-preview').hidden = true;
  const password = $('mg-import-pass').value;
  if (!password) {
    mensaje('mg-error', 'Escribe la contraseña de la migración.');
    $('mg-import-pass').focus();
    return;
  }
  $('mg-check').disabled = true;
  try {
    const resumen = await enviar('/api/admin/migration/import', archivo, password, true); // vista previa
    contrasena = password;
    $('mg-apply').disabled = !pintarLista($('mg-list'), resumen);
    $('mg-preview').hidden = false;
  } catch (err) {
    mensaje('mg-error', err.message); // p. ej. contraseña incorrecta: se queda el campo para probar otra vez
    $('mg-import-pass').select();
  } finally {
    $('mg-check').disabled = false;
  }
}

$('mg-check').addEventListener('click', verQueTrae);
$('mg-import-pass').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    verQueTrae();
  }
});

$('mg-cancel').addEventListener('click', reiniciar);

$('mg-apply').addEventListener('click', async () => {
  mensaje('mg-error', '');
  $('mg-apply').disabled = true;
  try {
    await enviar('/api/admin/migration/import', archivo, contrasena, false);
    reiniciar();
    mensaje('mg-ok', 'Listo: la migración se importó. Se recarga la página para mostrar todo actualizado…');
    setTimeout(() => window.location.reload(), 1800);
  } catch (err) {
    mensaje('mg-error', err.message);
    $('mg-apply').disabled = false;
  }
});
