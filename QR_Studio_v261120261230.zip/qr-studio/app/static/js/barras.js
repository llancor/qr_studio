// Generador de códigos de barras con JsBarcode (vendor/JsBarcode.all.min.js). Todo en el navegador.

const $ = (id) => document.getElementById(id);

const FORMATS = {
  CODE128: { hint: 'Cualquier texto o número (letras, cifras y signos).', example: 'QR-STUDIO-001' },
  EAN13: { hint: '12 dígitos (la cifra de control se calcula sola) o los 13 completos.', example: '590123412345' },
  EAN8: { hint: '7 dígitos (la cifra de control se calcula sola) o los 8 completos.', example: '9638507' },
  UPC: { hint: '11 dígitos (la cifra de control se calcula sola) o los 12 completos.', example: '12345678901' },
  CODE39: { hint: 'Letras MAYÚSCULAS, cifras, espacio y - . $ / + %', example: 'CODE-39' },
  ITF14: { hint: '13 dígitos (la cifra de control se calcula sola) o los 14 completos.', example: '1234567890123' },
};

const canvas = $('bc-canvas');
let valid = false;

function options(extra = {}) {
  return {
    format: $('bc-format').value,
    width: Number($('bc-width').value),
    height: Math.min(300, Math.max(30, Number($('bc-height').value) || 100)),
    margin: Math.min(80, Math.max(0, Number($('bc-margin').value) || 0)),
    displayValue: $('bc-text').checked,
    lineColor: $('bc-fg').value,
    background: $('bc-bg').value,
    fontSize: 20,
    font: 'sans-serif',
    ...extra,
  };
}

function setError(message) {
  $('bc-error').textContent = message || '';
  $('bc-error').hidden = !message;
}

function setStatus(message) {
  $('bc-status').textContent = message || '';
  $('bc-status').hidden = !message;
}

/** Dibuja el código en el canvas. Devuelve true si el valor es válido para el formato. */
function draw() {
  const value = $('bc-value').value;
  let ok = true;
  try {
    window.JsBarcode(canvas, value, options({ valid: (isValid) => { ok = isValid; } }));
  } catch {
    ok = false;
  }
  if (!ok || !value) {
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    canvas.width = 1;
    canvas.height = 1;
    setError(value ? `El valor no es válido para este formato. ${FORMATS[$('bc-format').value].hint}` : 'Escribe el valor del código.');
    valid = false;
  } else {
    setError('');
    valid = true;
  }
  $('bc-png').disabled = !valid;
  $('bc-svg').disabled = !valid;
  return valid;
}

function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

const fileName = (ext) => `codigo-${$('bc-format').value.toLowerCase()}-${$('bc-value').value.replace(/[^\w-]+/g, '_').slice(0, 40)}.${ext}`;

$('bc-png').addEventListener('click', () => {
  if (!draw()) return;
  canvas.toBlob((blob) => {
    if (blob) saveBlob(blob, fileName('png'));
    setStatus('PNG descargado.');
  }, 'image/png');
});

$('bc-svg').addEventListener('click', () => {
  if (!draw()) return;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  try {
    window.JsBarcode(svg, $('bc-value').value, options());
  } catch {
    setError('No se pudo crear el SVG.');
    return;
  }
  svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  saveBlob(new Blob([new XMLSerializer().serializeToString(svg)], { type: 'image/svg+xml' }), fileName('svg'));
  setStatus('SVG descargado.');
});

function onFormat() {
  const info = FORMATS[$('bc-format').value];
  $('bc-hint').textContent = info.hint;
  $('bc-value').value = info.example;
  draw();
}

$('bc-format').addEventListener('change', onFormat);
for (const id of ['bc-value', 'bc-width', 'bc-height', 'bc-margin', 'bc-text', 'bc-fg', 'bc-bg']) {
  $(id).addEventListener('input', () => {
    setStatus('');
    draw();
  });
}

$('year').textContent = new Date().getFullYear();
$('bc-hint').textContent = FORMATS.CODE128.hint;
draw();
