// Menú de la barra superior en pantallas chicas. En el teléfono los enlaces de la cabecera (Generador, Páginas,
// PNG a ICO, Lector QR, Códigos de barras, Ajustes) no caben en la fila, así que se agrupan detrás de un botón
// «Menú» que abre un panel debajo de la cabecera. En pantallas anchas el botón no se ve y todo sigue como antes.
// El botón se crea aquí para no repetirlo en cada página.
//
// Está escrito a propósito en JavaScript básico (script clásico con `defer`, sin módulos ni sintaxis nueva) para que
// funcione también en teléfonos con un navegador antiguo: un error de sintaxis en un módulo lo deja sin ejecutar.
(function () {
  'use strict';

  var nav = document.querySelector('.site-header .main-nav');
  var inner = document.querySelector('.site-header .header-inner');
  if (!nav || !inner || document.querySelector('.menu-btn')) return;

  if (!nav.id) nav.id = 'menu-principal';

  var button = document.createElement('button');
  button.type = 'button';
  button.className = 'menu-btn';
  button.setAttribute('aria-controls', nav.id);

  var ns = 'http://www.w3.org/2000/svg';
  var icon = document.createElementNS(ns, 'svg');
  icon.setAttribute('viewBox', '0 0 24 24');
  icon.setAttribute('aria-hidden', 'true');
  [6, 12, 18].forEach(function (y) {
    var line = document.createElementNS(ns, 'path');
    line.setAttribute('d', 'M4 ' + y + 'h16');
    icon.appendChild(line);
  });
  var label = document.createElement('span');
  label.textContent = 'Menú';
  button.appendChild(icon);
  button.appendChild(label);
  inner.appendChild(button);

  /** Busca hacia arriba (incluido el propio elemento) uno que cumpla `test`; sirve aunque falte Element.closest. */
  function up(node, test) {
    while (node && node.nodeType === 1) {
      if (test(node)) return node;
      node = node.parentNode;
    }
    return null;
  }

  function isOpen() {
    return nav.classList.contains('is-open');
  }

  function setOpen(open) {
    if (open) nav.classList.add('is-open');
    else nav.classList.remove('is-open');
    button.setAttribute('aria-expanded', open ? 'true' : 'false');
    button.setAttribute('aria-label', open ? 'Cerrar el menú' : 'Abrir el menú');
  }
  setOpen(false);

  button.addEventListener('click', function () {
    setOpen(!isOpen());
  });

  // Al elegir un enlace el panel se cierra (en la página principal «Generador» solo baja a la sección).
  nav.addEventListener('click', function (event) {
    if (up(event.target, function (n) { return n.tagName === 'A'; })) setOpen(false);
  });

  document.addEventListener('keydown', function (event) {
    if ((event.key === 'Escape' || event.key === 'Esc') && isOpen()) {
      setOpen(false);
      button.focus();
    }
  });

  // Tocar fuera de la cabecera también lo cierra.
  document.addEventListener('click', function (event) {
    if (isOpen() && !up(event.target, function (n) { return n.className && /(^|\s)site-header(\s|$)/.test(n.className); })) {
      setOpen(false);
    }
  });

  // Si la pantalla se ensancha (por ejemplo al girar el teléfono), el menú vuelve a la barra de siempre.
  if (window.matchMedia) {
    var wide = window.matchMedia('(min-width: 801px)');
    var onChange = function (event) {
      if (event.matches) setOpen(false);
    };
    if (wide.addEventListener) wide.addEventListener('change', onChange);
    else if (wide.addListener) wide.addListener(onChange);
  }
})();
