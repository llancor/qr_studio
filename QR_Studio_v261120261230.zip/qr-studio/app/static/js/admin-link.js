// Muestra los enlaces marcados con data-signed-in (p. ej. «Ajustes») a quien tiene la sesión iniciada.
// Antes solo lo veía el administrador (el atributo se llamaba data-admin-only y este archivo conserva el nombre);
// ahora Ajustes incluye la Personalización, que es de cada cuenta. Lo que es solo del administrador (usuarios,
// crear cuentas, correo) lo decide el servidor en cada petición de /api/admin y la propia página de Ajustes.

fetch('/api/auth/me', { credentials: 'same-origin' })
  .then((res) => (res.ok ? res.json() : null))
  .then((data) => {
    if (!data?.user) return;
    document.querySelectorAll('[data-signed-in]').forEach((el) => {
      el.hidden = false;
    });
  })
  .catch(() => {
    /* sin conexión: los enlaces siguen ocultos */
  });
