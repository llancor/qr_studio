// Lector de QR: decodifica una imagen o la cámara con jsQR (vendor/jsQR.js). Todo en el navegador.
// Todo texto leído de un QR se muestra con textContent: nunca se interpreta como HTML.

const $ = (id) => document.getElementById(id);
const MAX_SIDE = 1600;
const ACCEPTED = new Set(['image/png', 'image/jpeg', 'image/webp']);

let stream = null;
let scanning = false;

function setError(message) {
  $('rd-error').textContent = message || '';
  $('rd-error').hidden = !message;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

/** Tipo de contenido (para mostrarlo en español) y datos útiles del texto leído. */
export function describe(text) {
  const t = text.trim();
  if (/^https?:\/\//i.test(t)) return { kind: 'Enlace web', link: t };
  if (/^WIFI:/i.test(t)) {
    const field = (key) => {
      const m = new RegExp(`(?:^|;)${key}:((?:\\\\.|[^;])*)`, 'i').exec(t.replace(/^WIFI:/i, ''));
      return m ? m[1].replace(/\\(.)/g, '$1') : '';
    };
    return { kind: 'Red WiFi', rows: [['Red', field('S')], ['Seguridad', field('T') || 'sin contraseña'], ['Contraseña', field('P')]] };
  }
  if (/^mailto:/i.test(t)) return { kind: 'Correo electrónico', rows: [['Para', t.slice(7).split('?')[0]]] };
  if (/^tel:/i.test(t)) return { kind: 'Teléfono', rows: [['Número', t.slice(4)]] };
  if (/^smsto?:/i.test(t)) return { kind: 'SMS', rows: [['Contenido', t.replace(/^smsto?:/i, '')]] };
  if (/^geo:/i.test(t)) return { kind: 'Ubicación', rows: [['Coordenadas', t.slice(4)]] };
  if (/^BEGIN:VCARD/i.test(t)) return { kind: 'Contacto (vCard)', rows: [] };
  if (/^BEGIN:VCALENDAR/i.test(t)) return { kind: 'Evento de calendario', rows: [] };
  return { kind: 'Texto', rows: [] };
}

function showResult(text) {
  const info = describe(text);
  const box = $('rd-result');
  box.replaceChildren();
  box.append(el('p', 'reader-kind', info.kind));
  for (const [label, value] of info.rows ?? []) if (value) box.append(el('p', 'reader-row', `${label}: ${value}`));
  const raw = el('pre', 'reader-raw', text);
  box.append(raw);
  const actions = el('div', 'bulk-actions');
  const copy = el('button', 'btn btn-small', 'Copiar el contenido');
  copy.type = 'button';
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(text);
      copy.textContent = 'Copiado';
    } catch {
      copy.textContent = 'No se pudo copiar';
    }
  });
  actions.append(copy);
  if (info.link) {
    const open = el('a', 'btn btn-small btn-primary', 'Abrir el enlace');
    open.href = info.link;
    open.target = '_blank';
    open.rel = 'noopener noreferrer';
    actions.append(open);
    box.append(el('p', 'hint', 'Revisa la dirección antes de abrirla: solo abre enlaces en los que confíes.'));
  }
  box.append(actions);
}

/**
 * jsQR devuelve el texto y también los bytes originales. Su texto sale vacío o mal con tildes y «ñ»
 * (UTF-8), así que primero se leen los bytes como UTF-8; si no lo son (QR antiguos en Latin-1), se usa
 * el texto de jsQR.
 */
function textOf(found) {
  if (found.binaryData?.length) {
    const bytes = Uint8Array.from(found.binaryData);
    try {
      return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    } catch {
      // No es UTF-8: un QR antiguo en Latin-1 (como los que hacía este generador antes). En los
      // navegadores «iso-8859-1» es Windows-1252, que además lee bien el «€».
      return new TextDecoder('iso-8859-1').decode(bytes);
    }
  }
  return found.data;
}

function decode(imageData) {
  const found = window.jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: 'attemptBoth' });
  return found ? textOf(found) : null;
}

/**
 * Prueba la imagen (o solo la región `region` = {x, y, w, h} en píxeles de la imagen) y, si no se lee, a menor
 * tamaño (a veces un QR muy grande o ruidoso así sale). Un recorte se lee con un margen blanco alrededor, porque
 * el QR lo necesita y al recortar justo al borde suele perderse; si el recorte es pequeño también se prueba ampliado.
 */
function decodeBitmap(bitmap, region = null) {
  const sx = region ? region.x : 0;
  const sy = region ? region.y : 0;
  const sw = region ? region.w : bitmap.width;
  const sh = region ? region.h : bitmap.height;
  const pad = region ? Math.max(8, Math.round(Math.max(sw, sh) * 0.12)) : 0;
  const scales = region && Math.max(sw, sh) < 400 ? [1, 2, 3, 0.5] : [1, 0.5, 0.25];
  for (const factor of scales) {
    let f = factor;
    const big = Math.max(sw + 2 * pad, sh + 2 * pad) * f;
    if (big > MAX_SIDE) f *= MAX_SIDE / big;
    const w = Math.round((sw + 2 * pad) * f);
    const h = Math.round((sh + 2 * pad) * f);
    if (w < 40 || h < 40) continue;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.fillStyle = '#ffffff'; // los PNG transparentes se leen sobre blanco
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(bitmap, sx, sy, sw, sh, Math.round(pad * f), Math.round(pad * f), Math.round(sw * f), Math.round(sh * f));
    const text = decode(ctx.getImageData(0, 0, w, h));
    if (text) return text;
  }
  return null;
}

// ----- Recorte de la imagen -----
// La imagen elegida se queda en el navegador (`current`). El recuadro se guarda en fracciones (0 a 1) de la imagen
// mostrada, así no depende de lo grande que se vea; al leer se convierte a píxeles de la imagen original.

let current = null; // ImageBitmap de la imagen elegida
let sel = null; // { x0, y0, x1, y1 } en fracciones, o null si no hay recorte
let drag = null;
const MIN_FRAC = 0.02;
const PREVIEW_SIDE = 1200;

const clamp01 = (v) => Math.min(1, Math.max(0, v));
const rectOf = (s) => ({ x0: Math.min(s.x0, s.x1), y0: Math.min(s.y0, s.y1), x1: Math.max(s.x0, s.x1), y1: Math.max(s.y0, s.y1) });

function regionPx() {
  if (!current || !sel) return null;
  const r = rectOf(sel);
  const x = Math.round(r.x0 * current.width);
  const y = Math.round(r.y0 * current.height);
  const w = Math.min(current.width - x, Math.max(1, Math.round((r.x1 - r.x0) * current.width)));
  const h = Math.min(current.height - y, Math.max(1, Math.round((r.y1 - r.y0) * current.height)));
  return { x, y, w, h };
}

function drawSelection() {
  const box = $('rd-box');
  const valid = sel && Math.abs(sel.x1 - sel.x0) >= MIN_FRAC && Math.abs(sel.y1 - sel.y0) >= MIN_FRAC;
  box.hidden = !valid;
  $('rd-read-crop').disabled = !valid;
  if (!valid) {
    $('rd-crop-size').textContent = 'Sin recorte: se lee toda la imagen.';
    return;
  }
  const r = rectOf(sel);
  const pct = (v) => `${(v * 100).toFixed(3)}%`;
  box.style.setProperty('left', pct(r.x0));
  box.style.setProperty('top', pct(r.y0));
  box.style.setProperty('width', pct(r.x1 - r.x0));
  box.style.setProperty('height', pct(r.y1 - r.y0));
  const px = regionPx();
  $('rd-crop-size').textContent = `Recorte de ${px.w} × ${px.h} px. Pulsa «Leer el recorte».`;
}

function setSelection(next) {
  sel = next;
  drawSelection();
}

function showCrop(bitmap) {
  current?.close?.();
  current = bitmap;
  const k = Math.min(1, PREVIEW_SIDE / Math.max(bitmap.width, bitmap.height));
  const canvas = $('rd-canvas');
  canvas.width = Math.max(1, Math.round(bitmap.width * k));
  canvas.height = Math.max(1, Math.round(bitmap.height * k));
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  setSelection(null);
  $('rd-crop').hidden = false;
}

function hideCrop() {
  current?.close?.();
  current = null;
  sel = null;
  drag = null;
  $('rd-crop').hidden = true;
  $('rd-box').hidden = true;
  $('rd-title').textContent = 'Arrastra una imagen con un QR o pulsa para elegirla';
  $('rd-file').value = '';
}

function pointOf(event) {
  const b = $('rd-stage').getBoundingClientRect();
  return { x: clamp01((event.clientX - b.left) / b.width), y: clamp01((event.clientY - b.top) / b.height) };
}

$('rd-stage').addEventListener('pointerdown', (event) => {
  if (!current || event.button > 0) return;
  event.preventDefault();
  const p = pointOf(event);
  const handle = event.target.closest?.('.crop-h')?.dataset.h;
  if (handle && sel) {
    drag = { mode: 'resize', handle };
  } else if (event.target.closest?.('.crop-box') && sel) {
    drag = { mode: 'move', from: p, start: rectOf(sel) };
  } else {
    drag = { mode: 'new', from: p };
    setSelection({ x0: p.x, y0: p.y, x1: p.x, y1: p.y });
  }
  $('rd-stage').setPointerCapture?.(event.pointerId);
});

$('rd-stage').addEventListener('pointermove', (event) => {
  if (!drag) return;
  const p = pointOf(event);
  if (drag.mode === 'new') {
    setSelection({ x0: drag.from.x, y0: drag.from.y, x1: p.x, y1: p.y });
  } else if (drag.mode === 'move') {
    const w = drag.start.x1 - drag.start.x0;
    const h = drag.start.y1 - drag.start.y0;
    const x0 = Math.min(1 - w, Math.max(0, drag.start.x0 + p.x - drag.from.x));
    const y0 = Math.min(1 - h, Math.max(0, drag.start.y0 + p.y - drag.from.y));
    setSelection({ x0, y0, x1: x0 + w, y1: y0 + h });
  } else {
    const next = { ...sel };
    if (drag.handle.includes('w')) next.x0 = p.x;
    if (drag.handle.includes('e')) next.x1 = p.x;
    if (drag.handle.includes('n')) next.y0 = p.y;
    if (drag.handle.includes('s')) next.y1 = p.y;
    setSelection(next);
  }
});

function endDrag() {
  if (!drag) return;
  drag = null;
  // Un clic sin arrastrar, o un recuadro diminuto, no es un recorte.
  if (sel && (Math.abs(sel.x1 - sel.x0) < MIN_FRAC || Math.abs(sel.y1 - sel.y0) < MIN_FRAC)) setSelection(null);
  else if (sel) setSelection(rectOf(sel)); // normaliza si se cruzaron los lados
}
$('rd-stage').addEventListener('pointerup', endDrag);
$('rd-stage').addEventListener('pointercancel', endDrag);

// Con el teclado: flechas mueven el recuadro; Mayús + flechas cambian su tamaño (esquina de abajo a la derecha).
$('rd-box').addEventListener('keydown', (event) => {
  const step = event.altKey ? 0.002 : 0.01;
  const dx = { ArrowLeft: -step, ArrowRight: step }[event.key] ?? 0;
  const dy = { ArrowUp: -step, ArrowDown: step }[event.key] ?? 0;
  if (!sel || (!dx && !dy)) return;
  event.preventDefault();
  const r = rectOf(sel);
  if (event.shiftKey) {
    setSelection({ ...r, x1: Math.max(r.x0 + MIN_FRAC, clamp01(r.x1 + dx)), y1: Math.max(r.y0 + MIN_FRAC, clamp01(r.y1 + dy)) });
  } else {
    const w = r.x1 - r.x0;
    const h = r.y1 - r.y0;
    const x0 = Math.min(1 - w, Math.max(0, r.x0 + dx));
    const y0 = Math.min(1 - h, Math.max(0, r.y0 + dy));
    setSelection({ x0, y0, x1: x0 + w, y1: y0 + h });
  }
});

function readCurrent(region) {
  if (!current) return;
  const text = decodeBitmap(current, region);
  if (text) {
    showResult(text);
    return;
  }
  $('rd-result').replaceChildren(
    el(
      'p',
      'hint center',
      region
        ? 'No se pudo leer ese recorte. Ajusta el recuadro para que incluya todo el QR (con un poco de margen) y nada más.'
        : 'No se encontró ningún código QR en la imagen. Si trae mucho más contenido, arrastra sobre la imagen para marcar solo el QR y pulsa «Leer el recorte».',
    ),
  );
}

$('rd-read-crop').addEventListener('click', () => readCurrent(regionPx()));
$('rd-read-all').addEventListener('click', () => {
  setSelection(null);
  readCurrent(null);
});
$('rd-clear-img').addEventListener('click', () => {
  hideCrop();
  setError('');
  $('rd-result').replaceChildren(el('p', 'hint center', 'Aquí aparecerá el contenido del QR.'));
});

async function readFile(file) {
  setError('');
  if (!file) return;
  if (!ACCEPTED.has(file.type)) {
    setError('Formato no admitido. Usa un PNG, JPG o WebP.');
    return;
  }
  try {
    const bitmap = await createImageBitmap(file);
    if (scanning) stopCamera();
    $('rd-title').textContent = file.name || 'Imagen pegada';
    showCrop(bitmap);
    readCurrent(null); // primero se intenta con toda la imagen; si no sale, se puede recortar
  } catch {
    setError('No se pudo abrir la imagen: el archivo está dañado o no es una imagen válida.');
  }
}

// ----- Cámara -----

function stopCamera() {
  scanning = false;
  stream?.getTracks().forEach((track) => track.stop());
  stream = null;
  $('rd-video').hidden = true;
  $('rd-video').srcObject = null;
  $('rd-stop').hidden = true;
  $('rd-camera').hidden = false;
}

async function startCamera() {
  setError('');
  if (!navigator.mediaDevices?.getUserMedia) {
    setError('La cámara no está disponible aquí: necesita una página segura (https) o abrirla desde este mismo equipo (localhost). Sube una imagen en su lugar.');
    return;
  }
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
  } catch {
    setError('No se pudo usar la cámara. Revisa el permiso del navegador o sube una imagen.');
    return;
  }
  hideCrop(); // la cámara y la imagen no se usan a la vez
  const video = $('rd-video');
  video.srcObject = stream;
  video.hidden = false;
  await video.play();
  $('rd-camera').hidden = true;
  $('rd-stop').hidden = false;
  scanning = true;
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  const tick = () => {
    if (!scanning) return;
    if (video.readyState >= 2 && video.videoWidth) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);
      const text = decode(ctx.getImageData(0, 0, canvas.width, canvas.height));
      if (text) {
        stopCamera();
        showResult(text);
        return;
      }
    }
    setTimeout(() => requestAnimationFrame(tick), 150);
  };
  tick();
}

$('rd-file').addEventListener('change', (event) => readFile(event.target.files?.[0]));
$('rd-camera').addEventListener('click', startCamera);
$('rd-stop').addEventListener('click', stopCamera);

const drop = $('rd-drop');
for (const type of ['dragenter', 'dragover']) {
  drop.addEventListener(type, (event) => {
    event.preventDefault();
    drop.classList.add('is-over');
  });
}
for (const type of ['dragleave', 'drop']) {
  drop.addEventListener(type, (event) => {
    event.preventDefault();
    drop.classList.remove('is-over');
  });
}
drop.addEventListener('drop', (event) => readFile(event.dataTransfer?.files?.[0]));

// Ctrl+V con una imagen copiada (por ejemplo, una captura de pantalla).
document.addEventListener('paste', (event) => {
  const file = [...(event.clipboardData?.files ?? [])].find((f) => ACCEPTED.has(f.type));
  if (file) readFile(file);
});

window.addEventListener('pagehide', stopCamera);
$('year').textContent = new Date().getFullYear();
