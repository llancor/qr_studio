// Página pública (/p/<código>): cuenta los clics en los botones, abre los PDF en un visor propio y
// muestra la carta como un libro que pasa las hojas (en móvil, una página; en pantallas grandes, dos).
// Sin JavaScript la página sigue siendo útil: los PDF se descargan y las hojas de la carta se apilan.

const body = document.body;
const code = body.dataset.code;
const preview = body.dataset.preview === '1';

// ---------- Clics en los botones ----------

for (const link of document.querySelectorAll('[data-k]')) {
  link.addEventListener('click', () => {
    if (preview) return;
    try {
      navigator.sendBeacon(`/p/${code}/clic/${link.dataset.k}`);
    } catch {
      /* sin conteo: no importa */
    }
  });
}

// ---------- Visor de PDF ----------

for (const link of document.querySelectorAll('[data-pdf]')) {
  link.addEventListener('click', async (event) => {
    event.preventDefault();
    try {
      const { openPdf } = await import('/js/visor-pdf.js');
      await openPdf({ url: link.dataset.pdf, title: link.textContent.trim(), downloadUrl: link.href });
    } catch (error) {
      console.error(error);
      window.location.href = link.href; // sin visor: se descarga
    }
  });
}

// ---------- Carta: libro y lista ----------

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = () => reject(new Error(`No se pudo cargar ${src}`));
    document.head.append(script);
  });
}

async function startBook(section) {
  const stage = section.querySelector('.libro-stage');
  const images = [...stage.querySelectorAll('.libro-pagina')];
  const bar = section.querySelector('.libro-barra');
  const counter = section.querySelector('.libro-contador');
  if (!images.length) return;

  await loadScript('/vendor/page-flip.browser.js');
  const first = images[0];
  if (!first.complete) await new Promise((resolve) => { first.onload = first.onerror = resolve; });
  const ratio = first.naturalWidth ? first.naturalHeight / first.naturalWidth : 1.4;

  const sheets = images.map((image, index) => {
    const sheet = document.createElement('div');
    sheet.className = 'libro-hoja';
    if (index === 0 || index === images.length - 1) sheet.dataset.density = 'hard'; // tapas rígidas
    const copy = document.createElement('img');
    copy.src = image.currentSrc || image.src;
    copy.alt = image.alt;
    copy.decoding = 'async';
    sheet.append(copy);
    return sheet;
  });

  images.forEach((image) => { image.hidden = true; });
  const host = document.createElement('div');
  stage.append(host);
  stage.classList.add('is-ready');
  try {
    const flip = new window.St.PageFlip(host, {
      width: 600,
      height: Math.round(600 * ratio),
      size: 'stretch',
      minWidth: 260,
      maxWidth: 820,
      minHeight: 300,
      maxHeight: 1500,
      maxShadowOpacity: 0.45,
      showCover: true,
      usePortrait: true,
      mobileScrollSupport: true,
      flippingTime: 650,
    });
    flip.loadFromHTML(sheets);
    // Al ocultar las hojas apiladas el tamaño de la página cambia: se vuelve a medir el libro.
    requestAnimationFrame(() => window.dispatchEvent(new Event('resize')));

    const refresh = () => {
      const index = flip.getCurrentPageIndex();
      const total = flip.getPageCount();
      const spread = flip.getOrientation() === 'landscape' && index > 0 && index < total - 1;
      counter.textContent = spread ? `Páginas ${index + 1}–${Math.min(index + 2, total)} de ${total}` : `Página ${index + 1} de ${total}`;
    };
    flip.on('flip', refresh);
    flip.on('changeOrientation', refresh);
    refresh();
    bar.hidden = false;

    section.querySelector('[data-flip="prev"]').addEventListener('click', () => flip.flipPrev());
    section.querySelector('[data-flip="next"]').addEventListener('click', () => flip.flipNext());
    // ----- Pantalla completa -----
    // Es una capa fija que ocupa toda la ventana (así también funciona donde el navegador no deja poner un
    // elemento a pantalla completa) y, si se puede, además se pide la pantalla completa real. Con la capa el
    // libro se estiraba mal y quedaba en una sola página: por eso aquí se fija su ancho según el alto
    // disponible y se le avisa a la librería para que vuelva a medirlo.
    const full = section.querySelector('[data-flip="full"]');
    let remeasuring = false;
    const remeasure = () => {
      if (remeasuring) return;
      remeasuring = true;
      window.dispatchEvent(new Event('resize'));
      remeasuring = false;
    };
    const fitFull = () => {
      if (!section.classList.contains('is-full')) {
        stage.style.maxWidth = '';
        return;
      }
      const availH = window.innerHeight - bar.offsetHeight - 14 - 40;
      const availW = window.innerWidth - 24;
      // Con 520 px o más la librería abre el libro a dos páginas; con menos, a una.
      const width = availW >= 520 ? Math.max(520, Math.min(availW, (2 * availH) / ratio)) : Math.max(260, Math.min(availW, availH / ratio));
      stage.style.maxWidth = `${Math.floor(width)}px`;
    };
    const setFull = (on) => {
      section.classList.toggle('is-full', on);
      document.body.classList.toggle('libro-abierto', on);
      full.textContent = on ? '✕' : '⛶';
      full.setAttribute('aria-label', on ? 'Salir de pantalla completa' : 'Pantalla completa');
      fitFull();
      remeasure();
      requestAnimationFrame(() => { fitFull(); remeasure(); }); // cuando el diseño ya se asentó
      if (on) section.requestFullscreen?.().catch(() => {});
      else if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
    };
    full.addEventListener('click', () => setFull(!section.classList.contains('is-full')));
    window.addEventListener('resize', () => {
      if (remeasuring) return;
      fitFull();
      remeasure();
    });
    document.addEventListener('fullscreenchange', () => {
      if (!document.fullscreenElement && section.classList.contains('is-full')) setFull(false); // salió con Esc
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && section.classList.contains('is-full') && !document.querySelector('.visor')) setFull(false);
      if (section.hidden || document.querySelector('.visor') || event.target.closest?.('input, textarea')) return;
      if (event.key === 'ArrowRight') flip.flipNext();
      if (event.key === 'ArrowLeft') flip.flipPrev();
    });
  } catch (error) {
    console.error(error);
    host.remove();
    stage.classList.remove('is-ready');
    images.forEach((image) => { image.hidden = false; }); // las hojas quedan apiladas
  }
}

const panels = new Map([...document.querySelectorAll('[data-panel]')].map((panel) => [panel.dataset.panel, panel]));
const book = panels.get('libro');
let bookStarted = false;

function showPanel(name) {
  for (const [key, panel] of panels) panel.hidden = key !== name;
  for (const tab of document.querySelectorAll('[data-vista]')) {
    const on = tab.dataset.vista === name;
    tab.classList.toggle('is-on', on);
    tab.setAttribute('aria-selected', String(on));
  }
  if (name === 'libro' && book && !bookStarted) {
    bookStarted = true;
    startBook(book).catch((error) => console.error(error));
  }
}

for (const tab of document.querySelectorAll('[data-vista]')) {
  tab.addEventListener('click', () => showPanel(tab.dataset.vista));
}
if (book) showPanel('libro');
