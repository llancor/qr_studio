// Muestra la versión del software («Versión v191120261705», igual que el nombre del .zip) en el pie de la página.
// Falla en silencio: si no se puede leer, el pie queda como está.
(async () => {
  const container = document.querySelector(".site-footer .container");
  if (!container) return;
  try {
    const response = await fetch("/healthz", { cache: "no-store" });
    if (!response.ok) return;
    const { version } = await response.json();
    if (!version) return;
    const line = document.createElement("p");
    line.className = "site-version";
    line.textContent = `Versión ${version}`;
    container.append(line);
  } catch {
    /* sin versión visible */
  }
})();
