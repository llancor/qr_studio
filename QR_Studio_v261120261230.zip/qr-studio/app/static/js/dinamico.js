// QR dinámicos (opcionales). Con sesión, el usuario puede marcar «Hacerlo dinámico» en la pestaña
// Sitio web: el QR lleva un enlace corto de este sitio (/q/<código>), y desde aquí puede cambiar el
// destino sin reimprimir el QR, pausarlo, ver cuántas veces se escaneó o eliminarlo.
// Todo texto que viene del usuario o del servidor se pone con textContent.

const $ = (id) => document.getElementById(id);

async function api(path, { method = 'GET', json } = {}) {
  const res = await fetch(path, {
    method,
    headers: json ? { 'Content-Type': 'application/json' } : undefined,
    body: json ? JSON.stringify(json) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* sin cuerpo JSON */
  }
  if (!res.ok) {
    const error = new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
    error.status = res.status;
    throw error;
  }
  return data;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function formatDate(iso) {
  if (!iso) return 'nunca';
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? 'nunca' : date.toLocaleString('es', { dateStyle: 'medium', timeStyle: 'short' });
}

/**
 * getTarget() -> dirección escrita en el formulario de Sitio web (destino del nuevo QR dinámico).
 * onPreview() pide a la página que redibuje la vista previa.
 */
export function createDynamic({ getTarget, onPreview }) {
  let user = null;
  let features = null;
  let items = [];
  let selectedId = null;
  let editingId = null;
  let statsFor = null;

  const toggle = $('dyn-toggle');
  const status = $('dyn-status');

  const available = () => Boolean(user && features?.dynamicQr);
  const active = () => available() && toggle.checked;
  const selected = () => items.find((i) => i.id === selectedId) ?? null;
  const base = () => features?.publicUrl || window.location.origin;
  const shortUrl = (item) => `${base()}/q/${item.code}`;

  function setStatus(message, isError = false) {
    status.textContent = message || '';
    status.hidden = !message;
    status.classList.toggle('field-error', isError);
  }

  function handleError(err) {
    if (err.status === 401) {
      setUser(null);
      return;
    }
    setStatus(err.message, true);
  }

  // Botón que pide una segunda pulsación (3 segundos) antes de borrar.
  function confirmButton(label, armedLabel, action) {
    const button = el('button', 'btn btn-small btn-danger', label);
    button.type = 'button';
    let timer = 0;
    button.addEventListener('click', () => {
      if (button.dataset.armed) {
        clearTimeout(timer);
        action();
        return;
      }
      button.dataset.armed = '1';
      button.textContent = armedLabel;
      timer = setTimeout(() => {
        delete button.dataset.armed;
        button.textContent = label;
      }, 3000);
    });
    return button;
  }

  function smallButton(label, onClick) {
    const button = el('button', 'btn btn-small', label);
    button.type = 'button';
    button.addEventListener('click', onClick);
    return button;
  }

  async function refresh() {
    if (!available()) return;
    try {
      items = (await api('/api/dynamic')).items;
      if (selectedId && !selected()) selectedId = null;
      render();
    } catch (err) {
      handleError(err);
    }
  }

  async function patch(item, body, message) {
    try {
      await api(`/api/dynamic/${item.id}`, { method: 'PATCH', json: body });
      setStatus(message);
      editingId = null;
      await refresh();
      onPreview();
    } catch (err) {
      setStatus(err.message, true);
    }
  }

  async function showStats(item) {
    if (statsFor === item.id) {
      statsFor = null;
      render();
      return;
    }
    try {
      const data = await api(`/api/dynamic/${item.id}/stats`);
      statsFor = item.id;
      render(data);
    } catch (err) {
      handleError(err);
    }
  }

  function renderStats(box, data) {
    const max = Math.max(1, ...data.days.map((d) => d.count));
    box.append(el('p', 'hint', `Total: ${data.total} escaneos · último: ${formatDate(data.lastScanAt)}. Últimos 30 días:`));
    const bars = el('div', 'dyn-bars');
    for (const day of data.days) {
      const bar = el('div', 'dyn-bar');
      bar.style.height = `${Math.max(day.count ? 8 : 2, Math.round((day.count / max) * 56))}px`;
      bar.title = `${day.day}: ${day.count}`;
      bars.append(bar);
    }
    box.append(bars);
  }

  function render(statsData) {
    const list = $('dyn-list');
    list.replaceChildren();
    if (!items.length) {
      list.append(el('p', 'hint', 'Todavía no tienes QR dinámicos. Crea el primero con el botón de arriba.'));
      return;
    }
    for (const item of items) {
      const row = el('div', `bulk-folder dyn-row${item.id === selectedId ? ' is-selected' : ''}${item.active ? '' : ' is-paused'}`);
      const info = el('div', 'bulk-folder-info');
      info.append(
        el('strong', '', `${item.name}${item.active ? '' : ' (pausado)'}`),
        el('span', 'dyn-target', `Destino: ${item.target}`),
        el('span', '', `Enlace del QR: ${shortUrl(item)}`),
        el('span', '', `${item.scans} escaneos · último: ${formatDate(item.lastScanAt)}`),
      );
      const actions = el('div', 'bulk-folder-actions');
      actions.append(
        smallButton(item.id === selectedId ? 'En uso' : 'Usar este QR', () => {
          selectedId = item.id;
          setStatus('Listo: a la derecha está el QR de este enlace; descárgalo con el botón de descarga.');
          render();
          onPreview();
        }),
        smallButton('Cambiar destino', () => {
          editingId = editingId === item.id ? null : item.id;
          render();
        }),
        smallButton(item.active ? 'Pausar' : 'Activar', () =>
          patch(item, { active: !item.active }, item.active ? 'QR pausado: quien lo escanee verá un aviso.' : 'QR activado.'),
        ),
        smallButton('Estadísticas', () => showStats(item)),
        confirmButton('Eliminar', 'Pulsa otra vez para eliminar', async () => {
          try {
            await api(`/api/dynamic/${item.id}`, { method: 'DELETE' });
            if (selectedId === item.id) selectedId = null;
            setStatus('QR dinámico eliminado. El QR impreso dejará de funcionar.');
            await refresh();
            onPreview();
          } catch (err) {
            handleError(err);
          }
        }),
      );
      row.append(info, actions);
      if (editingId === item.id) {
        const edit = el('div', 'dyn-edit');
        const input = el('input');
        input.type = 'text';
        input.value = item.target;
        input.maxLength = 2000;
        input.setAttribute('aria-label', 'Nuevo destino');
        const save = smallButton('Guardar destino', () => patch(item, { target: input.value }, 'Destino actualizado: el mismo QR ya lleva al enlace nuevo.'));
        const cancel = smallButton('Cancelar', () => {
          editingId = null;
          render();
        });
        edit.append(input, save, cancel);
        row.append(edit);
      }
      if (statsFor === item.id && statsData) {
        const box = el('div', 'dyn-stats');
        renderStats(box, statsData);
        row.append(box);
      }
      list.append(row);
    }
  }

  async function create() {
    setStatus('');
    const target = getTarget();
    if (!target) {
      setStatus('Escribe primero la dirección del sitio web (arriba) a la que llevará el QR.', true);
      return;
    }
    $('dyn-create').disabled = true;
    try {
      const item = await api('/api/dynamic', { method: 'POST', json: { name: $('dyn-name').value, target } });
      selectedId = item.id;
      $('dyn-name').value = '';
      setStatus(`Creado «${item.name}». A la derecha está el QR; descárgalo con el botón de descarga.`);
      await refresh();
      onPreview();
    } catch (err) {
      handleError(err);
    } finally {
      $('dyn-create').disabled = false;
    }
  }

  $('dyn-create').addEventListener('click', create);
  toggle.addEventListener('change', () => {
    $('dyn-box').hidden = !toggle.checked;
    onPreview();
  });

  async function setUser(next) {
    user = next;
    features = null;
    items = [];
    selectedId = null;
    if (user) {
      try {
        features = await api('/api/features');
      } catch {
        features = null;
      }
      if (available()) await refresh();
    } else {
      toggle.checked = false;
      $('dyn-box').hidden = true;
      $('dyn-list').replaceChildren();
    }
  }

  return {
    setUser,
    available,
    active,
    /** Vuelve a pedir la lista (para ver los escaneos al día cuando el panel se muestra otra vez). */
    refresh,
    /** Contenido del QR dinámico en uso (su enlace corto), o null si todavía no hay uno elegido. */
    previewData: () => (selected() ? shortUrl(selected()) : null),
  };
}
