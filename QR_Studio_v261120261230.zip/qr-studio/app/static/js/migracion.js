// Migración de la configuración: piezas compartidas por Ajustes (administrador) y por la pantalla de entrar
// (primer arranque, sin cuenta). Aquí no se toca la página: cada pantalla pone sus propios botones y mensajes.
// El archivo de migración va SIEMPRE cifrado con una contraseña: el servidor lo descifra con la contraseña que se
// escribe aquí (nunca se guarda) y valida todo; esto solo comprueba lo básico antes de enviarlo.

export const MAX_BYTES = 12 * 1024 * 1024;
export const MIN_PASSWORD = 10; // igual que en el servidor (migracion.MIN_PASSWORD)

/** Lee el archivo elegido y comprueba que es JSON. Devuelve el objeto (el servidor lo vuelve a validar). */
export async function leerArchivo(file) {
  if (file.size > MAX_BYTES) throw new Error('El archivo es demasiado grande (máximo 12 MB).');
  const text = await file.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error('Ese archivo no es una migración de QR Studio (no se pudo leer como JSON).');
  }
}

/**
 * Envía el archivo cifrado con la contraseña que lo abre. dryRun = solo ver qué se importaría, sin cambiar nada.
 * Falla con el mensaje del servidor (p. ej. «La contraseña no es correcta, o el archivo está dañado»).
 */
export async function enviar(ruta, archivo, password, dryRun) {
  const res = await fetch(ruta + (dryRun ? '?dry_run=true' : ''), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password, file: archivo }),
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  return data;
}

/** Frases que explican qué trae (o qué importó) una migración, a partir del resumen del servidor. */
export function lineas(r) {
  const out = [];
  if (r.registrationOpen !== null && r.registrationOpen !== undefined) {
    out.push(`Crear cuentas: ${r.registrationOpen ? 'abierto' : 'cerrado'}.`);
  }
  if (r.smtp) {
    out.push(
      r.smtpPassword
        ? 'Servidor de correo (SMTP), con su contraseña.'
        : 'Servidor de correo (SMTP). La contraseña no viene en el archivo: se conserva la que ya hubiera.'
    );
  }
  if (r.brand) out.push(r.logo ? 'Nombre, colores y logo del sitio.' : 'Nombre y colores del sitio.');
  if (r.loginImage) out.push(r.loginImageFile ? 'Página de acceso: ajustes e imagen de fondo.' : 'Página de acceso: ajustes.');
  if (r.usersAdded || r.usersSkipped) {
    let text = `Usuarios: ${r.usersAdded} ${r.usersAdded === 1 ? 'nuevo' : 'nuevos'}`;
    text += r.usersSkipped ? `; ${r.usersSkipped} ya existían y no se tocan.` : '.';
    out.push(text);
  }
  return out;
}

/** Pinta las frases en una lista (<ul>) con textContent. Si no hay nada, lo dice. */
export function pintarLista(lista, report) {
  const items = lineas(report);
  lista.replaceChildren(
    ...(items.length ? items : ['El archivo no trae nada que importar.']).map((text) => {
      const li = document.createElement('li');
      li.textContent = text;
      return li;
    })
  );
  return items.length > 0;
}
