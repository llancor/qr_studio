// Ajustes → Personalización: tema, color de acento, estilo (esquinas, texto, letra) e imagen de portada.
// Los cambios se aplican al instante y se guardan en la cuenta del usuario (servidor) a través de window.QRTema
// (js/tema.js, que cada página carga en su <head>): cada usuario tiene su propio aspecto en cualquier navegador.

const Tema = window.QRTema;
const $ = (id) => document.getElementById(id);

// La imagen se reduce y se comprime antes de subirla: el servidor acepta hasta 4 MB, así que se apunta a menos.
const MAX_BYTES = 3_500_000;
const MAX_ARCHIVO = 25 * 1024 * 1024;
const LADOS = [2560, 1920, 1440, 1080];
const CALIDADES = [0.86, 0.74, 0.62];

// Combinaciones listas para usar. No tocan el tamaño del texto ni la portada.
const ESTILOS = [
  { nombre: 'Clásico', tema: 'claro', acento: '#2f5bff', esquinas: 'suaves', fuente: 'sistema' },
  { nombre: 'Medianoche', tema: 'oscuro', acento: '#4f46e5', esquinas: 'suaves', fuente: 'sistema' },
  { nombre: 'Bosque', tema: 'claro', acento: '#16a34a', esquinas: 'redondas', fuente: 'sistema' },
  { nombre: 'Atardecer', tema: 'claro', acento: '#ea580c', esquinas: 'redondas', fuente: 'sistema' },
  { nombre: 'Sobrio', tema: 'claro', acento: '#475569', esquinas: 'rectas', fuente: 'serif' },
];

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function mensaje(id, text) {
  const box = $(id);
  box.textContent = text || '';
  box.hidden = !text;
}

let avisoTimer = 0;
function aviso(text) {
  mensaje('pe-portada-ok', text);
  clearTimeout(avisoTimer);
  if (text) avisoTimer = setTimeout(() => mensaje('pe-portada-ok', ''), 5000);
}

// ----- Pintar los controles con lo guardado ---------------------------------------------------

let imagenMostrada = null;

function mostrar() {
  const p = Tema.cargar();
  for (const group of document.querySelectorAll('[data-pe]')) {
    const value = p[group.dataset.pe];
    for (const radio of group.querySelectorAll('input[type="radio"]')) radio.checked = radio.value === value;
  }
  for (const radio of document.querySelectorAll('input[name="pe-acento"]')) radio.checked = radio.value === p.acento;
  $('pe-acento-custom').value = p.acento;

  $('pe-velo').value = p.velo;
  $('pe-velo-out').textContent = `${p.velo} %`;
  $('pe-desenfoque').value = p.desenfoque;
  $('pe-desenfoque-out').textContent = `${p.desenfoque} px`;
  $('pe-ajuste').value = p.ajuste;
  $('pe-posicion').value = p.posicion;

  const imagen = Tema.urlPortada(); // /api/me/cover?v=N: la versión cambia con cada portada nueva
  const img = $('pe-portada-img');
  if (imagen !== imagenMostrada) {
    // Solo se vuelve a cargar la miniatura si la imagen cambió.
    if (imagen) img.src = imagen;
    else img.removeAttribute('src');
    imagenMostrada = imagen;
  }
  img.hidden = !imagen;
  $('pe-portada-vacio').hidden = Boolean(imagen);
  $('pe-portada-quitar').disabled = !imagen;
  $('pe-portada-opciones').setAttribute('aria-disabled', String(!imagen));
  for (const control of $('pe-portada-opciones').querySelectorAll('input, select')) control.disabled = !imagen;
}

// ----- Tema, esquinas, texto y letra ----------------------------------------------------------

for (const group of document.querySelectorAll('[data-pe]')) {
  group.addEventListener('change', (event) => {
    if (event.target.matches('input[type="radio"]')) {
      Tema.guardar({ [group.dataset.pe]: event.target.value });
      mostrar();
    }
  });
}

// ----- Color de acento ---------------------------------------------------------------------------

const swatches = $('pe-acentos');
for (const { nombre, hex } of Tema.ACENTOS) {
  const label = el('label', 'pers-swatch');
  label.title = nombre;
  const input = el('input');
  input.type = 'radio';
  input.name = 'pe-acento';
  input.value = hex;
  input.setAttribute('aria-label', nombre);
  const dot = el('span');
  dot.style.backgroundColor = hex; // CSSOM: la política de seguridad no admite el atributo style, pero esto sí
  label.append(input, dot);
  swatches.append(label);
}
swatches.addEventListener('change', (event) => {
  if (event.target.matches('input[type="radio"]')) {
    Tema.guardar({ acento: event.target.value });
    mostrar();
  }
});
$('pe-acento-custom').addEventListener('input', (event) => {
  Tema.guardar({ acento: event.target.value });
  mostrar();
});

// ----- Estilos rápidos --------------------------------------------------------------------------

const presets = $('pe-presets');
for (const estilo of ESTILOS) {
  const button = el('button', 'btn btn-small pers-preset');
  button.type = 'button';
  const dot = el('span', 'pers-dot');
  dot.style.backgroundColor = estilo.acento;
  button.append(dot, document.createTextNode(estilo.nombre));
  button.addEventListener('click', () => {
    const { nombre, ...cambios } = estilo;
    Tema.guardar(cambios);
    mostrar();
  });
  presets.append(button);
}

// ----- Imagen de portada --------------------------------------------------------------------------

/** Lee la imagen elegida, la reduce y la comprime (JPEG) hasta que pese lo bastante poco para subirla. */
export async function prepararImagen(file) {
  if (!file.type.startsWith('image/')) throw new Error('Elige un archivo de imagen (JPG, PNG, WebP…).');
  if (file.size > MAX_ARCHIVO) throw new Error('La imagen pesa más de 25 MB. Elige una más pequeña.');

  const { source: img, ancho, alto, cerrar } = await abrirImagen(file);
  try {
    if (!ancho || !alto) throw new Error('No se pudo leer esa imagen. Prueba con otra (JPG, PNG o WebP).');

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    for (const lado of LADOS) {
      const escala = Math.min(1, lado / Math.max(ancho, alto));
      canvas.width = Math.max(1, Math.round(ancho * escala));
      canvas.height = Math.max(1, Math.round(alto * escala));
      ctx.fillStyle = '#fff'; // el JPEG no tiene transparencia
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      for (const calidad of CALIDADES) {
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', calidad));
        if (blob && blob.size <= MAX_BYTES) return blob;
      }
    }
    throw new Error('Esa imagen es demasiado grande para guardarla. Elige una más pequeña.');
  } finally {
    cerrar();
  }
}

/**
 * Abre la imagen elegida. createImageBitmap es rápido y no depende de que la página esté pintando; si el navegador
 * no puede con ese formato (p. ej. un SVG) se prueba con un <img>. No se usa img.decode(): en una pestaña sin
 * foco puede no terminar nunca.
 */
export async function abrirImagen(file) {
  const noSePudo = () => new Error('No se pudo leer esa imagen. Prueba con otra (JPG, PNG o WebP).');
  if (typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(file);
      return { source: bitmap, ancho: bitmap.width, alto: bitmap.height, cerrar: () => bitmap.close() };
    } catch {
      /* formato que createImageBitmap no abre: se prueba con <img> */
    }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(noSePudo());
      el.src = url;
    });
    return { source: img, ancho: img.naturalWidth, alto: img.naturalHeight, cerrar: () => {} };
  } finally {
    URL.revokeObjectURL(url);
  }
}

$('pe-portada-file').addEventListener('change', async (event) => {
  const input = event.target;
  const file = input.files?.[0];
  mensaje('pe-portada-error', '');
  aviso('');
  if (!file) return;
  input.disabled = true;
  try {
    const blob = await prepararImagen(file);
    await Tema.ponerPortada(blob); // se sube a tu cuenta; si el servidor la rechaza, llega como Error con su mensaje
    mostrar();
    aviso('Listo: la imagen ya es la portada de todas las páginas.');
  } catch (err) {
    mensaje('pe-portada-error', err.message);
  } finally {
    input.value = '';
    input.disabled = false;
  }
});

$('pe-portada-quitar').addEventListener('click', async () => {
  mensaje('pe-portada-error', '');
  try {
    await Tema.quitarPortada();
    mostrar();
    aviso('Se quitó la imagen de portada.');
  } catch (err) {
    mensaje('pe-portada-error', err.message);
  }
});

$('pe-velo').addEventListener('input', (event) => {
  Tema.guardar({ velo: Number(event.target.value) });
  $('pe-velo-out').textContent = `${event.target.value} %`;
});
$('pe-desenfoque').addEventListener('input', (event) => {
  Tema.guardar({ desenfoque: Number(event.target.value) });
  $('pe-desenfoque-out').textContent = `${event.target.value} px`;
});
$('pe-ajuste').addEventListener('change', (event) => Tema.guardar({ ajuste: event.target.value }));
$('pe-posicion').addEventListener('change', (event) => Tema.guardar({ posicion: event.target.value }));

// ----- Restablecer todo ------------------------------------------------------------------------------

$('pe-reset').addEventListener('click', async () => {
  const hayPortada = Tema.hayPortada();
  const texto = hayPortada
    ? '¿Volver al aspecto original? Se quitarán también los colores, el estilo y la imagen de portada.'
    : '¿Volver al aspecto original? Se quitarán los colores y el estilo que elegiste.';
  if (!window.confirm(texto)) return;
  mensaje('pe-portada-error', '');
  try {
    await Tema.restablecer();
    mostrar();
    aviso('Se restableció el aspecto original.');
  } catch (err) {
    mensaje('pe-portada-error', err.message);
  }
});

// Cambios hechos desde otra pestaña
window.addEventListener('storage', mostrar);

mostrar();
// Cuando llega lo guardado en la cuenta (puede diferir de la copia local), se vuelven a pintar los controles.
Tema.listo.then(mostrar);
