// Aviso de privacidad y términos de uso: los textos están escritos en el HTML; este archivo solo rellena los datos
// del responsable (los pone el administrador en Ajustes → Legal) y enseña u oculta lo que depende de qué funciones
// tiene este sitio activadas. Todo se escribe con textContent: nunca se interpreta como HTML.

(function () {
  'use strict';

  var $$ = function (selector) {
    return Array.prototype.slice.call(document.querySelectorAll(selector));
  };

  function fechaLarga(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    if (!m) return '';
    var meses = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    return Number(m[3]) + ' de ' + meses[Number(m[2]) - 1] + ' de ' + m[1];
  }

  function aplicar(d) {
    var valores = {
      name: d.name || '[responsable: se completa en Ajustes → Legal]',
      email: d.email || '[correo de contacto: se completa en Ajustes → Legal]',
      country: d.country || '[país: se completa en Ajustes → Legal]',
      address: d.address || '',
      site: d.siteName || 'QR Studio',
      date: fechaLarga(d.updatedAt) || 'sin fecha todavía',
      days: String(d.sessionDays || 14),
    };
    $$('[data-l]').forEach(function (el) {
      el.textContent = valores[el.getAttribute('data-l')] || '';
    });
    // Enlace de correo: solo si hay uno guardado (el servidor ya lo validó).
    $$('[data-l-mail]').forEach(function (el) {
      if (d.email) {
        el.textContent = d.email;
        el.setAttribute('href', 'mailto:' + d.email);
      } else {
        el.textContent = valores.email;
        el.removeAttribute('href');
      }
    });
    // Bloques que dependen de las funciones activas.
    var activo = {
      recovery: !!d.recoveryEnabled,
      public: !!d.publicAccess,
      nopublic: !d.publicAccess,
      register: !!d.registrationOpen,
      dynamic: !!d.dynamicQr,
      pages: !!d.pages,
      address: !!d.address,
    };
    $$('[data-if]').forEach(function (el) {
      el.hidden = !activo[el.getAttribute('data-if')];
    });
    var pendiente = document.getElementById('lg-pending');
    if (pendiente) pendiente.hidden = !!d.configured;
    if (d.siteName) document.title = document.title.replace('QR Studio', d.siteName);
  }

  var anio = document.getElementById('year');
  if (anio) anio.textContent = String(new Date().getFullYear());

  fetch('/api/auth/legal', { credentials: 'same-origin' })
    .then(function (res) {
      return res.ok ? res.json() : null;
    })
    .then(function (d) {
      aplicar(d || {});
    })
    .catch(function () {
      aplicar({});
    });
})();
