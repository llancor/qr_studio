// Creación masiva de QR y carpetas del usuario. Requiere sesión iniciada.
//
// El usuario pega una lista (una línea por QR). Cada QR se genera en el navegador con el diseño
// elegido (marco, colores, logo...) y el PNG se guarda en una carpeta de su cuenta en el servidor
// (/api/qr/*). Todo texto que viene del usuario o del servidor se pone con textContent.
import { TYPES, buildContent } from './qr.js';
import { buildSheetPdf } from './pdf.js';

const $ = (id) => document.getElementById(id);
const enc = encodeURIComponent;

export const MAX_LINES = 200;
// Qué campo del tipo de contenido recibe cada línea de la lista.
const KINDS = { website: 'url', text: 'text', phone: 'phone', email: 'to' };

// ---------- Lista pegada ----------

function slug(text) {
  return text
    .replace(/^[a-z][a-z0-9+.-]*:\/*/i, '')
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 30);
}

/**
 * Convierte el texto en [{ line, name, data }] y los problemas por línea. Una línea puede ser solo el
 * contenido, o «nombre;contenido» / «nombre<TAB>contenido» (por ejemplo, dos columnas pegadas de Excel).
 * El «;» solo separa el nombre cuando lo anterior parece un nombre (sin «:», «/» ni «@»).
 */
export function parseList(text, kind) {
  const type = TYPES.find((t) => t.id === kind);
  const field = KINDS[kind];
  const items = [];
  const problems = [];
  if (!type || !field) return { items, problems: [{ line: 0, message: 'Tipo de contenido no válido.' }] };

  text.split(/\r?\n/).forEach((raw, index) => {
    const line = raw.trim();
    if (!line) return;
    let name = '';
    let content = line;
    const tab = line.indexOf('\t');
    if (tab > 0) {
      name = line.slice(0, tab);
      content = line.slice(tab + 1);
    } else {
      const semi = line.indexOf(';');
      if (semi > 0 && semi <= 60 && !/[:/@]/.test(line.slice(0, semi))) {
        name = line.slice(0, semi);
        content = line.slice(semi + 1);
      }
    }
    name = name.trim();
    content = content.trim().replace(/^"(.*)"$/, '$1');
    const built = buildContent(type, { [field]: content });
    if (!built.data) {
      problems.push({ line: index + 1, message: built.error || 'Falta el contenido.' });
      return;
    }
    if (items.length >= MAX_LINES) {
      problems.push({ line: index + 1, message: `Se omite: el máximo es ${MAX_LINES} QR por vez.` });
      return;
    }
    const seq = String(items.length + 1).padStart(3, '0');
    items.push({ line: index + 1, name: name || `${seq}-${slug(content) || 'qr'}`, data: built.data });
  });
  return { items, problems };
}

// ---------- Plantilla CSV ----------

const TEMPLATES = {
  website: [
    ['tienda', 'https://www.ejemplo.com/tienda'],
    ['oferta', 'https://www.ejemplo.com/oferta'],
    ['contacto', 'https://www.ejemplo.com/contacto'],
  ],
  text: [
    ['saludo', 'Hola, bienvenido'],
    ['horario', 'Abierto de lunes a viernes de 9 a 18 h'],
    ['gracias', 'Gracias por su visita'],
  ],
  phone: [
    ['recepcion', '+34 600 000 001'],
    ['ventas', '+34 600 000 002'],
    ['soporte', '+34 600 000 003'],
  ],
  email: [
    ['ventas', 'ventas@ejemplo.com'],
    ['soporte', 'soporte@ejemplo.com'],
    ['info', 'info@ejemplo.com'],
  ],
};

/**
 * Texto de una plantilla CSV lista para rellenar: «nombre;contenido» en cada línea (sin encabezado),
 * con BOM UTF-8 y saltos CRLF para que Excel abra bien las tildes y las columnas.
 */
export function templateCsv(kind) {
  const rows = TEMPLATES[kind] ?? TEMPLATES.website;
  return `﻿${rows.map(([name, content]) => `${name};${content}`).join('\r\n')}\r\n`;
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

async function api(path, { method = 'GET', json, body } = {}) {
  const headers = json ? { 'Content-Type': 'application/json' } : body ? { 'Content-Type': 'image/png' } : undefined;
  const res = await fetch(path, { method, headers, body: json ? JSON.stringify(json) : body, credentials: 'same-origin' });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* sin cuerpo JSON */
  }
  if (!res.ok) {
    const error = new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
    error.status = res.status;
    throw error;
  }
  return data;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// ---------- Panel ----------

/**
 * renderCanvas({ data, size, placeholder }) -> canvas con el QR y el marco actuales.
 * onPreview() pide a la página que redibuje la vista previa.
 */
export function createBulk({ renderCanvas, exportSize, onPreview }) {
  let user = null;
  let busy = false;
  let cancelled = false;
  let openedFolder = null;
  let openedFiles = [];

  const status = $('bulk-status');
  const progress = $('bulk-progress');
  const problemsList = $('bulk-problems');

  function setStatus(message, isError = false) {
    status.textContent = message || '';
    status.hidden = !message;
    status.classList.toggle('field-error', isError);
  }

  function showProblems(problems) {
    problemsList.replaceChildren();
    for (const p of problems.slice(0, 20)) problemsList.append(el('li', '', p.line ? `Línea ${p.line}: ${p.message}` : p.message));
    if (problems.length > 20) problemsList.append(el('li', '', `…y ${problems.length - 20} más.`));
    problemsList.hidden = problems.length === 0;
  }

  function setBusy(value) {
    busy = value;
    for (const id of ['bulk-kind', 'bulk-folder', 'bulk-text', 'bulk-file', 'bulk-create']) $(id).disabled = value;
    $('bulk-cancel').hidden = !value;
    progress.hidden = !value;
  }

  function sessionExpired() {
    setUser(null);
    setStatus('Tu sesión terminó. Inicia sesión de nuevo.', true);
  }

  function handleError(err) {
    if (err.status === 401) sessionExpired();
    else setStatus(err.message, true);
  }

  // ----- Carpetas -----

  async function refreshFolders() {
    if (!user) return;
    try {
      renderFolders(await api('/api/qr/folders'));
    } catch (err) {
      handleError(err);
    }
  }

  function renderFolders(data) {
    const box = $('bulk-folders');
    box.replaceChildren();
    const list = $('bulk-folder-list');
    list.replaceChildren();
    $('bulk-quota').textContent = `Espacio usado: ${formatBytes(data.quota.used)} de ${formatBytes(data.quota.limit)}`;
    if (!data.folders.length) {
      box.append(el('p', 'hint', 'Todavía no tienes carpetas. Crea tus primeros QR arriba y se guardarán aquí.'));
      return;
    }
    for (const folder of data.folders) {
      list.append(Object.assign(document.createElement('option'), { value: folder.name }));
      const row = el('div', 'bulk-folder');
      const info = el('div', 'bulk-folder-info');
      info.append(el('strong', '', folder.name), el('span', '', `${folder.count} QR · ${formatBytes(folder.bytes)}`));
      const actions = el('div', 'bulk-folder-actions');
      const open = el('button', 'btn btn-small', 'Abrir');
      open.type = 'button';
      open.addEventListener('click', () => openFolder(folder.name));
      const zip = el('a', 'btn btn-small', 'Descargar ZIP');
      zip.href = `/api/qr/folders/${enc(folder.name)}/zip`;
      zip.download = `${folder.name}.zip`;
      const remove = confirmButton('Eliminar', 'Pulsa otra vez para eliminar', () => deleteFolder(folder.name));
      actions.append(open, zip, remove);
      row.append(info, actions);
      box.append(row);
    }
  }

  // Botón que pide una segunda pulsación (3 segundos) antes de borrar.
  function confirmButton(label, armedLabel, action) {
    const button = el('button', 'btn btn-small btn-danger', label);
    button.type = 'button';
    let timer = 0;
    button.addEventListener('click', () => {
      if (button.dataset.armed) {
        clearTimeout(timer);
        action();
        return;
      }
      button.dataset.armed = '1';
      button.textContent = armedLabel;
      timer = setTimeout(() => {
        delete button.dataset.armed;
        button.textContent = label;
      }, 3000);
    });
    return button;
  }

  async function deleteFolder(name) {
    try {
      await api(`/api/qr/folders/${enc(name)}`, { method: 'DELETE' });
      if (openedFolder === name) closeFolder();
      setStatus(`Se eliminó la carpeta «${name}».`);
      await refreshFolders();
    } catch (err) {
      handleError(err);
    }
  }

  async function openFolder(name) {
    try {
      const data = await api(`/api/qr/folders/${enc(name)}`);
      openedFolder = data.name;
      renderFiles(data);
      $('bulk-files').scrollIntoView({ block: 'nearest' });
    } catch (err) {
      handleError(err);
    }
  }

  function closeFolder() {
    openedFolder = null;
    $('bulk-files').hidden = true;
    $('bulk-grid').replaceChildren();
  }

  function renderFiles(data) {
    openedFiles = data.files;
    $('sheet-status').hidden = true;
    $('bulk-files').hidden = false;
    $('bulk-files-title').textContent = `Carpeta «${data.name}» (${data.files.length} QR)`;
    const grid = $('bulk-grid');
    grid.replaceChildren();
    if (!data.files.length) grid.append(el('p', 'hint', 'La carpeta está vacía.'));
    for (const file of data.files) {
      const url = `/api/qr/folders/${enc(data.name)}/files/${enc(file.name)}`;
      const card = el('figure', 'bulk-file');
      const img = el('img');
      img.src = url;
      img.alt = `QR ${file.name}`;
      img.loading = 'lazy';
      const caption = el('figcaption', '', file.name);
      const actions = el('div', 'bulk-file-actions');
      const save = el('a', 'btn btn-small', 'Descargar');
      save.href = `${url}?download=true`;
      const remove = confirmButton('Borrar', '¿Seguro?', async () => {
        try {
          await api(url, { method: 'DELETE' });
          await openFolder(data.name);
          await refreshFolders();
        } catch (err) {
          handleError(err);
        }
      });
      actions.append(save, remove);
      card.append(img, caption, actions);
      grid.append(card);
    }
  }

  $('bulk-files-close').addEventListener('click', closeFolder);

  // Hoja para imprimir: reúne los QR de la carpeta abierta en páginas A4 y baja un PDF.
  $('sheet-pdf').addEventListener('click', async () => {
    const files = openedFiles;
    const folder = openedFolder;
    const note = $('sheet-status');
    const button = $('sheet-pdf');
    if (!folder || !files.length) return;
    button.disabled = true;
    note.hidden = false;
    note.classList.remove('field-error');
    const items = [];
    try {
      for (const [i, file] of files.entries()) {
        note.textContent = `Preparando ${i + 1} de ${files.length}…`;
        const res = await fetch(`/api/qr/folders/${enc(folder)}/files/${enc(file.name)}`, { credentials: 'same-origin' });
        if (res.status === 401) throw Object.assign(new Error('Tu sesión terminó. Inicia sesión de nuevo.'), { status: 401 });
        if (!res.ok) throw new Error(`No se pudo leer ${file.name}.`);
        items.push({ bitmap: await createImageBitmap(await res.blob()), name: file.name });
      }
      note.textContent = 'Armando el PDF…';
      const bytes = await buildSheetPdf(items, { title: folder, columns: Number($('sheet-cols').value), showNames: $('sheet-names').checked });
      const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = `${folder}.pdf`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      note.textContent = `Listo: ${folder}.pdf con ${items.length} QR (${(bytes.length / 1024).toFixed(0)} KB).`;
    } catch (err) {
      note.textContent = err.message;
      note.classList.add('field-error');
      if (err.status === 401) sessionExpired();
    } finally {
      for (const item of items) item.bitmap.close?.();
      button.disabled = false;
    }
  });

  // ----- Crear y guardar -----

  function currentItems() {
    return parseList($('bulk-text').value, $('bulk-kind').value);
  }

  async function createAll() {
    setStatus('');
    closeFolder();
    const { items, problems } = currentItems();
    showProblems(problems);
    if (!items.length) {
      setStatus(problems.length ? 'Ninguna línea es válida. Revisa los avisos.' : 'Escribe o pega al menos una línea.', true);
      return;
    }
    const folderName = $('bulk-folder').value.trim();
    if (!folderName) {
      setStatus('Escribe el nombre de la carpeta donde guardar los QR.', true);
      return;
    }

    cancelled = false;
    setBusy(true);
    progress.max = items.length;
    progress.value = 0;
    let saved = 0;
    let folder = folderName;
    try {
      const created = await api('/api/qr/folders', { method: 'POST', json: { name: folderName } });
      folder = created.name;
      for (const [i, item] of items.entries()) {
        if (cancelled) break;
        setStatus(`Creando y guardando ${i + 1} de ${items.length}…`);
        const canvas = await renderCanvas({ data: item.data, size: exportSize, placeholder: false });
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
        if (!blob) throw new Error('No se pudo generar uno de los QR.');
        await api(`/api/qr/folders/${enc(folder)}/files?name=${enc(item.name)}`, { method: 'POST', body: blob });
        saved += 1;
        progress.value = saved;
      }
      const tail = problems.length ? ` ${problems.length} línea(s) se omitieron por errores.` : '';
      setStatus(
        cancelled
          ? `Cancelado: se guardaron ${saved} de ${items.length} QR en «${folder}».${tail}`
          : `Listo: se guardaron ${saved} QR en la carpeta «${folder}».${tail}`,
      );
    } catch (err) {
      const prefix = saved ? `Se guardaron ${saved} de ${items.length} QR antes del error. ` : '';
      if (err.status === 401) sessionExpired();
      else setStatus(`${prefix}${err.message}`, true);
    } finally {
      setBusy(false);
    }
    if (user) {
      await refreshFolders();
      if (saved) await openFolder(folder);
    }
  }

  $('bulk-create').addEventListener('click', createAll);
  $('bulk-cancel').addEventListener('click', () => {
    cancelled = true;
  });

  function onInput() {
    if (busy) return;
    const { items, problems } = currentItems();
    showProblems(problems);
    $('bulk-count').textContent = items.length
      ? `${items.length} QR listos para crear${problems.length ? ` · ${problems.length} línea(s) con aviso` : ''}.`
      : '';
    onPreview();
  }
  $('bulk-text').addEventListener('input', onInput);
  $('bulk-kind').addEventListener('change', onInput);

  $('bulk-file').addEventListener('change', (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (file.size > 1024 * 1024) {
      setStatus('El archivo pesa más de 1 MB.', true);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      $('bulk-text').value = String(reader.result ?? '');
      setStatus(`Se cargó «${file.name}». Revisa la lista y pulsa «Crear y guardar».`);
      onInput();
    };
    reader.onerror = () => setStatus('No se pudo leer el archivo.', true);
    reader.readAsText(file);
  });

  $('bulk-template').addEventListener('click', () => {
    const kind = $('bulk-kind').value;
    const blob = new Blob([templateCsv(kind)], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `plantilla-qr-${kind}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatus('Plantilla descargada: cambia los datos de ejemplo, guarda el archivo como CSV y cárgalo aquí.');
  });

  // ----- Sesión -----

  function setUser(next) {
    user = next;
    $('bulk-guest').hidden = Boolean(user);
    $('bulk-user').hidden = !user;
    if (user) {
      refreshFolders();
    } else {
      closeFolder();
      $('bulk-folders').replaceChildren();
    }
  }

  /** Contenido del primer QR válido de la lista, para la vista previa del lateral. */
  function previewData() {
    return currentItems().items[0]?.data ?? null;
  }

  return { setUser, previewData };
}
