// Generador masivo de códigos de barras. Una línea por código («valor» o «nombre;valor»).
// Usa el formato y el aspecto del generador de arriba. El tamaño se elige con un deslizador en mm y
// una vista previa a tamaño real. Todo se hace en el navegador: un .zip con PNG (y SVG opcional)
// o una hoja A4 en PDF donde caben tantos códigos como quepan en la página.
import { makeZip } from './zip.js';
import { deflate, rgbFromRgba, makePdf } from './pdf.js';

const $ = (id) => document.getElementById(id);
const SVG_NS = 'http://www.w3.org/2000/svg';
export const MAX_BARCODES = 200;

const MM_PER_INCH = 25.4;
const SCREEN_PPI = 96; // tamaño que se ve en pantalla (px CSS)
const PNG_PPI = 300; // resolución de las imágenes PNG del .zip
const PRINT_PPI = 200; // resolución de la hoja PDF
const PAGE_MM = { w: 210, h: 297 }; // A4
const MARGIN_MM = 10;
const HEADER_MM = 12;
const GAP_MM = 4;
const LABEL_MM = 6;

const FORMAT_LABELS = {
  CODE128: 'Code 128',
  EAN13: 'EAN-13',
  EAN8: 'EAN-8',
  UPC: 'UPC-A',
  CODE39: 'Code 39',
  ITF14: 'ITF-14',
};
const FORMAT_HINTS = {
  CODE128: 'Cualquier texto o número.',
  EAN13: '12 dígitos (la cifra de control se calcula sola) o los 13 completos.',
  EAN8: '7 dígitos (la cifra de control se calcula sola) o los 8 completos.',
  UPC: '11 dígitos (la cifra de control se calcula sola) o los 12 completos.',
  CODE39: 'Letras MAYÚSCULAS, cifras, espacio y - . $ / + %.',
  ITF14: '13 dígitos (la cifra de control se calcula sola) o los 14 completos.',
};

const currentFormat = () => $('bc-format').value;

// Ejemplos válidos para cada formato, usados en la plantilla CSV y en la vista previa.
const TEMPLATE_VALUES = {
  CODE128: ['QR-STUDIO-001', 'QR-STUDIO-002', 'QR-STUDIO-003'],
  EAN13: ['590123412345', '590123412352', '590123412369'],
  EAN8: ['9638507', '9638508', '9638509'],
  UPC: ['12345678901', '12345678902', '12345678903'],
  CODE39: ['CODE-39-001', 'CODE-39-002', 'CODE-39-003'],
  ITF14: ['1234567890123', '1234567890124', '1234567890125'],
};

/** Plantilla «nombre;valor» (sin encabezado) con BOM UTF-8 y saltos CRLF para Excel. */
export function templateCsv(format) {
  const values = TEMPLATE_VALUES[format] ?? TEMPLATE_VALUES.CODE128;
  return `﻿${values.map((value, i) => `codigo-${String(i + 1).padStart(2, '0')};${value}`).join('\r\n')}\r\n`;
}

const mmToPx = (mm, ppi) => Math.round((mm * ppi) / MM_PER_INCH);

/** Opciones de JsBarcode con el aspecto elegido arriba. scale > 1 da más resolución. */
function barcodeOptions(scale = 1) {
  return {
    format: currentFormat(),
    width: Number($('bc-width').value) * scale,
    height: Math.min(300, Math.max(30, Number($('bc-height').value) || 100)) * scale,
    margin: Math.min(80, Math.max(0, Number($('bc-margin').value) || 0)) * scale,
    displayValue: $('bc-text').checked,
    lineColor: $('bc-fg').value,
    background: $('bc-bg').value,
    fontSize: 20 * scale,
    font: 'sans-serif',
  };
}

/** Dibuja el código en un canvas o un <svg>. Devuelve false si el valor no es válido para el formato. */
function draw(target, value, options) {
  let ok = true;
  try {
    window.JsBarcode(target, value, { ...options, valid: (isValid) => { ok = isValid; } });
  } catch {
    ok = false;
  }
  return ok;
}

const scratch = document.createElement('canvas');
const isValid = (value) => draw(scratch, value, barcodeOptions());

function toCanvas(value, scale = 1) {
  const canvas = document.createElement('canvas');
  draw(canvas, value, barcodeOptions(scale));
  return canvas;
}

/** Código dibujado con `widthPx` píxeles de ancho (el alto sale del aspecto). */
function renderAt(value, widthPx) {
  const probe = toCanvas(value, 1);
  const scale = Math.max(2, Math.ceil(widthPx / Math.max(1, probe.width)));
  const src = toCanvas(value, scale);
  const out = document.createElement('canvas');
  out.width = Math.max(1, Math.round(widthPx));
  out.height = Math.max(1, Math.round((src.height * out.width) / src.width));
  const ctx = out.getContext('2d');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(src, 0, 0, out.width, out.height);
  return out;
}

/** Alto en mm que resulta del aspecto del código para un ancho dado. */
function heightMmFor(value, wMm) {
  const c = toCanvas(value, 1);
  return c.width ? (wMm * c.height) / c.width : wMm / 2;
}

function toSvgText(value) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  draw(svg, value, barcodeOptions());
  svg.setAttribute('xmlns', SVG_NS);
  return new XMLSerializer().serializeToString(svg);
}

const canvasToPng = (canvas) => new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));

function slug(text) {
  return text
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 30);
}

/**
 * Convierte el texto en [{ line, name, value }] y los avisos por línea. El «;» o el tabulador separan
 * «nombre» de «valor» (por ejemplo, dos columnas pegadas de Excel). Los nombres de archivo quedan únicos.
 */
export function parseBarcodeList(text) {
  const items = [];
  const problems = [];
  const used = new Set();
  const format = currentFormat();

  text.split(/\r?\n/).forEach((raw, index) => {
    const line = raw.trim();
    if (!line) return;
    let name = '';
    let value = line;
    const tab = line.indexOf('\t');
    const semi = line.indexOf(';');
    if (tab > 0) {
      name = line.slice(0, tab);
      value = line.slice(tab + 1);
    } else if (semi > 0 && semi <= 60) {
      name = line.slice(0, semi);
      value = line.slice(semi + 1);
    }
    value = value.trim().replace(/^"(.*)"$/, '$1');

    if (!value) {
      problems.push({ line: index + 1, message: 'Falta el valor del código.' });
      return;
    }
    if (!isValid(value)) {
      problems.push({ line: index + 1, message: `«${value}» no es válido para ${FORMAT_LABELS[format]}. ${FORMAT_HINTS[format]}` });
      return;
    }
    if (items.length >= MAX_BARCODES) {
      problems.push({ line: index + 1, message: `Se omite: el máximo es ${MAX_BARCODES} códigos por vez.` });
      return;
    }

    const seq = String(items.length + 1).padStart(3, '0');
    const base = (name.trim() || `${seq}-${slug(value) || 'codigo'}`).replace(/[^\p{L}\p{N}._ -]+/gu, '_').slice(0, 60);
    let unique = base;
    for (let n = 2; used.has(unique.toLowerCase()); n += 1) unique = `${base}-${n}`;
    used.add(unique.toLowerCase());
    items.push({ line: index + 1, name: unique, value });
  });
  return { items, problems };
}

/** Cuadrícula de una hoja A4 para códigos de `wMm` × `hMm`: cuántas columnas y filas caben. */
function sheetLayout(wMm, hMm, withNames) {
  const usableW = PAGE_MM.w - 2 * MARGIN_MM;
  const usableH = PAGE_MM.h - 2 * MARGIN_MM - HEADER_MM;
  const cellH = hMm + (withNames ? LABEL_MM : 0);
  const cols = Math.max(0, Math.floor((usableW + GAP_MM) / (wMm + GAP_MM)));
  const rows = Math.max(0, Math.floor((usableH + GAP_MM) / (cellH + GAP_MM)));
  return { cols, rows, perPage: cols * rows };
}

function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Recorta el texto con «…» para que quepa en `maxPx`. */
function fitText(ctx, text, maxPx) {
  if (ctx.measureText(text).width <= maxPx) return text;
  let cut = text;
  while (cut.length > 1 && ctx.measureText(`${cut}…`).width > maxPx) cut = cut.slice(0, -1);
  return `${cut}…`;
}

/** PDF A4 con los códigos a `wMm` de ancho, en tantas columnas y páginas como hagan falta. */
async function buildPdf(items, wMm, withNames, title, onPage) {
  const hMax = Math.max(...items.map((item) => heightMmFor(item.value, wMm)));
  const { cols, rows, perPage } = sheetLayout(wMm, hMax, withNames);
  if (!perPage) throw new Error('Este tamaño no cabe en una hoja A4. Elige un tamaño menor.');

  const k = PRINT_PPI / MM_PER_INCH; // px por mm a resolución de impresión
  const pageW = mmToPx(PAGE_MM.w, PRINT_PPI);
  const pageH = mmToPx(PAGE_MM.h, PRINT_PPI);
  const widthPx = mmToPx(wMm, PRINT_PPI);
  const cellH = hMax + (withNames ? LABEL_MM : 0);
  const gridW = cols * wMm + (cols - 1) * GAP_MM;
  const left = (PAGE_MM.w - gridW) / 2;
  const top = MARGIN_MM + HEADER_MM;
  const pageCount = Math.ceil(items.length / perPage);
  const pages = [];

  for (let p = 0; p < pageCount; p += 1) {
    const canvas = document.createElement('canvas');
    canvas.width = pageW;
    canvas.height = pageH;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, pageW, pageH);

    ctx.fillStyle = '#6b6a7b';
    ctx.font = `${Math.round(3.5 * k)}px system-ui, "Segoe UI", Roboto, sans-serif`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(`${title} · página ${p + 1} de ${pageCount}`, MARGIN_MM * k, (MARGIN_MM + 6) * k);

    for (const [i, item] of items.slice(p * perPage, (p + 1) * perPage).entries()) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = (left + col * (wMm + GAP_MM)) * k;
      const cellTop = top + row * (cellH + GAP_MM);
      const y = cellTop * k;
      const src = renderAt(item.value, widthPx);
      ctx.drawImage(src, x, y, widthPx, src.height);
      if (withNames) {
        ctx.fillStyle = '#1a1630';
        ctx.font = `600 ${Math.round(3 * k)}px system-ui, "Segoe UI", Roboto, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(fitText(ctx, item.name, widthPx), x + widthPx / 2, (cellTop + hMax + 4) * k);
      }
    }

    const rgba = ctx.getImageData(0, 0, pageW, pageH).data;
    pages.push({ width: pageW, height: pageH, dpi: PRINT_PPI, data: await deflate(rgbFromRgba(rgba)) });
    onPage?.(p + 1, pageCount);
  }
  return makePdf(pages);
}

// ----- Panel -----

const status = $('bcm-status');
const progress = $('bcm-progress');
const problemsList = $('bcm-problems');
const previewCanvas = $('bcm-preview');
let busy = false;

const sizeMm = () => Number($('bcm-size').value);

function setStatus(message, isError = false) {
  status.textContent = message || '';
  status.hidden = !message;
  status.classList.toggle('field-error', isError);
}

function showProblems(problems) {
  problemsList.replaceChildren();
  for (const p of problems.slice(0, 20)) {
    const li = document.createElement('li');
    li.textContent = p.line ? `Línea ${p.line}: ${p.message}` : p.message;
    problemsList.append(li);
  }
  if (problems.length > 20) {
    const li = document.createElement('li');
    li.textContent = `…y ${problems.length - 20} más.`;
    problemsList.append(li);
  }
  problemsList.hidden = problems.length === 0;
}

function setBusy(value) {
  busy = value;
  for (const id of ['bcm-text', 'bcm-file', 'bcm-zip', 'bcm-pdf', 'bcm-svg', 'bcm-size', 'bcm-names']) $(id).disabled = value;
  progress.hidden = !value;
}

/** Vista previa a tamaño real del primer código y medidas en mm y px, con cuántos caben en la hoja. */
function updatePreview(items) {
  const wMm = sizeMm();
  const list = items.slice(0, MAX_BARCODES);
  const value = list[0]?.value ?? TEMPLATE_VALUES[currentFormat()]?.[0] ?? '';
  $('bcm-size-out').textContent = `${wMm} mm`;

  const wPx = mmToPx(wMm, SCREEN_PPI);
  const src = renderAt(value, wPx * 2); // doble resolución para que se vea nítido
  const hMm = (wMm * src.height) / src.width;
  const hPx = mmToPx(hMm, SCREEN_PPI);
  previewCanvas.width = src.width;
  previewCanvas.height = src.height;
  previewCanvas.style.width = `${wPx}px`;
  previewCanvas.style.height = `${hPx}px`;
  previewCanvas.getContext('2d').drawImage(src, 0, 0);
  $('bcm-dims').textContent = `Ancho ${wMm} mm = ${wPx} px · Alto ${hMm.toFixed(1)} mm = ${hPx} px (medidas a 96 ppp, como se ven en pantalla).`;

  const hMax = list.length ? Math.max(...list.map((item) => heightMmFor(item.value, wMm))) : hMm;
  const { cols, rows, perPage } = sheetLayout(wMm, hMax, $('bcm-names').checked);
  $('bcm-fit').textContent = perPage
    ? `En una hoja A4 caben ${perPage} códigos de este tamaño (${cols} columnas × ${rows} filas).${list.length ? ` Tus ${list.length} códigos ocupan ${Math.ceil(list.length / perPage)} hoja(s).` : ''}`
    : 'Este tamaño no cabe en una hoja A4. Elige uno más pequeño.';
}

/** Revisa la lista y actualiza el contador, los avisos, los botones y la vista previa. */
function refresh() {
  if (busy) return;
  const { items, problems } = parseBarcodeList($('bcm-text').value);
  showProblems(problems);
  $('bcm-count').textContent = items.length
    ? `${items.length} códigos listos${problems.length ? ` · ${problems.length} línea(s) con aviso` : ''}.`
    : '';
  $('bcm-zip').disabled = items.length === 0;
  $('bcm-pdf').disabled = items.length === 0;
  updatePreview(items);
}

const stamp = () => new Date().toISOString().slice(0, 10);
const fileBase = () => `codigos-${currentFormat().toLowerCase()}-${stamp()}`;

function listOrWarn() {
  const { items, problems } = parseBarcodeList($('bcm-text').value);
  showProblems(problems);
  if (!items.length) {
    setStatus(problems.length ? 'Ninguna línea es válida. Revisa los avisos.' : 'Escribe o pega al menos un código.', true);
    return null;
  }
  return items;
}

$('bcm-zip').addEventListener('click', async () => {
  setStatus('');
  const items = listOrWarn();
  if (!items) return;
  const withSvg = $('bcm-svg').checked;
  const pngPx = mmToPx(sizeMm(), PNG_PPI);
  setBusy(true);
  progress.max = items.length;
  progress.value = 0;
  try {
    const files = [];
    for (const [i, item] of items.entries()) {
      setStatus(`Generando ${i + 1} de ${items.length}…`);
      const blob = await canvasToPng(renderAt(item.value, pngPx));
      if (!blob) throw new Error('No se pudo generar uno de los códigos.');
      files.push({ name: `${item.name}.png`, data: new Uint8Array(await blob.arrayBuffer()) });
      if (withSvg) files.push({ name: `${item.name}.svg`, data: new TextEncoder().encode(toSvgText(item.value)) });
      progress.value = i + 1;
    }
    setStatus('Armando el .zip…');
    const bytes = makeZip(files);
    saveBlob(new Blob([bytes], { type: 'application/zip' }), `${fileBase()}.zip`);
    setStatus(`Listo: ${items.length} códigos de ${sizeMm()} mm (PNG a 300 ppp) en un .zip.`);
  } catch (err) {
    setStatus(err.message, true);
  } finally {
    setBusy(false);
    refresh();
  }
});

$('bcm-pdf').addEventListener('click', async () => {
  setStatus('');
  const items = listOrWarn();
  if (!items) return;
  setBusy(true);
  progress.max = 1;
  progress.value = 0;
  try {
    const bytes = await buildPdf(items, sizeMm(), $('bcm-names').checked, `Códigos ${FORMAT_LABELS[currentFormat()]}`, (done, total) => {
      progress.max = total;
      progress.value = done;
      setStatus(`Armando la página ${done} de ${total}…`);
    });
    saveBlob(new Blob([bytes], { type: 'application/pdf' }), `${fileBase()}.pdf`);
    setStatus(`Listo: PDF con ${items.length} códigos de ${sizeMm()} mm (${(bytes.length / 1024).toFixed(0)} KB).`);
  } catch (err) {
    setStatus(err.message, true);
  } finally {
    setBusy(false);
    refresh();
  }
});

$('bcm-template').addEventListener('click', () => {
  const format = currentFormat();
  const blob = new Blob([templateCsv(format)], { type: 'text/csv;charset=utf-8' });
  saveBlob(blob, `plantilla-codigos-${format.toLowerCase()}.csv`);
  setStatus('Plantilla descargada: cambia los datos de ejemplo, guarda el archivo como CSV y cárgalo aquí.');
});

$('bcm-file').addEventListener('change', (event) => {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (!file) return;
  if (file.size > 1024 * 1024) {
    setStatus('El archivo pesa más de 1 MB.', true);
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    $('bcm-text').value = String(reader.result ?? '');
    setStatus(`Se cargó «${file.name}». Revisa la lista y descarga los códigos.`);
    refresh();
  };
  reader.onerror = () => setStatus('No se pudo leer el archivo.', true);
  reader.readAsText(file);
});

$('bcm-text').addEventListener('input', () => {
  setStatus('');
  refresh();
});

$('bcm-size').addEventListener('input', refresh);
$('bcm-names').addEventListener('change', refresh);

// El aspecto del generador de arriba cambia la forma del código: se actualiza la vista previa.
for (const id of ['bc-width', 'bc-height', 'bc-margin', 'bc-text', 'bc-fg', 'bc-bg']) {
  $(id).addEventListener('input', refresh);
}
// Si cambia el formato de arriba, las líneas pueden dejar de ser válidas.
$('bc-format').addEventListener('change', refresh);

refresh();
