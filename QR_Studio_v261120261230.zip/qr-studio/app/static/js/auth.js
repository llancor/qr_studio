// Registro, inicio y cierre de sesión contra la API (/api/auth/*).

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) {
    throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  }
  return data;
}

// onUser(user | null) se llama cada vez que cambia la sesión (al cargar, al entrar y al salir).
export function initAuth(onUser) {
  const $ = (id) => document.getElementById(id);
  const dialog = $('auth-dialog');
  const form = $('auth-form');
  const guest = $('auth-guest');
  const userBox = $('auth-user');
  const errorEl = $('auth-error');
  const submit = $('auth-submit');
  let mode = 'login';
  let opener = null;
  // Lo que decide el administrador: ¿se puede entrar sin cuenta?, ¿hay textos legales que aceptar al crear una cuenta?
  let options = { publicAccess: false, legalConfigured: false, registrationOpen: true };

  /** Si el administrador cerró la creación de cuentas, no se ofrece «Registrarse» ni «Crear cuenta» en ninguna parte. */
  function applyRegistration() {
    const open = options.registrationOpen !== false;
    document.querySelectorAll('[data-auth-open="register"]').forEach((node) => {
      node.hidden = !open;
    });
    $('auth-switch-row').hidden = !open && mode !== 'register';
  }

  const optionsReady = api('/api/auth/options')
    .then((data) => {
      options = data;
      applyRegistration();
    })
    .catch(() => {
      /* sin conexión: se deja lo predeterminado */
    });

  function showUser(user) {
    // Marca la página como «invitado» (sin sesión): el CSS compacta la cabecera del teléfono para que quepan los botones.
    if (user) document.documentElement.removeAttribute('data-invitado');
    else document.documentElement.setAttribute('data-invitado', '');
    // Enlaces que solo ve quien tiene sesión (p. ej. «Ajustes»). admin-link.js los muestra al cargar la página, pero con
    // el acceso abierto se puede iniciar sesión sin recargarla: por eso también se ajustan aquí cada vez que cambia la sesión.
    document.querySelectorAll('[data-signed-in]').forEach((node) => {
      node.hidden = !user;
    });
    guest.hidden = Boolean(user);
    userBox.hidden = !user;
    $('user-name').textContent = user ? user.name : '';
    onUser?.(user);
  }

  function setError(message) {
    errorEl.textContent = message || '';
    errorEl.hidden = !message;
  }

  function setMode(next) {
    mode = next;
    const register = next === 'register';
    $('auth-title').textContent = register ? 'Crear cuenta' : 'Iniciar sesión';
    $('auth-name-field').hidden = !register;
    $('auth-password-hint').hidden = !register;
    $('auth-password').autocomplete = register ? 'new-password' : 'current-password';
    submit.textContent = register ? 'Crear cuenta' : 'Entrar';
    $('auth-switch-text').textContent = register ? '¿Ya tienes cuenta?' : '¿No tienes cuenta?';
    $('auth-switch').textContent = register ? 'Inicia sesión' : 'Regístrate';
    $('auth-terms-row').hidden = !(register && options.legalConfigured);
    applyRegistration();
    setError('');
  }

  function open(nextMode, trigger) {
    opener = trigger || null;
    form.reset();
    setMode(nextMode);
    dialog.showModal();
    (nextMode === 'register' ? $('auth-name') : $('auth-email')).focus();
  }

  document.querySelectorAll('[data-auth-open]').forEach((btn) => {
    btn.addEventListener('click', () => open(btn.dataset.authOpen, btn));
  });
  $('auth-switch').addEventListener('click', () => setMode(mode === 'login' ? 'register' : 'login'));
  $('auth-close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('close', () => opener?.focus?.());
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close(); // clic en el fondo
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    setError('');
    const email = $('auth-email').value.trim();
    const password = $('auth-password').value;
    const name = $('auth-name').value.trim();

    if (!email || !password || (mode === 'register' && !name)) {
      setError('Completa todos los campos.');
      return;
    }

    const acceptTerms = $('auth-terms').checked;
    if (mode === 'register' && options.legalConfigured && !acceptTerms) {
      setError('Para crear una cuenta debes aceptar los Términos de uso y el Aviso de privacidad.');
      return;
    }

    submit.disabled = true;
    try {
      const payload = mode === 'register' ? { email, name, password, acceptTerms } : { email, password };
      const data = await api(`/api/auth/${mode}`, { method: 'POST', body: payload });
      showUser(data.user);
      dialog.close();
      // El aspecto es de cada cuenta: se suelta la copia anterior de este navegador y se carga el de la cuenta que acaba
      // de entrar (sin recargar la página, para no perder lo que la persona estaba haciendo en el generador).
      window.QRTema?.olvidar();
      window.QRTema?.sincronizar();
    } catch (err) {
      setError(err.message);
    } finally {
      submit.disabled = false;
    }
  });

  $('logout-btn').addEventListener('click', async () => {
    try {
      await api('/api/auth/logout', { method: 'POST' });
    } finally {
      showUser(null);
      // El aspecto es de cada cuenta: se borra la copia de este navegador para que la siguiente persona no la vea.
      window.QRTema?.olvidar();
      // Si el sitio exige sesión, al salir se vuelve a la página de acceso; con acceso abierto se vuelve al inicio.
      window.location.assign(options.publicAccess ? '/' : '/entrar/');
    }
  });

  // Restaura la sesión al cargar la página. Si ya no es válida (caducó), se vuelve a la página de acceso.
  api('/api/auth/me')
    .then(async (data) => {
      showUser(data.user);
      if (data.user) return;
      // Sin sesión: con acceso abierto se queda como invitado; si no, se manda a la página de acceso.
      await optionsReady;
      if (!options.publicAccess) {
        window.location.replace(`/entrar/?next=${encodeURIComponent(window.location.pathname + window.location.search)}`);
      }
    })
    .catch(() => showUser(null));
}
