// Convertidor de PNG (o JPG/WebP) a .ico. Todo ocurre en el navegador: la imagen no se envía a ningún servidor.
import { PNG_FROM_SIZE, dibFromRgba, encodeIco } from './ico.js';
import { makeZip } from './zip.js';

const $ = (id) => document.getElementById(id);
const MAX_BYTES = 10 * 1024 * 1024;
const MAX_SIDE = 8192;
const ACCEPTED = new Set(['image/png', 'image/jpeg', 'image/webp']);

let source = null; // { bitmap, name }

const fileInput = $('png-file');
const dropzone = $('dropzone');
const downloadBtn = $('ico-download');
const statusEl = $('ico-status');
const errorEl = $('ico-error');

function setError(message) {
  errorEl.textContent = message || '';
  errorEl.hidden = !message;
}

function setStatus(message) {
  statusEl.textContent = message || '';
  statusEl.hidden = !message;
}

function selectedSizes() {
  return [...document.querySelectorAll('input[name="ico-size"]:checked')]
    .map((el) => Number(el.value))
    .sort((a, b) => a - b);
}

function makeCanvas(w, h) {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  return canvas;
}

// Cuadrado de lado `side` con la imagen: «contain» la deja entera con bordes transparentes;
// «cover» recorta el centro.
function squareFrom(bitmap, fit) {
  const { width, height } = bitmap;
  if (fit === 'cover') {
    const side = Math.min(width, height);
    const canvas = makeCanvas(side, side);
    canvas.getContext('2d').drawImage(bitmap, (width - side) / 2, (height - side) / 2, side, side, 0, 0, side, side);
    return canvas;
  }
  const side = Math.max(width, height);
  const canvas = makeCanvas(side, side);
  canvas.getContext('2d').drawImage(bitmap, (side - width) / 2, (side - height) / 2);
  return canvas;
}

// Reduce a la mitad tantas veces como haga falta antes del ajuste final: así los iconos pequeños
// (16, 32 px) salen nítidos y sin dientes de sierra aunque el original sea enorme.
function scaleTo(src, size) {
  let current = src;
  while (current.width / 2 >= size) {
    const half = makeCanvas(Math.floor(current.width / 2), Math.floor(current.height / 2));
    const ctx = half.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(current, 0, 0, half.width, half.height);
    current = half;
  }
  const out = makeCanvas(size, size);
  const ctx = out.getContext('2d');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(current, 0, 0, size, size);
  return out;
}

function renderSize(size) {
  return scaleTo(squareFrom(source.bitmap, $('ico-fit').value), size);
}

function renderPreviews() {
  const box = $('ico-previews');
  box.replaceChildren();
  if (!source) return;
  for (const size of selectedSizes()) {
    const canvas = renderSize(size);
    canvas.className = 'ico-thumb-canvas';
    // Los iconos pequeños se muestran ampliados (sin suavizar) para que se vean los píxeles reales.
    const shown = Math.min(Math.max(size, 48), 96);
    canvas.style.width = `${shown}px`;
    canvas.style.height = `${shown}px`;
    canvas.setAttribute('aria-hidden', 'true');
    const caption = document.createElement('span');
    caption.textContent = `${size}×${size}`;
    const item = document.createElement('div');
    item.className = 'ico-thumb';
    item.append(canvas, caption);
    box.append(item);
  }
}

function refresh() {
  renderPreviews();
  const sizes = selectedSizes();
  downloadBtn.disabled = !source || sizes.length === 0;
  $('fav-download').disabled = !source;
  const small = source && Math.max(source.bitmap.width, source.bitmap.height) < (sizes[sizes.length - 1] ?? 0);
  $('ico-small').hidden = !small;
  if (source && sizes.length === 0) setStatus('Marca al menos un tamaño.');
  else if (source && statusEl.textContent === 'Marca al menos un tamaño.') setStatus('');
}

async function loadFile(file) {
  setError('');
  setStatus('');
  if (!file) return;
  if (!ACCEPTED.has(file.type)) {
    setError('Formato no admitido. Usa un PNG (también se aceptan JPG y WebP).');
    return;
  }
  if (file.size > MAX_BYTES) {
    setError('La imagen pesa más de 10 MB.');
    return;
  }
  try {
    const bitmap = await createImageBitmap(file);
    if (bitmap.width > MAX_SIDE || bitmap.height > MAX_SIDE) {
      setError(`La imagen es demasiado grande (máximo ${MAX_SIDE} × ${MAX_SIDE} px).`);
      return;
    }
    source?.bitmap.close?.();
    source = { bitmap, name: file.name.replace(/\.[^.]+$/, '') || 'icono' };
    $('dropzone-title').textContent = file.name;
    $('dropzone-hint').textContent = `${bitmap.width} × ${bitmap.height} px · pulsa para cambiar la imagen`;
    refresh();
  } catch {
    setError('No se pudo abrir la imagen: el archivo está dañado o no es una imagen válida.');
  }
}

async function buildIcoFile(sizes = selectedSizes()) {
  const entries = [];
  for (const size of sizes) {
    const canvas = renderSize(size);
    let data;
    if (size >= PNG_FROM_SIZE) {
      const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
      if (!blob) throw new Error('No se pudo codificar el PNG.');
      data = new Uint8Array(await blob.arrayBuffer());
    } else {
      const { data: rgba } = canvas.getContext('2d').getImageData(0, 0, size, size);
      data = dibFromRgba(rgba, size, size);
    }
    entries.push({ size, data });
  }
  return encodeIco(entries);
}

// ---------- Paquete de favicon (ZIP) ----------

const FAVICON_SNIPPET = [
  '<link rel="icon" href="/favicon.ico" sizes="any">',
  '<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">',
  '<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">',
  '<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">',
  '<link rel="manifest" href="/site.webmanifest">',
].join('\n');

// [archivo, lado en píxeles]: lo que piden los navegadores, iOS y Android.
const FAVICON_PNGS = [
  ['favicon-16x16.png', 16],
  ['favicon-32x32.png', 32],
  ['apple-touch-icon.png', 180],
  ['android-chrome-192x192.png', 192],
  ['android-chrome-512x512.png', 512],
];

async function canvasPng(canvas) {
  const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/png'));
  if (!blob) throw new Error('No se pudo codificar el PNG.');
  return new Uint8Array(await blob.arrayBuffer());
}

async function buildFaviconZip() {
  const encoder = new TextEncoder();
  const files = [{ name: 'favicon.ico', data: await buildIcoFile([16, 32, 48]) }];
  for (const [name, size] of FAVICON_PNGS) files.push({ name, data: await canvasPng(renderSize(size)) });
  const manifest = {
    name: source.name,
    short_name: source.name,
    icons: [
      { src: '/android-chrome-192x192.png', sizes: '192x192', type: 'image/png' },
      { src: '/android-chrome-512x512.png', sizes: '512x512', type: 'image/png' },
    ],
    theme_color: '#ffffff',
    background_color: '#ffffff',
    display: 'standalone',
  };
  files.push({ name: 'site.webmanifest', data: encoder.encode(`${JSON.stringify(manifest, null, 2)}\n`) });
  files.push({
    name: 'LEEME.txt',
    data: encoder.encode(
      `Copia estos archivos a la carpeta raíz de tu sitio web y pega esto dentro de <head> en tus páginas:\r\n\r\n${FAVICON_SNIPPET.replaceAll('\n', '\r\n')}\r\n`,
    ),
  });
  return makeZip(files);
}

function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

$('fav-snippet').textContent = FAVICON_SNIPPET;

$('fav-download').addEventListener('click', async () => {
  setError('');
  try {
    const bytes = await buildFaviconZip();
    saveBlob(new Blob([bytes], { type: 'application/zip' }), `favicon-${source.name}.zip`);
    setStatus(`Listo: favicon-${source.name}.zip con el .ico, 5 PNG, el manifiesto y el fragmento HTML (${(bytes.length / 1024).toFixed(1)} KB).`);
  } catch (err) {
    console.error(err);
    setError('No se pudo crear el paquete. Prueba con otra imagen.');
  }
});

$('fav-copy').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(FAVICON_SNIPPET);
    setStatus('Fragmento HTML copiado.');
  } catch {
    setStatus('No se pudo copiar automáticamente: selecciona el texto y cópialo.');
  }
});

fileInput.addEventListener('change', () => loadFile(fileInput.files?.[0]));

for (const el of document.querySelectorAll('input[name="ico-size"]')) el.addEventListener('change', refresh);
$('ico-fit').addEventListener('change', refresh);

// Arrastrar y soltar sobre la zona de carga.
for (const type of ['dragenter', 'dragover']) {
  dropzone.addEventListener(type, (event) => {
    event.preventDefault();
    dropzone.classList.add('is-over');
  });
}
for (const type of ['dragleave', 'drop']) {
  dropzone.addEventListener(type, (event) => {
    event.preventDefault();
    dropzone.classList.remove('is-over');
  });
}
dropzone.addEventListener('drop', (event) => loadFile(event.dataTransfer?.files?.[0]));

downloadBtn.addEventListener('click', async () => {
  setError('');
  try {
    const bytes = await buildIcoFile();
    const blob = new Blob([bytes], { type: 'image/vnd.microsoft.icon' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${source.name}.ico`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatus(`Listo: ${source.name}.ico con ${selectedSizes().length} tamaños (${(bytes.length / 1024).toFixed(1)} KB).`);
  } catch (err) {
    console.error(err);
    setError('No se pudo crear el icono. Prueba con otra imagen.');
  }
});

$('year').textContent = new Date().getFullYear();
refresh();
