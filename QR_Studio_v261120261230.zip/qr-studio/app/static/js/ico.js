// Codificador del formato .ico (sin dependencias del DOM, se puede probar en Node).
//
// Un .ico es: cabecera de 6 bytes (ICONDIR) + una entrada de 16 bytes por imagen (ICONDIRENTRY) +
// los datos de cada imagen. Para máxima compatibilidad (Windows, navegadores, editores antiguos)
// los tamaños menores de 256 px se guardan como mapa de bits (DIB de 32 bits con transparencia) y
// el de 256 px como PNG, que es lo que hace el propio Windows.

export const PNG_FROM_SIZE = 256;

/**
 * Convierte píxeles RGBA (de arriba abajo) en el DIB que va dentro de un .ico:
 * BITMAPINFOHEADER (la altura es el doble: imagen + máscara) + píxeles BGRA de abajo arriba +
 * máscara AND de 1 bit (todo a 0: la transparencia la da el canal alfa).
 */
export function dibFromRgba(rgba, width, height) {
  if (rgba.length !== width * height * 4) throw new Error('Tamaño de píxeles inesperado.');
  const maskRow = ((width + 31) >> 5) << 2;
  const pixelBytes = width * height * 4;
  const out = new Uint8Array(40 + pixelBytes + maskRow * height);
  const dv = new DataView(out.buffer);
  dv.setUint32(0, 40, true); // biSize
  dv.setInt32(4, width, true);
  dv.setInt32(8, height * 2, true);
  dv.setUint16(12, 1, true); // planos
  dv.setUint16(14, 32, true); // bits por píxel
  dv.setUint32(20, pixelBytes + maskRow * height, true); // biSizeImage
  let p = 40;
  for (let y = height - 1; y >= 0; y -= 1) {
    for (let x = 0; x < width; x += 1) {
      const s = (y * width + x) * 4;
      out[p] = rgba[s + 2]; // B
      out[p + 1] = rgba[s + 1]; // G
      out[p + 2] = rgba[s]; // R
      out[p + 3] = rgba[s + 3]; // A
      p += 4;
    }
  }
  return out;
}

/** entries: [{ size, data: Uint8Array }] (size = lado en píxeles, 1..256). Devuelve el .ico. */
export function encodeIco(entries) {
  if (!entries.length) throw new Error('Elige al menos un tamaño.');
  const header = 6 + 16 * entries.length;
  const total = entries.reduce((sum, e) => sum + e.data.length, header);
  const out = new Uint8Array(total);
  const dv = new DataView(out.buffer);
  dv.setUint16(0, 0, true); // reservado
  dv.setUint16(2, 1, true); // tipo: icono
  dv.setUint16(4, entries.length, true);
  let offset = header;
  entries.forEach((e, i) => {
    if (e.size < 1 || e.size > 256) throw new Error(`Tamaño no válido: ${e.size}`);
    const p = 6 + 16 * i;
    const side = e.size === 256 ? 0 : e.size; // 0 significa 256
    out[p] = side;
    out[p + 1] = side;
    out[p + 2] = 0; // sin paleta
    out[p + 3] = 0;
    dv.setUint16(p + 4, 1, true); // planos
    dv.setUint16(p + 6, 32, true); // bits por píxel
    dv.setUint32(p + 8, e.data.length, true);
    dv.setUint32(p + 12, offset, true);
    out.set(e.data, offset);
    offset += e.data.length;
  });
  return out;
}
