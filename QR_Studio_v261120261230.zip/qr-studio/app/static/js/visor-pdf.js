// Visor de PDF a pantalla completa para la página pública. Usa PDF.js (guardado en /vendor, sin CDN),
// dibuja solo las páginas que se ven y permite acercar o alejar. Se carga solo al tocar un botón de PDF.
// Los PDF no pueden ejecutar scripts aquí: PDF.js se usa con isEvalSupported desactivado.

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (window.pdfjsLib) return resolve();
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = () => reject(new Error(`No se pudo cargar ${src}`));
    document.head.append(script);
  });
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

const MAX_PAGES = 200;
const MAX_CANVAS_PIXELS = 16_000_000;

export async function openPdf({ url, title, downloadUrl }) {
  if (document.querySelector('.visor')) return;
  const opener = document.activeElement;

  const root = el('div', 'visor');
  root.setAttribute('role', 'dialog');
  root.setAttribute('aria-modal', 'true');
  root.setAttribute('aria-label', title || 'Documento PDF');

  const bar = el('div', 'visor-barra');
  const heading = el('span', 'visor-titulo', title || 'Documento');
  const zoomOut = el('button', 'visor-btn', '−');
  zoomOut.type = 'button';
  zoomOut.setAttribute('aria-label', 'Alejar');
  const zoomIn = el('button', 'visor-btn', '+');
  zoomIn.type = 'button';
  zoomIn.setAttribute('aria-label', 'Acercar');
  const download = el('a', 'visor-btn', 'Descargar');
  download.href = downloadUrl;
  const close = el('button', 'visor-btn', 'Cerrar');
  close.type = 'button';
  bar.append(heading, zoomOut, zoomIn, download, close);

  const area = el('div', 'visor-paginas');
  const status = el('p', 'visor-estado', 'Abriendo el documento…');
  area.append(status);
  root.append(bar, area);

  const previousOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';
  document.body.append(root);
  close.focus();

  let destroyed = false;
  let observer = null;
  const tasks = new Set();

  function shut() {
    destroyed = true;
    observer?.disconnect();
    for (const task of tasks) task.cancel?.();
    root.remove();
    document.body.style.overflow = previousOverflow;
    document.removeEventListener('keydown', onKey);
    opener?.focus?.();
  }
  function onKey(event) {
    if (event.key === 'Escape') shut();
  }
  close.addEventListener('click', shut);
  document.addEventListener('keydown', onKey);

  try {
    await loadScript('/vendor/pdf.min.js');
    const lib = window.pdfjsLib;
    lib.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.js';
    const pdf = await lib.getDocument({ url, isEvalSupported: false }).promise;
    if (destroyed) return;

    const count = Math.min(pdf.numPages, MAX_PAGES);
    const pages = await Promise.all(Array.from({ length: count }, (_, i) => pdf.getPage(i + 1)));
    if (destroyed) return;
    const sizes = pages.map((page) => page.getViewport({ scale: 1 }));

    area.replaceChildren();
    const canvases = pages.map((_, index) => {
      const canvas = el('canvas', 'visor-pagina');
      canvas.setAttribute('role', 'img');
      canvas.setAttribute('aria-label', `Página ${index + 1} de ${count}`);
      area.append(canvas);
      return canvas;
    });

    let zoom = 1;
    const fitWidth = () => Math.min(Math.max(area.clientWidth - 16, 240), 900);

    async function paint(index) {
      const canvas = canvases[index];
      if (destroyed || canvas.dataset.zoom === String(zoom)) return;
      canvas.dataset.zoom = String(zoom);
      const cssWidth = fitWidth() * zoom;
      const base = sizes[index];
      let ratio = (cssWidth / base.width) * Math.min(window.devicePixelRatio || 1, 2);
      const pixels = base.width * ratio * base.height * ratio;
      if (pixels > MAX_CANVAS_PIXELS) ratio *= Math.sqrt(MAX_CANVAS_PIXELS / pixels);
      const viewport = pages[index].getViewport({ scale: ratio });
      canvas.width = Math.floor(viewport.width);
      canvas.height = Math.floor(viewport.height);
      const task = pages[index].render({ canvasContext: canvas.getContext('2d'), viewport });
      tasks.add(task);
      try {
        await task.promise;
      } catch {
        canvas.dataset.zoom = ''; // se canceló al cambiar el zoom: se volverá a dibujar
      } finally {
        tasks.delete(task);
      }
    }

    function layout() {
      observer?.disconnect();
      for (const task of tasks) task.cancel?.();
      const width = fitWidth() * zoom;
      canvases.forEach((canvas, index) => {
        canvas.dataset.zoom = '';
        canvas.style.width = `${width}px`;
        canvas.style.height = `${(width / sizes[index].width) * sizes[index].height}px`;
      });
      observer = new IntersectionObserver(
        (entries) => {
          for (const entry of entries) if (entry.isIntersecting) paint(canvases.indexOf(entry.target));
        },
        { root: area, rootMargin: '700px 0px' },
      );
      canvases.forEach((canvas) => observer.observe(canvas));
    }

    const setZoom = (value) => {
      zoom = Math.min(3, Math.max(0.5, value));
      layout();
    };
    zoomOut.addEventListener('click', () => setZoom(zoom - 0.25));
    zoomIn.addEventListener('click', () => setZoom(zoom + 0.25));
    layout();
  } catch (error) {
    console.error(error);
    if (destroyed) return;
    area.replaceChildren();
    const message = el('p', 'visor-estado', 'No se pudo abrir el documento aquí. ');
    const link = el('a', '', 'Descárgalo');
    link.href = downloadUrl;
    message.append(link, '.');
    area.append(message);
  }
}
