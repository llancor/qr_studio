// Hoja de QR para imprimir (PDF), generada en el navegador y sin librerías.
// Cada página A4 se dibuja en un <canvas> (a 200 ppp) y se guarda en el PDF como una imagen RGB
// sin pérdida (FlateDecode): los QR salen nítidos y sin artefactos de compresión.

const DPI = 200;
const PAGE_W = 1654; // A4 a 200 ppp
const PAGE_H = 2339;
const MARGIN = 118; // ~1,5 cm
const HEADER = 70;

/** Comprime con zlib («deflate»), el formato que espera FlateDecode. */
export async function deflate(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/** RGBA (ImageData) -> RGB. */
export function rgbFromRgba(rgba) {
  const out = new Uint8Array((rgba.length / 4) * 3);
  for (let i = 0, j = 0; i < rgba.length; i += 4, j += 3) {
    out[j] = rgba[i];
    out[j + 1] = rgba[i + 1];
    out[j + 2] = rgba[i + 2];
  }
  return out;
}

/** pages: [{ width, height, dpi, data: Uint8Array (RGB comprimido con deflate) }] -> Uint8Array (PDF). */
export function makePdf(pages) {
  const encoder = new TextEncoder();
  const chunks = [];
  const offsets = [];
  let size = 0;
  const push = (part) => {
    const bytes = typeof part === 'string' ? encoder.encode(part) : part;
    chunks.push(bytes);
    size += bytes.length;
  };
  const object = (number, parts) => {
    offsets[number] = size;
    push(`${number} 0 obj\n`);
    for (const part of parts) push(part);
    push('\nendobj\n');
  };
  const points = (px, dpi) => ((px * 72) / dpi).toFixed(2);

  push('%PDF-1.4\n');
  push(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a])); // comentario binario: marca el archivo como binario
  object(1, ['<< /Type /Catalog /Pages 2 0 R >>']);
  object(2, [`<< /Type /Pages /Count ${pages.length} /Kids [${pages.map((_, i) => `${3 + 3 * i} 0 R`).join(' ')}] >>`]);
  pages.forEach((page, i) => {
    const pageObj = 3 + 3 * i;
    const w = points(page.width, page.dpi);
    const h = points(page.height, page.dpi);
    const content = `q ${w} 0 0 ${h} 0 0 cm /Im0 Do Q`;
    object(pageObj, [`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${w} ${h}] /Resources << /XObject << /Im0 ${pageObj + 2} 0 R >> >> /Contents ${pageObj + 1} 0 R >>`]);
    object(pageObj + 1, [`<< /Length ${content.length} >>\nstream\n${content}\nendstream`]);
    object(pageObj + 2, [
      `<< /Type /XObject /Subtype /Image /Width ${page.width} /Height ${page.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ${page.data.length} >>\nstream\n`,
      page.data,
      '\nendstream',
    ]);
  });
  const total = 3 + 3 * pages.length;
  const xrefAt = size;
  push(`xref\n0 ${total}\n0000000000 65535 f \n`);
  for (let n = 1; n < total; n += 1) push(`${String(offsets[n]).padStart(10, '0')} 00000 n \n`);
  push(`trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xrefAt}\n%%EOF\n`);

  const out = new Uint8Array(size);
  let p = 0;
  for (const chunk of chunks) {
    out.set(chunk, p);
    p += chunk.length;
  }
  return out;
}

function fitText(ctx, text, maxWidth) {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let cut = text;
  while (cut.length > 1 && ctx.measureText(`${cut}…`).width > maxWidth) cut = cut.slice(0, -1);
  return `${cut}…`;
}

/**
 * items: [{ bitmap: ImageBitmap|canvas, name }] -> PDF (Uint8Array) con los QR en cuadrícula sobre
 * páginas A4. Cada QR (con o sin marco) se ajusta a su casilla sin deformarse.
 */
export async function buildSheetPdf(items, { title = '', columns = 3, showNames = true } = {}) {
  const cols = Math.min(6, Math.max(1, Math.floor(columns)));
  const cellW = (PAGE_W - 2 * MARGIN) / cols;
  const box = Math.floor(cellW * 0.88);
  const labelH = showNames ? 52 : 0;
  const rowH = box + labelH + 36;
  const rows = Math.max(1, Math.floor((PAGE_H - 2 * MARGIN - HEADER) / rowH));
  const perPage = cols * rows;
  const pageCount = Math.max(1, Math.ceil(items.length / perPage));
  const pages = [];

  for (let p = 0; p < pageCount; p += 1) {
    const canvas = document.createElement('canvas');
    canvas.width = PAGE_W;
    canvas.height = PAGE_H;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, PAGE_W, PAGE_H);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    ctx.fillStyle = '#6b6a7b';
    ctx.font = '30px system-ui, "Segoe UI", Roboto, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(`${title}${title ? ' · ' : ''}página ${p + 1} de ${pageCount}`, MARGIN, MARGIN - 20);

    items.slice(p * perPage, (p + 1) * perPage).forEach((item, k) => {
      const col = k % cols;
      const row = Math.floor(k / cols);
      const x0 = MARGIN + col * cellW + (cellW - box) / 2;
      const y0 = MARGIN + HEADER + row * rowH;
      const scale = Math.min(box / item.bitmap.width, box / item.bitmap.height);
      const dw = item.bitmap.width * scale;
      const dh = item.bitmap.height * scale;
      ctx.drawImage(item.bitmap, x0 + (box - dw) / 2, y0 + (box - dh) / 2, dw, dh);
      if (showNames) {
        ctx.fillStyle = '#1a1630';
        ctx.font = '600 28px system-ui, "Segoe UI", Roboto, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(fitText(ctx, item.name.replace(/\.png$/i, ''), box), x0 + box / 2, y0 + box + 38);
      }
    });

    const rgba = ctx.getImageData(0, 0, PAGE_W, PAGE_H).data;
    pages.push({ width: PAGE_W, height: PAGE_H, dpi: DPI, data: await deflate(rgbFromRgba(rgba)) });
  }
  return makePdf(pages);
}
