// Restablecer la contraseña con el enlace que llegó por correo (/restablecer/?token=...).
// Es pública: quien la usa no tiene sesión. El servidor comprueba el token, que caduca y sirve una sola vez.

const $ = (id) => document.getElementById(id);

const params = new URLSearchParams(window.location.search);
const token = params.get('token') || '';
// El token no tiene por qué quedarse en la barra de direcciones ni en el historial.
if (token) window.history.replaceState(null, '', window.location.pathname);

function setError(message) {
  $('rs-error').textContent = message || '';
  $('rs-error').hidden = !message;
}

async function api(path, body) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  return data;
}

if (!token) {
  $('rs-form').hidden = true;
  $('rs-lead').textContent = 'Este enlace no es válido. Pide uno nuevo desde «¿Olvidaste tu contraseña?» en la página de acceso.';
}

$('rs-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  setError('');
  const password = $('rs-password').value;
  if (password !== $('rs-confirm').value) {
    setError('Las contraseñas no coinciden.');
    return;
  }
  if (!password) {
    setError('Escribe la contraseña nueva.');
    return;
  }
  $('rs-submit').disabled = true;
  try {
    await api('/api/auth/reset', { token, password });
    $('rs-form').hidden = true;
    $('rs-lead').textContent = '';
    $('rs-done').textContent = 'Listo: tu contraseña cambió. Entra con la nueva.';
    $('rs-done').hidden = false;
    $('rs-back').textContent = 'Ir a entrar';
    $('rs-back').focus();
  } catch (err) {
    setError(err.message);
    $('rs-submit').disabled = false;
  }
});

$('year').textContent = new Date().getFullYear();
