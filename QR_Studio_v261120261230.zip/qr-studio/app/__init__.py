"""QR Studio: generador de códigos QR con cuentas de usuario."""
