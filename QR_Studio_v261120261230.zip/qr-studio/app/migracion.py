"""Migración de la configuración: exportar a un archivo y volver a importarlo (en otra instalación o en esta).

Qué lleva el archivo: si se pueden crear cuentas, el servidor SMTP, la marca del sitio (nombre, colores,
logo), la imagen de la página de acceso y, solo si se pide, los usuarios con su contraseña protegida (el hash, nunca
la contraseña) y su aspecto. La contraseña del SMTP también es opcional. NO lleva datos de uso: QR guardados, QR
dinámicos, páginas ni la portada de cada cuenta (eso es el respaldo completo del instalador).

El archivo SIEMPRE sale cifrado con una contraseña que elige quien exporta, y hace falta la misma para importarlo
(sin ella no se puede abrir ni recuperar). Cifrado: AES-256-GCM (librería «cryptography») con una clave derivada de
la contraseña con scrypt y una sal aleatoria. GCM además detecta si el archivo se tocó. La cabecera (formato,
versión, fecha, parámetros) va en claro y queda autenticada junto con los datos.

Importar nunca borra nada: aplica lo que trae el archivo, añade los usuarios que faltan y se salta los que ya
existen. Todo se valida con las mismas reglas que la página; si algo no vale, no se aplica nada.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
import re
import sqlite3
from datetime import datetime, timezone

from . import admin, auth, mail, marca, prefs
from .prefs import PrefsError

FORMAT = "qr-studio-migration"  # el contenido en claro (lo que se cifra y lo que `apply` entiende)
ENCRYPTED_FORMAT = "qr-studio-migration-encrypted"  # el archivo que se descarga
VERSION = 1
MAX_USERS = 500
MAX_FILE_BYTES = 12 * 1024 * 1024  # el archivo entero (con imágenes en base64)
MIN_PASSWORD = 10
MAX_PASSWORD = 128

# Derivación de la clave (scrypt). Al abrir un archivo ajeno se aceptan estos parámetros solo dentro de un rango
# razonable, para que nadie pueda pedir un coste que agote la memoria o el tiempo del servidor.
KDF_N, KDF_R, KDF_P = 2**15, 8, 1
_MAXMEM = 96 * 1024 * 1024

_EMAIL = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,63}$")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ----- Cifrado con contraseña -----------------------------------------------------------------------------

def _aesgcm(key: bytes):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        raise PrefsError(
            503, "Falta la librería «cryptography» en el servidor (pip install -r requirements.txt) y reiniciar."
        ) from None
    return AESGCM(key)


def check_password(password: object) -> str:
    if not isinstance(password, str) or not MIN_PASSWORD <= len(password) <= MAX_PASSWORD:
        raise PrefsError(422, f"La contraseña de la migración debe tener entre {MIN_PASSWORD} y {MAX_PASSWORD} caracteres.")
    return password


def _key(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=n, r=r, p=p, maxmem=_MAXMEM, dklen=32)


def _aad(header: dict) -> bytes:
    """Lo que GCM autentica además de los datos: la cabecera completa, en una forma fija."""
    return json.dumps(header, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")


def seal(data: dict, password: str) -> dict:
    """Cifra una migración (el dict de `export`) con la contraseña y devuelve el archivo (dict JSON)."""
    check_password(password)
    salt, nonce = os.urandom(16), os.urandom(12)
    header = {
        "format": ENCRYPTED_FORMAT,
        "version": VERSION,
        "created": data.get("created", _now()),
        "app": data.get("app", ""),
        "kdf": {"name": "scrypt", "n": KDF_N, "r": KDF_R, "p": KDF_P, "salt": base64.b64encode(salt).decode("ascii")},
        "cipher": {"name": "AES-256-GCM", "nonce": base64.b64encode(nonce).decode("ascii")},
    }
    plain = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    cipher = _aesgcm(_key(password, salt, KDF_N, KDF_R, KDF_P)).encrypt(nonce, plain, _aad(header))
    return {**header, "data": base64.b64encode(cipher).decode("ascii")}


def _unb64(value: object, what: str, low: int, high: int) -> bytes:
    if not isinstance(value, str):
        raise PrefsError(422, f"El archivo está dañado ({what}).")
    try:
        raw = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error):
        raise PrefsError(422, f"El archivo está dañado ({what}).") from None
    if not low <= len(raw) <= high:
        raise PrefsError(422, f"El archivo está dañado ({what}).")
    return raw


def unseal(archivo: object, password: object) -> dict:
    """Abre un archivo de migración cifrado. Falla con un mensaje claro si no lo es, si está dañado o si la
    contraseña no es la correcta."""
    if not isinstance(archivo, dict):
        raise PrefsError(422, "Este archivo no es una migración de QR Studio.")
    if archivo.get("format") == FORMAT:
        raise PrefsError(
            422,
            "Este archivo no está cifrado. Por seguridad ya no se importan así: vuelve a exportarlo desde Ajustes → Migración, con contraseña.",
        )
    if archivo.get("format") != ENCRYPTED_FORMAT:
        raise PrefsError(422, "Este archivo no es una migración de QR Studio.")
    version = archivo.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise PrefsError(422, "El archivo no indica su versión.")
    if version > VERSION:
        raise PrefsError(422, "Este archivo es de una versión más nueva de QR Studio. Actualiza este servidor primero.")
    if not isinstance(password, str) or not password:
        raise PrefsError(422, "Escribe la contraseña de la migración.")

    kdf, cipher = archivo.get("kdf"), archivo.get("cipher")
    if not isinstance(kdf, dict) or not isinstance(cipher, dict) or kdf.get("name") != "scrypt" or cipher.get("name") != "AES-256-GCM":
        raise PrefsError(422, "El archivo usa un cifrado que este servidor no conoce.")
    n, r, p = kdf.get("n"), kdf.get("r"), kdf.get("p")
    if not all(isinstance(v, int) and not isinstance(v, bool) for v in (n, r, p)) or not (
        n & (n - 1) == 0 and 4096 <= n <= 32768 and 1 <= r <= 8 and 1 <= p <= 2
    ):
        raise PrefsError(422, "El archivo está dañado (parámetros de cifrado).")
    salt = _unb64(kdf.get("salt"), "sal", 8, 64)
    nonce = _unb64(cipher.get("nonce"), "nonce", 12, 12)
    data = _unb64(archivo.get("data"), "datos", 16, MAX_FILE_BYTES)

    header = {k: v for k, v in archivo.items() if k != "data"}
    try:
        from cryptography.exceptions import InvalidTag
    except ImportError:
        raise PrefsError(503, "Falta la librería «cryptography» en el servidor (pip install -r requirements.txt).") from None
    try:
        plain = _aesgcm(_key(password, salt, n, r, p)).decrypt(nonce, data, _aad(header))
    except InvalidTag:
        raise PrefsError(422, "La contraseña no es correcta, o el archivo está dañado.") from None
    try:
        return json.loads(plain)
    except ValueError:
        raise PrefsError(422, "El archivo está dañado.") from None


# ----- Exportar ---------------------------------------------------------------------------------------

def _b64(data: bytes, mime: str) -> dict:
    return {"mime": mime, "data": base64.b64encode(data).decode("ascii")}


def export(
    conn: sqlite3.Connection,
    *,
    registration_default: bool,
    app_version: str,
    include_users: bool = False,
    include_smtp_password: bool = False,
) -> dict:
    out: dict = {
        "format": FORMAT,
        "version": VERSION,
        "created": _now(),
        "app": app_version,
        "includes": {"users": include_users, "smtpPassword": include_smtp_password},
        "settings": {"registrationOpen": admin.registration_open(conn, registration_default)},
        "smtp": mail.export_config(conn, include_smtp_password),
    }

    brand = marca.get(conn)
    logo = marca.get_logo(conn)
    out["brand"] = {
        "name": brand["name"],
        "card": brand["card"],
        "text": brand["text"],
        "accent": brand["accent"],
        "logo": _b64(*logo) if logo else None,
    }

    login = prefs.login_get(conn)
    image = prefs.login_get_image(conn)
    out["login"] = {
        **{k: login[k] for k in prefs.LOGIN_DEFAULTS},
        "image": _b64(*image) if image else None,
    }

    if include_users:
        users = []
        for row in conn.execute(
            "SELECT u.email, u.name, u.role, u.active, u.password_hash, p.prefs "
            "FROM users u LEFT JOIN user_prefs p ON p.user_id = u.id ORDER BY u.id"
        ):
            try:
                look = json.loads(row["prefs"]) if row["prefs"] else None
            except ValueError:
                look = None
            users.append(
                {
                    "email": row["email"],
                    "name": row["name"],
                    "role": row["role"],
                    "active": bool(row["active"]),
                    "hash": row["password_hash"],
                    "prefs": look,
                }
            )
        out["users"] = users
    return out


# ----- Importar -----------------------------------------------------------------------------------------

def _decode_image(what: str, obj: object) -> bytes:
    if not isinstance(obj, dict) or not isinstance(obj.get("data"), str):
        raise PrefsError(422, f"La imagen de «{what}» del archivo no es válida.")
    try:
        return base64.b64decode(obj["data"], validate=True)
    except (ValueError, binascii.Error):
        raise PrefsError(422, f"La imagen de «{what}» del archivo está dañada.") from None


def _section(data: dict, key: str) -> dict | None:
    value = data.get(key)
    if value is None:
        return None
    if not isinstance(value, dict):
        raise PrefsError(422, f"La sección «{key}» del archivo no es válida.")
    return value


def _clean_user(raw: object) -> dict:
    if not isinstance(raw, dict):
        raise PrefsError(422, "Un usuario del archivo no es válido.")
    email = raw.get("email")
    name = raw.get("name")
    if not isinstance(email, str) or not _EMAIL.match(email.strip().lower()):
        raise PrefsError(422, "Un usuario del archivo tiene un correo no válido.")
    if not isinstance(name, str) or not 1 <= len(name.strip()) <= 80:
        raise PrefsError(422, f"El usuario {email} tiene un nombre no válido.")
    if raw.get("role") not in admin.ROLES:
        raise PrefsError(422, f"El usuario {email} tiene un rol no válido.")
    if not isinstance(raw.get("active"), bool):
        raise PrefsError(422, f"El usuario {email} no indica si está activo.")
    if not auth.is_valid_hash(raw.get("hash")):
        raise PrefsError(422, f"La contraseña protegida de {email} no es válida.")
    look = None
    if isinstance(raw.get("prefs"), dict):
        try:
            look = prefs.clean(raw["prefs"])
        except PrefsError:
            look = None  # un aspecto dañado no impide importar al usuario
    return {
        "email": email.strip().lower(),
        "name": name.strip(),
        "role": raw["role"],
        "active": raw["active"],
        "hash": raw["hash"],
        "prefs": look,
    }


def apply(conn: sqlite3.Connection, data: object, *, first_run: bool = False) -> dict:
    """Aplica una migración dentro de la transacción de `conn` y devuelve un resumen de lo que hizo.

    Lanza PrefsError / MailError con un mensaje claro si algo no vale: quien llama revierte la transacción.
    `first_run`: instalación sin ninguna cuenta; si el archivo trae usuarios, debe haber un administrador activo."""
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        raise PrefsError(422, "Este archivo no es una migración de QR Studio.")
    version = data.get("version")
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise PrefsError(422, "El archivo no indica su versión.")
    if version > VERSION:
        raise PrefsError(422, "Este archivo es de una versión más nueva de QR Studio. Actualiza este servidor primero.")

    report = {
        "registrationOpen": None,
        "smtp": False,
        "smtpPassword": False,
        "brand": False,
        "logo": False,
        "loginImage": False,
        "loginImageFile": False,
        "usersAdded": 0,
        "usersSkipped": 0,
    }

    settings = _section(data, "settings")
    if settings is not None and "registrationOpen" in settings:
        if not isinstance(settings["registrationOpen"], bool):
            raise PrefsError(422, "«registrationOpen» debe ser verdadero o falso.")
        admin.set_registration_open(conn, settings["registrationOpen"])
        report["registrationOpen"] = settings["registrationOpen"]

    smtp = _section(data, "smtp")
    if smtp is not None:
        password = smtp.get("password")
        if password is not None and not isinstance(password, str):
            raise PrefsError(422, "La contraseña del correo del archivo no es válida.")
        port = smtp.get("port")
        if isinstance(port, bool) or not isinstance(port, int):
            raise PrefsError(422, "El puerto del correo del archivo no es válido.")
        mail.save(
            conn,
            host=str(smtp.get("host", "")),
            port=port,
            security=str(smtp.get("security", "")),
            user=str(smtp.get("user", "")),
            password=password or None,  # sin contraseña en el archivo se conserva la que ya hubiera
            clear_password=False,
            sender=str(smtp.get("sender", "")).strip().lower(),
            sender_name=str(smtp.get("senderName", "")),
            site=str(smtp.get("siteUrl", "")),
        )
        report["smtp"] = True
        report["smtpPassword"] = bool(password)

    brand = _section(data, "brand")
    if brand is not None:
        marca.save(conn, {k: brand[k] for k in ("name", "card", "text", "accent") if k in brand})
        report["brand"] = True
        if brand.get("logo") is not None:
            marca.set_logo(conn, _decode_image("logo", brand["logo"]))
            report["logo"] = True

    login = _section(data, "login")
    if login is not None:
        prefs.login_save_settings(conn, {k: login[k] for k in prefs.LOGIN_DEFAULTS if k in login})
        report["loginImage"] = True
        if login.get("image") is not None:
            prefs.login_set_image(conn, _decode_image("página de acceso", login["image"]))
            report["loginImageFile"] = True

    if "users" in data and data["users"] is not None:
        raw_users = data["users"]
        if not isinstance(raw_users, list):
            raise PrefsError(422, "La sección «users» del archivo no es válida.")
        if len(raw_users) > MAX_USERS:
            raise PrefsError(422, f"El archivo trae demasiados usuarios (máximo {MAX_USERS}).")
        users = [_clean_user(u) for u in raw_users]
        if first_run and users and not any(u["role"] == "admin" and u["active"] for u in users):
            raise PrefsError(422, "El archivo trae usuarios pero ningún administrador activo: nadie podría entrar a Ajustes.")
        seen: set[str] = {row["email"] for row in conn.execute("SELECT email FROM users")}
        now = _now()
        for user in users:
            if user["email"] in seen:
                report["usersSkipped"] += 1
                continue
            seen.add(user["email"])
            cur = conn.execute(
                "INSERT INTO users (email, name, password_hash, created_at, role, active) VALUES (?, ?, ?, ?, ?, ?)",
                (user["email"], user["name"], user["hash"], now, user["role"], 1 if user["active"] else 0),
            )
            if user["prefs"] is not None:
                conn.execute(
                    "INSERT INTO user_prefs (user_id, prefs, updated_at) VALUES (?, ?, ?)",
                    (cur.lastrowid, json.dumps(user["prefs"], separators=(",", ":")), now),
                )
            report["usersAdded"] += 1

    return report
