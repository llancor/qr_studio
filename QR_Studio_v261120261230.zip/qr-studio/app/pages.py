"""Páginas dinámicas (función opcional): evento, empresa o carta con QR.

Cada página se publica en /p/<código>. Su dueño la edita cuando quiera y el QR impreso sigue siendo
el mismo. Aquí viven: la validación del contenido, los archivos (imágenes y PDF), las estadísticas, el
archivo de calendario (.ics) y el HTML público.

Seguridad:
- El contenido solo se guarda como datos (JSON validado) y siempre se escribe en el HTML escapado;
  nunca se acepta HTML libre.
- Los enlaces solo pueden ser http, https, tel, mailto o WhatsApp (se construyen aquí).
- Los archivos se reconocen por su cabecera real (PNG, JPEG, WebP, PDF), se guardan con un nombre
  aleatorio y se sirven con el tipo fijo que se detectó, nunca con el que declara el cliente.
"""

from __future__ import annotations

import json
import re
import secrets
import sqlite3
import struct
import unicodedata
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from html import escape
from pathlib import Path
from urllib.parse import quote

from . import dynamic

TEMPLATES = ("evento", "empresa", "carta")
THEMES = ("azul", "verde", "rojo", "naranja", "morado", "negro")
BUTTON_TYPES = ("link", "phone", "whatsapp", "email", "map", "pdf")
# Cómo se ajusta la portada a su caja fija (16:7): llenarla recortando, o mostrarla entera; y hacia dónde
# se enfoca el recorte. Son clases CSS fijas porque la CSP del sitio no admite estilos en línea.
COVER_FITS = ("cover", "contain")
COVER_POSITIONS = ("center", "top", "bottom", "left", "right")

ALPHABET = dynamic.ALPHABET
CODE_LEN = 7
CODE_RE = dynamic.CODE_RE
TOKEN_RE = re.compile(r"^[a-f0-9]{20}$")
CLICK_RE = re.compile(r"^(b\d{1,2}|ics|mapa)$")

MAX_PER_USER = 100
MAX_ASSETS_PER_PAGE = 120
MAX_BUTTONS = 8
MAX_AGENDA = 30
MAX_SECTIONS = 20
MAX_ITEMS = 60
MAX_BOOK_PAGES = 80
MAX_IMAGE_SIDE = 12000

MONTHS = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
WEEKDAYS = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]

_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,63}$")
_PHONE_RE = re.compile(r"^\+?[\d\s().-]{6,30}$")
_PRICE_RE = re.compile(r"^(\d[\d.,\s]{0,11})?$")
_SAFE_FILENAME = re.compile(r"[^\w .\-()]", re.UNICODE)


class PageError(Exception):
    """Error pensado para el usuario: lleva el código HTTP y el mensaje en español."""

    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


@dataclass(frozen=True)
class Limits:
    quota_bytes: int = 200 * 1024 * 1024
    max_image_bytes: int = 5 * 1024 * 1024
    max_pdf_bytes: int = 20 * 1024 * 1024


# ----- Utilidades de validación -----------------------------------------------------------------


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _clean(raw, limit: int, label: str, *, required: bool = False, multiline: bool = False) -> str:
    if raw is None:
        raw = ""
    if not isinstance(raw, str):
        raise PageError(422, f"«{label}» no es válido.")
    text = _CTRL.sub("", raw.replace("\r\n", "\n").replace("\r", "\n"))
    if multiline:
        text = "\n".join(line.rstrip() for line in text.split("\n")).strip()
        text = re.sub(r"\n{3,}", "\n\n", text)
    else:
        text = re.sub(r"\s+", " ", text).strip()
    if required and not text:
        raise PageError(422, f"Escribe «{label}».")
    if len(text) > limit:
        raise PageError(422, f"«{label}» es demasiado largo (máximo {limit} caracteres).")
    return text


def _list(raw, maximum: int, label: str) -> list[dict]:
    if raw is None:
        return []
    if not isinstance(raw, list) or any(not isinstance(item, dict) for item in raw):
        raise PageError(422, f"«{label}» no es válido.")
    if len(raw) > maximum:
        raise PageError(422, f"Hay demasiados elementos en «{label}» (máximo {maximum}).")
    return raw


def _url(raw, label: str = "enlace") -> str:
    text = _clean(raw, dynamic.MAX_TARGET, label, required=True)
    try:
        return dynamic.clean_target(text)
    except dynamic.DynamicError as exc:
        raise PageError(exc.status, exc.message) from None


def _asset(token, assets: dict[str, str], kind: str) -> str:
    if not token:
        return ""
    if not isinstance(token, str) or assets.get(token) != kind:
        raise PageError(422, "Uno de los archivos ya no existe. Súbelo de nuevo.")
    return token


def _when(raw, label: str) -> str:
    text = _clean(raw, 25, label)
    if not text:
        return ""
    try:
        if "T" in text or " " in text:
            return datetime.fromisoformat(text.replace(" ", "T")).strftime("%Y-%m-%dT%H:%M")
        return date.fromisoformat(text).isoformat()
    except ValueError:
        raise PageError(422, f"«{label}» no tiene una fecha válida.") from None


def _digits(raw: str) -> str:
    return re.sub(r"\D", "", raw)


def _phone(raw, label: str, *, required: bool = False) -> str:
    text = _clean(raw, 30, label, required=required)
    if text and not _PHONE_RE.match(text):
        raise PageError(422, f"«{label}» no parece un número de teléfono.")
    return text


def _email(raw, label: str, *, required: bool = False) -> str:
    text = _clean(raw, 120, label, required=required)
    if text and not _EMAIL_RE.match(text):
        raise PageError(422, f"«{label}» no es un correo válido.")
    return text


# ----- Contenido por plantilla -----------------------------------------------------------------


def default_content(template: str, name: str) -> dict:
    content = {
        "title": name,
        "subtitle": "",
        "description": "",
        "theme": "azul",
        "logo": "",
        "cover": "",
        "coverFit": "cover",
        "coverPos": "center",
        "buttons": [],
    }
    if template == "evento":
        content["evento"] = {"start": "", "end": "", "place": "", "address": "", "agenda": []}
    elif template == "empresa":
        content["empresa"] = {"phone": "", "email": "", "web": "", "address": "", "hours": ""}
    else:
        content["carta"] = {"currency": "$", "notes": "", "sections": [], "book": []}
    return content


def _buttons(raw, assets: dict[str, str]) -> list[dict]:
    result = []
    for item in _list(raw, MAX_BUTTONS, "botones"):
        kind = item.get("type")
        if kind not in BUTTON_TYPES:
            raise PageError(422, "Un botón tiene un tipo no válido.")
        label = _clean(item.get("label"), 40, "texto del botón", required=True)
        value = item.get("value")
        if kind == "link":
            value = _url(value, "enlace del botón")
        elif kind == "phone":
            value = _phone(value, "teléfono del botón", required=True)
        elif kind == "whatsapp":
            value = _clean(value, 30, "WhatsApp del botón", required=True)
            if not 8 <= len(_digits(value)) <= 15 or not _PHONE_RE.match(value):
                raise PageError(422, "El número de WhatsApp debe llevar el código de país (8 a 15 cifras).")
        elif kind == "email":
            value = _email(value, "correo del botón", required=True)
        elif kind == "map":
            value = _clean(value, 300, "lugar del botón", required=True)
            if re.match(r"^https?://", value, re.IGNORECASE):
                value = _url(value, "enlace del mapa")
        else:  # pdf
            value = _asset(value, assets, "pdf")
            if not value:
                raise PageError(422, f"Sube el PDF del botón «{label}» o quítalo.")
        result.append({"type": kind, "label": label, "value": value})
    return result


def _evento(raw, assets: dict[str, str]) -> dict:
    raw = raw if isinstance(raw, dict) else {}
    start = _when(raw.get("start"), "inicio del evento")
    end = _when(raw.get("end"), "fin del evento")
    if end and not start:
        raise PageError(422, "Escribe también el inicio del evento.")
    if start and end and datetime.fromisoformat(end) < datetime.fromisoformat(start):
        raise PageError(422, "El evento no puede terminar antes de empezar.")
    agenda = []
    for item in _list(raw.get("agenda"), MAX_AGENDA, "agenda"):
        agenda.append(
            {
                "time": _clean(item.get("time"), 20, "hora de la agenda"),
                "title": _clean(item.get("title"), 120, "actividad de la agenda", required=True),
                "detail": _clean(item.get("detail"), 300, "detalle de la agenda"),
            }
        )
    return {
        "start": start,
        "end": end,
        "place": _clean(raw.get("place"), 120, "lugar"),
        "address": _clean(raw.get("address"), 200, "dirección"),
        "agenda": agenda,
    }


def _empresa(raw, assets: dict[str, str]) -> dict:
    raw = raw if isinstance(raw, dict) else {}
    web = _clean(raw.get("web"), dynamic.MAX_TARGET, "sitio web")
    return {
        "phone": _phone(raw.get("phone"), "teléfono"),
        "email": _email(raw.get("email"), "correo"),
        "web": _url(web, "sitio web") if web else "",
        "address": _clean(raw.get("address"), 200, "dirección"),
        "hours": _clean(raw.get("hours"), 600, "horarios", multiline=True),
    }


def _carta(raw, assets: dict[str, str]) -> dict:
    raw = raw if isinstance(raw, dict) else {}
    sections = []
    for section in _list(raw.get("sections"), MAX_SECTIONS, "categorías"):
        items = []
        for item in _list(section.get("items"), MAX_ITEMS, "platos"):
            price = _clean(item.get("price"), 12, "precio")
            if not _PRICE_RE.match(price):
                raise PageError(422, "El precio solo puede llevar números, puntos y comas.")
            items.append(
                {
                    "name": _clean(item.get("name"), 80, "nombre del plato", required=True),
                    "desc": _clean(item.get("desc"), 220, "descripción del plato"),
                    "price": price,
                    "available": bool(item.get("available", True)),
                    "photo": _asset(item.get("photo"), assets, "image"),
                }
            )
        sections.append({"name": _clean(section.get("name"), 60, "nombre de la categoría", required=True), "items": items})
    book = raw.get("book") or []
    if not isinstance(book, list) or len(book) > MAX_BOOK_PAGES:
        raise PageError(422, f"La carta en libro admite hasta {MAX_BOOK_PAGES} páginas.")
    return {
        "currency": _clean(raw.get("currency", "$"), 4, "moneda"),
        "notes": _clean(raw.get("notes"), 600, "notas", multiline=True),
        "sections": sections,
        "book": [_asset(token, assets, "image") for token in book if token],
    }


_TEMPLATE_CLEANERS = {"evento": _evento, "empresa": _empresa, "carta": _carta}


def clean_content(template: str, raw, assets: dict[str, str]) -> dict:
    """Valida y normaliza el contenido que llega del cliente. `assets`: {token: tipo} de la página."""
    if template not in TEMPLATES:
        raise PageError(422, "Plantilla no válida.")
    if not isinstance(raw, dict):
        raise PageError(422, "El contenido de la página no es válido.")
    theme = raw.get("theme", "azul")
    if theme not in THEMES:
        raise PageError(422, "El color elegido no es válido.")
    cover_fit = raw.get("coverFit", "cover")
    if cover_fit not in COVER_FITS:
        raise PageError(422, "El ajuste de la portada no es válido.")
    cover_pos = raw.get("coverPos", "center")
    if cover_pos not in COVER_POSITIONS:
        raise PageError(422, "El enfoque de la portada no es válido.")
    content = {
        "title": _clean(raw.get("title"), 100, "título", required=True),
        "subtitle": _clean(raw.get("subtitle"), 160, "subtítulo"),
        "description": _clean(raw.get("description"), 3000, "descripción", multiline=True),
        "theme": theme,
        "logo": _asset(raw.get("logo"), assets, "image"),
        "cover": _asset(raw.get("cover"), assets, "image"),
        "coverFit": cover_fit,
        "coverPos": cover_pos,
        "buttons": _buttons(raw.get("buttons"), assets),
    }
    content[template] = _TEMPLATE_CLEANERS[template](raw.get(template), assets)
    return content


def strip_asset(content: dict, token: str) -> dict:
    """Quita de un contenido las referencias a un archivo que se va a borrar."""
    for key in ("logo", "cover"):
        if content.get(key) == token:
            content[key] = ""
    content["buttons"] = [b for b in content.get("buttons", []) if not (b.get("type") == "pdf" and b.get("value") == token)]
    carta = content.get("carta")
    if carta:
        carta["book"] = [t for t in carta.get("book", []) if t != token]
        for section in carta.get("sections", []):
            for item in section.get("items", []):
                if item.get("photo") == token:
                    item["photo"] = ""
    return content


def clean_expiry(raw) -> str | None:
    if raw in (None, ""):
        return None
    try:
        return date.fromisoformat(_clean(raw, 10, "fecha de caducidad")).isoformat()
    except ValueError:
        raise PageError(422, "La fecha de caducidad no es válida.") from None


# ----- Archivos --------------------------------------------------------------------------------


def detect_file(data: bytes) -> tuple[str, str, str]:
    """(tipo, mime, extensión) según la cabecera real del archivo, o error 415."""
    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) > 33 and data[12:16] == b"IHDR":
        width, height = struct.unpack(">II", data[16:24])
        if not (0 < width <= MAX_IMAGE_SIDE and 0 < height <= MAX_IMAGE_SIDE):
            raise PageError(415, "Las dimensiones de la imagen no son válidas.")
        return "image", "image/png", "png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image", "image/jpeg", "jpg"
    if len(data) > 16 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image", "image/webp", "webp"
    if data.startswith(b"%PDF-") and b"%%EOF" in data[-2048:]:
        return "pdf", "application/pdf", "pdf"
    raise PageError(415, "Solo se admiten imágenes PNG, JPG o WebP y archivos PDF válidos.")


def _safe_filename(raw: str) -> str:
    name = unicodedata.normalize("NFC", (raw or "").replace("\\", "/").rsplit("/", 1)[-1])
    name = re.sub(r"\s+", " ", _SAFE_FILENAME.sub("-", name)).strip(" .-")
    return name[:80] or "archivo"


def asset_path(root: Path, user_id: int, token: str, ext: str) -> Path:
    if not TOKEN_RE.match(token) or ext not in {"png", "jpg", "webp", "pdf"}:
        raise PageError(404, "El archivo no existe.")
    return Path(root) / str(int(user_id)) / f"{token}.{ext}"


def _ext_for(mime: str) -> str:
    return {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "application/pdf": "pdf"}[mime]


def used_bytes(conn: sqlite3.Connection, user_id: int) -> int:
    (total,) = conn.execute("SELECT COALESCE(SUM(bytes), 0) FROM page_assets WHERE user_id = ?", (user_id,)).fetchone()
    return int(total)


# ----- Páginas del usuario -----------------------------------------------------------------------


def _owned(conn: sqlite3.Connection, user_id: int, page_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM pages WHERE id = ? AND user_id = ?", (page_id, user_id)).fetchone()
    if not row:
        raise PageError(404, "No se encontró esa página.")
    return row


def _assets_of(conn: sqlite3.Connection, page_id: int) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM page_assets WHERE page_id = ? ORDER BY id", (page_id,)).fetchall()


def _asset_kinds(conn: sqlite3.Connection, page_id: int) -> dict[str, str]:
    return {row["token"]: row["kind"] for row in _assets_of(conn, page_id)}


def is_expired(row: sqlite3.Row) -> bool:
    expiry = row["expires_at"]
    return bool(expiry) and date.today() > date.fromisoformat(expiry)


def _summary(row: sqlite3.Row) -> dict:
    content = json.loads(row["content"])
    return {
        "id": row["id"],
        "code": row["code"],
        "template": row["template"],
        "name": row["name"],
        "title": content.get("title", ""),
        "active": bool(row["active"]),
        "expiresAt": row["expires_at"],
        "expired": is_expired(row),
        "views": row["views"],
        "lastViewAt": row["last_view_at"],
        "updatedAt": row["updated_at"],
    }


def _full(conn: sqlite3.Connection, row: sqlite3.Row) -> dict:
    data = _summary(row)
    data["content"] = json.loads(row["content"])
    data["assets"] = [
        {"token": a["token"], "kind": a["kind"], "name": a["filename"], "bytes": a["bytes"]} for a in _assets_of(conn, row["id"])
    ]
    return data


def list_items(conn: sqlite3.Connection, user_id: int, limits: Limits) -> dict:
    rows = conn.execute("SELECT * FROM pages WHERE user_id = ? ORDER BY id DESC", (user_id,)).fetchall()
    return {
        "items": [_summary(r) for r in rows],
        "limit": MAX_PER_USER,
        "quota": {"used": used_bytes(conn, user_id), "limit": limits.quota_bytes},
    }


def get(conn: sqlite3.Connection, user_id: int, page_id: int) -> dict:
    return _full(conn, _owned(conn, user_id, page_id))


def owned_row(conn: sqlite3.Connection, user_id: int, page_id: int) -> sqlite3.Row:
    return _owned(conn, user_id, page_id)


def create(conn: sqlite3.Connection, user_id: int, template: str, name: str) -> dict:
    if template not in TEMPLATES:
        raise PageError(422, "Elige una plantilla: evento, empresa o carta.")
    name = _clean(name, 80, "nombre", required=True)
    (count,) = conn.execute("SELECT COUNT(*) FROM pages WHERE user_id = ?", (user_id,)).fetchone()
    if count >= MAX_PER_USER:
        raise PageError(409, f"Has llegado al máximo de {MAX_PER_USER} páginas.")
    now = _now().isoformat()
    content = json.dumps(default_content(template, name), ensure_ascii=False)
    for _ in range(20):
        code = "".join(secrets.choice(ALPHABET) for _ in range(CODE_LEN))
        try:
            cur = conn.execute(
                "INSERT INTO pages (user_id, code, template, name, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (user_id, code, template, name, content, now, now),
            )
        except sqlite3.IntegrityError:
            continue
        return _full(conn, conn.execute("SELECT * FROM pages WHERE id = ?", (cur.lastrowid,)).fetchone())
    raise PageError(500, "No se pudo crear la página. Inténtalo de nuevo.")


def update(conn: sqlite3.Connection, user_id: int, page_id: int, *, name, content, active, expires_at, clear_expiry: bool = False) -> dict:
    row = _owned(conn, user_id, page_id)
    new_name = _clean(name, 80, "nombre", required=True) if name is not None else row["name"]
    if content is not None:
        new_content = clean_content(row["template"], content, _asset_kinds(conn, page_id))
    else:
        new_content = json.loads(row["content"])
    new_active = int(bool(active)) if active is not None else row["active"]
    if clear_expiry:
        new_expiry = None
    else:
        new_expiry = clean_expiry(expires_at) if expires_at is not None else row["expires_at"]
    conn.execute(
        "UPDATE pages SET name = ?, content = ?, active = ?, expires_at = ?, updated_at = ? WHERE id = ?",
        (new_name, json.dumps(new_content, ensure_ascii=False), new_active, new_expiry, _now().isoformat(), page_id),
    )
    return _full(conn, conn.execute("SELECT * FROM pages WHERE id = ?", (page_id,)).fetchone())


def delete(conn: sqlite3.Connection, root: Path, user_id: int, page_id: int) -> None:
    _owned(conn, user_id, page_id)
    for asset in _assets_of(conn, page_id):
        asset_path(root, user_id, asset["token"], _ext_for(asset["mime"])).unlink(missing_ok=True)
    conn.execute("DELETE FROM pages WHERE id = ?", (page_id,))


def add_asset(conn: sqlite3.Connection, root: Path, user_id: int, page_id: int, filename: str, data: bytes, limits: Limits) -> dict:
    _owned(conn, user_id, page_id)
    kind, mime, ext = detect_file(data)
    if len(data) > (limits.max_pdf_bytes if kind == "pdf" else limits.max_image_bytes):
        raise PageError(413, "El archivo es demasiado grande.")
    (count,) = conn.execute("SELECT COUNT(*) FROM page_assets WHERE page_id = ?", (page_id,)).fetchone()
    if count >= MAX_ASSETS_PER_PAGE:
        raise PageError(409, f"Esta página ya tiene el máximo de {MAX_ASSETS_PER_PAGE} archivos.")
    if used_bytes(conn, user_id) + len(data) > limits.quota_bytes:
        raise PageError(413, "Has superado tu espacio disponible. Borra algo para seguir subiendo.")
    token = secrets.token_hex(10)
    path = asset_path(root, user_id, token, ext)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    name = _safe_filename(filename)
    try:
        conn.execute(
            "INSERT INTO page_assets (page_id, user_id, token, kind, mime, filename, bytes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (page_id, user_id, token, kind, mime, name, len(data), _now().isoformat()),
        )
    except Exception:
        path.unlink(missing_ok=True)
        raise
    return {"token": token, "kind": kind, "name": name, "bytes": len(data)}


def remove_asset(conn: sqlite3.Connection, root: Path, user_id: int, page_id: int, token: str) -> dict:
    row = _owned(conn, user_id, page_id)
    asset = conn.execute("SELECT * FROM page_assets WHERE page_id = ? AND token = ?", (page_id, token)).fetchone()
    if not asset:
        raise PageError(404, "El archivo no existe.")
    content = strip_asset(json.loads(row["content"]), token)
    conn.execute(
        "UPDATE pages SET content = ?, updated_at = ? WHERE id = ?",
        (json.dumps(content, ensure_ascii=False), _now().isoformat(), page_id),
    )
    conn.execute("DELETE FROM page_assets WHERE id = ?", (asset["id"],))
    asset_path(root, user_id, token, _ext_for(asset["mime"])).unlink(missing_ok=True)
    return _full(conn, conn.execute("SELECT * FROM pages WHERE id = ?", (page_id,)).fetchone())


def read_asset(conn: sqlite3.Connection, root: Path, page_id: int, token: str) -> tuple[Path, str, str]:
    """(ruta, mime, nombre) de un archivo de la página, o error 404."""
    asset = None
    if TOKEN_RE.match(token or ""):
        asset = conn.execute("SELECT * FROM page_assets WHERE page_id = ? AND token = ?", (page_id, token)).fetchone()
    if not asset:
        raise PageError(404, "El archivo no existe.")
    path = asset_path(root, asset["user_id"], token, _ext_for(asset["mime"]))
    if not path.is_file():
        raise PageError(404, "El archivo no existe.")
    return path, asset["mime"], asset["filename"]


# ----- Estadísticas -----------------------------------------------------------------------------


def stats(conn: sqlite3.Connection, user_id: int, page_id: int, days: int = 30) -> dict:
    row = _owned(conn, user_id, page_id)
    today = _now().date()
    start = today - timedelta(days=days - 1)
    found = {
        r["day"]: r["count"]
        for r in conn.execute("SELECT day, count FROM pages_daily WHERE page_id = ? AND day >= ?", (page_id, start.isoformat()))
    }
    series = [
        {"day": (start + timedelta(days=i)).isoformat(), "count": found.get((start + timedelta(days=i)).isoformat(), 0)}
        for i in range(days)
    ]
    content = json.loads(row["content"])
    labels = {f"b{i}": b["label"] for i, b in enumerate(content.get("buttons", []))}
    labels.update({"ics": "Agregar al calendario", "mapa": "Cómo llegar"})
    clicks = [
        {"key": r["key"], "label": labels[r["key"]], "count": r["count"]}
        for r in conn.execute("SELECT key, count FROM pages_clicks WHERE page_id = ? ORDER BY count DESC", (page_id,))
        if r["key"] in labels
    ]
    return {"total": row["views"], "lastViewAt": row["last_view_at"], "days": series, "clicks": clicks}


# ----- Público ----------------------------------------------------------------------------------


def public_lookup(conn: sqlite3.Connection, code: str) -> tuple[str, sqlite3.Row | None]:
    """('ok'|'paused'|'expired'|'missing', fila)."""
    if not CODE_RE.match(code or ""):
        return "missing", None
    row = conn.execute("SELECT * FROM pages WHERE code = ?", (code,)).fetchone()
    if not row:
        return "missing", None
    if not row["active"]:
        return "paused", row
    if is_expired(row):
        return "expired", row
    return "ok", row


def record_view(conn: sqlite3.Connection, page_id: int) -> None:
    now = _now()
    conn.execute("UPDATE pages SET views = views + 1, last_view_at = ? WHERE id = ?", (now.isoformat(), page_id))
    conn.execute(
        "INSERT INTO pages_daily (page_id, day, count) VALUES (?, ?, 1) ON CONFLICT(page_id, day) DO UPDATE SET count = count + 1",
        (page_id, now.date().isoformat()),
    )


def record_click(conn: sqlite3.Connection, page_id: int, key: str) -> None:
    if not CLICK_RE.match(key or ""):
        return
    conn.execute(
        "INSERT INTO pages_clicks (page_id, key, count) VALUES (?, ?, 1) ON CONFLICT(page_id, key) DO UPDATE SET count = count + 1",
        (page_id, key),
    )


# ----- Calendario (.ics) --------------------------------------------------------------------------


def _ics_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def _fold(line: str) -> list[str]:
    """Parte una línea a 75 octetos como pide el formato (las continuaciones empiezan con un espacio)."""
    parts, current, size = [], "", 0
    for char in line:
        width = len(char.encode("utf-8"))
        if size + width > (74 if parts else 75):
            parts.append(current)
            current, size = "", 0
        current += char
        size += width
    parts.append(current)
    return [parts[0], *[" " + p for p in parts[1:]]]


def build_ics(row: sqlite3.Row) -> str | None:
    content = json.loads(row["content"])
    event = content.get("evento") or {}
    if not event.get("start"):
        return None
    start_text, end_text = event["start"], event.get("end") or ""
    all_day = "T" not in start_text
    start = datetime.fromisoformat(start_text)
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//QR Studio//Paginas//ES", "CALSCALE:GREGORIAN", "BEGIN:VEVENT"]
    lines += [f"UID:{row['code']}@qr-studio", f"DTSTAMP:{_now().strftime('%Y%m%dT%H%M%SZ')}"]
    if all_day:
        end = datetime.fromisoformat(end_text) if end_text else start
        lines += [f"DTSTART;VALUE=DATE:{start:%Y%m%d}", f"DTEND;VALUE=DATE:{(end + timedelta(days=1)):%Y%m%d}"]
    else:
        end = datetime.fromisoformat(end_text) if end_text else start + timedelta(hours=2)
        lines += [f"DTSTART:{start:%Y%m%dT%H%M%S}", f"DTEND:{end:%Y%m%dT%H%M%S}"]
    lines.append(f"SUMMARY:{_ics_escape(content['title'])}")
    place = ", ".join(p for p in (event.get("place"), event.get("address")) if p)
    if place:
        lines.append(f"LOCATION:{_ics_escape(place)}")
    if content.get("description"):
        lines.append(f"DESCRIPTION:{_ics_escape(content['description'][:1000])}")
    lines += ["END:VEVENT", "END:VCALENDAR"]
    return "\r\n".join(part for line in lines for part in _fold(line)) + "\r\n"


# ----- HTML público --------------------------------------------------------------------------------


def _e(text) -> str:
    return escape(str(text), quote=True)


def _paragraphs(text: str) -> str:
    blocks = [b for b in re.split(r"\n\s*\n", text.strip()) if b.strip()]
    return "".join("<p>" + _e(b).replace("\n", "<br>") + "</p>" for b in blocks)


def _fmt_day(value: str) -> str:
    d = datetime.fromisoformat(value)
    return f"{WEEKDAYS[d.weekday()]} {d.day} de {MONTHS[d.month - 1]} de {d.year}"


def _fmt_when(start: str, end: str) -> str:
    if not start:
        return ""
    s = datetime.fromisoformat(start)
    timed = "T" in start
    text = _fmt_day(start) + (f", {s:%H:%M} h" if timed else "")
    if end:
        e = datetime.fromisoformat(end)
        if e.date() == s.date():
            if timed and "T" in end:
                text += f" a {e:%H:%M} h"
        else:
            text += f" — {_fmt_day(end)}" + (f", {e:%H:%M} h" if "T" in end else "")
    return text


def _map_url(query: str) -> str:
    if re.match(r"^https?://", query, re.IGNORECASE):
        return query
    return f"https://www.google.com/maps/search/?api=1&query={quote(query)}"


def _button_html(index: int, button: dict, asset_url) -> str:
    kind, label, value = button["type"], _e(button["label"]), button["value"]
    key = f'data-k="b{index}" data-t="{kind}"'
    if kind == "pdf":
        url = _e(asset_url(value))
        return f'<a class="pub-btn" href="{url}?descargar=1" data-pdf="{url}" {key}>{label}</a>'
    if kind == "phone":
        href, external = "tel:" + re.sub(r"[^\d+]", "", value), False
    elif kind == "email":
        href, external = "mailto:" + value, False
    elif kind == "whatsapp":
        href, external = "https://wa.me/" + _digits(value), True
    elif kind == "map":
        href, external = _map_url(value), True
    else:
        href, external = value, True
    target = ' target="_blank" rel="noopener noreferrer"' if external else ""
    return f'<a class="pub-btn" href="{_e(href)}"{target} {key}>{label}</a>'


_INFO_ICONS = {
    "Cuándo": "when", "Dónde": "where", "Teléfono": "phone", "Correo": "mail",
    "Web": "web", "Dirección": "where", "Horarios": "hours",
}


def _info(rows: list[tuple[str, str]]) -> str:
    items = "".join(
        f'<div class="i-{_INFO_ICONS.get(label, "web")}"><dt>{_e(label)}</dt><dd>{value}</dd></div>'
        for label, value in rows
        if value
    )
    return f'<section class="pub-card"><dl class="pub-info">{items}</dl></section>' if items else ""


def _evento_html(content: dict, code: str) -> tuple[str, list[str]]:
    event = content["evento"]
    extra_buttons = []
    rows = [("Cuándo", _e(_fmt_when(event["start"], event["end"])))]
    place = " · ".join(p for p in (event["place"], event["address"]) if p)
    rows.append(("Dónde", _e(place)))
    if event["start"]:
        extra_buttons.append(f'<a class="pub-btn pub-btn-soft" href="/p/{code}/evento.ics" data-k="ics">Agregar al calendario</a>')
    if event["place"] or event["address"]:
        query = ", ".join(p for p in (event["place"], event["address"]) if p)
        extra_buttons.append(
            f'<a class="pub-btn pub-btn-soft" href="{_e(_map_url(query))}" target="_blank" rel="noopener noreferrer" data-k="mapa">Cómo llegar</a>'
        )
    body = _info(rows)
    if event["agenda"]:
        entries = "".join(
            "<li>"
            f'<span class="pub-hora">{_e(a["time"])}</span>'
            f'<div><strong>{_e(a["title"])}</strong>' + (f'<p>{_e(a["detail"])}</p>' if a["detail"] else "") + "</div></li>"
            for a in event["agenda"]
        )
        body += f'<section class="pub-card"><h2>Agenda</h2><ol class="pub-agenda">{entries}</ol></section>'
    return body, extra_buttons


def _empresa_html(content: dict) -> str:
    company = content["empresa"]
    phone_href = re.sub(r"[^0-9+]", "", company["phone"])
    rows = [
        ("Teléfono", f'<a href="tel:{_e(phone_href)}">{_e(company["phone"])}</a>' if company["phone"] else ""),
        ("Correo", f'<a href="mailto:{_e(company["email"])}">{_e(company["email"])}</a>' if company["email"] else ""),
        ("Web", f'<a href="{_e(company["web"])}" target="_blank" rel="noopener noreferrer">{_e(company["web"])}</a>' if company["web"] else ""),
        ("Dirección", _e(company["address"])),
        ("Horarios", _e(company["hours"]).replace("\n", "<br>")),
    ]
    return _info(rows)


def _carta_html(content: dict, asset_url) -> str:
    carta = content["carta"]
    currency = _e(carta["currency"])
    has_book, has_list = bool(carta["book"]), bool(carta["sections"])
    out = []
    if has_book and has_list:
        out.append(
            '<div class="pub-vistas" role="tablist" aria-label="Forma de ver la carta">'
            '<button type="button" role="tab" class="is-on" data-vista="libro" aria-selected="true">Ver como libro</button>'
            '<button type="button" role="tab" data-vista="lista" aria-selected="false">Ver como lista</button></div>'
        )
    if has_book:
        pages = "".join(
            f'<img class="libro-pagina" src="{_e(asset_url(t))}" alt="Página {n} de la carta" loading="{"eager" if n < 3 else "lazy"}">'
            for n, t in enumerate(carta["book"], start=1)
        )
        out.append(
            '<section class="pub-libro" data-panel="libro" aria-label="Carta en formato libro">'
            f'<div class="libro-stage">{pages}</div>'
            '<div class="libro-barra" hidden>'
            '<button type="button" class="libro-btn" data-flip="prev" aria-label="Página anterior">‹</button>'
            '<span class="libro-contador" aria-live="polite"></span>'
            '<button type="button" class="libro-btn" data-flip="next" aria-label="Página siguiente">›</button>'
            '<button type="button" class="libro-btn libro-full" data-flip="full" aria-label="Pantalla completa">⛶</button></div>'
            "</section>"
        )
    if has_list:
        blocks = []
        for section in carta["sections"]:
            dishes = []
            for item in section["items"]:
                price = f'<span class="plato-precio">{currency}{_e(item["price"])}</span>' if item["price"] else ""
                sold = "" if item["available"] else '<span class="plato-agotado">Agotado</span>'
                photo = f'<img class="plato-foto" src="{_e(asset_url(item["photo"]))}" alt="" loading="lazy">' if item["photo"] else ""
                desc = f'<p class="plato-desc">{_e(item["desc"])}</p>' if item["desc"] else ""
                cls = "plato" + ("" if item["available"] else " es-agotado")
                dishes.append(
                    f'<li class="{cls}">{photo}<div class="plato-texto"><div class="plato-fila">'
                    f'<strong>{_e(item["name"])}</strong>{sold}'
                    + ('<span class="plato-linea" aria-hidden="true"></span>' if item["price"] else "")
                    + f"{price}</div>{desc}</div></li>"
                )
            blocks.append(f'<section class="pub-card"><h2>{_e(section["name"])}</h2><ul class="platos">{"".join(dishes)}</ul></section>')
        hidden = " hidden" if has_book else ""
        out.append(f'<div class="pub-lista" data-panel="lista"{hidden}>{"".join(blocks)}</div>')
    if carta["notes"]:
        out.append(f'<section class="pub-card pub-notas">{_paragraphs(carta["notes"])}</section>')
    return "".join(out)


_EYEBROWS = {"evento": "Evento", "empresa": "Empresa", "carta": "Carta"}


def render_public(row: sqlite3.Row, asset_url, *, preview: bool = False) -> str:
    """HTML de la página pública. `asset_url(token)` da la dirección de cada archivo."""
    content = json.loads(row["content"])
    template, code = row["template"], row["code"]
    extra_buttons: list[str] = []
    if template == "evento":
        middle, extra_buttons = _evento_html(content, code)
    elif template == "empresa":
        middle = _empresa_html(content)
    else:
        middle = ""
    # Las páginas guardadas antes de existir estos campos se ven como siempre: llenar, enfocando el centro.
    fit = content.get("coverFit") if content.get("coverFit") in COVER_FITS else "cover"
    pos = content.get("coverPos") if content.get("coverPos") in COVER_POSITIONS else "center"
    cover = (
        f'<div class="pub-cover fit-{fit} pos-{pos}"><img src="{_e(asset_url(content["cover"]))}" alt=""></div>'
        if content["cover"]
        else ""
    )
    logo = f'<img class="pub-logo" src="{_e(asset_url(content["logo"]))}" alt="">' if content["logo"] else ""
    subtitle = f'<p class="pub-sub">{_e(content["subtitle"])}</p>' if content["subtitle"] else ""
    description = f'<section class="pub-card pub-desc">{_paragraphs(content["description"])}</section>' if content["description"] else ""
    carta = _carta_html(content, asset_url) if template == "carta" else ""
    buttons = extra_buttons + [_button_html(i, b, asset_url) for i, b in enumerate(content["buttons"])]
    actions = f'<nav class="pub-actions" aria-label="Acciones">{"".join(buttons)}</nav>' if buttons else ""
    banner = '<p class="pub-preview">Vista previa: esta visita no se cuenta.</p>' if preview else ""
    title = _e(content["title"])
    return (
        '<!doctype html><html lang="es"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        f"<title>{title}</title>"
        '<meta name="robots" content="noindex, nofollow">'
        f'<meta name="description" content="{_e(content["subtitle"] or content["title"])}">'
        '<link rel="stylesheet" href="/css/publica.css"></head>'
        f'<body class="pub tema-{content["theme"]} plantilla-{template}" data-code="{_e(code)}" data-preview="{1 if preview else 0}">'
        f'{banner}<main class="pub-wrap"><header class="pub-head">{cover}'
        f'<div class="pub-title">{logo}<p class="pub-eyebrow">{_EYEBROWS[template]}</p><h1>{title}</h1>{subtitle}</div></header>'
        f"{actions}{middle}{description}{carta}</main>"
        '<footer class="pub-foot">Hecho con QR Studio</footer>'
        '<script src="/js/publica.js" defer></script></body></html>'
    )
