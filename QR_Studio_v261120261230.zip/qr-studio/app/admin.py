"""Administración de usuarios (solo para administradores): alta, contraseñas, activar o desactivar
cuentas, cambiar el rol y decidir si cualquiera puede crear una cuenta."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from . import auth

ROLES = ("user", "admin")


class AdminError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


# ----- Ajuste: ¿se pueden crear cuentas? -------------------------------------

def registration_open(conn: sqlite3.Connection, default: bool) -> bool:
    """Lo que decidió el administrador; si nunca lo cambió, el valor inicial de la configuración."""
    row = conn.execute("SELECT value FROM app_settings WHERE key = 'registration_open'").fetchone()
    return default if row is None else row["value"] == "1"


def set_registration_open(conn: sqlite3.Connection, value: bool) -> None:
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES ('registration_open', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        ("1" if value else "0",),
    )


# ----- Ajuste: ¿pueden entrar a las herramientas sin iniciar sesión? ---------------

def public_access(conn: sqlite3.Connection, default: bool) -> bool:
    """Lo que decidió el administrador; si nunca lo cambió, el valor inicial de la configuración (apagado)."""
    row = conn.execute("SELECT value FROM app_settings WHERE key = 'public_access'").fetchone()
    return default if row is None else row["value"] == "1"


def set_public_access(conn: sqlite3.Connection, value: bool) -> None:
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES ('public_access', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        ("1" if value else "0",),
    )


# ----- Usuarios --------------------------------------------------------------

def count_users(conn: sqlite3.Connection) -> int:
    return int(conn.execute("SELECT COUNT(*) FROM users").fetchone()[0])


def _item(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "email": row["email"],
        "name": row["name"],
        "role": row["role"],
        "active": bool(row["active"]),
        "createdAt": row["created_at"],
    }


def _get(conn: sqlite3.Connection, user_id: int) -> sqlite3.Row:
    row = conn.execute(
        "SELECT id, email, name, role, active, created_at FROM users WHERE id = ?", (user_id,)
    ).fetchone()
    if row is None:
        raise AdminError(404, "Ese usuario no existe.")
    return row


def list_users(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT id, email, name, role, active, created_at FROM users ORDER BY id"
    ).fetchall()
    return [_item(row) for row in rows]


def create_user(conn: sqlite3.Connection, email: str, name: str, password_hash: str, role: str) -> dict:
    if role not in ROLES:
        raise AdminError(422, "El rol debe ser «user» o «admin».")
    now = datetime.now(timezone.utc).isoformat()
    try:
        cur = conn.execute(
            "INSERT INTO users (email, name, password_hash, created_at, role) VALUES (?, ?, ?, ?, ?)",
            (email, name, password_hash, now, role),
        )
    except sqlite3.IntegrityError:
        raise AdminError(409, "Ya existe una cuenta con ese correo.") from None
    return _item(_get(conn, int(cur.lastrowid)))


def set_password(
    conn: sqlite3.Connection, user_id: int, password_hash: str, keep_token: str | None = None
) -> None:
    """Cambia la contraseña y cierra las sesiones abiertas de ese usuario (salvo `keep_token`)."""
    _get(conn, user_id)
    conn.execute("UPDATE users SET password_hash = ? WHERE id = ?", (password_hash, user_id))
    auth.delete_sessions_of(conn, user_id, keep_token)


def _other_active_admins(conn: sqlite3.Connection, user_id: int) -> int:
    return int(
        conn.execute(
            "SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1 AND id != ?", (user_id,)
        ).fetchone()[0]
    )


def update_user(
    conn: sqlite3.Connection,
    actor_id: int,
    user_id: int,
    *,
    role: str | None = None,
    active: bool | None = None,
    name: str | None = None,
    email: str | None = None,
) -> dict:
    row = _get(conn, user_id)
    new_role = row["role"] if role is None else role
    new_active = bool(row["active"]) if active is None else active
    new_name = row["name"] if name is None else name
    new_email = row["email"] if email is None else email
    if new_role not in ROLES:
        raise AdminError(422, "El rol debe ser «user» o «admin».")
    if user_id == actor_id and not new_active:
        raise AdminError(409, "No puedes desactivar tu propia cuenta.")
    was_active_admin = row["role"] == "admin" and bool(row["active"])
    stays_active_admin = new_role == "admin" and new_active
    if was_active_admin and not stays_active_admin and _other_active_admins(conn, user_id) == 0:
        raise AdminError(409, "Debe quedar al menos un administrador activo.")

    try:
        conn.execute(
            "UPDATE users SET role = ?, active = ?, name = ?, email = ? WHERE id = ?",
            (new_role, 1 if new_active else 0, new_name, new_email, user_id),
        )
    except sqlite3.IntegrityError:
        raise AdminError(409, "Ya existe una cuenta con ese correo.") from None
    if new_email != row["email"]:
        # Un enlace de recuperación mandado al correo anterior ya no debe servir.
        conn.execute("DELETE FROM password_resets WHERE user_id = ?", (user_id,))
    if not new_active:
        auth.delete_sessions_of(conn, user_id)
    return _item(_get(conn, user_id))
