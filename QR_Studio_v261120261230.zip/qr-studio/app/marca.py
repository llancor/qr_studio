"""Marca del sitio: nombre, logo y colores de la página de acceso.

Los elige el administrador (Ajustes → Página de acceso) y son PÚBLICOS: se ven sin iniciar sesión, porque la
página de acceso es lo primero que ve cualquiera. El nombre y los colores viven en app_settings; el logo, en la
tabla site_logo. Un color vacío significa «el predeterminado del tema».
"""

from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone

from .prefs import PrefsError, check_image

DEFAULT_NAME = "QR Studio"
MAX_NAME = 40
MAX_LOGO_BYTES = 1024 * 1024

_HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")

# clave de la API -> clave en app_settings
_COLORS = {"card": "login_card", "text": "login_text", "accent": "login_accent"}


def _get(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
    return default if row is None else row["value"]


def _set(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def get(conn: sqlite3.Connection) -> dict:
    """{name, logoVersion, card, text, accent}. logoVersion es 0 sin logo; un color vacío es el predeterminado."""
    row = conn.execute("SELECT version, image IS NOT NULL AS has_image FROM site_logo WHERE id = 1").fetchone()
    return {
        "name": _get(conn, "brand_name") or DEFAULT_NAME,
        "logoVersion": int(row["version"]) if row and row["has_image"] else 0,
        **{key: _get(conn, setting) for key, setting in _COLORS.items()},
    }


def save(conn: sqlite3.Connection, raw: object) -> dict:
    """Guarda nombre y colores. Lo que no venga en `raw` se queda como estaba."""
    if not isinstance(raw, dict):
        raise PrefsError(422, "Ajustes no válidos.")
    if "name" in raw:
        name = raw["name"]
        if not isinstance(name, str) or _CONTROL.search(name):
            raise PrefsError(422, "El nombre del sitio no es válido.")
        name = name.strip()
        if len(name) > MAX_NAME:
            raise PrefsError(422, f"El nombre del sitio es demasiado largo (máximo {MAX_NAME} caracteres).")
        # Vacío = volver al nombre por defecto.
        _set(conn, "brand_name", "" if name == DEFAULT_NAME else name)
    for key, setting in _COLORS.items():
        if key in raw:
            color = raw[key]
            if color not in ("", None) and (not isinstance(color, str) or not _HEX.match(color)):
                raise PrefsError(422, "Los colores deben ser como #2f5bff (o vacíos para el predeterminado).")
            _set(conn, setting, (color or "").lower())
    return get(conn)


def set_logo(conn: sqlite3.Connection, data: bytes) -> dict:
    mime = check_image(data)
    if len(data) > MAX_LOGO_BYTES:
        raise PrefsError(413, "El logo es demasiado grande (máximo 1 MB).")
    conn.execute(
        "INSERT INTO site_logo (id, image, mime, version, updated_at) VALUES (1, ?, ?, 1, ?) "
        "ON CONFLICT(id) DO UPDATE SET image = excluded.image, mime = excluded.mime, "
        "version = site_logo.version + 1, updated_at = excluded.updated_at",
        (data, mime, datetime.now(timezone.utc).isoformat()),
    )
    return get(conn)


def get_logo(conn: sqlite3.Connection) -> tuple[bytes, str] | None:
    row = conn.execute("SELECT image, mime FROM site_logo WHERE id = 1 AND image IS NOT NULL").fetchone()
    return None if row is None else (bytes(row["image"]), row["mime"])


def delete_logo(conn: sqlite3.Connection) -> dict:
    conn.execute(
        "UPDATE site_logo SET image = NULL, mime = NULL, version = version + 1, updated_at = ? WHERE id = 1",
        (datetime.now(timezone.utc).isoformat(),),
    )
    return get(conn)
