"""Usuarios desde la línea de comandos: la vía de rescate cuando no se puede entrar a la página
(por ejemplo, el administrador olvidó su contraseña). Quien puede ejecutarlo ya tiene acceso a la
carpeta del servidor y a la base de datos, así que no abre ninguna puerta nueva.

    python -m app.usuarios                                 menú interactivo
    python -m app.usuarios listar
    python -m app.usuarios crear CORREO --nombre "Ana" --rol admin
    python -m app.usuarios restablecer CORREO              pide la contraseña nueva (sin mostrarla)
    python -m app.usuarios restablecer CORREO --generar    inventa una y la muestra
    python -m app.usuarios activar CORREO | desactivar CORREO
    python -m app.usuarios rol CORREO admin|user
    python -m app.usuarios registro abrir|cerrar|estado

La base de datos es la de APP_DB_PATH (igual que la página). Puede estar en marcha: SQLite lo permite.
Usa las mismas reglas que la página: contraseñas del largo configurado, sesiones cerradas al cambiar
la clave o desactivar, y siempre queda al menos un administrador activo.
"""

from __future__ import annotations

import argparse
import getpass
import secrets
import sys
from pathlib import Path
from typing import Callable

from . import admin, auth, db
from .config import Settings, load_settings
from .main import EMAIL_RE

ALFABETO = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # sin 0/O ni 1/l/I


class Error(Exception):
    """Un problema que se explica al usuario (no es un fallo del programa)."""


def generar_clave(largo: int = 14) -> str:
    return "".join(secrets.choice(ALFABETO) for _ in range(largo))


class Herramienta:
    def __init__(
        self,
        settings: Settings,
        *,
        salida: Callable[[str], None] = print,
        entrada: Callable[[str], str] = input,
        secreto: Callable[[str], str] = getpass.getpass,
    ) -> None:
        self.settings = settings
        self.salida = salida
        self.entrada = entrada
        self.secreto = secreto

    # ----- Utilidades -----------------------------------------------------------

    def _abrir(self, *, crear: bool = False):
        ruta: Path = self.settings.db_path
        if not ruta.exists() and not crear:
            raise Error(
                f"No se encontró la base de datos: {ruta}\n"
                "Si QR Studio nunca se abrió, aún no hay usuarios; créalos con «crear»."
            )
        db.init_db(ruta)  # crea la base si falta y pone al día una de versión anterior
        return db.connect(ruta)

    @staticmethod
    def _correo(crudo: str) -> str:
        correo = crudo.strip().lower()
        if not EMAIL_RE.match(correo):
            raise Error(f"«{crudo}» no es un correo electrónico válido.")
        return correo

    def _comprobar_clave(self, clave: str) -> None:
        minimo = self.settings.min_password_length
        if not minimo <= len(clave) <= 128:
            raise Error(f"La contraseña debe tener entre {minimo} y 128 caracteres.")

    def _clave(self, clave: str | None, generar: bool) -> tuple[str, bool]:
        """(contraseña, fue_generada). Sin --clave ni --generar se pide dos veces, sin mostrarla."""
        if generar:
            return generar_clave(), True
        if clave is not None:
            self._comprobar_clave(clave)
            return clave, False
        primera = self.secreto("Contraseña nueva (no se muestra): ")
        self._comprobar_clave(primera)
        if self.secreto("Repítela: ") != primera:
            raise Error("Las dos contraseñas no coinciden. No se cambió nada.")
        return primera, False

    @staticmethod
    def _buscar(conn, correo: str):
        fila = conn.execute(
            "SELECT id, email, name, role, active FROM users WHERE email = ?", (correo,)
        ).fetchone()
        if fila is None:
            raise Error(f"No existe ninguna cuenta con el correo {correo}. Mira la lista con «listar».")
        return fila

    # ----- Órdenes ---------------------------------------------------------------

    def listar(self) -> None:
        with self._abrir() as conn:
            usuarios = admin.list_users(conn)
            abierto = admin.registration_open(conn, self.settings.registration_open)
        if not usuarios:
            self.salida("Todavía no hay ninguna cuenta. Crea la primera con «crear … --rol admin».")
        else:
            self.salida(f"{'ID':>3}  {'CORREO':<34} {'NOMBRE':<22} {'ROL':<14} ESTADO")
            for u in usuarios:
                rol = "administrador" if u["role"] == "admin" else "usuario"
                estado = "activa" if u["active"] else "DESACTIVADA"
                self.salida(f"{u['id']:>3}  {u['email']:<34} {u['name'][:22]:<22} {rol:<14} {estado}")
        self.salida(f"\nCrear cuentas desde la página: {'permitido' if abierto else 'desactivado'}.")

    def crear(self, correo: str, nombre: str | None, rol: str, clave: str | None, generar: bool) -> None:
        correo = self._correo(correo)
        nombre = (nombre or correo.split("@")[0]).strip()
        if not 1 <= len(nombre) <= 80:
            raise Error("El nombre debe tener entre 1 y 80 caracteres.")
        if rol not in admin.ROLES:
            raise Error("El rol debe ser «admin» o «user».")
        contrasena, generada = self._clave(clave, generar)

        with self._abrir(crear=True) as conn:
            try:
                admin.create_user(conn, correo, nombre, auth.hash_password(contrasena), rol)
            except admin.AdminError as error:
                raise Error(error.message) from None
        self.salida(f"Cuenta creada: {correo} ({'administrador' if rol == 'admin' else 'usuario'}).")
        if generada:
            self.salida(f"Contraseña: {contrasena}\nCómpartesela a esa persona y anótala ahora: no se vuelve a mostrar.")

    def restablecer(self, correo: str, clave: str | None, generar: bool) -> None:
        correo = self._correo(correo)
        with self._abrir() as conn:
            fila = self._buscar(conn, correo)
            contrasena, generada = self._clave(clave, generar)
            try:
                admin.set_password(conn, int(fila["id"]), auth.hash_password(contrasena))
            except admin.AdminError as error:
                raise Error(error.message) from None
        self.salida(f"Contraseña de {correo} restablecida. Sus sesiones abiertas se cerraron.")
        if not fila["active"]:
            self.salida("Ojo: esa cuenta está DESACTIVADA; usa «activar» para que pueda entrar.")
        if generada:
            self.salida(f"Contraseña nueva: {contrasena}\nAnótala ahora: no se vuelve a mostrar.")

    def _cambiar(self, correo: str, *, rol: str | None = None, activa: bool | None = None) -> None:
        correo = self._correo(correo)
        with self._abrir() as conn:
            fila = self._buscar(conn, correo)
            try:
                admin.update_user(conn, 0, int(fila["id"]), role=rol, active=activa)
            except admin.AdminError as error:
                raise Error(error.message) from None

    def activar(self, correo: str) -> None:
        self._cambiar(correo, activa=True)
        self.salida(f"Cuenta {correo.strip().lower()} activada.")

    def desactivar(self, correo: str) -> None:
        self._cambiar(correo, activa=False)
        self.salida(f"Cuenta {correo.strip().lower()} desactivada (perdió el acceso de inmediato).")

    def rol(self, correo: str, rol: str) -> None:
        if rol not in admin.ROLES:
            raise Error("El rol debe ser «admin» o «user».")
        self._cambiar(correo, rol=rol)
        self.salida(f"{correo.strip().lower()} ahora es {'administrador' if rol == 'admin' else 'usuario'}.")

    def registro(self, accion: str) -> None:
        with self._abrir() as conn:
            if accion == "estado":
                abierto = admin.registration_open(conn, self.settings.registration_open)
            else:
                abierto = accion == "abrir"
                admin.set_registration_open(conn, abierto)
        self.salida(f"Crear cuentas desde la página: {'permitido' if abierto else 'desactivado'}.")

    # ----- Menú interactivo ---------------------------------------------------------

    def menu(self) -> None:
        opciones = {
            "1": ("Ver usuarios", self.listar),
            "2": ("Crear un usuario", self._m_crear),
            "3": ("Restablecer la contraseña de alguien", self._m_restablecer),
            "4": ("Activar o desactivar una cuenta", self._m_activar),
            "5": ("Hacer o quitar administrador", self._m_rol),
            "6": ("Permitir o impedir que se creen cuentas", self._m_registro),
        }
        while True:
            self.salida(f"\nQR Studio · Usuarios\nBase de datos: {self.settings.db_path}\n")
            for clave, (texto, _) in opciones.items():
                self.salida(f"  {clave}) {texto}")
            self.salida("  0) Salir")
            try:
                eleccion = self.entrada("\nOpción: ").strip()
            except (EOFError, KeyboardInterrupt):
                return
            if eleccion in ("0", "q", "Q", ""):
                return
            if eleccion not in opciones:
                continue
            try:
                opciones[eleccion][1]()
            except Error as error:
                self.salida(f"\nERROR: {error}")
            except (EOFError, KeyboardInterrupt):
                return

    def _pedir(self, texto: str) -> str:
        return self.entrada(texto).strip()

    def _si(self, texto: str, por_defecto: bool) -> bool:
        respuesta = self._pedir(texto).lower()
        if not respuesta:
            return por_defecto
        return respuesta in ("s", "si", "sí", "y", "yes")

    def _m_crear(self) -> None:
        correo = self._pedir("Correo: ")
        nombre = self._pedir("Nombre (Enter = la parte antes de la @): ") or None
        rol = "admin" if self._si("¿Será administrador? (s/N): ", False) else "user"
        inventar = self._si("¿Inventar la contraseña? (S/n): ", True)
        self.crear(correo, nombre, rol, None, inventar)

    def _m_restablecer(self) -> None:
        self.listar()
        correo = self._pedir("\nCorreo de la cuenta: ")
        inventar = self._si("¿Inventar la contraseña? (S/n): ", True)
        self.restablecer(correo, None, inventar)

    def _m_activar(self) -> None:
        self.listar()
        correo = self._pedir("\nCorreo de la cuenta: ")
        que = self._pedir("¿Activar (a) o desactivar (d)?: ").lower()
        if que.startswith("a"):
            self.activar(correo)
        elif que.startswith("d"):
            self.desactivar(correo)
        else:
            self.salida("No se cambió nada.")

    def _m_rol(self) -> None:
        self.listar()
        correo = self._pedir("\nCorreo de la cuenta: ")
        que = self._pedir("¿Administrador (a) o usuario (u)?: ").lower()
        if que.startswith("a"):
            self.rol(correo, "admin")
        elif que.startswith("u"):
            self.rol(correo, "user")
        else:
            self.salida("No se cambió nada.")

    def _m_registro(self) -> None:
        self.registro("estado")
        que = self._pedir("¿Permitir (p) o impedir (i) que se creen cuentas?: ").lower()
        if que.startswith("p"):
            self.registro("abrir")
        elif que.startswith("i"):
            self.registro("cerrar")
        else:
            self.salida("No se cambió nada.")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m app.usuarios",
        description="Usuarios de QR Studio desde la línea de comandos (rescate). Sin órdenes abre un menú.",
    )
    sub = parser.add_subparsers(dest="orden")

    def con_clave(p: argparse.ArgumentParser) -> None:
        grupo = p.add_mutually_exclusive_group()
        grupo.add_argument("--clave", help="contraseña (queda en el historial del terminal: mejor omítela y se pide)")
        grupo.add_argument("--generar", action="store_true", help="inventa una contraseña y la muestra")

    sub.add_parser("listar", help="muestra las cuentas")
    p = sub.add_parser("crear", help="crea una cuenta")
    p.add_argument("correo")
    p.add_argument("--nombre")
    p.add_argument("--rol", choices=admin.ROLES, default="user")
    con_clave(p)
    p = sub.add_parser("restablecer", help="cambia la contraseña de una cuenta (y cierra sus sesiones)")
    p.add_argument("correo")
    con_clave(p)
    for nombre, ayuda in (("activar", "reactiva una cuenta"), ("desactivar", "le quita el acceso a una cuenta")):
        sub.add_parser(nombre, help=ayuda).add_argument("correo")
    p = sub.add_parser("rol", help="hace administrador a alguien, o lo vuelve usuario")
    p.add_argument("correo")
    p.add_argument("nuevo", choices=admin.ROLES)
    p = sub.add_parser("registro", help="permite o impide que se creen cuentas desde la página")
    p.add_argument("accion", choices=("abrir", "cerrar", "estado"))
    return parser


def main(argv: list[str] | None = None, *, settings: Settings | None = None, **io) -> int:
    for flujo in (sys.stdout, sys.stderr):  # una consola de Windows con otra codificación no debe romper el texto
        try:
            flujo.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass
    args = _parser().parse_args(argv)
    herramienta = Herramienta(settings or load_settings(), **io)
    try:
        if args.orden is None:
            herramienta.menu()
        elif args.orden == "listar":
            herramienta.listar()
        elif args.orden == "crear":
            herramienta.crear(args.correo, args.nombre, args.rol, args.clave, args.generar)
        elif args.orden == "restablecer":
            herramienta.restablecer(args.correo, args.clave, args.generar)
        elif args.orden == "activar":
            herramienta.activar(args.correo)
        elif args.orden == "desactivar":
            herramienta.desactivar(args.correo)
        elif args.orden == "rol":
            herramienta.rol(args.correo, args.nuevo)
        elif args.orden == "registro":
            herramienta.registro(args.accion)
    except Error as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    except (EOFError, KeyboardInterrupt):
        print("\nCancelado. No se cambió nada.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
