"""QR dinámicos (función opcional).

Un QR dinámico no lleva el destino dentro, sino un enlace corto de este sitio (/q/<código>). Al
escanearlo, el servidor cuenta la visita y redirige al destino actual, que su dueño puede cambiar
sin tener que reimprimir el QR. El destino solo lo escribe el dueño (no se acepta en la dirección
corta), y solo se admiten enlaces http o https.
"""

from __future__ import annotations

import re
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"  # sin letras que se confunden (i, l, o, 0, 1)
CODE_LEN = 7
CODE_RE = re.compile(r"^[a-z0-9]{4,16}$")
MAX_PER_USER = 200
MAX_TARGET = 2000
MAX_NAME = 80

_SCHEME_RE = re.compile(r"^[a-z][a-z0-9+.-]*:", re.IGNORECASE)


class DynamicError(Exception):
    """Error pensado para el usuario: lleva el código HTTP y el mensaje en español."""

    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def clean_target(raw: str) -> str:
    target = (raw or "").strip()
    if not target:
        raise DynamicError(422, "Escribe la dirección de destino.")
    if len(target) > MAX_TARGET:
        raise DynamicError(422, f"La dirección es demasiado larga (máximo {MAX_TARGET} caracteres).")
    if not _SCHEME_RE.match(target):
        target = f"https://{target}"
    parts = urlparse(target)
    if parts.scheme.lower() not in {"http", "https"} or not parts.hostname:
        raise DynamicError(422, "Solo se admiten enlaces http o https válidos.")
    if re.search(r"\s", target):
        raise DynamicError(422, "La dirección no puede llevar espacios.")
    return target


def clean_name(raw: str, target: str) -> str:
    name = re.sub(r"\s+", " ", (raw or "")).strip()
    if not name:
        name = urlparse(target).hostname or "QR dinámico"
    return name[:MAX_NAME]


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _item(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "code": row["code"],
        "name": row["name"],
        "target": row["target"],
        "active": bool(row["active"]),
        "scans": row["scans"],
        "lastScanAt": row["last_scan_at"],
        "createdAt": row["created_at"],
        "updatedAt": row["updated_at"],
    }


def _owned(conn: sqlite3.Connection, user_id: int, qr_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM dynamic_qr WHERE id = ? AND user_id = ?", (qr_id, user_id)).fetchone()
    if not row:
        raise DynamicError(404, "No se encontró ese QR dinámico.")
    return row


def list_items(conn: sqlite3.Connection, user_id: int) -> dict:
    rows = conn.execute("SELECT * FROM dynamic_qr WHERE user_id = ? ORDER BY id DESC", (user_id,)).fetchall()
    return {"items": [_item(r) for r in rows], "limit": MAX_PER_USER}


def create(conn: sqlite3.Connection, user_id: int, name: str, target: str) -> dict:
    target = clean_target(target)
    name = clean_name(name, target)
    (count,) = conn.execute("SELECT COUNT(*) FROM dynamic_qr WHERE user_id = ?", (user_id,)).fetchone()
    if count >= MAX_PER_USER:
        raise DynamicError(409, f"Has llegado al máximo de {MAX_PER_USER} QR dinámicos.")
    now = _now().isoformat()
    for _ in range(20):
        code = "".join(secrets.choice(ALPHABET) for _ in range(CODE_LEN))
        try:
            cur = conn.execute(
                "INSERT INTO dynamic_qr (user_id, code, name, target, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                (user_id, code, name, target, now, now),
            )
        except sqlite3.IntegrityError:
            continue  # código repetido: se prueba otro
        return _item(conn.execute("SELECT * FROM dynamic_qr WHERE id = ?", (cur.lastrowid,)).fetchone())
    raise DynamicError(500, "No se pudo crear el código. Inténtalo de nuevo.")


def update(conn: sqlite3.Connection, user_id: int, qr_id: int, *, name=None, target=None, active=None) -> dict:
    row = _owned(conn, user_id, qr_id)
    new_target = clean_target(target) if target is not None else row["target"]
    new_name = clean_name(name, new_target) if name is not None else row["name"]
    new_active = int(bool(active)) if active is not None else row["active"]
    conn.execute(
        "UPDATE dynamic_qr SET name = ?, target = ?, active = ?, updated_at = ? WHERE id = ?",
        (new_name, new_target, new_active, _now().isoformat(), qr_id),
    )
    return _item(conn.execute("SELECT * FROM dynamic_qr WHERE id = ?", (qr_id,)).fetchone())


def delete(conn: sqlite3.Connection, user_id: int, qr_id: int) -> None:
    _owned(conn, user_id, qr_id)
    conn.execute("DELETE FROM dynamic_qr WHERE id = ?", (qr_id,))


def stats(conn: sqlite3.Connection, user_id: int, qr_id: int, days: int = 30) -> dict:
    row = _owned(conn, user_id, qr_id)
    today = _now().date()
    start = today - timedelta(days=days - 1)
    found = {
        r["day"]: r["count"]
        for r in conn.execute(
            "SELECT day, count FROM dynamic_qr_daily WHERE qr_id = ? AND day >= ?", (qr_id, start.isoformat())
        )
    }
    series = [
        {"day": (start + timedelta(days=i)).isoformat(), "count": found.get((start + timedelta(days=i)).isoformat(), 0)}
        for i in range(days)
    ]
    return {"total": row["scans"], "lastScanAt": row["last_scan_at"], "days": series}


def record_scan(conn: sqlite3.Connection, code: str) -> tuple[str, str | None]:
    """Cuenta una visita. Devuelve ('ok', destino), ('paused', None) o ('missing', None)."""
    if not CODE_RE.match(code or ""):
        return "missing", None
    row = conn.execute("SELECT id, target, active FROM dynamic_qr WHERE code = ?", (code,)).fetchone()
    if not row:
        return "missing", None
    if not row["active"]:
        return "paused", None
    now = _now()
    conn.execute("UPDATE dynamic_qr SET scans = scans + 1, last_scan_at = ? WHERE id = ?", (now.isoformat(), row["id"]))
    conn.execute(
        "INSERT INTO dynamic_qr_daily (qr_id, day, count) VALUES (?, ?, 1) "
        "ON CONFLICT(qr_id, day) DO UPDATE SET count = count + 1",
        (row["id"], now.date().isoformat()),
    )
    return "ok", row["target"]
