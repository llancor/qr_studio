"""Datos legales del sitio: quién es el responsable y cuándo se actualizaron los textos.

Las páginas «Aviso de privacidad» (/privacidad/) y «Términos de uso» (/terminos/) son públicas y traen el texto
escrito de fábrica según lo que esta aplicación realmente recopila (ver BITACORA.md, sección legal). Lo único que
cambia de un sitio a otro es QUIÉN lo opera: el nombre del responsable, un correo de contacto y el país cuya ley
se aplica. Lo escribe el administrador en Ajustes → Legal y vive en app_settings.

Mientras no estén el nombre y el correo, las páginas avisan de que faltan y NO se exige aceptar nada al crear una
cuenta. En cuanto se completan, crear una cuenta exige marcar que se aceptan, y se guarda cuándo y qué versión.
"""

from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone

from .prefs import PrefsError

# clave de la API -> (clave en app_settings, longitud máxima)
_FIELDS = {
    "name": ("legal_name", 120),
    "email": ("legal_email", 254),
    "country": ("legal_country", 80),
    "address": ("legal_address", 200),
}
_EMAIL = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,63}$")
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")


def _get(conn: sqlite3.Connection, key: str) -> str:
    row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
    return "" if row is None else row["value"]


def _set(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def get(conn: sqlite3.Connection) -> dict:
    """{name, email, country, address, updatedAt, configured}. `configured`: ya hay responsable y correo."""
    data = {key: _get(conn, setting) for key, (setting, _) in _FIELDS.items()}
    return {**data, "updatedAt": _get(conn, "legal_updated"), "configured": bool(data["name"] and data["email"])}


def is_configured(conn: sqlite3.Connection) -> bool:
    return bool(_get(conn, "legal_name") and _get(conn, "legal_email"))


def save(conn: sqlite3.Connection, raw: object) -> dict:
    """Guarda los datos. Lo que no venga en `raw` se queda como estaba; si algo cambia, se actualiza la fecha."""
    if not isinstance(raw, dict):
        raise PrefsError(422, "Datos no válidos.")
    changes: dict[str, str] = {}
    for key, (setting, limit) in _FIELDS.items():
        if key not in raw:
            continue
        value = raw[key]
        if value is None:
            value = ""
        if not isinstance(value, str) or _CONTROL.search(value):
            raise PrefsError(422, "Hay un dato legal con caracteres no válidos.")
        value = value.strip()
        if len(value) > limit:
            raise PrefsError(422, f"Un dato legal es demasiado largo (máximo {limit} caracteres).")
        if key == "email" and value and not _EMAIL.match(value):
            raise PrefsError(422, "Escribe un correo de contacto válido.")
        changes[setting] = value
    current = {setting: _get(conn, setting) for setting, _ in _FIELDS.values()}
    if any(current[setting] != value for setting, value in changes.items()):
        for setting, value in changes.items():
            _set(conn, setting, value)
        # La fecha de «última actualización» que ven los visitantes cambia solo cuando cambia algo de verdad.
        _set(conn, "legal_updated", datetime.now(timezone.utc).date().isoformat())
    return get(conn)


def record_acceptance(conn: sqlite3.Connection, user_id: int) -> None:
    """Deja constancia de que esta cuenta aceptó los textos vigentes (fecha y versión)."""
    conn.execute(
        "UPDATE users SET terms_accepted_at = ?, terms_version = ? WHERE id = ?",
        (datetime.now(timezone.utc).isoformat(), _get(conn, "legal_updated"), user_id),
    )
