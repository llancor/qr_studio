"""Los datos de una cuenta: descargarlos y eliminarla.

Lo pide el Aviso de privacidad (derechos de acceso, portabilidad y supresión). Lo que vive en una cuenta:
  · filas en SQLite: el usuario, su aspecto (`user_prefs`), sus QR dinámicos y sus páginas (con contadores y archivos);
  · carpetas de QR guardados con «Masivo»:  <datos>/qr/<id>/<carpeta>/*.png
  · archivos de sus páginas dinámicas:      <datos>/paginas/<id>/<token>.<ext>
Eliminar la fila de `users` borra todas las filas de SQLite en cascada (las claves foráneas llevan ON DELETE CASCADE);
los archivos de disco hay que quitarlos aparte, DESPUÉS de confirmar el cambio en la base de datos.
"""

from __future__ import annotations

import json
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import pages
from .admin import AdminError
from .files import QrStore

LEEME = """Tus datos de {site}
Generado el {when}.

Contenido de este archivo:
  datos.json    Tu cuenta, tu aspecto, tus QR dinámicos y tus páginas, con sus contadores, en un formato que otro
                programa puede leer.
  qr/           Los códigos QR que guardaste en carpetas (uno por archivo PNG).
  paginas/      Las imágenes y los PDF que subiste a tus páginas.
  portada.*     Tu imagen de portada, si pusiste una.

No incluye tu contraseña: nunca se guarda tal cual, solo una huella que no permite recuperarla.
"""


def _rows(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> list[dict]:
    return [dict(row) for row in conn.execute(sql, params).fetchall()]


def _collect(conn: sqlite3.Connection, user_id: int) -> dict:
    """Todo lo textual de la cuenta, listo para escribir como JSON (sin la contraseña ni los tokens de sesión)."""
    user = conn.execute(
        "SELECT id, email, name, role, active, created_at, terms_accepted_at, terms_version FROM users WHERE id = ?",
        (user_id,),
    ).fetchone()
    prefs = conn.execute("SELECT prefs, cover_mime, cover_v, updated_at FROM user_prefs WHERE user_id = ?", (user_id,)).fetchone()
    dynamic = _rows(
        conn,
        "SELECT id, code, name, target, active, scans, last_scan_at, created_at, updated_at FROM dynamic_qr WHERE user_id = ? ORDER BY id",
        (user_id,),
    )
    for item in dynamic:
        item["scansPerDay"] = _rows(conn, "SELECT day, count FROM dynamic_qr_daily WHERE qr_id = ? ORDER BY day", (item.pop("id"),))
    pages_out = []
    for row in conn.execute("SELECT * FROM pages WHERE user_id = ? ORDER BY id", (user_id,)).fetchall():
        pages_out.append(
            {
                "code": row["code"],
                "template": row["template"],
                "name": row["name"],
                "content": json.loads(row["content"]),
                "active": bool(row["active"]),
                "expiresAt": row["expires_at"],
                "views": row["views"],
                "lastViewAt": row["last_view_at"],
                "createdAt": row["created_at"],
                "updatedAt": row["updated_at"],
                "viewsPerDay": _rows(conn, "SELECT day, count FROM pages_daily WHERE page_id = ? ORDER BY day", (row["id"],)),
                "clicks": _rows(conn, "SELECT key, count FROM pages_clicks WHERE page_id = ? ORDER BY key", (row["id"],)),
                "files": [
                    {"token": a["token"], "kind": a["kind"], "name": a["filename"], "mime": a["mime"], "bytes": a["bytes"]}
                    for a in conn.execute("SELECT * FROM page_assets WHERE page_id = ? ORDER BY id", (row["id"],)).fetchall()
                ],
            }
        )
    return {
        "account": {
            "id": user["id"],
            "email": user["email"],
            "name": user["name"],
            "role": user["role"],
            "active": bool(user["active"]),
            "createdAt": user["created_at"],
            "termsAcceptedAt": user["terms_accepted_at"],
            "termsVersion": user["terms_version"],
        },
        "appearance": {
            "preferences": json.loads(prefs["prefs"]) if prefs and prefs["prefs"] else None,
            "coverMime": prefs["cover_mime"] if prefs else None,
            "updatedAt": prefs["updated_at"] if prefs else None,
        },
        "dynamicQr": dynamic,
        "pages": pages_out,
    }


def export_zip(conn: sqlite3.Connection, store: QrStore, pages_root: Path, user_id: int, site: str, version: str):
    """Un .zip con todos los datos de la cuenta. Devuelve el archivo temporal abierto; quien lo llama debe cerrarlo."""
    data = _collect(conn, user_id)
    now = datetime.now(timezone.utc)
    folders = []
    for folder in store.list_folders(user_id)["folders"]:
        listing = store.list_files(user_id, folder["name"])
        folders.append({"name": folder["name"], "files": [f["name"] for f in listing["files"]]})
    data["qrFolders"] = folders
    data["exportedAt"] = now.isoformat()
    data["appVersion"] = version

    tmp = tempfile.SpooledTemporaryFile(max_size=32 * 1024 * 1024)  # noqa: SIM115 (lo cierra el llamador)
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as archive:  # imágenes y PDF ya van comprimidos
        archive.writestr("LEEME.txt", LEEME.format(site=site, when=now.strftime("%Y-%m-%d %H:%M UTC")))
        archive.writestr("datos.json", json.dumps(data, ensure_ascii=False, indent=2))
        for folder in folders:
            for name in folder["files"]:
                archive.write(store.file_path(user_id, folder["name"], name), arcname=f"qr/{folder['name']}/{name}")
        for page in data["pages"]:
            for asset in page["files"]:
                path = pages.asset_path(pages_root, user_id, asset["token"], pages._ext_for(asset["mime"]))
                if path.is_file():
                    archive.write(path, arcname=f"paginas/{path.name}")
        cover = conn.execute("SELECT cover, cover_mime FROM user_prefs WHERE user_id = ? AND cover IS NOT NULL", (user_id,)).fetchone()
        if cover:
            ext = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}.get(cover["cover_mime"], "img")
            archive.writestr(f"portada.{ext}", bytes(cover["cover"]))
    tmp.seek(0)
    return tmp


def delete_user(conn: sqlite3.Connection, user_id: int) -> None:
    """Borra la cuenta y, en cascada, todas sus filas. No quita archivos de disco: eso lo hace `remove_files` después."""
    row = conn.execute("SELECT role, active FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise AdminError(404, "Ese usuario no existe.")
    if row["role"] == "admin" and row["active"]:
        others = conn.execute(
            "SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1 AND id != ?", (user_id,)
        ).fetchone()[0]
        if others == 0:
            raise AdminError(409, "Es el único administrador activo: nombra a otra persona administradora antes de eliminar esta cuenta.")
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))


def remove_files(store: QrStore, pages_root: Path, user_id: int) -> None:
    """Quita del disco las carpetas de QR y los archivos de páginas de esa cuenta (tras confirmar el borrado en la base)."""
    store.delete_user(user_id)
    shutil.rmtree(Path(pages_root) / str(int(user_id)), ignore_errors=True)
