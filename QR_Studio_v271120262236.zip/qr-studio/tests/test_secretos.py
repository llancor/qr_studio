"""Cifrado en reposo de las credenciales guardadas (contraseña del SMTP). Ejecutar desde web/:  python -m pytest"""

import base64
import os
import re
import sqlite3
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app import db, mail, secretos
from app.config import Settings
from app.main import create_app

APP = Path(__file__).resolve().parents[1] / "app"
USER = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
PASSWORD = "contrasena-smtp-ultra-secreta"
SMTP = {
    "host": "smtp.example.com",
    "port": 587,
    "security": "starttls",
    "user": "avisos@example.com",
    "sender": "avisos@example.com",
    "senderName": "Avisos",
    "siteUrl": "https://qr.example.com",
}


@pytest.fixture(autouse=True)
def no_env_key(monkeypatch):
    monkeypatch.delenv(secretos.ENV_KEY, raising=False)


def make_settings(tmp_path):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
        files_path=tmp_path / "qr",
    )


@pytest.fixture()
def app(tmp_path):
    return create_app(make_settings(tmp_path))


@pytest.fixture()
def boss(app):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=USER).status_code == 201  # la primera cuenta es la del administrador
    return client


def save_smtp(boss, **changes):
    return boss.put("/api/admin/smtp", json={**SMTP, "password": PASSWORD, **changes})


def raw(tmp_path, key="smtp_password"):
    with sqlite3.connect(tmp_path / "test.db") as conn:
        row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
    return None if row is None else row[0]


def database_bytes(tmp_path) -> bytes:
    return b"".join(path.read_bytes() for path in sorted(tmp_path.glob("test.db*")))


def test_the_smtp_password_is_stored_encrypted(boss, tmp_path):
    assert save_smtp(boss).status_code == 200
    stored = raw(tmp_path)
    assert stored.startswith(secretos.PREFIX) and PASSWORD not in stored
    # En ningún archivo de la base de datos (principal ni -wal) queda la contraseña en claro.
    assert PASSWORD.encode() not in database_bytes(tmp_path)


def test_the_password_is_still_usable_and_never_returned(boss, app, tmp_path):
    save_smtp(boss)
    with db.connect(tmp_path / "test.db") as conn:
        cfg = mail.load(conn)
    assert cfg is not None and cfg.password == PASSWORD
    view = boss.get("/api/admin/smtp")
    assert view.json()["passwordSet"] is True and PASSWORD not in view.text


def test_other_settings_stay_readable(boss, tmp_path):
    save_smtp(boss)
    assert raw(tmp_path, "smtp_host") == "smtp.example.com"
    assert raw(tmp_path, "site_url") == "https://qr.example.com"


def test_the_key_lives_in_a_file_next_to_the_database_not_inside_it(boss, tmp_path):
    save_smtp(boss)
    key_file = tmp_path / secretos.KEY_FILE
    key = base64.b64decode(key_file.read_bytes().strip(), validate=True)
    assert len(key) == 32
    assert key not in database_bytes(tmp_path) and base64.b64encode(key) not in database_bytes(tmp_path)
    if os.name != "nt":
        assert key_file.stat().st_mode & 0o077 == 0  # solo el dueño puede leerla


def test_the_same_password_is_encrypted_differently_each_time(boss, tmp_path):
    save_smtp(boss)
    first = raw(tmp_path)
    save_smtp(boss)
    assert raw(tmp_path) != first  # nonce aleatorio


def test_clearing_the_password_leaves_nothing_stored(boss, tmp_path):
    save_smtp(boss)
    res = boss.put("/api/admin/smtp", json={**SMTP, "clearPassword": True})
    assert res.json()["passwordSet"] is False and raw(tmp_path) == ""


def test_a_password_saved_in_clear_by_an_older_version_is_encrypted_on_startup(tmp_path):
    path = tmp_path / "test.db"
    db.init_db(path)
    with db.connect(path) as conn:
        conn.execute("INSERT INTO app_settings (key, value) VALUES ('smtp_host', 'smtp.example.com')")
        conn.execute("INSERT INTO app_settings (key, value) VALUES ('smtp_from', 'avisos@example.com')")
        conn.execute("INSERT INTO app_settings (key, value) VALUES ('smtp_password', ?)", (PASSWORD,))
    assert PASSWORD.encode() in database_bytes(tmp_path)

    db.init_db(path)  # lo que pasa al arrancar la versión nueva

    stored = raw(tmp_path)
    assert stored.startswith(secretos.PREFIX) and PASSWORD not in stored
    assert PASSWORD.encode() not in database_bytes(tmp_path)  # tampoco queda el valor viejo en el archivo
    with db.connect(path) as conn:
        assert mail.load(conn).password == PASSWORD
    db.init_db(path)  # y arrancar otra vez no lo cifra dos veces
    assert raw(tmp_path) == stored


def test_losing_the_key_reads_as_no_password_and_does_not_break_the_site(boss, tmp_path):
    save_smtp(boss)
    (tmp_path / secretos.KEY_FILE).unlink()
    secretos._keys.clear()  # como un proceso nuevo: la clave nueva no abre lo guardado con la anterior
    res = boss.get("/api/admin/smtp")
    assert res.status_code == 200 and res.json()["passwordSet"] is False
    with db.connect(tmp_path / "test.db") as conn:
        assert mail.load(conn).password == ""
    assert save_smtp(boss).status_code == 200  # el administrador vuelve a escribirla y todo sigue
    with db.connect(tmp_path / "test.db") as conn:
        assert mail.load(conn).password == PASSWORD


def test_a_tampered_value_is_rejected(boss, tmp_path):
    save_smtp(boss)
    stored = raw(tmp_path)
    broken = stored[:-4] + ("AAAA" if not stored.endswith("AAAA") else "BBBB")
    with sqlite3.connect(tmp_path / "test.db") as conn:
        conn.execute("UPDATE app_settings SET value = ? WHERE key = 'smtp_password'", (broken,))
    assert boss.get("/api/admin/smtp").json()["passwordSet"] is False


def test_an_encrypted_value_does_not_open_under_another_setting_name(boss, tmp_path):
    save_smtp(boss)
    stored = raw(tmp_path)
    with db.connect(tmp_path / "test.db") as conn:
        assert secretos.unseal(conn, "smtp_password", stored) == PASSWORD
        assert secretos.unseal(conn, "otra_clave", stored) == ""


def test_the_key_can_come_from_the_environment_instead_of_a_file(boss, tmp_path, monkeypatch):
    monkeypatch.setenv(secretos.ENV_KEY, "x" * 40)
    assert save_smtp(boss).status_code == 200
    assert not (tmp_path / secretos.KEY_FILE).exists()
    with db.connect(tmp_path / "test.db") as conn:
        assert mail.load(conn).password == PASSWORD
    monkeypatch.setenv(secretos.ENV_KEY, "y" * 40)  # otra clave no abre lo guardado
    with db.connect(tmp_path / "test.db") as conn:
        assert mail.load(conn).password == ""


def test_a_short_environment_key_is_refused_with_a_clear_message(boss, monkeypatch):
    monkeypatch.setenv(secretos.ENV_KEY, "corta")
    res = save_smtp(boss)
    assert res.status_code == 503 and secretos.ENV_KEY in res.json()["detail"]


def test_a_damaged_key_file_is_not_silently_replaced(boss, tmp_path):
    save_smtp(boss)
    (tmp_path / secretos.KEY_FILE).write_text("esto no es una clave", encoding="utf-8")
    secretos._keys.clear()
    assert save_smtp(boss).status_code == 503  # no se inventa una clave nueva que dejaría sin abrir lo guardado
    assert boss.get("/api/admin/smtp").json()["passwordSet"] is False


def test_the_migration_file_still_carries_the_password_when_asked(boss):
    save_smtp(boss)
    res = boss.post("/api/admin/migration/export", json={"password": "migracion-clave-1", "smtpPassword": True})
    assert res.status_code == 200 and PASSWORD not in res.text  # y el archivo va cifrado con su propia contraseña


def test_nothing_credential_like_is_saved_without_being_declared_secret():
    # Si alguien guarda una clave nueva en app_settings (…_password, …_token, …_api_key…) debe añadirla a
    # SECRET_SETTINGS de app/secretos.py para que se cifre.
    pattern = re.compile(r'(?:_set|set_setting)\(\s*conn,\s*"([a-z_]+)"')
    names = {name for source in APP.glob("*.py") for name in pattern.findall(source.read_text(encoding="utf-8"))}
    assert "smtp_password" in names
    credentials = {name for name in names if re.search(r"password|secret|token|api_?key|credential", name)}
    assert credentials <= secretos.SECRET_SETTINGS
