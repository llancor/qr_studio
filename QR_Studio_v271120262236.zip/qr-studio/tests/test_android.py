"""App de Android (subir el .apk y descargarlo) y manifiesto para instalar el sitio. Ejecutar desde web/:  python -m pytest"""

import io
import zipfile

import pytest
from fastapi.testclient import TestClient

from app import android
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}


def make_zip(*names: str) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as z:
        for name in names:
            z.writestr(name, b"contenido")
    return buffer.getvalue()


APK = make_zip("AndroidManifest.xml", "classes.dex", "res/icon.png")
AAB = make_zip("base/manifest/AndroidManifest.xml", "base/dex/classes.dex")  # un .aab: no se puede instalar
EMPTY = {"available": False, "filename": "", "size": 0, "uploadedAt": ""}


@pytest.fixture()
def app(tmp_path):
    return create_app(
        Settings(
            db_path=tmp_path / "test.db",
            session_days=14,
            cookie_secure=False,
            min_password_length=8,
            login_max_attempts=5,
            login_window_seconds=300,
            files_path=tmp_path / "qr",
        )
    )


def sign_up(app, who):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=who).status_code == 201
    return client


@pytest.fixture()
def ana(app):
    return sign_up(app, ANA)  # la primera cuenta es la del administrador


@pytest.fixture()
def luis(app, ana):
    return sign_up(app, LUIS)


# ----- Sin archivo ------------------------------------------------------------------


def test_starts_without_an_app(app):
    guest = TestClient(app, follow_redirects=False)
    assert guest.get("/api/auth/android").json() == EMPTY  # público: el pie lo consulta sin sesión
    assert guest.get("/api/auth/android/download").status_code == 404


# ----- Subir y descargar -------------------------------------------------------------


def test_admin_uploads_and_anyone_downloads_without_a_session(app, ana):
    info = ana.put("/api/admin/android?name=Mi%20App.apk", content=APK).json()
    assert info["available"] is True and info["filename"] == "Mi App.apk" and info["size"] == len(APK)
    assert info["uploadedAt"].startswith("20")

    guest = TestClient(app, follow_redirects=False)
    assert guest.get("/api/auth/android").json() == info
    res = guest.get("/api/auth/android/download")
    assert res.status_code == 200 and res.content == APK
    assert res.headers["content-type"] == "application/vnd.android.package-archive"
    disposition = res.headers["content-disposition"]  # el nombre va codificado (RFC 5987): «Mi App.apk» → Mi%20App.apk
    assert disposition.startswith("attachment") and "Mi%20App.apk" in disposition


def test_uploading_again_replaces_the_file(ana):
    ana.put("/api/admin/android?name=uno.apk", content=APK)
    bigger = make_zip("AndroidManifest.xml", "classes.dex", "res/otro.bin", "lib/x.so")
    info = ana.put("/api/admin/android?name=dos.apk", content=bigger).json()
    assert info["filename"] == "dos.apk" and info["size"] == len(bigger)


def test_delete_removes_the_app(app, ana):
    ana.put("/api/admin/android", content=APK)
    assert ana.delete("/api/admin/android").json() == EMPTY
    guest = TestClient(app, follow_redirects=False)
    assert guest.get("/api/auth/android").json() == EMPTY
    assert guest.get("/api/auth/android/download").status_code == 404


# ----- Solo el administrador sube o quita ---------------------------------------------


def test_only_the_admin_can_upload_or_delete(app, ana, luis):
    guest = TestClient(app, follow_redirects=False)
    for client, expected in ((guest, 401), (luis, 403)):
        assert client.put("/api/admin/android", content=APK).status_code == expected
        assert client.delete("/api/admin/android").status_code == expected
    assert guest.get("/api/auth/android").json() == EMPTY  # no quedó nada


# ----- Validación ---------------------------------------------------------------------


@pytest.mark.parametrize(
    "body",
    [b"", b"no soy un zip", b"PK\x03\x04roto", make_zip("hola.txt"), AAB],
    ids=["vacio", "texto", "zip-roto", "zip-sin-manifiesto", "aab"],
)
def test_files_that_are_not_an_apk_are_rejected(ana, body):
    assert ana.put("/api/admin/android", content=body).status_code == 422
    assert ana.get("/api/auth/android").json() == EMPTY  # un rechazo no deja nada a medias


def test_too_big_is_rejected(ana, monkeypatch):
    monkeypatch.setattr(android, "MAX_BYTES", len(APK) - 1)
    res = ana.put("/api/admin/android", content=APK)
    assert res.status_code == 413 and "demasiado grande" in res.json()["detail"]
    assert ana.get("/api/auth/android").json() == EMPTY


@pytest.mark.parametrize(
    "raw, expected",
    [
        ("Mi App.apk", "Mi App.apk"),
        ("QR_Studio_v1", "QR_Studio_v1.apk"),
        ("../../etc/passwd", "passwd.apk"),
        ("C:\\Users\\ana\\app.APK", "app.apk"),
        ("<script>.apk", "_script_.apk"),
        ("", "app.apk"),
        (None, "app.apk"),
        ("   ..  ", "app.apk"),
        ("a" * 200, "a" * 80 + ".apk"),
    ],
)
def test_the_download_name_is_always_safe(raw, expected):
    assert android.clean_filename(raw) == expected


# ----- Instalar el sitio como app (manifiesto) ---------------------------------------------


def test_manifest_and_icons_are_public(app):
    guest = TestClient(app, follow_redirects=False)
    res = guest.get("/manifest.webmanifest")
    assert res.status_code == 200 and res.headers["content-type"].startswith("application/manifest+json")
    manifest = res.json()
    assert manifest["display"] == "standalone" and manifest["start_url"] == "/" and manifest["name"] == "QR Studio"
    sizes = {icon["sizes"] for icon in manifest["icons"]}
    assert {"192x192", "512x512"} <= sizes and any(icon["purpose"] == "maskable" for icon in manifest["icons"])
    for icon in manifest["icons"]:  # cada icono existe y se pide sin sesión, como lo hace el navegador
        got = guest.get(icon["src"])
        assert got.status_code == 200 and got.headers["content-type"] == "image/png", icon["src"]
    assert guest.get("/icons/apple-touch-icon.png").status_code == 200


def test_manifest_uses_the_site_name(app, ana):
    ana.put("/api/admin/branding", json={"name": "Mi Tienda de Cafe Especial"})
    manifest = TestClient(app).get("/manifest.webmanifest").json()
    assert manifest["name"] == "Mi Tienda de Cafe Especial"
    assert manifest["short_name"] == "Mi Tienda de"  # el nombre corto cabe bajo el icono (12 letras)


def test_pages_link_the_manifest():
    from pathlib import Path

    static = Path(__file__).resolve().parent.parent / "app" / "static"
    pages = [p for p in static.glob("**/index.html") if "vendor" not in p.parts]
    assert len(pages) >= 10
    for page in pages:
        html = page.read_text(encoding="utf-8")
        assert 'rel="manifest" href="/manifest.webmanifest"' in html, page
        assert 'rel="apple-touch-icon" href="/icons/apple-touch-icon.png"' in html, page
