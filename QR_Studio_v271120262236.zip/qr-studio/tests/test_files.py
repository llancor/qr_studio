"""Tests de las carpetas de QR por usuario. Ejecutar desde web/:  python -m pytest"""

import io
import struct
import zipfile
import zlib
from dataclasses import replace

import pytest
from fastapi.testclient import TestClient

from app import files
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}


def png_bytes(width: int = 8, height: int = 8) -> bytes:
    """PNG mínimo válido (gris) para las pruebas."""

    def chunk(kind: bytes, data: bytes) -> bytes:
        body = kind + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    raw = b"".join(b"\x00" + b"\x80" * width for _ in range(height))
    return (
        files.PNG_SIGNATURE
        + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw))
        + chunk(b"IEND", b"")
    )


@pytest.fixture()
def settings(tmp_path):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
        files_path=tmp_path / "qr",
    )


@pytest.fixture()
def app(settings):
    return create_app(settings)


@pytest.fixture()
def ana(app):
    client = TestClient(app)
    assert client.post("/api/auth/register", json=ANA).status_code == 201
    return client


@pytest.fixture()
def luis(app):
    client = TestClient(app)
    assert client.post("/api/auth/register", json=LUIS).status_code == 201
    return client


def upload(client, folder, name, data=None):
    return client.post(
        f"/api/qr/folders/{folder}/files",
        params={"name": name},
        content=data if data is not None else png_bytes(),
        headers={"Content-Type": "image/png"},
    )


# ----- Nombres seguros -------------------------------------------------------


@pytest.mark.parametrize(
    "raw, expected",
    [
        ("Mi lote 2026", "Mi lote 2026"),
        ("  espacios   raros  ", "espacios raros"),
        ("a/b\\c", "a-b-c"),
        ("../../etc/passwd", "etc-passwd"),
        ("camión áéí ñ", "camión áéí ñ"),
        ("nombre.", "nombre"),
        ("con", "_con"),
        ("NUL.txt", "_NUL.txt"),
    ],
)
def test_safe_name(raw, expected):
    assert files.safe_name(raw) == expected


@pytest.mark.parametrize("raw", ["", "   ", "..", "...", "---", "/", "\\"])
def test_safe_name_rejects_empty(raw):
    with pytest.raises(files.StoreError):
        files.safe_name(raw)


def test_safe_name_limits_length():
    assert len(files.safe_name("x" * 500)) == 60


def test_validate_png():
    files.validate_png(png_bytes(), 10_000)
    for bad in (b"", b"no es png", files.PNG_SIGNATURE + b"x" * 40, png_bytes()[:20]):
        with pytest.raises(files.StoreError) as err:
            files.validate_png(bad, 10_000)
        assert err.value.status == 415
    with pytest.raises(files.StoreError) as err:
        files.validate_png(png_bytes(), 10)
    assert err.value.status == 413
    with pytest.raises(files.StoreError):
        files.validate_png(png_bytes(files.MAX_PIXELS_SIDE + 1, 1), 10_000_000)


# ----- Autenticación ---------------------------------------------------------


def test_all_endpoints_require_login(app):
    client = TestClient(app)
    calls = [
        ("get", "/api/qr/folders", {}),
        ("post", "/api/qr/folders", {"json": {"name": "x"}}),
        ("get", "/api/qr/folders/x", {}),
        ("delete", "/api/qr/folders/x", {}),
        ("post", "/api/qr/folders/x/files?name=a", {"content": png_bytes()}),
        ("get", "/api/qr/folders/x/files/a.png", {}),
        ("delete", "/api/qr/folders/x/files/a.png", {}),
        ("get", "/api/qr/folders/x/zip", {}),
    ]
    for method, url, kwargs in calls:
        res = getattr(client, method)(url, **kwargs)
        assert res.status_code == 401, (method, url)


def test_cross_origin_write_is_rejected(ana):
    res = ana.post("/api/qr/folders", json={"name": "x"}, headers={"Origin": "https://malo.example"})
    assert res.status_code == 403


# ----- Carpetas y archivos ---------------------------------------------------


def test_full_flow(ana, settings):
    assert ana.get("/api/qr/folders").json()["folders"] == []

    res = ana.post("/api/qr/folders", json={"name": "  Mi lote  "})
    assert res.status_code == 201
    assert res.json() == {"name": "Mi lote", "created": True}
    assert ana.post("/api/qr/folders", json={"name": "Mi lote"}).json()["created"] is False

    saved = upload(ana, "Mi lote", "sitio-1.png")
    assert saved.status_code == 201
    assert saved.json()["name"] == "sitio-1.png"
    assert upload(ana, "Mi lote", "sitio-2").json()["name"] == "sitio-2.png"  # sin extensión: se añade

    folders = ana.get("/api/qr/folders").json()
    assert folders["folders"][0]["name"] == "Mi lote"
    assert folders["folders"][0]["count"] == 2
    assert folders["quota"]["used"] > 0

    listing = ana.get("/api/qr/folders/Mi lote").json()
    assert [f["name"] for f in listing["files"]] == ["sitio-1.png", "sitio-2.png"]

    shown = ana.get("/api/qr/folders/Mi lote/files/sitio-1.png")
    assert shown.status_code == 200
    assert shown.headers["content-type"] == "image/png"
    assert shown.content.startswith(files.PNG_SIGNATURE)
    assert "attachment" not in shown.headers.get("content-disposition", "")
    assert "attachment" in ana.get("/api/qr/folders/Mi lote/files/sitio-1.png?download=true").headers["content-disposition"]

    archive = ana.get("/api/qr/folders/Mi lote/zip")
    assert archive.status_code == 200
    assert archive.headers["content-type"] == "application/zip"
    with zipfile.ZipFile(io.BytesIO(archive.content)) as z:
        assert sorted(z.namelist()) == ["sitio-1.png", "sitio-2.png"]
        assert z.testzip() is None

    assert ana.delete("/api/qr/folders/Mi lote/files/sitio-1.png").status_code == 200
    assert ana.get("/api/qr/folders/Mi lote/files/sitio-1.png").status_code == 404
    assert ana.delete("/api/qr/folders/Mi lote").status_code == 200
    assert ana.get("/api/qr/folders/Mi lote").status_code == 404
    assert not (settings.files_path / "1" / "Mi lote").exists()


def test_name_collisions_get_a_suffix(ana):
    ana.post("/api/qr/folders", json={"name": "c"})
    names = [upload(ana, "c", "igual").json()["name"] for _ in range(3)]
    assert names == ["igual.png", "igual (2).png", "igual (3).png"]


def test_upload_requires_existing_folder(ana):
    assert upload(ana, "no-existe", "a").status_code == 404


def test_upload_rejects_non_png_and_large(ana, app):
    ana.post("/api/qr/folders", json={"name": "c"})
    assert upload(ana, "c", "a", b"<html>no soy png</html>").status_code == 415
    app.state.qr_store.limits = replace(app.state.qr_store.limits, max_file_bytes=50)
    assert upload(ana, "c", "a").status_code == 413


def test_quota_and_per_folder_limits(ana, app):
    store = app.state.qr_store
    ana.post("/api/qr/folders", json={"name": "c"})
    one = len(png_bytes())

    store.limits = replace(store.limits, quota_bytes=one * 2)
    assert upload(ana, "c", "a").status_code == 201
    assert upload(ana, "c", "b").status_code == 201
    assert upload(ana, "c", "c").status_code == 413  # sin espacio

    store.limits = replace(store.limits, quota_bytes=10**9, max_files_per_folder=2)
    assert upload(ana, "c", "d").status_code == 409  # carpeta llena

    store.limits = replace(store.limits, max_folders=1)
    assert ana.post("/api/qr/folders", json={"name": "otra"}).status_code == 409


def test_users_cannot_see_each_others_files(ana, luis):
    ana.post("/api/qr/folders", json={"name": "privada"})
    upload(ana, "privada", "secreto")

    assert luis.get("/api/qr/folders").json()["folders"] == []
    assert luis.get("/api/qr/folders/privada").status_code == 404
    assert luis.get("/api/qr/folders/privada/files/secreto.png").status_code == 404
    assert luis.get("/api/qr/folders/privada/zip").status_code == 404
    assert luis.delete("/api/qr/folders/privada").status_code == 404
    assert upload(luis, "privada", "intruso").status_code == 404
    # Ana sigue teniendo lo suyo.
    assert ana.get("/api/qr/folders/privada/files/secreto.png").status_code == 200


@pytest.mark.parametrize("bad", ["...", "%2e%2e", "a%2f..%2f..", "", "%20"])
def test_path_traversal_is_not_possible(ana, settings, bad):
    ana.post("/api/qr/folders", json={"name": "ok"})
    for url in (
        f"/api/qr/folders/{bad}",
        f"/api/qr/folders/ok/files/{bad}",
        f"/api/qr/folders/{bad}/files/x.png",
    ):
        assert ana.get(url).status_code in {400, 404, 405, 422}, url  # 400: la ruta con «..» se rechaza antes de llegar aquí
    # Nada se escribió ni se borró fuera de la carpeta del usuario.
    assert (settings.files_path / "1" / "ok").is_dir()
    assert ana.post("/api/qr/folders", json={"name": "../fuera"}).json()["name"] == "fuera"
    assert not (settings.files_path / "fuera").exists()
    assert (settings.files_path / "1" / "fuera").is_dir()


@pytest.mark.parametrize("bad", ["..", ".", "../x", "x/..", "..\\x", "/etc/passwd", "C:\\Windows"])
def test_store_never_leaves_the_user_folder(tmp_path, bad):
    # El cliente HTTP ya normaliza «..» en la URL; aquí se prueba el almacén directamente.
    store = files.QrStore(tmp_path / "qr")
    store.create_folder(7, "ok")
    (tmp_path / "qr" / "secreto.png").write_bytes(png_bytes())
    for action in (
        lambda: store.file_path(7, bad, "a.png"),
        lambda: store.file_path(7, "ok", bad),
        lambda: store.list_files(7, bad),
        lambda: store.delete_folder(7, bad),
        lambda: store.save_file(7, bad, "a", png_bytes()),
    ):
        with pytest.raises(files.StoreError):
            action()
    # Si el nombre se limpia hasta algo válido, queda dentro de la carpeta del usuario.
    user_dir = tmp_path / "qr" / "7"
    assert (tmp_path / "qr" / "secreto.png").exists()
    assert {p.name for p in user_dir.iterdir()} == {"ok"}


def test_database_file_is_not_reachable_through_files(ana, settings):
    ana.post("/api/qr/folders", json={"name": "ok"})
    assert ana.get("/api/qr/folders/ok/files/test.db").status_code == 404
    assert ana.get("/api/qr/folders/..%2F..%2Ftest.db/files/x").status_code in {400, 404, 422}
    assert settings.db_path.exists()
