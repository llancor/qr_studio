"""Tests de las páginas dinámicas (evento, empresa, carta). Ejecutar desde web/:  python -m pytest"""

import json
import sqlite3
import struct
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient

from app import pages
from app.config import Settings
from app.main import create_app

ANA = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}
LUIS = {"email": "luis@example.com", "name": "Luis", "password": "correct-horse-2"}

PNG_SIG = b"\x89PNG\r\n\x1a\n"
PDF = b"%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"


def png(width=10, height=10) -> bytes:
    return PNG_SIG + struct.pack(">I", 13) + b"IHDR" + struct.pack(">II", width, height) + b"\x08\x02\x00\x00\x00" + b"\x00" * 16


def make_settings(tmp_path, **extra):
    return Settings(
        db_path=tmp_path / "test.db",
        session_days=14,
        cookie_secure=False,
        min_password_length=8,
        login_max_attempts=5,
        login_window_seconds=300,
        files_path=tmp_path / "qr",
        pages_path=tmp_path / "paginas",
        **extra,
    )


@pytest.fixture()
def settings(tmp_path):
    return make_settings(tmp_path)


@pytest.fixture()
def app(settings):
    return create_app(settings)


def member(app, who):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=who).status_code == 201
    return client


@pytest.fixture()
def ana(app):
    return member(app, ANA)


@pytest.fixture()
def luis(app):
    return member(app, LUIS)


@pytest.fixture()
def visitor(app):
    return TestClient(app, follow_redirects=False)


def new_page(client, template="evento", name="Fiesta"):
    res = client.post("/api/paginas", json={"template": template, "name": name})
    assert res.status_code == 201, res.text
    return res.json()


def save(client, page, **changes):
    content = {**page["content"], **changes}
    return client.put(f"/api/paginas/{page['id']}", json={"content": content})


def upload(client, page_id, data, name="archivo.png"):
    return client.post(f"/api/paginas/{page_id}/archivos", params={"name": name}, content=data)


# ----- Acceso ------------------------------------------------------------------------------------


def test_requires_login(visitor):
    assert visitor.get("/api/paginas").status_code == 401
    assert visitor.post("/api/paginas", json={"template": "evento", "name": "x"}).status_code == 401


def test_features_reports_pages(ana):
    assert ana.get("/api/features").json()["pages"] is True


def test_can_be_disabled(tmp_path):
    app = create_app(make_settings(tmp_path, pages_enabled=False))
    client = member(app, ANA)
    assert client.get("/api/paginas").status_code == 404
    assert client.get("/p/abcdefg").status_code == 404


def test_public_assets_and_page_need_no_session(visitor):
    for path in ("/css/publica.css", "/js/publica.js", "/js/visor-pdf.js", "/vendor/page-flip.browser.js", "/vendor/pdf.min.js"):
        assert visitor.get(path).status_code == 200, path
    assert visitor.get("/p/abcdefg").status_code == 404  # sin sesión llega al aviso, no al login


# ----- Crear, editar y aislar ----------------------------------------------------------------------


def test_create_list_get(ana):
    page = new_page(ana, "carta", "Mi carta")
    assert page["template"] == "carta" and page["active"] is True
    assert len(page["code"]) == pages.CODE_LEN
    assert page["content"]["title"] == "Mi carta"
    assert page["content"]["carta"] == {"currency": "$", "notes": "", "sections": [], "book": []}
    listing = ana.get("/api/paginas").json()
    assert [p["id"] for p in listing["items"]] == [page["id"]]
    assert ana.get(f"/api/paginas/{page['id']}").json()["code"] == page["code"]


@pytest.mark.parametrize("template", ["", "tienda", "EVENTO"])
def test_rejects_unknown_template(ana, template):
    assert ana.post("/api/paginas", json={"template": template, "name": "x"}).status_code == 422


def test_requires_name(ana):
    assert ana.post("/api/paginas", json={"template": "evento", "name": "   "}).status_code == 422


def test_users_are_isolated(ana, luis):
    page = new_page(ana)
    for call in (
        lambda: luis.get(f"/api/paginas/{page['id']}"),
        lambda: luis.put(f"/api/paginas/{page['id']}", json={"active": False}),
        lambda: luis.delete(f"/api/paginas/{page['id']}"),
        lambda: luis.get(f"/api/paginas/{page['id']}/stats"),
        lambda: luis.get(f"/api/paginas/{page['id']}/vista"),
        lambda: upload(luis, page["id"], png()),
    ):
        assert call().status_code == 404
    assert luis.get("/api/paginas").json()["items"] == []


def test_limit_per_user(ana, monkeypatch):
    monkeypatch.setattr(pages, "MAX_PER_USER", 2)
    new_page(ana)
    new_page(ana)
    assert ana.post("/api/paginas", json={"template": "evento", "name": "tercera"}).status_code == 409


# ----- Validación del contenido ----------------------------------------------------------------------


def test_title_required_and_trimmed(ana):
    page = new_page(ana)
    assert save(ana, page, title="   ").status_code == 422
    res = save(ana, page, title="  Gran   fiesta  ")
    assert res.json()["content"]["title"] == "Gran fiesta"


def test_rejects_bad_theme(ana):
    page = new_page(ana)
    assert save(ana, page, theme="rosa-fosforito").status_code == 422


@pytest.mark.parametrize("value", ["javascript:alert(1)", "data:text/html,hola", "ftp://x.com/a", "https://exa mple.com"])
def test_link_buttons_only_accept_http(ana, value):
    page = new_page(ana)
    res = save(ana, page, buttons=[{"type": "link", "label": "Web", "value": value}])
    assert res.status_code == 422


def test_link_button_adds_https(ana):
    page = new_page(ana)
    res = save(ana, page, buttons=[{"type": "link", "label": "Web", "value": "ejemplo.com/menu"}])
    assert res.json()["content"]["buttons"][0]["value"] == "https://ejemplo.com/menu"


def test_other_button_kinds_validate(ana):
    page = new_page(ana)
    ok = [
        {"type": "phone", "label": "Llamar", "value": "+57 300 123 4567"},
        {"type": "whatsapp", "label": "WhatsApp", "value": "+57 300 123 4567"},
        {"type": "email", "label": "Correo", "value": "hola@ejemplo.com"},
        {"type": "map", "label": "Mapa", "value": "Calle 1 # 2-3, Bogotá"},
    ]
    assert save(ana, page, buttons=ok).status_code == 200
    for bad in (
        {"type": "phone", "label": "x", "value": "<script>"},
        {"type": "whatsapp", "label": "x", "value": "123"},
        {"type": "email", "label": "x", "value": "no-es-correo"},
        {"type": "mailto", "label": "x", "value": "a@b.co"},
        {"type": "link", "label": "", "value": "https://a.com"},
        {"type": "pdf", "label": "PDF", "value": ""},
    ):
        assert save(ana, page, buttons=[bad]).status_code == 422, bad


def test_too_many_buttons(ana):
    page = new_page(ana)
    buttons = [{"type": "link", "label": f"b{i}", "value": "https://a.com"} for i in range(pages.MAX_BUTTONS + 1)]
    assert save(ana, page, buttons=buttons).status_code == 422


def test_evento_dates(ana):
    page = new_page(ana)
    good = {"start": "2026-12-14T19:00", "end": "2026-12-14T22:00", "place": "Salón", "address": "Calle 1", "agenda": []}
    res = save(ana, page, evento=good)
    assert res.status_code == 200 and res.json()["content"]["evento"]["start"] == "2026-12-14T19:00"
    assert save(ana, page, evento={**good, "start": "mañana"}).status_code == 422
    assert save(ana, page, evento={**good, "end": "2026-12-14T18:00"}).status_code == 422
    assert save(ana, page, evento={**good, "start": "", "end": "2026-12-14T18:00"}).status_code == 422
    assert save(ana, page, evento={**good, "agenda": [{"time": "19:00", "title": ""}]}).status_code == 422


def test_empresa_contact_validation(ana):
    page = new_page(ana, "empresa", "Mi empresa")
    ok = {"phone": "601 234 5678", "email": "info@ejemplo.com", "web": "ejemplo.com", "address": "Av 1", "hours": "L-V 8 a 5"}
    res = save(ana, page, empresa=ok)
    assert res.status_code == 200 and res.json()["content"]["empresa"]["web"] == "https://ejemplo.com"
    assert save(ana, page, empresa={**ok, "email": "mal"}).status_code == 422
    assert save(ana, page, empresa={**ok, "web": "javascript:alert(1)"}).status_code == 422


def test_carta_prices_and_sections(ana):
    page = new_page(ana, "carta", "Carta")
    carta = {
        "currency": "$",
        "notes": "Contiene gluten",
        "sections": [{"name": "Entradas", "items": [{"name": "Nachos", "desc": "Con queso", "price": "12.500", "available": True}]}],
        "book": [],
    }
    assert save(ana, page, carta=carta).status_code == 200
    bad_price = {**carta, "sections": [{"name": "X", "items": [{"name": "Y", "price": "<b>1</b>"}]}]}
    assert save(ana, page, carta=bad_price).status_code == 422
    no_name = {**carta, "sections": [{"name": "", "items": []}]}
    assert save(ana, page, carta=no_name).status_code == 422


def test_active_and_expiry(ana):
    page = new_page(ana)
    res = ana.put(f"/api/paginas/{page['id']}", json={"active": False, "expiresAt": "2030-01-31"})
    assert res.json()["active"] is False and res.json()["expiresAt"] == "2030-01-31"
    assert ana.put(f"/api/paginas/{page['id']}", json={"expiresAt": "31/01/2030"}).status_code == 422
    cleared = ana.put(f"/api/paginas/{page['id']}", json={"expiresAt": ""})
    assert cleared.json()["expiresAt"] is None


# ----- Archivos --------------------------------------------------------------------------------------


def test_upload_detects_real_type(ana):
    page = new_page(ana)
    image = upload(ana, page["id"], png(), "logo.png")
    assert image.status_code == 201 and image.json()["kind"] == "image"
    document = upload(ana, page["id"], PDF, "flyer.pdf")
    assert document.status_code == 201 and document.json()["kind"] == "pdf"
    # Un archivo que dice ser PNG pero no lo es, o HTML disfrazado, se rechaza.
    assert upload(ana, page["id"], b"<script>alert(1)</script>", "x.png").status_code == 415
    assert upload(ana, page["id"], b"MZ\x90\x00" + b"\x00" * 100, "virus.pdf").status_code == 415
    assert upload(ana, page["id"], b"%PDF-1.4 sin cierre", "roto.pdf").status_code == 415


def test_upload_filename_is_sanitized(ana):
    page = new_page(ana)
    res = upload(ana, page["id"], png(), "../../etc/<passwd>.png")
    assert res.status_code == 201
    name = res.json()["name"]
    assert "/" not in name and "<" not in name and ".." not in name


def test_upload_limits(ana, app):
    app.state.pages_limits = pages.Limits(quota_bytes=1000, max_image_bytes=200, max_pdf_bytes=400)
    page = new_page(ana)
    assert upload(ana, page["id"], png() + b"0" * 400).status_code == 413  # imagen demasiado grande
    assert upload(ana, page["id"], PDF + b"0" * 600).status_code == 413  # PDF demasiado grande
    for _ in range(3):
        assert upload(ana, page["id"], png()).status_code == 201
    used = ana.get("/api/paginas").json()["quota"]["used"]
    assert used == 3 * len(png())
    big = PDF + b" " * 340
    assert upload(ana, page["id"], big).status_code == 201
    assert upload(ana, page["id"], big).status_code == 201
    assert upload(ana, page["id"], big).status_code == 413  # supera el espacio total


def test_asset_must_belong_to_page(ana):
    one, two = new_page(ana, name="Uno"), new_page(ana, name="Dos")
    token = upload(ana, one["id"], png()).json()["token"]
    assert save(ana, one, logo=token).status_code == 200
    assert save(ana, two, logo=token).status_code == 422
    assert save(ana, one, logo="0" * 20).status_code == 422


def test_pdf_cannot_be_used_as_image_and_vice_versa(ana):
    page = new_page(ana)
    pdf = upload(ana, page["id"], PDF).json()["token"]
    img = upload(ana, page["id"], png()).json()["token"]
    assert save(ana, page, logo=pdf).status_code == 422
    assert save(ana, page, buttons=[{"type": "pdf", "label": "Ver", "value": img}]).status_code == 422
    assert save(ana, page, buttons=[{"type": "pdf", "label": "Ver", "value": pdf}]).status_code == 200


def test_removing_asset_cleans_references(ana, settings):
    page = new_page(ana, "carta", "Carta")
    img = upload(ana, page["id"], png()).json()["token"]
    pdf = upload(ana, page["id"], PDF).json()["token"]
    carta = {"currency": "$", "notes": "", "book": [img], "sections": [{"name": "A", "items": [{"name": "B", "photo": img}]}]}
    save(ana, page, logo=img, cover=img, carta=carta, buttons=[{"type": "pdf", "label": "Carta", "value": pdf}])
    after = ana.delete(f"/api/paginas/{page['id']}/archivos/{img}").json()
    content = after["content"]
    assert content["logo"] == "" and content["cover"] == ""
    assert content["carta"]["book"] == [] and content["carta"]["sections"][0]["items"][0]["photo"] == ""
    assert len(content["buttons"]) == 1
    after = ana.delete(f"/api/paginas/{page['id']}/archivos/{pdf}").json()
    assert after["content"]["buttons"] == []
    assert after["assets"] == []
    assert not list((settings.pages_path / "1").glob("*")), "los archivos deben borrarse del disco"
    assert ana.delete(f"/api/paginas/{page['id']}/archivos/{pdf}").status_code == 404


def test_delete_page_removes_files(ana, settings):
    page = new_page(ana)
    upload(ana, page["id"], png())
    upload(ana, page["id"], PDF)
    assert len(list((settings.pages_path / "1").glob("*"))) == 2
    assert ana.delete(f"/api/paginas/{page['id']}").status_code == 200
    assert not list((settings.pages_path / "1").glob("*"))
    assert ana.get(f"/api/paginas/{page['id']}").status_code == 404


def test_owner_can_read_own_file_only(ana, luis):
    page = new_page(ana)
    token = upload(ana, page["id"], png()).json()["token"]
    res = ana.get(f"/api/paginas/{page['id']}/archivos/{token}")
    assert res.status_code == 200 and res.headers["content-type"] == "image/png"
    assert luis.get(f"/api/paginas/{page['id']}/archivos/{token}").status_code == 404


# ----- Página pública ----------------------------------------------------------------------------------


def test_public_page_counts_views_and_escapes(ana, visitor):
    page = new_page(ana, "evento", "Fiesta")
    evento = {
        "start": "2026-12-14T19:00",
        "end": "2026-12-14T22:00",
        "place": "<b>Salón</b>",
        "address": 'Calle "1"',
        "agenda": [{"time": "19:00", "title": "<script>x</script>", "detail": ""}],
    }
    res = save(ana, page, title="<img src=x onerror=alert(1)>", description="Hola <script>alert(1)</script>\n\nSegundo párrafo", evento=evento)
    assert res.status_code == 200, res.text
    html = visitor.get(f"/p/{page['code']}")
    assert html.status_code == 200 and html.headers["content-type"].startswith("text/html")
    body = html.text
    assert "<script>alert(1)" not in body and "<img src=x" not in body and "<b>Salón" not in body and "<script>x" not in body
    assert "&lt;script&gt;" in body and "&lt;b&gt;Salón" in body
    assert "<p>Segundo párrafo</p>" in body
    assert "lunes 14 de diciembre de 2026, 19:00 h a 22:00 h" in body  # el 14-dic-2026 cae en lunes
    assert html.headers["cache-control"] == "no-store"
    visitor.get(f"/p/{page['code']}")
    stats = ana.get(f"/api/paginas/{page['id']}/stats").json()
    assert stats["total"] == 2 and stats["days"][-1]["count"] == 2 and len(stats["days"]) == 30
    assert ana.get("/api/paginas").json()["items"][0]["views"] == 2


def test_preview_does_not_count(ana):
    page = new_page(ana)
    res = ana.get(f"/api/paginas/{page['id']}/vista")
    assert res.status_code == 200 and "Vista previa" in res.text
    assert ana.get(f"/api/paginas/{page['id']}/stats").json()["total"] == 0


def test_security_headers_on_public_page(ana, visitor):
    page = new_page(ana)
    res = visitor.get(f"/p/{page['code']}")
    assert "script-src 'self'" in res.headers["content-security-policy"]
    assert res.headers["x-content-type-options"] == "nosniff"
    assert "noindex" in res.text


def test_missing_paused_and_expired(ana, visitor):
    assert visitor.get("/p/zzzzzzz").status_code == 404
    page = new_page(ana)
    ana.put(f"/api/paginas/{page['id']}", json={"active": False})
    assert visitor.get(f"/p/{page['code']}").status_code == 410
    ana.put(f"/api/paginas/{page['id']}", json={"active": True})
    assert visitor.get(f"/p/{page['code']}").status_code == 200
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    ana.put(f"/api/paginas/{page['id']}", json={"expiresAt": yesterday})
    assert visitor.get(f"/p/{page['code']}").status_code == 410
    assert ana.get("/api/paginas").json()["items"][0]["expired"] is True
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    ana.put(f"/api/paginas/{page['id']}", json={"expiresAt": tomorrow})
    assert visitor.get(f"/p/{page['code']}").status_code == 200


def test_paused_page_does_not_count_views(ana, visitor):
    page = new_page(ana)
    ana.put(f"/api/paginas/{page['id']}", json={"active": False})
    visitor.get(f"/p/{page['code']}")
    assert ana.get(f"/api/paginas/{page['id']}/stats").json()["total"] == 0


def test_public_asset_headers(ana, visitor):
    page = new_page(ana)
    token = upload(ana, page["id"], PDF, "Mi carta.pdf").json()["token"]
    res = visitor.get(f"/p/{page['code']}/a/{token}")
    assert res.status_code == 200 and res.content == PDF
    assert res.headers["content-type"] == "application/pdf"
    assert res.headers["x-content-type-options"] == "nosniff"
    assert "max-age" in res.headers["cache-control"]
    download = visitor.get(f"/p/{page['code']}/a/{token}", params={"descargar": 1})
    assert "attachment" in download.headers["content-disposition"] and ".pdf" in download.headers["content-disposition"]
    assert visitor.get(f"/p/{page['code']}/a/{'0' * 20}").status_code == 404
    assert visitor.get(f"/p/{page['code']}/a/..%2f..%2fapp.db").status_code in {400, 404}  # 400: ruta con «..» rechazada


def test_asset_not_served_through_another_page(ana, visitor):
    one, two = new_page(ana, name="Uno"), new_page(ana, name="Dos")
    token = upload(ana, one["id"], png()).json()["token"]
    assert visitor.get(f"/p/{two['code']}/a/{token}").status_code == 404
    assert visitor.get(f"/p/{one['code']}/a/{token}").status_code == 200
    ana.put(f"/api/paginas/{one['id']}", json={"active": False})
    assert visitor.get(f"/p/{one['code']}/a/{token}").status_code == 404


def test_carta_public_renders_book_list_and_sold_out(ana, visitor):
    page = new_page(ana, "carta", "Mi carta")
    t1, t2 = (upload(ana, page["id"], png()).json()["token"] for _ in range(2))
    carta = {
        "currency": "$",
        "notes": "Propina voluntaria",
        "book": [t1, t2],
        "sections": [
            {
                "name": "Platos",
                "items": [
                    {"name": "Bandeja", "desc": "Con arroz", "price": "25.000", "available": True},
                    {"name": "Sopa", "desc": "", "price": "", "available": False},
                ],
            }
        ],
    }
    assert save(ana, page, carta=carta).status_code == 200
    html = visitor.get(f"/p/{page['code']}").text
    assert html.count('class="libro-pagina"') == 2 and f"/p/{page['code']}/a/{t1}" in html
    assert 'data-vista="libro"' in html and 'data-vista="lista"' in html
    assert "$25.000" in html and "Agotado" in html and "Propina voluntaria" in html
    assert 'class="plato es-agotado"' in html


def test_carta_without_book_has_no_tabs(ana, visitor):
    page = new_page(ana, "carta", "Carta")
    carta = {"currency": "$", "notes": "", "book": [], "sections": [{"name": "A", "items": [{"name": "B", "price": "1"}]}]}
    save(ana, page, carta=carta)
    html = visitor.get(f"/p/{page['code']}").text
    assert "data-vista" not in html and "libro-pagina" not in html and ">B<" in html


def test_pdf_button_renders_viewer_hook(ana, visitor):
    page = new_page(ana)
    pdf = upload(ana, page["id"], PDF, "flyer.pdf").json()["token"]
    buttons = [{"type": "pdf", "label": "Ver flyer", "value": pdf}, {"type": "link", "label": "Web", "value": "https://ejemplo.com"}]
    save(ana, page, buttons=buttons)
    html = visitor.get(f"/p/{page['code']}").text
    assert f'data-pdf="/p/{page["code"]}/a/{pdf}"' in html and "Ver flyer" in html
    assert 'href="https://ejemplo.com"' in html and 'rel="noopener noreferrer"' in html


def test_button_hrefs(ana, visitor):
    page = new_page(ana, "empresa", "Empresa")
    buttons = [
        {"type": "phone", "label": "Llamar", "value": "+57 (300) 123-4567"},
        {"type": "whatsapp", "label": "Chat", "value": "+57 300 123 4567"},
        {"type": "email", "label": "Correo", "value": "hola@ejemplo.com"},
        {"type": "map", "label": "Mapa", "value": "Calle 1 # 2-3"},
    ]
    save(ana, page, buttons=buttons)
    html = visitor.get(f"/p/{page['code']}").text
    assert 'href="tel:+573001234567"' in html
    assert 'href="https://wa.me/573001234567"' in html
    assert 'href="mailto:hola@ejemplo.com"' in html
    assert "google.com/maps/search/?api=1&amp;query=Calle%201%20%23%202-3" in html


# ----- Calendario y clics ---------------------------------------------------------------------------------


def test_ics_for_timed_event(ana, visitor):
    page = new_page(ana, name="Fiesta")
    evento = {"start": "2026-12-14T19:00", "end": "2026-12-14T22:30", "place": "Salón", "address": "Calle 1", "agenda": []}
    save(ana, page, title="Fiesta; de, fin", description="Línea 1\nLínea 2", evento=evento)
    res = visitor.get(f"/p/{page['code']}/evento.ics")
    assert res.status_code == 200 and res.headers["content-type"].startswith("text/calendar")
    assert "attachment" in res.headers["content-disposition"]
    text = res.text
    assert text.startswith("BEGIN:VCALENDAR\r\n") and text.endswith("END:VCALENDAR\r\n")
    assert "DTSTART:20261214T190000\r\n" in text and "DTEND:20261214T223000\r\n" in text
    assert "SUMMARY:Fiesta\\; de\\, fin" in text
    assert "LOCATION:Salón\\, Calle 1" in text
    assert "DESCRIPTION:Línea 1\\nLínea 2" in text
    assert all(len(line.encode()) <= 75 for line in text.split("\r\n"))


def test_ics_for_all_day_event_and_without_date(ana, visitor):
    page = new_page(ana)
    assert visitor.get(f"/p/{page['code']}/evento.ics").status_code == 404
    save(ana, page, evento={"start": "2026-12-14", "end": "", "place": "", "address": "", "agenda": []})
    text = visitor.get(f"/p/{page['code']}/evento.ics").text
    assert "DTSTART;VALUE=DATE:20261214" in text and "DTEND;VALUE=DATE:20261215" in text


def test_ics_folds_long_lines(ana, visitor):
    page = new_page(ana)
    save(ana, page, title="ñ" * 90, evento={"start": "2026-12-14T19:00", "end": "", "place": "", "address": "", "agenda": []})
    text = visitor.get(f"/p/{page['code']}/evento.ics").text
    assert all(len(line.encode()) <= 75 for line in text.split("\r\n"))
    assert "ñ" * 90 in text.replace("\r\n ", "")


def test_event_page_has_calendar_and_map_buttons(ana, visitor):
    page = new_page(ana)
    save(ana, page, evento={"start": "2026-12-14T19:00", "end": "", "place": "Salón", "address": "", "agenda": []})
    html = visitor.get(f"/p/{page['code']}").text
    assert f'href="/p/{page["code"]}/evento.ics"' in html and "Cómo llegar" in html


def test_click_counting(ana, visitor):
    page = new_page(ana)
    evento = {"start": "2026-12-14T19:00", "end": "", "place": "", "address": "", "agenda": []}
    save(ana, page, buttons=[{"type": "link", "label": "Reservar", "value": "https://ejemplo.com"}], evento=evento)
    for key in ("b0", "b0", "ics"):
        assert visitor.post(f"/p/{page['code']}/clic/{key}").status_code == 204
    for junk in ("b99999", "x", "b0;DROP"):
        assert visitor.post(f"/p/{page['code']}/clic/{junk}").status_code == 204
    clicks = ana.get(f"/api/paginas/{page['id']}/stats").json()["clicks"]
    assert clicks == [{"key": "b0", "label": "Reservar", "count": 2}, {"key": "ics", "label": "Agregar al calendario", "count": 1}]
    assert visitor.post("/p/zzzzzzz/clic/b0").status_code == 204


def test_click_rejects_foreign_origin(ana, visitor):
    page = new_page(ana)
    res = visitor.post(f"/p/{page['code']}/clic/b0", headers={"origin": "https://malo.example"})
    assert res.status_code == 403


# ----- Portada: ajuste y enfoque ---------------------------------------------------------------------


def test_cover_defaults_and_validation(ana):
    page = new_page(ana)
    assert page["content"]["coverFit"] == "cover" and page["content"]["coverPos"] == "center"
    ok = save(ana, page, coverFit="contain", coverPos="top")
    assert ok.status_code == 200
    assert ok.json()["content"]["coverFit"] == "contain" and ok.json()["content"]["coverPos"] == "top"
    for bad in ({"coverFit": "stretch"}, {"coverPos": "diagonal"}, {"coverFit": 5}, {"coverPos": ["top"]}):
        assert save(ana, page, **bad).status_code == 422, bad


def test_cover_classes_on_public_page(ana, visitor):
    page = new_page(ana)
    token = upload(ana, page["id"], png()).json()["token"]
    assert save(ana, page, cover=token).status_code == 200
    assert 'class="pub-cover fit-cover pos-center"' in visitor.get(f"/p/{page['code']}").text
    assert save(ana, page, cover=token, coverFit="contain", coverPos="bottom").status_code == 200
    assert 'class="pub-cover fit-contain pos-bottom"' in visitor.get(f"/p/{page['code']}").text


def test_pages_saved_before_cover_options_still_work(ana, visitor, settings):
    page = new_page(ana)
    token = upload(ana, page["id"], png()).json()["token"]
    save(ana, page, cover=token)
    with sqlite3.connect(settings.db_path) as conn:
        (raw,) = conn.execute("SELECT content FROM pages WHERE id = ?", (page["id"],)).fetchone()
        content = json.loads(raw)
        content.pop("coverFit")
        content.pop("coverPos")
        conn.execute("UPDATE pages SET content = ? WHERE id = ?", (json.dumps(content), page["id"]))
    assert 'class="pub-cover fit-cover pos-center"' in visitor.get(f"/p/{page['code']}").text
    # Un editor antiguo que no manda los campos tampoco rompe el guardado.
    res = ana.put(f"/api/paginas/{page['id']}", json={"content": content})
    assert res.status_code == 200 and res.json()["content"]["coverFit"] == "cover"


# ----- Unidades ------------------------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "data, kind",
    [(png(), "image"), (b"\xff\xd8\xff\xe0" + b"0" * 30, "image"), (b"RIFF\x00\x00\x00\x00WEBPVP8 " + b"0" * 8, "image"), (PDF, "pdf")],
)
def test_detect_file(data, kind):
    assert pages.detect_file(data)[0] == kind


@pytest.mark.parametrize("data", [b"", b"GIF89a....", b"<svg onload=alert(1)>", PNG_SIG, png(0, 5), png(99999, 5)])
def test_detect_file_rejects(data):
    with pytest.raises(pages.PageError) as exc:
        pages.detect_file(data)
    assert exc.value.status == 415
