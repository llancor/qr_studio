"""Tests del control de acceso: sin sesión solo se ve la página de acceso. Ejecutar desde web/:  python -m pytest"""

from urllib.parse import quote

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app

USER = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}


@pytest.fixture()
def app(tmp_path):
    return create_app(
        Settings(
            db_path=tmp_path / "test.db",
            session_days=14,
            cookie_secure=False,
            min_password_length=8,
            login_max_attempts=5,
            login_window_seconds=300,
            files_path=tmp_path / "qr",
        )
    )


@pytest.fixture()
def guest(app):
    return TestClient(app, follow_redirects=False)


@pytest.fixture()
def member(app):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=USER).status_code == 201
    return client


PAGES = ["/", "/index.html", "/png-a-ico/", "/png-a-ico/index.html", "/lector/", "/codigo-de-barras/", "/ajustes/"]
ASSETS = [
    "/js/app.js",
    "/js/qr.js",
    "/js/masivo.js",
    "/js/dinamico.js",
    "/js/auth.js",
    "/js/ico.js",
    "/js/zip.js",
    "/js/pdf.js",
    "/js/png-a-ico.js",
    "/js/lector.js",
    "/js/barras.js",
    "/js/ajustes.js",
    "/js/personalizacion.js",
    "/js/acceso-imagen.js",
    "/js/ajustes-migracion.js",
    "/js/admin-link.js",
    "/js/menu-movil.js",
    "/vendor/qr-code-styling.js",
    "/vendor/jsQR.js",
    "/vendor/JsBarcode.all.min.js",
]
PUBLIC = ["/entrar/", "/entrar/index.html", "/css/styles.css", "/js/entrar.js", "/js/version.js", "/js/tema.js", "/restablecer/", "/js/restablecer.js", "/js/migracion.js", "/privacidad/", "/terminos/", "/js/legal.js", "/api/auth/legal", "/api/auth/options", "/healthz"]


# ----- Sin sesión ---------------------------------------------------------------


@pytest.mark.parametrize("path", PAGES)
def test_pages_redirect_to_login(guest, path):
    res = guest.get(path, headers={"Accept": "text/html"})
    assert res.status_code == 303
    assert res.headers["location"] == f"/entrar/?next={quote(path, safe='')}"


def test_redirect_keeps_the_query_string(guest):
    res = guest.get("/?tipo=wifi", headers={"Accept": "text/html"})
    assert res.headers["location"] == "/entrar/?next=%2F%3Ftipo%3Dwifi"


def test_directory_without_slash_also_redirects_to_login(guest):
    res = guest.get("/png-a-ico", headers={"Accept": "text/html"})
    assert res.status_code == 303
    assert res.headers["location"].startswith("/entrar/?next=")


@pytest.mark.parametrize("path", ASSETS)
def test_assets_are_not_served_without_session(guest, path):
    res = guest.get(path)
    assert res.status_code == 401
    assert "function" not in res.text and "import " not in res.text  # ni una línea de código


def test_unknown_paths_do_not_reveal_whether_they_exist(guest):
    # Sin sesión todo da lo mismo (no se puede explorar el sitio).
    assert guest.get("/no-existe.js").status_code == 401
    assert guest.get("/no-existe/", headers={"Accept": "text/html"}).status_code == 303


@pytest.mark.parametrize("path", ["/entrar/../js/app.js", "/entrar/%2e%2e/js/app.js", "/css/styles.css/", "/CSS/styles.css"])
def test_public_list_cannot_be_bypassed_with_tricky_paths(guest, path):
    res = guest.get(path)
    assert res.status_code in {303, 400, 401, 404}
    assert "QRCodeStyling" not in res.text and "composeFrame" not in res.text


# Hallazgo de la prueba de seguridad (27-nov-2026): /p/ y /q/ son públicos y el servidor de archivos normalizaba «..»,
# así que /p/../js/app.js entregaba cualquier archivo del sitio sin iniciar sesión. Ahora la ruta con «..» se rechaza.
DOT_PATHS = [
    "/p/%2e%2e/js/app.js",
    "/p/..%2fjs/app.js",
    "/q/%2e%2e/index.html",
    "/api/auth/%2e%2e/%2e%2e/js/app.js",
    "/p/%2e%2e/ajustes/index.html",
    "/p/.%2fjs/app.js",
    # Con «\» en vez de «/»: en Windows el servidor de archivos también lo toma como separador.
    "/p/a/..%5c..%5cjs%5capp.js",
    "/q/a/..%5c..%5cindex.html",
    "/p/a/%5c..%5c..%5cjs%5capp.js",
]


@pytest.mark.parametrize(
    "path, bad",
    [("/p/../js/app.js", True), ("/p/./x", True), ("/p/..\\js\\app.js", True), ("/p/x\x00", True), ("/p/abc/evento.ics", False), ("/p/a.b/c..d", False), ("/js/app.js", False)],
)
def test_has_dot_segments(path, bad):
    # El cliente de pruebas no entrega «\» ni el byte nulo tal cual, así que se prueba la función directamente.
    from app.main import has_dot_segments

    assert has_dot_segments(path) is bad


@pytest.mark.parametrize("path", DOT_PATHS)
def test_dot_segments_cannot_reach_files_through_the_public_prefixes(guest, path):
    res = guest.get(path)
    assert res.status_code == 400
    assert "QRCodeStyling" not in res.text and "<html" not in res.text.lower()


@pytest.mark.parametrize("path", ["/p/%2e%2e/js/app.js", "/js/%2e%2e/js/app.js", "/api/qr/%2e%2e/folders"])
def test_dot_segments_are_rejected_even_with_a_session(member, path):
    assert member.get(path).status_code == 400


def test_cross_site_requests_without_origin_are_refused(member):
    # Algunos clientes no mandan «Origin»; el navegador sí dice desde dónde sale la petición.
    res = member.post("/api/qr/folders", json={"name": "csrf"}, headers={"Sec-Fetch-Site": "cross-site"})
    assert res.status_code == 403
    res = member.post("/api/qr/folders", json={"name": "csrf"}, headers={"Sec-Fetch-Site": "same-site"})
    assert res.status_code == 403
    for ok in ("same-origin", "none"):
        assert member.post("/api/qr/folders", json={"name": f"ok-{ok}"}, headers={"Sec-Fetch-Site": ok}).status_code == 201


def test_password_spraying_from_one_ip_is_blocked(guest):
    # Una contraseña común contra muchos correos distintos: el límite por correo no lo frena, el límite por IP sí.
    codes = [
        guest.post("/api/auth/login", json={"email": f"user{i}@example.com", "password": "Password123"}).status_code
        for i in range(40)
    ]
    assert codes[0] == 401 and 429 in codes
    assert codes.index(429) <= 30


def test_json_endpoints_refuse_huge_bodies_but_uploads_keep_their_own_limits(member):
    big = b"x" * (1024 * 1024 + 1)
    res = member.post("/api/auth/login", content=big, headers={"Content-Type": "application/json"})
    assert res.status_code == 413
    res = member.put("/api/me/prefs", content=big, headers={"Content-Type": "application/json"})
    assert res.status_code == 413
    # Una subida de archivos no pasa por ese tope (usa el suyo, de 4 MB): aquí llega hasta validar que no es un PNG.
    res = member.post("/api/qr/folders/nada/files?name=a", content=big)
    assert res.status_code == 415


@pytest.mark.parametrize(
    "method, path",
    [
        ("GET", "/api/paginas/99999999999999999999999"),
        ("GET", "/api/dynamic/99999999999999999999999/stats"),
        ("PATCH", "/api/admin/users/9223372036854775808"),
        ("DELETE", "/api/dynamic/99999999999999999999999"),
    ],
)
def test_ids_bigger_than_any_integer_are_just_not_found(member, method, path):
    # Prueba de seguridad del 27-nov-2026: un id enorme daba error 500 (desbordamiento de SQLite).
    res = member.request(method, path, json={"active": True} if method == "PATCH" else None)
    assert res.status_code == 404  # «member» es la primera cuenta, o sea administradora: llega hasta buscar el id


def test_security_headers_include_permissions_policy(member):
    headers = member.get("/").headers
    assert "camera=(self)" in headers["Permissions-Policy"] and "microphone=()" in headers["Permissions-Policy"]
    assert "Strict-Transport-Security" not in headers  # la prueba corre sin https (cookie_secure=False)


def test_api_requires_login_but_auth_endpoints_are_open(guest):
    assert guest.get("/api/qr/folders").status_code == 401
    assert guest.get("/api/otra-cosa").status_code == 401
    assert guest.get("/api/auth/me").json() == {"user": None}
    assert guest.post("/api/auth/login", json={"email": "x@y.zz", "password": "mala-clave"}).status_code == 401


@pytest.mark.parametrize("path", PUBLIC)
def test_login_page_and_its_files_are_public(guest, path):
    assert guest.get(path).status_code == 200


def test_login_page_is_the_only_html_without_session(guest):
    html = guest.get("/entrar/").text
    assert "Iniciar sesión" in html
    assert "composeFrame" not in html
    assert "/js/app.js" not in html  # la página de acceso no carga el generador


def test_security_headers_also_apply_to_rejections(guest):
    for res in (guest.get("/", headers={"Accept": "text/html"}), guest.get("/js/app.js")):
        assert "default-src 'self'" in res.headers["content-security-policy"]
        assert res.headers["x-content-type-options"] == "nosniff"
        assert res.headers["cache-control"] == "no-cache"


# ----- Con sesión ---------------------------------------------------------------------------------


@pytest.mark.parametrize("path", PAGES[:2] + PAGES[2:] + ASSETS + PUBLIC)
def test_everything_is_available_after_login(member, path):
    assert member.get(path).status_code == 200


def test_main_page_content_after_login(member):
    assert "Generador de códigos QR" in member.get("/").text


def test_logout_closes_the_whole_site(member):
    assert member.get("/js/app.js").status_code == 200
    assert member.post("/api/auth/logout").status_code == 200
    assert member.get("/js/app.js").status_code == 401
    assert member.get("/", headers={"Accept": "text/html"}).status_code == 303


def test_a_fake_or_expired_session_gets_nothing(guest):
    guest.cookies.set("session", "token-inventado")
    assert guest.get("/js/app.js").status_code == 401
    assert guest.get("/", headers={"Accept": "text/html"}).status_code == 303
    assert guest.get("/api/qr/folders").status_code == 401


def test_cache_is_revalidated_for_pages_and_never_stored_for_api(member):
    assert member.get("/").headers["cache-control"] == "no-cache"
    assert member.get("/api/auth/me").headers["cache-control"] == "no-store"
