// Selector de ubicación en un mapa para el QR «Ubicación». Usa Leaflet (vendor/leaflet) con los mapas de OpenStreetMap.
// Leaflet y su hoja de estilos se cargan solo cuando se abre esa pestaña. El mapa rellena los campos de latitud y
// longitud (que siguen siendo editables) y se mueve cuando se escriben a mano.
//
// Privacidad: el mapa pide las imágenes a tile.openstreetmap.org (ese servidor ve la IP y la zona que se mira, y recibe
// solo el dominio del sitio como «Referer»). La ubicación del dispositivo SOLO se pide si la persona pulsa «Usar mi
// ubicación»; nunca al abrir la página.

const TILES = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const ATTRIBUTION = '© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>';
const LEAFLET_LINK = '<a href="https://leafletjs.com" target="_blank" rel="noopener noreferrer">Leaflet</a>';

// Chile primero: el mapa abre en Santiago; «Ver todo Chile» encuadra el país entero (continente).
const CHILE_START = { center: [-33.4489, -70.6693], zoom: 11 };
const CHILE_BOUNDS = [[-56.0, -76.0], [-17.4, -66.4]];
const POINT_ZOOM = 16;

const MSG_HELP = 'Toca el mapa para marcar el punto; puedes arrastrar el marcador para afinarlo. Con el mouse, haz clic en el mapa para usar la rueda.';

let leafletPromise = null;
function loadLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  leafletPromise ??= new Promise((resolve, reject) => {
    const css = document.createElement('link');
    css.rel = 'stylesheet';
    css.href = '/vendor/leaflet/leaflet.css';
    const script = document.createElement('script');
    script.src = '/vendor/leaflet/leaflet.js';
    script.onload = () => resolve(window.L);
    script.onerror = () => {
      leafletPromise = null;
      reject(new Error('No se pudo cargar el mapa.'));
    };
    document.head.append(css, script);
  });
  return leafletPromise;
}

// «-33,45» o «-33.45» -> número; null si está vacío o fuera de rango.
function parsePoint(latText, lngText) {
  const clean = (s) => String(s ?? '').trim().replace(',', '.');
  if (!clean(latText) || !clean(lngText)) return null;
  const lat = Number(clean(latText));
  const lng = Number(clean(lngText));
  if (!Number.isFinite(lat) || Math.abs(lat) > 90 || !Number.isFinite(lng) || Math.abs(lng) > 180) return null;
  return [lat, lng];
}

let current = null; // { map } del mapa montado
let mountToken = 0;

export function unmountLocationMap() {
  mountToken += 1; // invalida un montaje que aún esté cargando Leaflet
  if (!current) return;
  current.map.remove();
  current = null;
}

// `host` es el contenedor (un <div class="field">) donde se dibuja; `latInput` y `lngInput`, los campos de texto.
export async function mountLocationMap(host, latInput, lngInput) {
  const token = ++mountToken;

  const label = document.createElement('span');
  label.className = 'field-label';
  label.id = 'mapa-etiqueta';
  label.textContent = 'Elige el punto en el mapa';

  const bar = document.createElement('div');
  bar.className = 'mapa-barra';
  const locateBtn = document.createElement('button');
  locateBtn.type = 'button';
  locateBtn.className = 'btn btn-small';
  locateBtn.textContent = 'Usar mi ubicación';
  const chileBtn = document.createElement('button');
  chileBtn.type = 'button';
  chileBtn.className = 'btn btn-small';
  chileBtn.textContent = 'Ver todo Chile';
  bar.append(locateBtn, chileBtn);

  const box = document.createElement('div');
  box.className = 'mapa-selector';
  box.setAttribute('role', 'application');
  box.setAttribute('aria-labelledby', label.id);

  const status = document.createElement('p');
  status.className = 'hint mapa-estado';
  status.setAttribute('role', 'status');
  status.textContent = 'Cargando el mapa…';

  host.append(label, bar, box, status);
  const say = (text) => { status.textContent = text; };

  let L;
  try {
    L = await loadLeaflet();
  } catch {
    if (token === mountToken) {
      say('No se pudo cargar el mapa. Escribe la latitud y la longitud a mano.');
      locateBtn.disabled = true;
      chileBtn.disabled = true;
    }
    return;
  }
  if (token !== mountToken) return; // el usuario ya cambió de pestaña

  L.Icon.Default.imagePath = '/vendor/leaflet/images/';
  const initial = parsePoint(latInput.value, lngInput.value);
  const map = L.map(box, { zoomControl: true, scrollWheelZoom: false, worldCopyJump: true });
  map.attributionControl.setPrefix(LEAFLET_LINK);
  let tileWarned = false;
  const tiles = L.tileLayer(TILES, { maxZoom: 19, attribution: ATTRIBUTION, referrerPolicy: 'origin' }).addTo(map);
  tiles.on('tileerror', () => {
    if (tileWarned) return;
    tileWarned = true;
    say('No se cargan las imágenes del mapa (¿sin internet?). Puedes escribir la latitud y la longitud.');
  });
  tiles.on('tileload', () => {
    if (!tileWarned) return;
    tileWarned = false;
    say(MSG_HELP);
  });

  // La rueda del mouse solo hace zoom cuando el mapa tiene el foco, para no atrapar el desplazamiento de la página.
  box.addEventListener('focusin', () => map.scrollWheelZoom.enable());
  box.addEventListener('focusout', () => map.scrollWheelZoom.disable());

  let marker = null;
  let syncing = false; // evita que escribir en los campos desde aquí vuelva a mover el marcador
  const writeInputs = (latlng) => {
    const p = latlng.wrap();
    syncing = true;
    latInput.value = p.lat.toFixed(6);
    lngInput.value = p.lng.toFixed(6);
    latInput.dispatchEvent(new Event('input', { bubbles: true }));
    lngInput.dispatchEvent(new Event('input', { bubbles: true }));
    syncing = false;
    say(`Punto elegido: ${latInput.value}, ${lngInput.value}`);
  };
  const putMarker = (latlng) => {
    if (marker) {
      marker.setLatLng(latlng);
      return;
    }
    marker = L.marker(latlng, { draggable: true, alt: 'Punto elegido' }).addTo(map);
    marker.on('dragend', () => writeInputs(marker.getLatLng()));
  };

  map.on('click', (event) => {
    putMarker(event.latlng);
    writeInputs(event.latlng);
  });

  // Si se escriben o borran las coordenadas a mano, el marcador las sigue.
  const followInputs = () => {
    if (syncing) return;
    const point = parsePoint(latInput.value, lngInput.value);
    if (!point) return;
    putMarker(point);
    if (!map.getBounds().contains(point)) map.setView(point, Math.max(map.getZoom(), 14));
  };
  latInput.addEventListener('input', followInputs);
  lngInput.addEventListener('input', followInputs);

  if (initial) {
    putMarker(initial);
    map.setView(initial, POINT_ZOOM);
  } else {
    map.setView(CHILE_START.center, CHILE_START.zoom);
  }

  chileBtn.addEventListener('click', () => map.fitBounds(CHILE_BOUNDS));

  const canLocate = 'geolocation' in navigator && window.isSecureContext;
  if (!canLocate) {
    locateBtn.disabled = true;
    locateBtn.title = 'El navegador solo comparte la ubicación en conexiones seguras (https).';
  }
  locateBtn.addEventListener('click', () => {
    locateBtn.disabled = true;
    say('Buscando tu ubicación… el navegador puede pedirte permiso.');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        locateBtn.disabled = false;
        map.setView([pos.coords.latitude, pos.coords.longitude], POINT_ZOOM);
        say('Mapa acercado a tu ubicación. Toca el punto exacto.');
      },
      (err) => {
        locateBtn.disabled = false;
        say(err.code === 1
          ? 'No diste permiso para usar tu ubicación. Elige el punto en el mapa.'
          : 'No se pudo obtener tu ubicación. Elige el punto en el mapa.');
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 },
    );
  });

  say(canLocate ? MSG_HELP : `${MSG_HELP} «Usar mi ubicación» solo funciona con https o en localhost.`);
  current = { map };
  // El contenedor ya estaba en la página, pero por si el tamaño cambió mientras cargaba Leaflet:
  requestAnimationFrame(() => map.invalidateSize());
}
