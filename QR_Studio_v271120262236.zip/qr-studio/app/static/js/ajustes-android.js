// Ajustes → App de Android: el administrador sube el .apk y el pie de todas las páginas lo ofrece para descargar.
// El servidor comprueba el rol en cada petición de /api/admin; si quien abre Ajustes no es administrador, la sección
// ni se muestra (la controla ajustes.js) y aquí no se hace nada más que leer el estado público.

const $ = (id) => document.getElementById(id);

function mensaje(id, text) {
  const box = $(id);
  box.textContent = text || '';
  box.hidden = !text;
}

let okTimer = 0;
function aviso(text) {
  mensaje('an-ok', text);
  clearTimeout(okTimer);
  if (text) okTimer = setTimeout(() => mensaje('an-ok', ''), 6000);
}

function tamano(bytes) {
  return bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function fecha(iso) {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toLocaleString('es', { dateStyle: 'medium', timeStyle: 'short' });
}

/** Pinta el estado y avisa al pie (version.js) para que el icono de descarga cambie sin recargar. */
function mostrar(info) {
  if (info.available) {
    const cuando = fecha(info.uploadedAt);
    $('an-estado').textContent = `${info.filename} · ${tamano(info.size)}${cuando ? ` · subido el ${cuando}` : ''}`;
  } else {
    $('an-estado').textContent = 'Todavía no hay ningún archivo: el pie no enseña el botón de Android.';
  }
  $('an-probar').hidden = !info.available;
  $('an-quitar').disabled = !info.available;
  document.dispatchEvent(new CustomEvent('qrandroid:cambio', { detail: info }));
}

/** Petición con respuesta JSON. `onProgreso(0..1)` solo en las subidas (fetch no informa del avance; XHR sí). */
function pedir(metodo, ruta, { cuerpo, onProgreso } = {}) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open(metodo, ruta);
    xhr.withCredentials = true;
    xhr.responseType = 'text';
    if (cuerpo) xhr.setRequestHeader('Content-Type', 'application/vnd.android.package-archive');
    if (onProgreso && xhr.upload) {
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) onProgreso(e.loaded / e.total);
      };
    }
    xhr.onerror = () => reject(new Error('No se pudo conectar con el servidor. Revisa la conexión.'));
    xhr.ontimeout = () => reject(new Error('La subida tardó demasiado. Inténtalo de nuevo.'));
    xhr.onload = () => {
      let data = null;
      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        /* respuesta sin JSON */
      }
      if (xhr.status >= 200 && xhr.status < 300) return resolve(data);
      if (xhr.status === 413 && typeof data?.detail !== 'string') {
        return reject(new Error('El archivo es demasiado grande para el servidor (o para el proxy que hay delante de él).'));
      }
      reject(new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.'));
    };
    xhr.send(cuerpo ?? null);
  });
}

$('an-file').addEventListener('change', async (event) => {
  const input = event.target;
  const file = input.files?.[0];
  mensaje('an-error', '');
  if (!file) return;
  if (!/\.apk$/i.test(file.name)) {
    mensaje('an-error', 'Elige un archivo con extensión .apk (un .aab no sirve: hace falta el .apk).');
    input.value = '';
    return;
  }
  input.disabled = true;
  $('an-quitar').disabled = true;
  try {
    const info = await pedir('PUT', `/api/admin/android?name=${encodeURIComponent(file.name)}`, {
      cuerpo: file,
      onProgreso: (p) => aviso(p < 1 ? `Subiendo… ${Math.round(p * 100)} %` : 'Procesando…'),
    });
    mostrar(info);
    aviso('Listo: el botón «Descargar para Android» ya sale en el pie de las páginas.');
  } catch (err) {
    aviso('');
    mensaje('an-error', err.message);
    $('an-quitar').disabled = $('an-probar').hidden; // vuelve a como estaba
  } finally {
    input.value = '';
    input.disabled = false;
  }
});

$('an-quitar').addEventListener('click', async () => {
  mensaje('an-error', '');
  if (!window.confirm('¿Quitar el archivo? El botón de Android dejará de salir en el pie de las páginas.')) return;
  try {
    mostrar(await pedir('DELETE', '/api/admin/android'));
    aviso('Se quitó el archivo.');
  } catch (err) {
    mensaje('an-error', err.message);
  }
});

// Arranque: el estado es público (el pie lo usa sin sesión), así que se lee siempre.
fetch('/api/auth/android', { cache: 'no-store', credentials: 'same-origin' })
  .then((res) => (res.ok ? res.json() : null))
  .then((info) => info && mostrar(info))
  .catch(() => {
    /* sin conexión: la sección queda con su texto inicial */
  });
