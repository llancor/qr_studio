// Páginas con QR: evento, empresa y carta. Requiere sesión (el servidor redirige al acceso si no la hay).
// Aquí se crean y editan las páginas, se suben sus archivos (logo, portada, PDF, hojas de la carta) y se
// descarga el QR. Todo texto que viene del usuario o del servidor se pone con textContent.

import { mountLocationMap, unmountLocationMap } from './mapa.js';

const $ = (id) => document.getElementById(id);
const enc = encodeURIComponent;

const TEMPLATE_LABEL = { evento: 'Evento', empresa: 'Empresa', carta: 'Carta' };
const THEMES = [
  ['azul', 'Azul'], ['verde', 'Verde'], ['rojo', 'Rojo'], ['naranja', 'Naranja'], ['morado', 'Morado'], ['negro', 'Negro'],
];
const BUTTON_TYPES = [
  ['link', 'Enlace web'], ['whatsapp', 'WhatsApp'], ['phone', 'Llamar'], ['email', 'Correo'], ['map', 'Mapa o dirección'], ['pdf', 'PDF o catálogo'],
];
const PLACEHOLDERS = {
  link: 'https://www.ejemplo.com',
  whatsapp: '+57 300 123 4567 (con código de país)',
  phone: '+57 601 234 5678',
  email: 'hola@ejemplo.com',
  map: 'Dirección, enlace de Google Maps o un punto del mapa',
};
const LIMITS = { buttons: 8, agenda: 30, sections: 20, items: 60, book: 80, image: 5 * 1024 * 1024, pdf: 20 * 1024 * 1024 };
const BOOK_WIDTH = 1100;

let features = null;
let items = [];
let quota = null;
let page = null; // página abierta en el editor (con content y assets)
let dirty = false;
let qrUrl = '';
let uid = 0;

// ---------- Utilidades ----------

async function api(path, { method = 'GET', json, body } = {}) {
  const res = await fetch(path, {
    method,
    headers: json ? { 'Content-Type': 'application/json' } : undefined,
    body: json ? JSON.stringify(json) : body,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* sin cuerpo JSON */
  }
  if (res.status === 401) {
    window.location.href = `/entrar/?next=${enc('/paginas/')}`;
    throw new Error('Inicia sesión para continuar.');
  }
  if (!res.ok) {
    const error = new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
    error.status = res.status;
    throw error;
  }
  return data;
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function button(label, onClick, className = 'btn btn-small') {
  const node = el('button', className, label);
  node.type = 'button';
  node.addEventListener('click', onClick);
  return node;
}

function linkButton(label, href) {
  const node = el('a', 'btn btn-small', label);
  node.href = href;
  node.target = '_blank';
  node.rel = 'noopener';
  return node;
}

// Botón que pide una segunda pulsación (3 segundos) antes de borrar.
function confirmButton(label, armedLabel, action) {
  const node = el('button', 'btn btn-small btn-danger', label);
  node.type = 'button';
  let timer = 0;
  node.addEventListener('click', () => {
    if (node.dataset.armed) {
      clearTimeout(timer);
      action();
      return;
    }
    node.dataset.armed = '1';
    node.textContent = armedLabel;
    timer = setTimeout(() => {
      delete node.dataset.armed;
      node.textContent = label;
    }, 3000);
  });
  return node;
}

function formatDate(iso) {
  if (!iso) return 'nunca';
  const date = new Date(iso);
  return Number.isNaN(date.getTime()) ? 'nunca' : date.toLocaleString('es', { dateStyle: 'medium', timeStyle: 'short' });
}

function formatBytes(bytes) {
  if (bytes < 1024 * 1024) return `${bytes > 0 ? Math.max(1, Math.round(bytes / 1024)) : 0} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function setStatus(message, isError = false) {
  const box = $('pg-status');
  box.textContent = message || '';
  box.hidden = !message;
  box.classList.toggle('is-error', isError);
  if (message && isError) box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

const base = () => features?.publicUrl || window.location.origin;
const publicUrl = (code) => `${base()}/p/${code}`;
const fileUrl = (token) => `/api/paginas/${page.id}/archivos/${token}`;
const markDirty = () => { dirty = true; };

async function copyText(text, okMessage) {
  try {
    await navigator.clipboard.writeText(text);
    setStatus(okMessage);
  } catch {
    window.prompt('Copia el enlace:', text);
  }
}

function saveBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    if (src.includes('pdf.min') && window.pdfjsLib) return resolve();
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = () => reject(new Error(`No se pudo cargar ${src}`));
    document.head.append(script);
  });
}

// ---------- Lista ----------

function stateOf(item) {
  if (!item.active) return 'Pausada';
  if (item.expired) return 'Caducada';
  return 'Activa';
}

// Etiqueta pequeña (plantilla, estado). `kind` solo cambia el color: «is-on», «is-off» o vacío.
function chip(text, kind = '') {
  return el('span', `pg-chip${kind ? ` ${kind}` : ''}`, text);
}

function renderList() {
  const list = $('pg-list');
  list.replaceChildren();
  if (!items.length) {
    list.append(el('p', 'pg-empty', 'Todavía no tienes páginas. Crea la primera con el formulario de arriba.'));
  }
  for (const item of items) {
    const live = item.active && !item.expired;
    const row = el('div', `bulk-folder dyn-row pg-item${live ? '' : ' is-paused'}`);
    const info = el('div', 'bulk-folder-info');
    const chips = el('div', 'pg-chips');
    chips.append(chip(TEMPLATE_LABEL[item.template] ?? item.template), chip(stateOf(item), live ? 'is-on' : 'is-off'));
    if (item.expiresAt) chips.append(chip(`Caduca el ${item.expiresAt}`));
    info.append(
      el('strong', 'pg-item-name', item.name),
      chips,
      el('span', 'dyn-target pg-link', publicUrl(item.code)),
      el('span', 'pg-meta', `${item.views} visitas · última: ${formatDate(item.lastViewAt)}`),
    );
    const actions = el('div', 'bulk-folder-actions');
    actions.append(
      button('Editar', () => openEditor(item.id)),
      linkButton('Ver', `/p/${item.code}`),
      button('Copiar enlace', () => copyText(publicUrl(item.code), 'Enlace copiado.')),
      confirmButton('Eliminar', 'Pulsa otra vez para eliminar', async () => {
        try {
          await api(`/api/paginas/${item.id}`, { method: 'DELETE' });
          setStatus('Página eliminada. El QR impreso dejará de funcionar.');
          await refreshList();
        } catch (err) {
          setStatus(err.message, true);
        }
      }),
    );
    row.append(info, actions);
    list.append(row);
  }
  if (quota) $('pg-quota').textContent = `Espacio de archivos: ${formatBytes(quota.used)} de ${formatBytes(quota.limit)}.`;
}

async function refreshList() {
  const data = await api('/api/paginas');
  items = data.items;
  quota = data.quota;
  renderList();
}

async function createPage(event) {
  event.preventDefault();
  setStatus('');
  const template = document.querySelector('input[name="pg-template"]:checked').value;
  $('pg-new-submit').disabled = true;
  try {
    const created = await api('/api/paginas', { method: 'POST', json: { template, name: $('pg-new-name').value } });
    $('pg-new-name').value = '';
    page = created;
    dirty = false;
    showEditor();
    setStatus('Página creada. Completa los datos y pulsa «Guardar cambios».');
  } catch (err) {
    setStatus(err.message, true);
  } finally {
    $('pg-new-submit').disabled = false;
  }
}

// ---------- Vistas ----------

function showList() {
  $('pg-edit-view').hidden = true;
  $('pg-list-view').hidden = false;
  page = null;
  dirty = false;
  refreshList().catch((err) => setStatus(err.message, true));
}

async function openEditor(id) {
  setStatus('');
  try {
    page = await api(`/api/paginas/${id}`);
    dirty = false;
    showEditor();
  } catch (err) {
    setStatus(err.message, true);
  }
}

function leaveEditor() {
  if (dirty && !window.confirm('Tienes cambios sin guardar. ¿Salir sin guardarlos?')) return;
  setStatus('');
  showList();
}

function showEditor() {
  $('pg-list-view').hidden = true;
  $('pg-edit-view').hidden = false;
  renderEditor();
  window.scrollTo({ top: 0 });
}

// ---------- Constructores de formulario ----------

function card(title, ...children) {
  const section = el('section', 'admin-card');
  section.append(el('h2', '', title), ...children);
  return section;
}

function field(labelText, control, hint) {
  const wrap = el('div', 'field');
  const id = `pg-f-${++uid}`;
  control.id = id;
  const label = el('label', '', labelText);
  label.htmlFor = id;
  wrap.append(label, control);
  if (hint) wrap.append(el('small', 'hint', hint));
  return wrap;
}

function textField(obj, key, label, { max, type = 'text', placeholder = '', hint, multiline = false, rows = 4 } = {}) {
  const input = multiline ? el('textarea') : el('input');
  if (multiline) input.rows = rows;
  else input.type = type;
  input.value = obj[key] ?? '';
  if (max) input.maxLength = max;
  if (placeholder) input.placeholder = placeholder;
  input.autocomplete = 'off';
  input.addEventListener('input', () => {
    obj[key] = input.value;
    markDirty();
  });
  return field(label, input, hint);
}

function checkField(obj, key, label, onChange) {
  const wrap = el('label', 'switch');
  const input = el('input');
  input.type = 'checkbox';
  input.checked = Boolean(obj[key]);
  input.addEventListener('change', () => {
    obj[key] = input.checked;
    markDirty();
    onChange?.();
  });
  wrap.append(input, el('span', '', label));
  return wrap;
}

function stripLocal(token) {
  const c = page.content;
  if (c.logo === token) c.logo = '';
  if (c.cover === token) c.cover = '';
  c.buttons = c.buttons.filter((b) => !(b.type === 'pdf' && b.value === token));
  if (c.carta) {
    c.carta.book = c.carta.book.filter((t) => t !== token);
    for (const section of c.carta.sections) for (const item of section.items) if (item.photo === token) item.photo = '';
  }
}

// ---------- Archivos ----------

async function uploadFile(file, name = file.name) {
  const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(name);
  const limit = isPdf ? LIMITS.pdf : LIMITS.image;
  if (file.size > limit) throw new Error(`«${name}» pesa ${formatBytes(file.size)}; el máximo es ${formatBytes(limit)}.`);
  const result = await api(`/api/paginas/${page.id}/archivos?name=${enc(name)}`, { method: 'POST', body: file });
  page.assets.push({ token: result.token, kind: result.kind, name: result.name, bytes: result.bytes });
  return result;
}

async function dropAsset(token) {
  try {
    await api(`/api/paginas/${page.id}/archivos/${token}`, { method: 'DELETE' });
  } catch {
    /* ya no existe: da igual */
  }
  page.assets = page.assets.filter((a) => a.token !== token);
}

/** Selector de una imagen (logo, portada, foto de un plato). */
function imageField(labelText, getToken, setToken, { hint, noThumb = false } = {}) {
  const wrap = el('div', 'field pg-image');
  wrap.append(el('span', 'field-label', labelText));
  const current = getToken();
  if (current && !noThumb) {
    const thumb = el('img', 'pg-thumb');
    thumb.src = fileUrl(current);
    thumb.alt = '';
    wrap.append(thumb);
  }
  const row = el('div', 'bulk-actions pg-row');
  const input = el('input');
  input.type = 'file';
  input.accept = 'image/png,image/jpeg,image/webp';
  input.setAttribute('aria-label', `${labelText}: elegir imagen`);
  input.addEventListener('change', async () => {
    const file = input.files?.[0];
    if (!file) return;
    try {
      setStatus('Subiendo imagen…');
      const result = await uploadFile(file);
      const old = getToken();
      setToken(result.token);
      if (old) await dropAsset(old);
      markDirty();
      setStatus('Imagen subida. Recuerda guardar los cambios.');
      renderEditor();
    } catch (err) {
      setStatus(err.message, true);
      input.value = '';
    }
  });
  row.append(input);
  if (current) {
    row.append(
      button('Quitar', async () => {
        const token = getToken();
        setToken('');
        await dropAsset(token);
        markDirty();
        renderEditor();
      }),
    );
  }
  wrap.append(row);
  if (hint) wrap.append(el('small', 'hint', hint));
  return wrap;
}

// ---------- Portada: tamaño, vista previa y recorte ----------

const COVER_W = 1600;
const COVER_H = 700;
const COVER_RATIO = COVER_W / COVER_H; // 16:7, la misma caja que usa la página pública
const COVER_FITS = [['cover', 'Llenar la portada y recortar (recomendado)'], ['contain', 'Mostrar la imagen completa, sin recortar']];
const COVER_POSITIONS = [['center', 'Centro'], ['top', 'Arriba'], ['bottom', 'Abajo'], ['left', 'Izquierda'], ['right', 'Derecha']];

/** Texto que explica cómo se verá una imagen de `w × h` px en la caja de la portada. */
function describeCover(w, h, fit) {
  const ratio = w / h;
  const visible = Math.round((Math.min(ratio, COVER_RATIO) / Math.max(ratio, COVER_RATIO)) * 100);
  const parts = [`Tu imagen mide ${w} × ${h} px.`];
  if (visible >= 97) parts.push('Encaja casi exacta en la portada.');
  else if (fit === 'cover') parts.push(`Se verá el ${visible}% de la imagen: se recorta ${ratio < COVER_RATIO ? 'arriba y abajo' : 'a los lados'}. Elige el enfoque para decidir qué parte se queda.`);
  else parts.push(`Se verá completa, con franjas de color ${ratio < COVER_RATIO ? 'a los lados' : 'arriba y abajo'}.`);
  if (w < 1000) parts.push('Es algo pequeña: en pantallas grandes puede verse borrosa.');
  return parts.join(' ');
}

function coverField(c) {
  c.coverFit = COVER_FITS.some(([v]) => v === c.coverFit) ? c.coverFit : 'cover';
  c.coverPos = COVER_POSITIONS.some(([v]) => v === c.coverPos) ? c.coverPos : 'center';

  const wrap = imageField('Imagen de portada', () => c.cover, (t) => { c.cover = t; }, { noThumb: true });
  wrap.classList.add('pg-cover');
  const frame = el('div', 'pg-cover-preview');
  const info = el('p', 'hint pg-cover-info');
  info.setAttribute('aria-live', 'polite');
  let size = null;

  const refresh = () => {
    frame.className = `pg-cover-preview fit-${c.coverFit} pos-${c.coverPos}`;
    info.textContent = !c.cover
      ? `Tamaño recomendado: ${COVER_W} × ${COVER_H} px (proporción 16:7, un banner ancho). Con otra proporción podrás elegir si se recorta o se muestra completa.`
      : size ? describeCover(size.w, size.h, c.coverFit) : '';
  };

  if (c.cover) {
    const img = el('img');
    img.alt = 'Vista previa de la portada';
    img.addEventListener('load', () => { size = { w: img.naturalWidth, h: img.naturalHeight }; refresh(); });
    img.src = fileUrl(c.cover);
    frame.append(img);
  } else {
    frame.append(el('span', 'pg-cover-empty', 'Sin portada'));
  }

  const fitSelect = el('select');
  for (const [value, name] of COVER_FITS) {
    const option = el('option', '', name);
    option.value = value;
    option.selected = c.coverFit === value;
    fitSelect.append(option);
  }
  const posSelect = el('select');
  for (const [value, name] of COVER_POSITIONS) {
    const option = el('option', '', name);
    option.value = value;
    option.selected = c.coverPos === value;
    posSelect.append(option);
  }
  const syncControls = () => { posSelect.disabled = c.coverFit === 'contain'; };
  fitSelect.addEventListener('change', () => { c.coverFit = fitSelect.value; syncControls(); refresh(); markDirty(); });
  posSelect.addEventListener('change', () => { c.coverPos = posSelect.value; refresh(); markDirty(); });
  syncControls();
  refresh();

  const controls = el('div', 'pg-cover-controls');
  controls.append(field('Ajuste de la imagen', fitSelect), field('Enfocar el recorte en', posSelect));
  wrap.children[0].after(frame, info); // justo debajo del título del campo
  wrap.append(controls);
  return wrap;
}

// ---------- Editor ----------

function renderEditor() {
  const scroll = window.scrollY;
  const root = $('pg-edit-view');
  closePickerMap(); // el mapa de un botón vive dentro del editor que se va a repintar
  root.replaceChildren();
  const c = page.content;

  const head = el('div', 'pg-head');
  const headTitle = el('h2', 'pg-head-title');
  headTitle.append(chip(TEMPLATE_LABEL[page.template]), el('span', 'pg-head-name', page.name));
  head.append(button('← Mis páginas', leaveEditor), headTitle, button('Guardar cambios', save, 'btn btn-primary'));
  root.append(head);

  root.append(qrCard());

  const basics = card('Datos de la página');
  const grid = el('div', 'fields');
  grid.append(
    textField(page, 'name', 'Nombre interno (solo lo ves tú)', { max: 80 }),
    textField(c, 'title', 'Título que verá el público', { max: 100 }),
    textField(c, 'subtitle', 'Subtítulo (opcional)', { max: 160 }),
    textField(c, 'description', 'Descripción', { max: 3000, multiline: true, rows: 5, hint: 'Deja una línea en blanco para separar párrafos.' }),
  );
  grid.append(themeField(c));
  const images = el('div', 'grid-2');
  images.append(
    imageField('Logo', () => c.logo, (t) => { c.logo = t; }, { hint: 'PNG, JPG o WebP, hasta 5 MB.' }),
    coverField(c),
  );
  basics.append(grid, images);
  root.append(basics);

  if (page.template === 'evento') root.append(eventCard(c.evento));
  if (page.template === 'empresa') root.append(companyCard(c.empresa));
  if (page.template === 'carta') root.append(menuCard(c.carta));
  root.append(buttonsCard(c));
  root.append(statsCard());

  const foot = el('div', 'bulk-actions');
  foot.append(button('Guardar cambios', save, 'btn btn-primary'), button('← Mis páginas', leaveEditor, 'btn btn-outline'));
  root.append(foot);
  window.scrollTo({ top: scroll });
}

function themeField(c) {
  const wrap = el('fieldset', 'pg-themes');
  wrap.append(el('legend', 'field-label', 'Color de la página'));
  for (const [value, name] of THEMES) {
    const label = el('label', 'pg-theme');
    const input = el('input');
    input.type = 'radio';
    input.name = 'pg-theme';
    input.value = value;
    input.checked = c.theme === value;
    input.addEventListener('change', () => {
      c.theme = value;
      markDirty();
    });
    label.append(input, el('span', `pg-swatch pg-sw-${value}`), el('span', '', name));
    wrap.append(label);
  }
  return wrap;
}

// ----- QR y estado -----

async function renderQr(img, data, type = 'png', size = 1024) {
  const qr = new window.QRCodeStyling({
    width: size,
    height: size,
    type: type === 'svg' ? 'svg' : 'canvas',
    data,
    margin: 12,
    qrOptions: { errorCorrectionLevel: 'M' },
    dotsOptions: { color: '#111111', type: 'square' },
    backgroundOptions: { color: '#ffffff' },
  });
  const blob = await qr.getRawData(type);
  if (img) {
    if (qrUrl) URL.revokeObjectURL(qrUrl);
    qrUrl = URL.createObjectURL(blob);
    img.src = qrUrl;
  }
  return blob;
}

function qrCard() {
  const url = publicUrl(page.code);
  const box = el('div', 'pg-qr');
  const img = el('img', 'pg-qr-img');
  img.alt = `Código QR de ${page.name}`;
  img.width = 220;
  img.height = 220;
  renderQr(img, url, 'png', 440).catch((err) => setStatus(`No se pudo generar el QR: ${err.message}`, true));

  const side = el('div', 'pg-qr-side');
  const link = el('input');
  link.type = 'text';
  link.readOnly = true;
  link.value = url;
  link.addEventListener('focus', () => link.select());
  const actions = el('div', 'bulk-actions pg-row');
  actions.append(
    button('Copiar enlace', () => copyText(url, 'Enlace copiado.')),
    button('Descargar QR (PNG)', async () => saveBlob(await renderQr(null, url, 'png', 1024), `qr-${page.code}.png`)),
    button('Descargar QR (SVG)', async () => saveBlob(await renderQr(null, url, 'svg', 1024), `qr-${page.code}.svg`)),
    linkButton('Vista previa', `/api/paginas/${page.id}/vista`),
    linkButton('Ver página pública', `/p/${page.code}`),
  );
  const state = el('div', 'fields pg-state');
  state.append(
    checkField(page, 'active', 'Página activa (si la pausas, quien escanee verá un aviso)'),
    textField(page, 'expiresAt', 'Caduca el (opcional)', { type: 'date', hint: 'Pasada esta fecha la página deja de mostrarse. Déjalo vacío para que no caduque.' }),
  );
  side.append(field('Enlace del QR', link), actions, state);
  if (['localhost', '127.0.0.1', '[::1]'].includes(new URL(url).hostname)) {
    side.append(
      el('p', 'hint warn', 'Este enlace usa «localhost», así que solo se abre en este equipo. Para que otras personas escaneen el QR, entra al sitio por su dirección pública o define APP_PUBLIC_URL en la configuración del servidor.'),
    );
  }
  box.append(img, side);
  return card('Tu QR y estado', box);
}

// ----- Evento -----

function eventCard(ev) {
  const wrap = card('Datos del evento');
  const allDay = { value: ev.start !== '' && !ev.start.includes('T') };
  const dates = el('div', 'grid-2');
  const draw = () => {
    dates.replaceChildren();
    const type = allDay.value ? 'date' : 'datetime-local';
    const convert = (v) => (allDay.value ? v.slice(0, 10) : v && !v.includes('T') ? `${v}T00:00` : v);
    ev.start = convert(ev.start);
    ev.end = convert(ev.end);
    dates.append(textField(ev, 'start', 'Empieza', { type }), textField(ev, 'end', 'Termina (opcional)', { type }));
  };
  draw();
  const fields = el('div', 'fields');
  fields.append(
    checkField(allDay, 'value', 'Evento de todo el día', draw),
    dates,
    textField(ev, 'place', 'Lugar', { max: 120, placeholder: 'Ej.: Salón Los Pinos' }),
    textField(ev, 'address', 'Dirección', { max: 200, hint: 'Con el lugar y la dirección se crea el botón «Cómo llegar».' }),
  );
  wrap.append(fields);

  wrap.append(el('h3', 'bulk-title', 'Agenda (opcional)'));
  const agenda = el('div', 'pg-rows');
  ev.agenda.forEach((entry, index) => {
    const row = el('div', 'pg-line');
    const cols = el('div', 'pg-line-fields');
    cols.append(
      textField(entry, 'time', 'Hora', { max: 20, placeholder: '19:00' }),
      textField(entry, 'title', 'Actividad', { max: 120 }),
      textField(entry, 'detail', 'Detalle (opcional)', { max: 300 }),
    );
    row.append(cols, button('Quitar', () => { ev.agenda.splice(index, 1); markDirty(); renderEditor(); }));
    agenda.append(row);
  });
  wrap.append(agenda);
  if (ev.agenda.length < LIMITS.agenda) {
    wrap.append(button('Agregar actividad', () => { ev.agenda.push({ time: '', title: '', detail: '' }); markDirty(); renderEditor(); }));
  }
  return wrap;
}

// ----- Empresa -----

function companyCard(co) {
  const fields = el('div', 'fields');
  const grid = el('div', 'grid-2');
  grid.append(
    textField(co, 'phone', 'Teléfono', { max: 30, type: 'tel' }),
    textField(co, 'email', 'Correo', { max: 120, type: 'email' }),
    textField(co, 'web', 'Sitio web', { max: 500, placeholder: 'www.miempresa.com' }),
    textField(co, 'address', 'Dirección', { max: 200 }),
  );
  fields.append(grid, textField(co, 'hours', 'Horarios', { max: 600, multiline: true, rows: 3, placeholder: 'Lunes a viernes: 8:00 a 17:00' }));
  return card('Datos de la empresa', fields, el('p', 'hint', 'Para redes sociales, catálogo o WhatsApp usa los «Botones» de abajo.'));
}

// ----- Carta -----

function canvasToBlob(canvas) {
  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      if (blob && blob.type === 'image/webp') resolve(blob);
      else canvas.toBlob(resolve, 'image/jpeg', 0.86);
    }, 'image/webp', 0.85);
  });
}

/** Sube una hoja dibujada en un canvas. Si es doble (más ancha que alta) y `split`, la parte en dos. */
async function uploadSheets(canvas, split, baseName) {
  const tokens = [];
  const wide = split && canvas.width > canvas.height * 1.15;
  const parts = wide ? 2 : 1;
  for (let part = 0; part < parts; part += 1) {
    let target = canvas;
    if (wide) {
      const half = Math.floor(canvas.width / 2);
      target = document.createElement('canvas');
      target.width = half;
      target.height = canvas.height;
      target.getContext('2d').drawImage(canvas, part * half, 0, half, canvas.height, 0, 0, half, canvas.height);
    }
    const blob = await canvasToBlob(target);
    const ext = blob.type === 'image/webp' ? 'webp' : 'jpg';
    const result = await uploadFile(blob, `${baseName}-${part + 1}.${ext}`);
    tokens.push(result.token);
    if (target !== canvas) target.width = 0;
  }
  return tokens;
}

async function importBook(files, split, progress) {
  const book = page.content.carta.book;
  const room = () => LIMITS.book - book.length;
  for (const file of files) {
    const stem = file.name.replace(/\.[^.]+$/, '') || 'hoja';
    if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
      progress(`Leyendo «${file.name}»…`);
      await loadScript('/vendor/pdf.min.js');
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdf.worker.min.js';
      const pdf = await window.pdfjsLib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false }).promise;
      for (let n = 1; n <= pdf.numPages; n += 1) {
        if (room() <= 0) throw new Error(`La carta admite hasta ${LIMITS.book} páginas.`);
        progress(`Convirtiendo la página ${n} de ${pdf.numPages} de «${file.name}»…`);
        const sheet = await pdf.getPage(n);
        const natural = sheet.getViewport({ scale: 1 });
        const wide = split && natural.width > natural.height * 1.15;
        const viewport = sheet.getViewport({ scale: (wide ? BOOK_WIDTH * 2 : BOOK_WIDTH) / natural.width });
        const canvas = document.createElement('canvas');
        canvas.width = Math.floor(viewport.width);
        canvas.height = Math.floor(viewport.height);
        const context = canvas.getContext('2d');
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        await sheet.render({ canvasContext: context, viewport }).promise;
        book.push(...(await uploadSheets(canvas, split, `${stem}-${n}`)));
        canvas.width = 0;
      }
    } else {
      if (room() <= 0) throw new Error(`La carta admite hasta ${LIMITS.book} páginas.`);
      progress(`Preparando «${file.name}»…`);
      const bitmap = await createImageBitmap(file).catch(() => {
        throw new Error(`«${file.name}» no es una imagen válida.`);
      });
      const scale = Math.min(1, (split && bitmap.width > bitmap.height * 1.15 ? BOOK_WIDTH * 2 : BOOK_WIDTH * 1.6) / bitmap.width);
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(bitmap.width * scale);
      canvas.height = Math.round(bitmap.height * scale);
      const context = canvas.getContext('2d');
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      bitmap.close?.();
      book.push(...(await uploadSheets(canvas, split, stem)));
      canvas.width = 0;
    }
  }
}

function bookEditor(carta) {
  const wrap = el('div', 'pg-book');
  wrap.append(el('h3', 'bulk-title', 'Carta en formato libro'));
  wrap.append(
    el('p', 'hint', 'Sube el PDF de tu carta (o fotos de sus hojas) y se verá como un libro que pasa las hojas. Cada hoja se convierte en tu navegador y se guarda como imagen, así abre rápido en el celular.'),
  );
  const split = { value: false };
  const picker = el('input');
  picker.type = 'file';
  picker.accept = 'application/pdf,image/png,image/jpeg,image/webp';
  picker.multiple = true;
  picker.setAttribute('aria-label', 'Elegir el PDF o las imágenes de la carta');
  const progress = el('p', 'hint', '');
  progress.setAttribute('role', 'status');
  const run = button('Convertir y subir', async () => {
    const files = [...(picker.files ?? [])];
    if (!files.length) {
      setStatus('Elige primero el PDF o las imágenes de la carta.', true);
      return;
    }
    run.disabled = true;
    picker.disabled = true;
    try {
      await importBook(files, split.value, (message) => { progress.textContent = message; });
      markDirty();
      renderEditor();
      setStatus('Hojas subidas. Revisa el orden y pulsa «Guardar cambios».');
    } catch (err) {
      console.error(err);
      markDirty();
      renderEditor(); // muestra las hojas que sí se subieron
      setStatus(err.message || 'No se pudo convertir el archivo.', true);
    }
  }, 'btn btn-small btn-primary');
  const tools = el('div', 'bulk-actions pg-row');
  tools.append(picker, run);
  wrap.append(tools, checkField(split, 'value', 'Mi PDF tiene dos páginas por hoja (formato horizontal): dividir cada hoja en dos'), progress);

  if (carta.book.length) {
    const grid = el('div', 'pg-book-grid');
    carta.book.forEach((token, index) => {
      const cell = el('figure', 'pg-sheet');
      const thumb = el('img');
      thumb.src = fileUrl(token);
      thumb.alt = `Hoja ${index + 1}`;
      thumb.loading = 'lazy';
      const sheetTools = el('div', 'pg-sheet-tools');
      const move = (delta) => {
        const target = index + delta;
        if (target < 0 || target >= carta.book.length) return;
        [carta.book[index], carta.book[target]] = [carta.book[target], carta.book[index]];
        markDirty();
        renderEditor();
      };
      const left = button('‹', () => move(-1));
      left.setAttribute('aria-label', `Mover la hoja ${index + 1} antes`);
      const right = button('›', () => move(1));
      right.setAttribute('aria-label', `Mover la hoja ${index + 1} después`);
      const remove = button('✕', async () => {
        stripLocal(token);
        await dropAsset(token);
        markDirty();
        renderEditor();
      });
      remove.setAttribute('aria-label', `Quitar la hoja ${index + 1}`);
      sheetTools.append(left, el('span', '', String(index + 1)), right, remove);
      cell.append(thumb, sheetTools);
      grid.append(cell);
    });
    wrap.append(grid);
  }
  return wrap;
}

function swap(list, a, b) {
  [list[a], list[b]] = [list[b], list[a]];
}

function menuEditor(carta) {
  const wrap = el('div', 'pg-menu');
  wrap.append(el('h3', 'bulk-title', 'Carta en lista (con precios)'));
  wrap.append(el('p', 'hint', 'Opcional. Si agregas libro y lista, quien escanea podrá elegir cómo verla. Marca un plato como agotado sin rehacer la carta.'));
  carta.sections.forEach((section, si) => {
    const box = el('div', 'pg-section');
    const head = el('div', 'pg-line-fields');
    head.append(textField(section, 'name', 'Categoría', { max: 60, placeholder: 'Ej.: Entradas' }));
    const headActions = el('div', 'bulk-actions pg-row');
    headActions.append(
      button('↑', () => { if (si > 0) { swap(carta.sections, si - 1, si); markDirty(); renderEditor(); } }),
      button('↓', () => { if (si < carta.sections.length - 1) { swap(carta.sections, si + 1, si); markDirty(); renderEditor(); } }),
      confirmButton('Quitar categoría', 'Pulsa otra vez', async () => {
        for (const item of section.items) if (item.photo) await dropAsset(item.photo);
        carta.sections.splice(si, 1);
        markDirty();
        renderEditor();
      }),
    );
    head.append(headActions);
    box.append(head);

    section.items.forEach((item, ii) => {
      const line = el('div', 'pg-dish');
      const fields = el('div', 'pg-line-fields');
      fields.append(
        textField(item, 'name', 'Plato', { max: 80 }),
        textField(item, 'price', 'Precio', { max: 12, placeholder: '25.000' }),
        textField(item, 'desc', 'Descripción (opcional)', { max: 220 }),
      );
      const extra = el('div', 'bulk-actions pg-row');
      extra.append(
        checkField(item, 'available', 'Disponible'),
        button('Quitar plato', async () => {
          if (item.photo) await dropAsset(item.photo);
          section.items.splice(ii, 1);
          markDirty();
          renderEditor();
        }),
      );
      line.append(fields, imageField('Foto (opcional)', () => item.photo, (t) => { item.photo = t; }), extra);
      box.append(line);
    });
    if (section.items.length < LIMITS.items) {
      box.append(button('Agregar plato', () => { section.items.push({ name: '', desc: '', price: '', available: true, photo: '' }); markDirty(); renderEditor(); }));
    }
    wrap.append(box);
  });
  if (carta.sections.length < LIMITS.sections) {
    wrap.append(button('Agregar categoría', () => { carta.sections.push({ name: '', items: [] }); markDirty(); renderEditor(); }, 'btn btn-small btn-primary'));
  }
  return wrap;
}

function menuCard(carta) {
  const top = el('div', 'grid-2');
  top.append(
    textField(carta, 'currency', 'Símbolo de moneda', { max: 4, placeholder: '$' }),
    textField(carta, 'notes', 'Notas al pie (alérgenos, propina…)', { max: 600, multiline: true, rows: 2 }),
  );
  return card('Carta', top, bookEditor(carta), menuEditor(carta));
}

// ----- Botones -----

// Elegir el punto de un botón «Mapa» tocando el mapa: el mismo selector (js/mapa.js) que usa el QR «Ubicación».
// El botón guarda «lat,lng» y la página pública abre Google Maps en ese punto. Solo hay un mapa abierto a la vez.
let closeActivePicker = null;

function closePickerMap() {
  closeActivePicker?.();
  closeActivePicker = null;
  unmountLocationMap();
}

function mapPicker(btn, valueInput) {
  const wrap = el('div', 'pg-map');
  const toggle = button('Elegir en el mapa', () => (host.isConnected ? close() : open()));
  wrap.append(toggle);
  const host = el('div', 'pg-map-host');

  function close() {
    unmountLocationMap();
    host.replaceChildren();
    host.remove();
    toggle.textContent = 'Elegir en el mapa';
    if (closeActivePicker === close) closeActivePicker = null;
  }

  async function open() {
    closePickerMap(); // cierra el mapa de otro botón, si lo hay
    closeActivePicker = close;
    toggle.textContent = 'Ocultar el mapa';

    const lat = el('input');
    const lng = el('input');
    for (const input of [lat, lng]) {
      input.type = 'text';
      input.inputMode = 'decimal';
      input.autocomplete = 'off';
    }
    lat.placeholder = 'Ej.: -33.4489';
    lng.placeholder = 'Ej.: -70.6693';
    const saved = /^\s*(-?\d{1,3}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$/.exec(btn.value ?? '');
    if (saved) [, lat.value, lng.value] = saved;

    // El mapa escribe en estos dos campos (y se mueve si se escriben a mano); aquí el par pasa a ser el valor del botón.
    const follow = () => {
      const a = Number(lat.value.trim().replace(',', '.'));
      const b = Number(lng.value.trim().replace(',', '.'));
      if (!lat.value.trim() || !lng.value.trim() || !Number.isFinite(a) || !Number.isFinite(b)) return;
      if (Math.abs(a) > 90 || Math.abs(b) > 180) return;
      btn.value = `${a},${b}`;
      valueInput.value = btn.value;
      markDirty();
    };
    lat.addEventListener('input', follow);
    lng.addEventListener('input', follow);

    const mapHost = el('div', 'field');
    const coords = el('div', 'pg-line-fields');
    coords.append(field('Latitud', lat), field('Longitud', lng));
    host.replaceChildren(mapHost, coords);
    wrap.append(host);
    await mountLocationMap(mapHost, lat, lng);
  }

  return wrap;
}

function buttonsCard(c) {
  const wrap = card('Botones');
  wrap.append(el('p', 'hint', 'Aparecen arriba de la página: enlaces, WhatsApp, llamadas, mapa o un PDF (flyer, catálogo, programa) que se abre en un visor.'));
  const rows = el('div', 'pg-rows');
  c.buttons.forEach((btn, index) => {
    const row = el('div', 'pg-line');
    const cols = el('div', 'pg-line-fields');
    let valueInput = null; // el campo de texto del botón (lo necesita el mapa de «Mapa o dirección»)

    const type = el('select');
    for (const [value, name] of BUTTON_TYPES) {
      const option = el('option', '', name);
      option.value = value;
      option.selected = btn.type === value;
      type.append(option);
    }
    type.addEventListener('change', async () => {
      if (btn.type === 'pdf' && btn.value) await dropAsset(btn.value);
      btn.type = type.value;
      btn.value = '';
      markDirty();
      renderEditor();
    });
    cols.append(field('Tipo', type), textField(btn, 'label', 'Texto del botón', { max: 40, placeholder: 'Ej.: Reservar' }));

    if (btn.type === 'pdf') {
      const slot = el('div', 'field');
      slot.append(el('span', 'field-label', 'Archivo PDF'));
      const asset = page.assets.find((a) => a.token === btn.value);
      if (asset) slot.append(el('span', 'hint', `${asset.name} · ${formatBytes(asset.bytes)}`));
      const input = el('input');
      input.type = 'file';
      input.accept = 'application/pdf';
      input.setAttribute('aria-label', 'Elegir PDF');
      input.addEventListener('change', async () => {
        const file = input.files?.[0];
        if (!file) return;
        try {
          setStatus('Subiendo PDF…');
          const result = await uploadFile(file);
          const old = btn.value;
          btn.value = result.token;
          if (old) await dropAsset(old);
          if (!btn.label) btn.label = 'Ver PDF';
          markDirty();
          renderEditor();
          setStatus('PDF subido. Recuerda guardar los cambios.');
        } catch (err) {
          setStatus(err.message, true);
          input.value = '';
        }
      });
      slot.append(input);
      cols.append(slot);
    } else {
      const valueField = textField(btn, 'value', 'Dirección o dato', { max: 500, placeholder: PLACEHOLDERS[btn.type] });
      cols.append(valueField);
      valueInput = valueField.querySelector('input');
    }
    row.append(
      cols,
      button('Quitar', async () => {
        if (btn.type === 'pdf' && btn.value) await dropAsset(btn.value);
        c.buttons.splice(index, 1);
        markDirty();
        renderEditor();
      }),
    );
    if (btn.type === 'map' && valueInput) row.append(mapPicker(btn, valueInput));
    rows.append(row);
  });
  wrap.append(rows);
  if (c.buttons.length < LIMITS.buttons) {
    wrap.append(button('Agregar botón', () => { c.buttons.push({ type: 'link', label: '', value: '' }); markDirty(); renderEditor(); }));
  }
  return wrap;
}

// ----- Estadísticas -----

function statsCard() {
  const box = el('div', 'dyn-stats');
  const show = button('Ver estadísticas', async () => {
    try {
      const data = await api(`/api/paginas/${page.id}/stats`);
      box.replaceChildren();
      const max = Math.max(1, ...data.days.map((d) => d.count));
      box.append(el('p', 'hint', `Total: ${data.total} visitas · última: ${formatDate(data.lastViewAt)}. Últimos 30 días:`));
      const bars = el('div', 'dyn-bars');
      for (const day of data.days) {
        const bar = el('div', 'dyn-bar');
        bar.style.height = `${Math.max(day.count ? 8 : 2, Math.round((day.count / max) * 56))}px`;
        bar.title = `${day.day}: ${day.count}`;
        bars.append(bar);
      }
      box.append(bars);
      if (data.clicks.length) {
        box.append(el('h3', 'bulk-title', 'Clics por botón'));
        const list = el('ul', 'pg-clicks');
        for (const clicked of data.clicks) list.append(el('li', '', `${clicked.label}: ${clicked.count}`));
        box.append(list);
      } else {
        box.append(el('p', 'hint', 'Todavía nadie ha tocado un botón.'));
      }
    } catch (err) {
      setStatus(err.message, true);
    }
  });
  return card('Estadísticas', show, box);
}

// ----- Guardar -----

async function save() {
  setStatus('');
  try {
    const saved = await api(`/api/paginas/${page.id}`, {
      method: 'PUT',
      json: { name: page.name, content: page.content, active: page.active, expiresAt: page.expiresAt || '' },
    });
    page = saved;
    dirty = false;
    renderEditor();
    setStatus('Cambios guardados. El mismo QR ya muestra la versión nueva.');
  } catch (err) {
    setStatus(err.message, true);
  }
}

// ---------- Arranque ----------

window.addEventListener('beforeunload', (event) => {
  if (!dirty) return;
  event.preventDefault();
  event.returnValue = '';
});

$('year').textContent = new Date().getFullYear();
$('pg-create').addEventListener('submit', createPage);

(async () => {
  try {
    features = await api('/api/features');
    if (!features.pages) {
      $('pg-denied').hidden = false;
      return;
    }
    $('pg-root').hidden = false;
    await refreshList();
  } catch (err) {
    setStatus(err.message, true);
  }
})();
