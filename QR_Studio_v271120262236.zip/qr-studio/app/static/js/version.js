// Pie de página (todas las páginas): la versión del software («Versión v191120261705», igual que el nombre del .zip),
// el botón «Actualizar página», el botón «Instalar como app» (cuando el navegador lo permite) y, si el administrador
// subió el .apk, el icono de Android para descargarlo. Falla en silencio: lo que no se pueda leer, no se enseña.

/** Vacía lo que el navegador guardó de este sitio, vuelve a bajar la página con sus archivos y la recarga.
 *  No toca la sesión ni las preferencias (localStorage): solo archivos en caché. */
async function actualizarPagina(boton) {
  const texto = boton.textContent;
  boton.disabled = true;
  boton.textContent = "Actualizando…";
  try {
    // 1) Caché de archivos del navegador (Cache Storage) y service workers, si algo los hubiera dejado.
    if ("caches" in window) {
      for (const nombre of await caches.keys()) await caches.delete(nombre);
    }
    if (navigator.serviceWorker?.getRegistrations) {
      for (const registro of await navigator.serviceWorker.getRegistrations()) await registro.unregister();
    }
    // 2) La página y todo lo que cargó (hojas de estilo, scripts y módulos importados) se piden otra vez sin caché;
    //    eso reemplaza la copia guardada. La API nunca se guarda en caché, así que no hace falta pedirla.
    const urls = new Set([window.location.href]);
    for (const recurso of performance.getEntriesByType("resource")) {
      const url = new URL(recurso.name, window.location.href);
      if (url.origin === window.location.origin && /\.(js|css|html|svg)$/.test(url.pathname)) urls.add(url.href);
    }
    await Promise.all([...urls].map((url) => fetch(url, { cache: "reload", credentials: "same-origin" }).catch(() => null)));
  } catch {
    /* si algo falla, igual se recarga */
  }
  // 3) Recarga. Con los archivos ya renovados, lo que se ve es lo último que hay en el servidor.
  window.location.reload();
  // Por si el navegador demora o cancela la recarga, el botón no queda trabado.
  setTimeout(() => {
    boton.disabled = false;
    boton.textContent = texto;
  }, 4000);
}

/** El dibujo de la cabeza de Android (formas simples; los ojos son huecos y toman el color del fondo). */
function iconoAndroid() {
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("width", "18");
  svg.setAttribute("height", "18");
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("focusable", "false");
  const cabeza = document.createElementNS(ns, "path");
  cabeza.setAttribute("fill", "currentColor");
  cabeza.setAttribute("fill-rule", "evenodd");
  cabeza.setAttribute("d", "M3 18a9 9 0 0 1 18 0z M8 14.2a1.1 1.1 0 1 0 2.2 0a1.1 1.1 0 1 0-2.2 0z M13.8 14.2a1.1 1.1 0 1 0 2.2 0a1.1 1.1 0 1 0-2.2 0z");
  const antenas = document.createElementNS(ns, "path");
  antenas.setAttribute("fill", "none");
  antenas.setAttribute("stroke", "currentColor");
  antenas.setAttribute("stroke-width", "1.6");
  antenas.setAttribute("stroke-linecap", "round");
  antenas.setAttribute("d", "M6.8 5.6 8.6 8.4 M17.2 5.6 15.4 8.4");
  svg.append(cabeza, antenas);
  return svg;
}

function tamano(bytes) {
  return bytes >= 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

/** Enseña (o quita) el icono «Descargar para Android» según lo que diga el servidor: `info` es /api/auth/android. */
function pintarAndroid(container, info) {
  let fila = container.querySelector(".site-android");
  if (!info?.available) {
    fila?.remove();
    return;
  }
  if (!fila) {
    fila = document.createElement("p");
    fila.className = "site-android";
    const enlace = document.createElement("a");
    enlace.className = "btn-android";
    enlace.href = "/api/auth/android/download";
    enlace.setAttribute("download", "");
    enlace.append(iconoAndroid(), document.createTextNode("Descargar para Android"));
    fila.append(enlace);
    const legal = container.querySelector(".footer-legal");
    if (legal) legal.after(fila);
    else container.append(fila);
  }
  fila.querySelector("a").title = `${info.filename} · ${tamano(info.size)}`;
}

async function leerAndroid(container) {
  try {
    const response = await fetch("/api/auth/android", { cache: "no-store" });
    if (response.ok) pintarAndroid(container, await response.json());
  } catch {
    /* sin icono de Android */
  }
}

(async () => {
  const container = document.querySelector(".site-footer .container");
  if (!container) return;

  // Botones: «Instalar como app» (solo si el navegador lo ofrece) y «Actualizar página».
  const fila = document.createElement("p");
  fila.className = "site-actualizar";
  const boton = document.createElement("button");
  boton.type = "button";
  boton.className = "btn-refrescar";
  boton.textContent = "Actualizar página";
  boton.title = "Borra la copia guardada por el navegador y vuelve a cargar la página con lo último del servidor";
  boton.addEventListener("click", () => actualizarPagina(boton));
  fila.append(boton);
  container.append(fila);

  // Instalar el sitio como app (Chrome en Android o en el ordenador, con HTTPS o localhost). Si el navegador no lo
  // ofrece, no se enseña nada: en el teléfono queda el menú ⋮ → «Agregar a la pantalla de inicio».
  let oferta = null;
  const yaInstalada = window.matchMedia?.("(display-mode: standalone)").matches || window.navigator.standalone === true;
  if (!yaInstalada) {
    window.addEventListener("beforeinstallprompt", (event) => {
      event.preventDefault(); // se guarda la oferta y se usa cuando la persona pulsa el botón
      oferta = event;
      if (fila.querySelector(".btn-instalar")) return;
      const instalar = document.createElement("button");
      instalar.type = "button";
      instalar.className = "btn-refrescar btn-instalar";
      instalar.textContent = "Instalar como app";
      instalar.title = "Agrega este sitio a la pantalla de inicio, con su icono, para abrirlo como una aplicación";
      instalar.addEventListener("click", async () => {
        if (!oferta) return;
        const actual = oferta;
        oferta = null; // la oferta solo se puede usar una vez
        try {
          await actual.prompt();
          await actual.userChoice;
        } catch {
          /* la persona cerró el diálogo */
        }
        instalar.remove();
      });
      fila.prepend(instalar);
    });
    window.addEventListener("appinstalled", () => fila.querySelector(".btn-instalar")?.remove());
  }

  // Ajustes avisa cuando el administrador sube o quita el .apk, para que el icono cambie sin recargar.
  document.addEventListener("qrandroid:cambio", (event) => pintarAndroid(container, event.detail));
  leerAndroid(container);

  try {
    const response = await fetch("/healthz", { cache: "no-store" });
    if (!response.ok) return;
    const { version } = await response.json();
    if (!version) return;
    const line = document.createElement("p");
    line.className = "site-version";
    line.textContent = `Versión ${version}`;
    fila.before(line); // la versión queda arriba de los botones
  } catch {
    /* sin versión visible */
  }
})();
