"""App de Android: el administrador sube el .apk (Ajustes → App Android) y cualquiera lo descarga desde el pie de la página.

El .apk no lo genera este programa: se hace aparte (por ejemplo con PWABuilder o Bubblewrap) y aquí solo se sube y se
ofrece para descargar. Es PÚBLICO a propósito: quien instala la app todavía no tiene sesión. El archivo vive en disco,
junto a la base de datos (en Docker, dentro del volumen de datos); su nombre y la fecha de subida, en app_settings.
"""

from __future__ import annotations

import io
import os
import re
import sqlite3
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from .prefs import PrefsError

MAX_BYTES = 100 * 1024 * 1024  # 100 MB: un .apk de una app web envuelta pesa unos pocos MB
DEFAULT_FILENAME = "app.apk"
_NAME_KEY = "android_filename"
_AT_KEY = "android_uploaded_at"
_UNSAFE = re.compile(r"[^A-Za-z0-9._ -]")


def file_path(root: Path) -> Path:
    """Dónde queda el archivo. `root` es la carpeta de datos (la de la base de datos)."""
    return root / "android" / "app.apk"


def _get(conn: sqlite3.Connection, key: str) -> str:
    row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
    return "" if row is None else row["value"]


def _set(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def clean_filename(raw: object) -> str:
    """Nombre con el que se ofrece la descarga: solo letras, números y . _ - (sin rutas) y siempre termina en .apk."""
    name = raw if isinstance(raw, str) else ""
    name = name.replace("\\", "/").rsplit("/", 1)[-1]
    name = _UNSAFE.sub("_", name).strip(" .")[:80]
    if name.lower().endswith(".apk"):
        name = name[:-4].strip(" .")
    return f"{name}.apk" if name else DEFAULT_FILENAME


def check_apk(data: bytes) -> None:
    """Un .apk es un .zip con AndroidManifest.xml en la raíz. (Un .aab no se puede instalar: lleva el manifiesto en base/.)"""
    if data[:2] != b"PK":
        raise PrefsError(422, "Ese archivo no es un .apk de Android.")
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as apk:
            names = set(apk.namelist())
    except zipfile.BadZipFile:
        raise PrefsError(422, "Ese archivo no es un .apk de Android (el .zip está dañado).") from None
    if "AndroidManifest.xml" not in names:
        raise PrefsError(
            422, "Ese archivo no parece un .apk instalable (falta AndroidManifest.xml). Un .aab no sirve: hace falta el .apk."
        )


def info(conn: sqlite3.Connection, root: Path) -> dict:
    """{available, filename, size, uploadedAt}: lo que se ve en Ajustes y lo que decide si el pie enseña el icono."""
    path = file_path(root)
    if not path.is_file():
        return {"available": False, "filename": "", "size": 0, "uploadedAt": ""}
    return {
        "available": True,
        "filename": _get(conn, _NAME_KEY) or DEFAULT_FILENAME,
        "size": path.stat().st_size,
        "uploadedAt": _get(conn, _AT_KEY),
    }


def save(conn: sqlite3.Connection, root: Path, data: bytes, filename: object) -> dict:
    check_apk(data)
    path = file_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)  # reemplazo atómico: nadie descarga un archivo a medias
    _set(conn, _NAME_KEY, clean_filename(filename))
    _set(conn, _AT_KEY, datetime.now(timezone.utc).isoformat(timespec="seconds"))
    return info(conn, root)


def delete(conn: sqlite3.Connection, root: Path) -> dict:
    file_path(root).unlink(missing_ok=True)
    _set(conn, _NAME_KEY, "")
    _set(conn, _AT_KEY, "")
    return info(conn, root)
