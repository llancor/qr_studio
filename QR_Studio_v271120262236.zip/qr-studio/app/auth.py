"""Contraseñas (scrypt de la librería estándar), sesiones y límite de intentos."""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import sqlite3
import threading
import time
from collections import deque
from datetime import datetime, timedelta, timezone

_SCRYPT_N = 2**14
_SCRYPT_R = 8
_SCRYPT_P = 1


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P
    )
    return f"scrypt${_SCRYPT_N}${_SCRYPT_R}${_SCRYPT_P}${_b64(salt)}${_b64(digest)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt_b64, digest_b64 = stored.split("$")
        if scheme != "scrypt":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.scrypt(
            password.encode("utf-8"), salt=salt, n=int(n), r=int(r), p=int(p)
        )
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(actual, expected)


def is_valid_hash(stored: object) -> bool:
    """¿Tiene el formato de hash_password() y parámetros razonables? Sirve para aceptar hashes de una migración
    sin que un archivo ajeno pueda traer parámetros que agoten la memoria al iniciar sesión."""
    if not isinstance(stored, str) or len(stored) > 300:
        return False
    try:
        scheme, n, r, p, salt_b64, digest_b64 = stored.split("$")
        n, r, p = int(n), int(r), int(p)
        salt = base64.b64decode(salt_b64, validate=True)
        digest = base64.b64decode(digest_b64, validate=True)
    except (ValueError, TypeError):  # binascii.Error es un ValueError
        return False
    return (
        scheme == "scrypt"
        and n & (n - 1) == 0
        and 4096 <= n <= 32768
        and 1 <= r <= 8
        and 1 <= p <= 2
        and 8 <= len(salt) <= 64
        and 16 <= len(digest) <= 128
    )


# Hash falso para igualar el tiempo de respuesta cuando el correo no existe.
DUMMY_HASH = hash_password(secrets.token_urlsafe(16))


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_session(conn: sqlite3.Connection, user_id: int, days: int) -> str:
    """Crea una sesión y devuelve el token en claro (solo se guarda su hash)."""
    token = secrets.token_urlsafe(32)
    now = _now()
    conn.execute("DELETE FROM sessions WHERE expires_at < ?", (now.isoformat(),))
    conn.execute(
        "INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
        (
            _token_hash(token),
            user_id,
            now.isoformat(),
            (now + timedelta(days=days)).isoformat(),
        ),
    )
    return token


def get_user_by_token(conn: sqlite3.Connection, token: str | None) -> sqlite3.Row | None:
    if not token:
        return None
    # Una cuenta desactivada pierde el acceso al instante, aunque su sesión no haya caducado.
    return conn.execute(
        """
        SELECT u.id, u.email, u.name, u.role
        FROM sessions s JOIN users u ON u.id = s.user_id
        WHERE s.token_hash = ? AND s.expires_at > ? AND u.active = 1
        """,
        (_token_hash(token), _now().isoformat()),
    ).fetchone()


def delete_session(conn: sqlite3.Connection, token: str | None) -> None:
    if token:
        conn.execute("DELETE FROM sessions WHERE token_hash = ?", (_token_hash(token),))


def delete_sessions_of(conn: sqlite3.Connection, user_id: int, keep_token: str | None = None) -> None:
    """Cierra todas las sesiones de un usuario (menos, si se indica, la que se está usando)."""
    if keep_token:
        conn.execute(
            "DELETE FROM sessions WHERE user_id = ? AND token_hash != ?", (user_id, _token_hash(keep_token))
        )
    else:
        conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))


def create_reset_token(conn: sqlite3.Connection, user_id: int, minutes: int) -> str:
    """Enlace para recuperar la contraseña: devuelve el token en claro (solo se guarda su hash).

    Un usuario tiene como mucho un enlace vigente: pedir otro anula el anterior."""
    token = secrets.token_urlsafe(32)
    now = _now()
    conn.execute("DELETE FROM password_resets WHERE expires_at < ? OR user_id = ?", (now.isoformat(), user_id))
    conn.execute(
        "INSERT INTO password_resets (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
        (_token_hash(token), user_id, now.isoformat(), (now + timedelta(minutes=minutes)).isoformat()),
    )
    return token


def consume_reset_token(conn: sqlite3.Connection, token: str) -> int | None:
    """Devuelve el usuario de un enlace vigente y lo gasta (sirve una sola vez). None si no vale."""
    if not token or len(token) > 200:
        return None
    digest = _token_hash(token)
    row = conn.execute(
        "SELECT r.user_id FROM password_resets r JOIN users u ON u.id = r.user_id "
        "WHERE r.token_hash = ? AND r.expires_at > ? AND u.active = 1",
        (digest, _now().isoformat()),
    ).fetchone()
    if row is None:
        return None
    conn.execute("DELETE FROM password_resets WHERE user_id = ?", (row["user_id"],))
    return int(row["user_id"])


class LoginLimiter:
    """Limita intentos fallidos por clave (IP + correo) en una ventana de tiempo."""

    def __init__(self, max_attempts: int, window_seconds: int) -> None:
        self.max_attempts = max_attempts
        self.window = window_seconds
        self._failures: dict[str, deque[float]] = {}
        self._lock = threading.Lock()

    def _prune(self, key: str, now: float) -> deque[float] | None:
        """Quita los fallos ya vencidos de una clave; si no queda ninguno, olvida la clave (None)."""
        bucket = self._failures.get(key)
        if bucket is None:
            return None
        while bucket and now - bucket[0] > self.window:
            bucket.popleft()
        if not bucket:
            del self._failures[key]
            return None
        return bucket

    def blocked(self, key: str) -> bool:
        # Solo mirar no guarda nada: así quien prueba miles de correos inventados no llena la memoria.
        with self._lock:
            bucket = self._prune(key, time.monotonic())
            return bucket is not None and len(bucket) >= self.max_attempts

    def record_failure(self, key: str) -> None:
        with self._lock:
            now = time.monotonic()
            if len(self._failures) > 5000:  # barrido: se descartan las claves cuyos fallos ya vencieron
                for stale in list(self._failures):
                    self._prune(stale, now)
            bucket = self._prune(key, now)
            if bucket is None:
                bucket = self._failures[key] = deque()
            bucket.append(now)

    def reset(self, key: str) -> None:
        with self._lock:
            self._failures.pop(key, None)
