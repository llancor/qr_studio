"""Cifrado en reposo de las credenciales que el sitio guarda en la base de datos.

Las contraseñas de las cuentas y los tokens de sesión o de recuperación NO se cifran: se guardan como hash y no hay
forma de recuperarlos. Aquí van las que el servidor necesita volver a leer en claro para usarlas con otro servicio
(hoy, la contraseña del servidor SMTP; mañana, cualquier clave de API). Para que alguien que se lleve solo la base
de datos (o un respaldo) no las vea, se guardan cifradas con AES-256-GCM:

    enc1:<base64url( nonce de 12 bytes + texto cifrado + etiqueta )>

La clave NO vive en la base de datos. Se busca, en este orden:

1. La variable de entorno APP_SECRET_KEY (al menos 32 caracteres; se usa su SHA-256). La clave queda fuera de la
   carpeta de datos. Ojo: si la pones en el .env del instalador de Debian, sus respaldos copian ese .env.
2. El archivo ``qr_studio.key`` junto a la base de datos (32 bytes aleatorios en base64). Se crea solo la primera vez,
   con permisos 0600 donde el sistema los respeta. No va a GitHub ni en los paquetes (.gitignore y el empaquetador
   lo excluyen) y los respaldos del instalador de Debian no lo copian (solo copian app.db, qr/ y el .env).

Cada valor se cifra con el nombre del ajuste como dato asociado (AAD): copiar el valor cifrado de un ajuste a otro
no sirve, no se descifra. Si falta la clave, está dañada o el valor fue alterado, se lee como «sin valor» (y se avisa
en el registro) en vez de romper el sitio: el administrador solo tiene que volver a escribir esa credencial.

Para guardar una credencial nueva (p. ej. la clave de una API) basta con añadir su nombre en SECRET_SETTINGS y leerla
y escribirla con get_setting() y set_setting(). Los valores guardados en claro por una versión anterior se cifran solos
al arrancar (migrate()).
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import logging
import os
import secrets
import sqlite3
import threading
import time
from pathlib import Path

log = logging.getLogger("qr_studio.secretos")

PREFIX = "enc1:"
KEY_FILE = "qr_studio.key"
ENV_KEY = "APP_SECRET_KEY"
MIN_ENV_KEY = 32

# Ajustes de app_settings que guardan una credencial: siempre cifrados. Añade aquí cualquier clave nueva.
SECRET_SETTINGS = frozenset({"smtp_password"})

_lock = threading.Lock()
_keys: dict[str, bytes] = {}
_MEMORY_KEY = secrets.token_bytes(32)  # solo para bases en memoria (pruebas): no sobrevive al proceso


class SecretError(RuntimeError):
    """No se pudo obtener la clave de cifrado (variable demasiado corta o archivo de clave dañado)."""


def _aesgcm(key: bytes):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        raise SecretError(
            "Falta la librería «cryptography» en el servidor (pip install -r requirements.txt) y reiniciar."
        ) from None
    return AESGCM(key)


# ----- La clave -----------------------------------------------------------------------------------------

def _db_file(conn: sqlite3.Connection) -> Path | None:
    for row in conn.execute("PRAGMA database_list"):
        if row["name"] == "main":
            return Path(row["file"]) if row["file"] else None
    return None


def _decode_key(raw: bytes) -> bytes:
    try:
        key = base64.b64decode(raw.strip(), validate=True)
    except (binascii.Error, ValueError):
        key = b""
    if len(key) != 32:
        raise SecretError(f"El archivo de clave «{KEY_FILE}» está dañado: no se puede descifrar lo guardado.")
    return key


def _load_or_create(path: Path) -> bytes:
    for attempt in range(5):
        try:
            return _decode_key(path.read_bytes())
        except FileNotFoundError:
            pass
        except SecretError:
            if attempt == 4:
                raise
            time.sleep(0.05)  # otro proceso puede estar escribiéndolo justo ahora
            continue
        key = secrets.token_bytes(32)
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            continue
        with os.fdopen(fd, "wb") as handle:
            handle.write(base64.b64encode(key) + b"\n")
        log.info("Se creó la clave de cifrado de credenciales: %s", path)
        return key
    raise SecretError(f"No se pudo leer ni crear la clave de cifrado «{path}».")


def _key_for(conn: sqlite3.Connection) -> bytes:
    env = os.environ.get(ENV_KEY, "").strip()
    if env:
        if len(env) < MIN_ENV_KEY:
            raise SecretError(f"{ENV_KEY} debe tener al menos {MIN_ENV_KEY} caracteres.")
        return hashlib.sha256(env.encode("utf-8")).digest()
    db_file = _db_file(conn)
    if db_file is None:
        return _MEMORY_KEY
    path = db_file.resolve().parent / KEY_FILE
    with _lock:
        key = _keys.get(str(path))
        if key is None:
            key = _keys[str(path)] = _load_or_create(path)
        return key


# ----- Cifrar y descifrar -------------------------------------------------------------------------------

def seal(conn: sqlite3.Connection, name: str, plain: str) -> str:
    """El valor listo para guardar. Un valor vacío se guarda vacío (significa «sin credencial»)."""
    if not plain:
        return ""
    nonce = secrets.token_bytes(12)
    data = _aesgcm(_key_for(conn)).encrypt(nonce, plain.encode("utf-8"), name.encode("utf-8"))
    return PREFIX + base64.urlsafe_b64encode(nonce + data).decode("ascii")


def unseal(conn: sqlite3.Connection, name: str, stored: str) -> str:
    """El valor en claro. Sin cifrar (versión anterior) se devuelve tal cual; si no se puede descifrar, vacío."""
    if not stored.startswith(PREFIX):
        return stored
    try:
        raw = base64.urlsafe_b64decode(stored[len(PREFIX):].encode("ascii"))
        if len(raw) < 12 + 16:
            raise ValueError("demasiado corto")
        return _aesgcm(_key_for(conn)).decrypt(raw[:12], raw[12:], name.encode("utf-8")).decode("utf-8")
    except SecretError as exc:
        log.error("No se puede leer «%s»: %s", name, exc)
    except Exception:  # etiqueta que no cuadra (clave distinta o dato alterado), base64 roto, etc.
        log.warning(
            "«%s» está cifrado con otra clave o fue alterado: se ignora. Vuelve a escribirlo en Ajustes "
            "(¿se movió la base de datos sin el archivo %s o sin %s?).",
            name, KEY_FILE, ENV_KEY,
        )
    return ""


# ----- app_settings -------------------------------------------------------------------------------------

def get_setting(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (key,)).fetchone()
    if row is None:
        return default
    return unseal(conn, key, row["value"]) if key in SECRET_SETTINGS else row["value"]


def set_setting(conn: sqlite3.Connection, key: str, value: str) -> None:
    if key in SECRET_SETTINGS:
        value = seal(conn, key, value)
    conn.execute(
        "INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def migrate(conn: sqlite3.Connection) -> bool:
    """Cifra las credenciales que una versión anterior guardó en claro. True si cambió alguna."""
    changed = False
    for name in sorted(SECRET_SETTINGS):
        row = conn.execute("SELECT value FROM app_settings WHERE key = ?", (name,)).fetchone()
        if row is None or not row["value"] or row["value"].startswith(PREFIX):
            continue
        if not changed:
            conn.execute("PRAGMA secure_delete = ON")  # que el valor viejo no quede en la página liberada
        conn.execute("UPDATE app_settings SET value = ? WHERE key = ?", (seal(conn, name, row["value"]), name))
        changed = True
        log.info("«%s» se guardaba sin cifrar: ahora está cifrado.", name)
    return changed
