"""Tests del control de acceso: sin sesión solo se ve la página de acceso. Ejecutar desde web/:  python -m pytest"""

from urllib.parse import quote

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app

USER = {"email": "ana@example.com", "name": "Ana", "password": "correct-horse-1"}


@pytest.fixture()
def app(tmp_path):
    return create_app(
        Settings(
            db_path=tmp_path / "test.db",
            session_days=14,
            cookie_secure=False,
            min_password_length=8,
            login_max_attempts=5,
            login_window_seconds=300,
            files_path=tmp_path / "qr",
        )
    )


@pytest.fixture()
def guest(app):
    return TestClient(app, follow_redirects=False)


@pytest.fixture()
def member(app):
    client = TestClient(app, follow_redirects=False)
    assert client.post("/api/auth/register", json=USER).status_code == 201
    return client


PAGES = ["/", "/index.html", "/png-a-ico/", "/png-a-ico/index.html", "/lector/", "/codigo-de-barras/", "/ajustes/"]
ASSETS = [
    "/js/app.js",
    "/js/qr.js",
    "/js/masivo.js",
    "/js/dinamico.js",
    "/js/auth.js",
    "/js/ico.js",
    "/js/zip.js",
    "/js/pdf.js",
    "/js/png-a-ico.js",
    "/js/lector.js",
    "/js/barras.js",
    "/js/ajustes.js",
    "/js/personalizacion.js",
    "/js/acceso-imagen.js",
    "/js/ajustes-migracion.js",
    "/js/admin-link.js",
    "/vendor/qr-code-styling.js",
    "/vendor/jsQR.js",
    "/vendor/JsBarcode.all.min.js",
]
PUBLIC = ["/entrar/", "/entrar/index.html", "/css/styles.css", "/js/entrar.js", "/js/version.js", "/js/tema.js", "/restablecer/", "/js/restablecer.js", "/js/migracion.js", "/api/auth/options", "/healthz"]


# ----- Sin sesión ---------------------------------------------------------------


@pytest.mark.parametrize("path", PAGES)
def test_pages_redirect_to_login(guest, path):
    res = guest.get(path, headers={"Accept": "text/html"})
    assert res.status_code == 303
    assert res.headers["location"] == f"/entrar/?next={quote(path, safe='')}"


def test_redirect_keeps_the_query_string(guest):
    res = guest.get("/?tipo=wifi", headers={"Accept": "text/html"})
    assert res.headers["location"] == "/entrar/?next=%2F%3Ftipo%3Dwifi"


def test_directory_without_slash_also_redirects_to_login(guest):
    res = guest.get("/png-a-ico", headers={"Accept": "text/html"})
    assert res.status_code == 303
    assert res.headers["location"].startswith("/entrar/?next=")


@pytest.mark.parametrize("path", ASSETS)
def test_assets_are_not_served_without_session(guest, path):
    res = guest.get(path)
    assert res.status_code == 401
    assert "function" not in res.text and "import " not in res.text  # ni una línea de código


def test_unknown_paths_do_not_reveal_whether_they_exist(guest):
    # Sin sesión todo da lo mismo (no se puede explorar el sitio).
    assert guest.get("/no-existe.js").status_code == 401
    assert guest.get("/no-existe/", headers={"Accept": "text/html"}).status_code == 303


@pytest.mark.parametrize("path", ["/entrar/../js/app.js", "/entrar/%2e%2e/js/app.js", "/css/styles.css/", "/CSS/styles.css"])
def test_public_list_cannot_be_bypassed_with_tricky_paths(guest, path):
    res = guest.get(path)
    assert res.status_code in {303, 401, 404}
    assert "QRCodeStyling" not in res.text and "composeFrame" not in res.text


def test_api_requires_login_but_auth_endpoints_are_open(guest):
    assert guest.get("/api/qr/folders").status_code == 401
    assert guest.get("/api/otra-cosa").status_code == 401
    assert guest.get("/api/auth/me").json() == {"user": None}
    assert guest.post("/api/auth/login", json={"email": "x@y.zz", "password": "mala-clave"}).status_code == 401


@pytest.mark.parametrize("path", PUBLIC)
def test_login_page_and_its_files_are_public(guest, path):
    assert guest.get(path).status_code == 200


def test_login_page_is_the_only_html_without_session(guest):
    html = guest.get("/entrar/").text
    assert "Iniciar sesión" in html
    assert "composeFrame" not in html
    assert "/js/app.js" not in html  # la página de acceso no carga el generador


def test_security_headers_also_apply_to_rejections(guest):
    for res in (guest.get("/", headers={"Accept": "text/html"}), guest.get("/js/app.js")):
        assert "default-src 'self'" in res.headers["content-security-policy"]
        assert res.headers["x-content-type-options"] == "nosniff"
        assert res.headers["cache-control"] == "no-cache"


# ----- Con sesión ---------------------------------------------------------------------------------


@pytest.mark.parametrize("path", PAGES[:2] + PAGES[2:] + ASSETS + PUBLIC)
def test_everything_is_available_after_login(member, path):
    assert member.get(path).status_code == 200


def test_main_page_content_after_login(member):
    assert "Generador de códigos QR" in member.get("/").text


def test_logout_closes_the_whole_site(member):
    assert member.get("/js/app.js").status_code == 200
    assert member.post("/api/auth/logout").status_code == 200
    assert member.get("/js/app.js").status_code == 401
    assert member.get("/", headers={"Accept": "text/html"}).status_code == 303


def test_a_fake_or_expired_session_gets_nothing(guest):
    guest.cookies.set("session", "token-inventado")
    assert guest.get("/js/app.js").status_code == 401
    assert guest.get("/", headers={"Accept": "text/html"}).status_code == 303
    assert guest.get("/api/qr/folders").status_code == 401


def test_cache_is_revalidated_for_pages_and_never_stored_for_api(member):
    assert member.get("/").headers["cache-control"] == "no-cache"
    assert member.get("/api/auth/me").headers["cache-control"] == "no-store"
