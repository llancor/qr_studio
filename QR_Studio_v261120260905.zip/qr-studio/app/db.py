"""Acceso a SQLite: esquema y conexión."""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT    NOT NULL UNIQUE,
    name          TEXT    NOT NULL,
    password_hash TEXT    NOT NULL,
    created_at    TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT    PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT    NOT NULL,
    expires_at TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_user    ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at);

-- QR dinámicos (función opcional): el QR apunta a /q/<code> y el destino se puede cambiar.
CREATE TABLE IF NOT EXISTS dynamic_qr (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code         TEXT    NOT NULL UNIQUE,
    name         TEXT    NOT NULL,
    target       TEXT    NOT NULL,
    active       INTEGER NOT NULL DEFAULT 1,
    scans        INTEGER NOT NULL DEFAULT 0,
    last_scan_at TEXT,
    created_at   TEXT    NOT NULL,
    updated_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_dynamic_user ON dynamic_qr(user_id);

CREATE TABLE IF NOT EXISTS dynamic_qr_daily (
    qr_id INTEGER NOT NULL REFERENCES dynamic_qr(id) ON DELETE CASCADE,
    day   TEXT    NOT NULL,
    count INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (qr_id, day)
);

-- Páginas dinámicas (función opcional): evento, empresa o carta, publicadas en /p/<code>.
-- «content» es JSON ya validado por app/pages.py; los archivos (imágenes, PDF) viven en disco.
CREATE TABLE IF NOT EXISTS pages (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code         TEXT    NOT NULL UNIQUE,
    template     TEXT    NOT NULL,
    name         TEXT    NOT NULL,
    content      TEXT    NOT NULL,
    active       INTEGER NOT NULL DEFAULT 1,
    expires_at   TEXT,
    views        INTEGER NOT NULL DEFAULT 0,
    last_view_at TEXT,
    created_at   TEXT    NOT NULL,
    updated_at   TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pages_user ON pages(user_id);

CREATE TABLE IF NOT EXISTS pages_daily (
    page_id INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    day     TEXT    NOT NULL,
    count   INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (page_id, day)
);

CREATE TABLE IF NOT EXISTS pages_clicks (
    page_id INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    key     TEXT    NOT NULL,
    count   INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (page_id, key)
);

CREATE TABLE IF NOT EXISTS page_assets (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    page_id    INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token      TEXT    NOT NULL UNIQUE,
    kind       TEXT    NOT NULL,
    mime       TEXT    NOT NULL,
    filename   TEXT    NOT NULL,
    bytes      INTEGER NOT NULL,
    created_at TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_assets_page ON page_assets(page_id);

-- Ajustes del sitio que cambia el administrador (p. ej. si se permite crear cuentas o el servidor SMTP).
CREATE TABLE IF NOT EXISTS app_settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Personalización de cada usuario: tema, color, estilo (JSON validado por app/prefs.py) e imagen de portada.
-- prefs NULL = nunca guardó nada. cover_v sube con cada cambio de la portada (va en la URL para el caché).
CREATE TABLE IF NOT EXISTS user_prefs (
    user_id    INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    prefs      TEXT,
    cover      BLOB,
    cover_mime TEXT,
    cover_v    INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT    NOT NULL
);

-- Imagen de fondo de la página de acceso (del sitio, la elige el administrador y es pública: se ve sin sesión).
-- Una sola fila (id = 1). version sube con cada cambio y va en la URL para el caché; settings es JSON validado.
CREATE TABLE IF NOT EXISTS login_image (
    id         INTEGER PRIMARY KEY CHECK (id = 1),
    image      BLOB,
    mime       TEXT,
    version    INTEGER NOT NULL DEFAULT 0,
    settings   TEXT,
    updated_at TEXT    NOT NULL
);

-- Logo del sitio (lo elige el administrador y es público: sale en la cabecera y en la página de acceso).
-- El nombre del sitio y los colores de la página de acceso van en app_settings (ver app/marca.py).
CREATE TABLE IF NOT EXISTS site_logo (
    id         INTEGER PRIMARY KEY CHECK (id = 1),
    image      BLOB,
    mime       TEXT,
    version    INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT    NOT NULL
);

-- Enlaces para recuperar la contraseña por correo. Solo se guarda el hash del token; caducan y se usan una vez.
CREATE TABLE IF NOT EXISTS password_resets (
    token_hash TEXT    PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT    NOT NULL,
    expires_at TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_resets_user ON password_resets(user_id);
"""


def _migrate(conn: sqlite3.Connection) -> None:
    """Pone al día bases creadas con versiones anteriores (sin roles ni cuentas desactivables)."""
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(users)")}
    if "role" not in columns:
        conn.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'")
    if "active" not in columns:
        conn.execute("ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
    # Las instalaciones anteriores no tenían administrador: el primer usuario creado pasa a serlo.
    if not conn.execute("SELECT 1 FROM users WHERE role = 'admin'").fetchone():
        conn.execute("UPDATE users SET role = 'admin' WHERE id = (SELECT MIN(id) FROM users)")


def init_db(db_path: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with connect(db_path) as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executescript(SCHEMA)
        _migrate(conn)


@contextmanager
def connect(db_path: Path) -> Iterator[sqlite3.Connection]:
    """Conexión por petición; confirma al salir y revierte si hay excepción."""
    conn = sqlite3.connect(db_path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
