// Página de acceso: inicio de sesión y registro. Es lo único que se ve sin sesión.
// Al entrar, lleva a la página que se pidió (?next=) o a la principal.

import { leerArchivo, enviar, pintarLista } from './migracion.js';

const $ = (id) => document.getElementById(id);

/** Solo se admiten rutas de este mismo sitio (evita redirigir a otro dominio con ?next=). */
export function safeNext(raw) {
  if (typeof raw !== 'string' || !raw.startsWith('/') || raw.startsWith('//') || raw.startsWith('/\\')) return '/';
  if (raw === '/entrar' || raw.startsWith('/entrar/') || raw.startsWith('/entrar?')) return '/';
  try {
    const url = new URL(raw, window.location.origin);
    if (url.origin !== window.location.origin) return '/';
    return url.pathname + url.search + url.hash;
  } catch {
    return '/';
  }
}

const destination = () => safeNext(new URLSearchParams(window.location.search).get('next'));

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* respuesta sin JSON */
  }
  if (!res.ok) throw new Error(typeof data?.detail === 'string' ? data.detail : 'Ocurrió un error inesperado.');
  return data;
}

const form = $('login-form');
const errorEl = $('login-error');
const submit = $('login-submit');
let mode = 'login';

function setError(message) {
  errorEl.textContent = message || '';
  errorEl.hidden = !message;
}

function setMode(next) {
  mode = next;
  const register = next === 'register';
  $('login-title').textContent = register ? 'Crear cuenta' : 'Iniciar sesión';
  document.title = `${register ? 'Crear cuenta' : 'Entrar'} – QR Studio`;
  $('login-name-field').hidden = !register;
  $('login-password-hint').hidden = !register;
  $('login-password').autocomplete = register ? 'new-password' : 'current-password';
  submit.textContent = register ? 'Crear cuenta' : 'Entrar';
  $('login-switch-text').textContent = register ? '¿Ya tienes cuenta?' : '¿No tienes cuenta?';
  $('login-switch').textContent = register ? 'Inicia sesión' : 'Regístrate';
  $('login-forgot-row').hidden = register || !recoveryEnabled;
  setError('');
  (register ? $('login-name') : $('login-email')).focus();
}

$('login-switch').addEventListener('click', () => setMode(mode === 'login' ? 'register' : 'login'));

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  setError('');
  const email = $('login-email').value.trim();
  const password = $('login-password').value;
  const name = $('login-name').value.trim();
  if (!email || !password || (mode === 'register' && !name)) {
    setError('Completa todos los campos.');
    return;
  }
  submit.disabled = true;
  try {
    const payload = mode === 'register' ? { email, name, password } : { email, password };
    await api(`/api/auth/${mode}`, { method: 'POST', body: payload });
    // El aspecto es de cada cuenta: la copia de este navegador puede ser de otra persona. La página siguiente
    // pedirá al servidor el de esta cuenta.
    window.QRTema?.olvidar();
    window.location.replace(destination());
  } catch (err) {
    setError(err.message);
    submit.disabled = false;
  }
});

// ----- Importar una migración al instalar -----------------------------------------------------------------
// Solo se ofrece mientras no hay ninguna cuenta (el servidor también lo exige). Primero se enseña qué trae el
// archivo (sin cambiar nada) y solo se aplica al confirmar.

// El archivo va cifrado: hace falta la contraseña con la que se exportó (no se guarda en ningún sitio).

let migracionArchivo = null; // el archivo elegido, ya leído
let migracionClave = ''; // la contraseña que abrió la vista previa, para aplicar

function setMigError(message) {
  $('mg-first-error').textContent = message || '';
  $('mg-first-error').hidden = !message;
}

$('mg-first-open').addEventListener('click', () => {
  $('mg-first-box').hidden = !$('mg-first-box').hidden;
});

$('mg-first-file').addEventListener('change', async (event) => {
  const input = event.target;
  const file = input.files?.[0];
  setMigError('');
  $('mg-first-preview').hidden = true;
  $('mg-first-pass-row').hidden = true;
  if (!file) return;
  try {
    migracionArchivo = await leerArchivo(file);
    $('mg-first-pass-row').hidden = false;
    $('mg-first-pass').focus();
  } catch (err) {
    migracionArchivo = null;
    input.value = '';
    setMigError(err.message);
  }
});

async function verQueTrae() {
  setMigError('');
  $('mg-first-preview').hidden = true;
  const password = $('mg-first-pass').value;
  if (!password) {
    setMigError('Escribe la contraseña de la migración.');
    $('mg-first-pass').focus();
    return;
  }
  $('mg-first-check').disabled = true;
  try {
    const resumen = await enviar('/api/auth/migration/import', migracionArchivo, password, true); // vista previa
    migracionClave = password;
    $('mg-first-apply').disabled = !pintarLista($('mg-first-list'), resumen);
    $('mg-first-preview').hidden = false;
  } catch (err) {
    setMigError(err.message); // p. ej. contraseña incorrecta: se queda el campo para probar otra vez
    $('mg-first-pass').select();
  } finally {
    $('mg-first-check').disabled = false;
  }
}

$('mg-first-check').addEventListener('click', verQueTrae);
$('mg-first-pass').addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    verQueTrae();
  }
});

$('mg-first-apply').addEventListener('click', async () => {
  setMigError('');
  $('mg-first-apply').disabled = true;
  try {
    const resultado = await enviar('/api/auth/migration/import', migracionArchivo, migracionClave, false);
    $('mg-first-preview').hidden = true;
    $('mg-first-ok').textContent =
      resultado.usersAdded > 0
        ? 'Listo: se importó la migración. Entra con una de las cuentas del archivo.'
        : 'Listo: se importó la configuración. Crea ahora la cuenta del administrador.';
    $('mg-first-ok').hidden = false;
    setTimeout(() => window.location.reload(), 1800); // la página vuelve a pedir el estado y ya refleja lo importado
  } catch (err) {
    setMigError(err.message);
    $('mg-first-apply').disabled = false;
  }
});

// ----- Recuperar la contraseña por correo ---------------------------------------------------------
// El servidor responde igual exista o no la cuenta, así que aquí tampoco se dice si el correo estaba registrado.

const forgotForm = $('forgot-form');
let recoveryEnabled = false;
let savedLead = '';

function setForgotError(message) {
  $('forgot-error').textContent = message || '';
  $('forgot-error').hidden = !message;
}

function setForgot(on) {
  const lead = $('login-lead');
  if (on) {
    savedLead = lead.textContent;
    $('login-title').textContent = 'Recuperar contraseña';
    document.title = 'Recuperar contraseña – QR Studio';
    lead.textContent = 'Escribe el correo de tu cuenta y te enviaremos un enlace para elegir una contraseña nueva.';
    $('forgot-email').value = $('login-email').value;
  } else {
    lead.textContent = savedLead || lead.textContent;
    setMode('login'); // restaura el título y el resto del formulario de entrada
  }
  form.hidden = on;
  forgotForm.hidden = !on;
  $('login-forgot-row').hidden = on || !recoveryEnabled;
  $('login-switch-row').hidden = on || !registrationOpen;
  setForgotError('');
  $('forgot-done').hidden = true;
  $('forgot-submit').disabled = false;
  if (on) $('forgot-email').focus();
}

$('login-forgot').addEventListener('click', () => setForgot(true));
$('forgot-back').addEventListener('click', () => setForgot(false));

forgotForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  setForgotError('');
  const email = $('forgot-email').value.trim();
  if (!email) {
    setForgotError('Escribe tu correo.');
    return;
  }
  $('forgot-submit').disabled = true;
  try {
    await api('/api/auth/forgot', { method: 'POST', body: { email } });
    $('forgot-done').textContent =
      'Si ese correo tiene una cuenta, te enviamos un enlace para elegir una contraseña nueva. Revisa tu bandeja de entrada y el correo no deseado. El enlace caduca en 60 minutos.';
    $('forgot-done').hidden = false; // el botón queda desactivado para no repetir el envío
  } catch (err) {
    setForgotError(err.message);
    $('forgot-submit').disabled = false;
  }
});

$('year').textContent = new Date().getFullYear();

// ¿Se pueden crear cuentas? Lo decide el administrador (Ajustes). Si no, no se ofrece «Regístrate».
// Sin ninguna cuenta todavía, la primera que se cree será la del administrador.
let registrationOpen = true;
api('/api/auth/options')
  .then((options) => {
    registrationOpen = options.registrationOpen;
    // Solo se ofrece recuperar la contraseña si el administrador configuró el servidor SMTP.
    recoveryEnabled = Boolean(options.recoveryEnabled);
    $('login-forgot-row').hidden = !recoveryEnabled || mode !== 'login';
    const lead = $('login-lead');
    if (options.firstUser) {
      lead.textContent = 'Aún no hay ninguna cuenta. La primera que crees será la del administrador.';
      setMode('register');
      $('mg-first').hidden = false; // también se puede empezar importando una migración
    } else if (!registrationOpen) {
      lead.textContent = 'Entra con tu cuenta. La creación de cuentas está desactivada: si necesitas una, pídela al administrador.';
      $('login-switch-row').hidden = true;
      if (mode === 'register') setMode('login');
    }
  })
  .catch(() => {
    /* sin conexión: se deja el formulario como está */
  });

if (new URLSearchParams(window.location.search).get('modo') === 'registro') setMode('register');

// Si ya hay una sesión válida, no tiene sentido mostrar el formulario.
api('/api/auth/me')
  .then((data) => {
    if (data.user) window.location.replace(destination());
  })
  .catch(() => {
    /* sin conexión: se deja el formulario */
  });
